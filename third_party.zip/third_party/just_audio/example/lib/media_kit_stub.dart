void initMediaKit() {}
