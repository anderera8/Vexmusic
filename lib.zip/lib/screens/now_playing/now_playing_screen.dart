import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/now_playing_palette_service.dart';
import '../../services/player_skin_service.dart';
import '../../widgets/model_sheet.dart';
import '../../widgets/toast.dart';
import '../../widgets/track_art_widget.dart';
import '../editor/tag_editor_screen.dart';
import 'widgets/album_art_section.dart';
import 'widgets/embedded_lyrics_panel.dart';
import 'widgets/now_playing_header.dart';
import 'widgets/secondary_controls.dart';
import 'widgets/seek_bar.dart';
import 'widgets/sleep_timer_badge.dart';
import 'widgets/track_info_section.dart';
import 'widgets/transport_controls.dart';
import 'widgets/up_next_button.dart';

class NowPlayingScreen extends StatefulWidget {
  const NowPlayingScreen({super.key});

  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _artAnimation;
  bool _wasPlaying = false;
  bool _showLyrics = false;
  String _visibleTrackIdentity = '';
  String _lyricsTrackIdentity = '';
  Color? _adaptiveColor;
  int _paletteGeneration = 0;
  PlayerSkinSettings _skin = const PlayerSkinSettings();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _artAnimation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );

    _loadSkinSettings();
  }

  Future<void> _loadSkinSettings() async {
    final settings = await PlayerSkinService.getSettings();

    if (mounted) {
      setState(() {
        _skin = settings;
        if (!settings.adaptiveColors) {
          _adaptiveColor = null;
        }
        _visibleTrackIdentity = '';
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadSkinSettings();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _artAnimation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Consumer<MusicProvider>(
          builder: (context, music, _) {
            if (music.isPlaying && !_wasPlaying) {
              _artAnimation.repeat(reverse: true);
            } else if (!music.isPlaying && _wasPlaying) {
              _artAnimation.stop();
            }

            _wasPlaying = music.isPlaying;

            final hasActiveTrack = music.hasStartedPlayback && music.hasTracks;
            final track = hasActiveTrack
                ? music.currentTrack
                : const Track(
                    id: 0,
                    mediaStoreId: 0,
                    stableKey: '',
                    title: 'Nothing playing',
                    artist: 'Pick a track from your library',
                    duration: 0,
                    art: '\u{1F3B5}',
                    grad: 'grad-a',
                    genre: '',
                  );

            final identity = _trackIdentity(track);
            if (_visibleTrackIdentity != identity) {
              _visibleTrackIdentity = identity;
              final trackChanged = _lyricsTrackIdentity != identity;
              _lyricsTrackIdentity = identity;

              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!mounted) return;
                if (_showLyrics && trackChanged) {
                  setState(() => _showLyrics = false);
                }
                unawaited(
                  _refreshAdaptiveColor(
                    track: track,
                    hasActiveTrack: hasActiveTrack,
                    brightness: theme.currentTheme.brightness,
                  ),
                );
              });
            }

            final lyricsFocusMode = _showLyrics && _skin.lyricsFocusMode;
            final accent = _effectiveAccent(theme);

            return Stack(
              children: [
                _buildPlayerBackground(
                  theme: theme,
                  track: track,
                  hasActiveTrack: hasActiveTrack,
                  accent: accent,
                ),
                Column(
                  children: [
                    if (lyricsFocusMode)
                      _buildLyricsFocusHeader(
                        theme: theme,
                        track: track,
                      )
                    else
                      NowPlayingHeader(
                        hasActiveTrack: hasActiveTrack,
                        skin: _skin,
                        accent: accent,
                        onOptionsTap: hasActiveTrack
                            ? () => _showTrackOptions(context, music)
                            : null,
                      ),
                    if (music.isRecoveringPlayback ||
                        music.lastPlaybackFailure != null)
                      _buildPlaybackStatusBanner(
                        context: context,
                        music: music,
                        theme: theme,
                      ),
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 320),
                        switchInCurve: Curves.easeOutCubic,
                        switchOutCurve: Curves.easeInCubic,
                        child: _showLyrics
                            ? EmbeddedLyricsPanel(
                                key: ValueKey('lyrics_${track.id}'),
                                trackId: track.id,
                                focusMode: lyricsFocusMode,
                                accent: accent,
                              )
                            : SingleChildScrollView(
                                key: ValueKey(
                                  'player_${track.id}_${_skin.layoutStyle}',
                                ),
                                child: _buildPlayerContent(
                                  track: track,
                                  hasActiveTrack: hasActiveTrack,
                                  accent: accent,
                                ),
                              ),
                      ),
                    ),
                    if (!lyricsFocusMode &&
                        (_showLyrics || _skin.showSeekBar))
                      SeekBar(accent: accent),
                    if (!lyricsFocusMode)
                      TransportControls(
                        hasActiveTrack: hasActiveTrack,
                        accent: accent,
                      ),
                    if (!lyricsFocusMode)
                      SecondaryControls(
                        hasActiveTrack: hasActiveTrack,
                        isLyricsVisible: _showLyrics,
                        onEqTap: _handleEqTap,
                        onSpeedTap: () => _showSpeedPicker(context, music),
                        onAddToTap: hasActiveTrack
                            ? () => _showAddToPlaylist(context, music)
                            : null,
                        onLyricsTap: hasActiveTrack
                            ? () => _handleLyricsTap(music)
                            : null,
                        accent: accent,
                      ),
                    if (!lyricsFocusMode && _skin.showQueueInfo)
                      UpNextButton(accent: accent),
                  ],
                ),
                SleepTimerBadge(accent: accent),
              ],
            );
          },
        ),
      ),
    );
  }

  String _trackIdentity(Track track) {
    final stableKey = track.stableKey.trim().toLowerCase();
    if (stableKey.isNotEmpty) return stableKey;
    return '${track.volumeName}:${track.mediaStoreId}:${track.id}';
  }

  Color _effectiveAccent(ThemeProvider theme) {
    if (!_skin.adaptiveColors) return theme.accent;
    return _adaptiveColor ?? theme.accent;
  }

  Future<void> _refreshAdaptiveColor({
    required Track track,
    required bool hasActiveTrack,
    required Brightness brightness,
  }) async {
    final generation = ++_paletteGeneration;

    if (!hasActiveTrack || !_skin.adaptiveColors) {
      if (mounted && generation == _paletteGeneration) {
        setState(() => _adaptiveColor = null);
      }
      return;
    }

    final color = await NowPlayingPaletteService.colorForTrack(
      track,
      brightness: brightness,
    );

    if (!mounted || generation != _paletteGeneration) return;
    setState(() => _adaptiveColor = color);
  }

  /// Opening the equalizer shows an interstitial first (subject to the
  /// frequency cap in [InterstitialAdController]) — it's free to use, no
  /// unlock required. Every control inside the equalizer screen (bands,
  /// bass boost, volume boost, virtualizer) is free to use once open.
  Future<void> _handleEqTap() async {
    unawaited(
      InterstitialAdController.maybeShow(InterstitialTrigger.equalizerOpened),
    );
    if (!mounted) return;
    Navigator.pushNamed(context, '/equalizer');
  }

  /// Closing lyrics is always free and never shows an ad. Opening them is
  /// free too, but shows an interstitial first (subject to the frequency
  /// cap).
  Future<void> _handleLyricsTap(MusicProvider music) async {
    if (_showLyrics) {
      _setLyricsVisible(false, music);
      return;
    }
    unawaited(
      InterstitialAdController.maybeShow(InterstitialTrigger.lyricsOpened),
    );
    if (!mounted) return;
    _setLyricsVisible(true, music);
  }

  void _setLyricsVisible(bool visible, MusicProvider music) {
    if (_showLyrics == visible) return;

    setState(() => _showLyrics = visible);

    if (!visible) {
      unawaited(_loadSkinSettings());
      return;
    }

    if (music.currentLyrics == null && !music.isLyricsLoading) {
      music.retryLyrics();
    }
  }

  Widget _buildLyricsFocusHeader({
    required ThemeProvider theme,
    required Track track,
  }) {
    final accent = _effectiveAccent(theme);

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 2),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Exit lyrics focus',
            onPressed: () => setState(() => _showLyrics = false),
            icon: Icon(Icons.keyboard_arrow_down_rounded, color: theme.text),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  track.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  'LYRICS FOCUS',
                  style: TextStyle(
                    color: accent,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _buildPlaybackStatusBanner({
    required BuildContext context,
    required MusicProvider music,
    required ThemeProvider theme,
  }) {
    final failure = music.lastPlaybackFailure;
    final recovering = music.isRecoveringPlayback;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Material(
        color: theme.surface.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: failure == null
              ? null
              : () => VibesToast.showPlaybackFailure(context, failure),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                if (recovering)
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: theme.accent,
                    ),
                  )
                else
                  Icon(
                    Icons.error_outline_rounded,
                    size: 20,
                    color: theme.accent,
                  ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    recovering
                        ? 'Skipping an unavailable or unplayable track…'
                        : failure?.message ?? 'Playback could not continue.',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.text,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                if (!recovering && failure != null)
                  IconButton(
                    tooltip: 'Dismiss playback error',
                    onPressed: music.clearPlaybackFailure,
                    icon: Icon(
                      Icons.close_rounded,
                      color: theme.muted,
                      size: 18,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlayerContent({
    required Track track,
    required bool hasActiveTrack,
    required Color accent,
  }) {
    final children = <Widget>[];

    switch (_skin.layoutStyle) {
      case 'minimal':
        if (_skin.showalbumArt) {
          children.add(
            AlbumArtSection(
              animation: _artAnimation,
              skin: _skin,
              accent: accent,
            ),
          );
        }
        children.add(
          TrackInfoSection(
            track: track,
            hasActiveTrack: hasActiveTrack,
          ),
        );
        children.add(const SizedBox(height: 8));
        break;

      case 'classic':
        children.add(const SizedBox(height: 8));
        children.add(
          TrackInfoSection(
            track: track,
            hasActiveTrack: hasActiveTrack,
          ),
        );
        if (_skin.showalbumArt) {
          children.add(
            AlbumArtSection(
              animation: _artAnimation,
              skin: _skin,
              accent: accent,
            ),
          );
        }
        break;

      case 'modern':
        children.add(const SizedBox(height: 8));
        if (_skin.showalbumArt) {
          children.add(
            AlbumArtSection(
              animation: _artAnimation,
              skin: _skin,
              accent: accent,
            ),
          );
        }
        children.add(
          TrackInfoSection(
            track: track,
            hasActiveTrack: hasActiveTrack,
          ),
        );
        children.add(const SizedBox(height: 18));
        break;

      case 'default':
      default:
        if (_skin.showalbumArt) {
          children.add(
            AlbumArtSection(
              animation: _artAnimation,
              skin: _skin,
              accent: accent,
            ),
          );
        }
        children.add(
          TrackInfoSection(
            track: track,
            hasActiveTrack: hasActiveTrack,
          ),
        );
        break;
    }

    return Column(children: children);
  }

  Widget _buildPlayerBackground({
    required ThemeProvider theme,
    required Track track,
    required bool hasActiveTrack,
    required Color accent,
  }) {
    switch (_skin.backgroundStyle) {
      case 'solid':
        return Stack(
          children: [
            Positioned.fill(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 600),
                color: theme.bg,
              ),
            ),
            _accentWash(theme, accent: accent, strength: 0.45),
          ],
        );

      case 'blurArt':
        return Stack(
          children: [
            Positioned.fill(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 600),
                color: theme.bg,
              ),
            ),
            if (hasActiveTrack)
              Positioned.fill(
                child: Opacity(
                  opacity: 0.42,
                  child: ImageFiltered(
                    imageFilter: ImageFilter.blur(
                      sigmaX: 36,
                      sigmaY: 36,
                    ),
                    child: Transform.scale(
                      scale: 1.24,
                      child: Center(
                        child: TrackArtWidget(
                          key: ValueKey(
                            'now-playing-bg-art-'
                            '${track.id}-'
                            '${track.mediaStoreId}-'
                            '${track.volumeName}-'
                            '${track.stableKey}-'
                            '${track.albumId ?? 0}-'
                            '${track.artPath ?? ''}',
                          ),
                          artPath: track.artPath,
                          albumId: track.albumId,
                          mediaStoreId: track.mediaStoreId,
                          volumeName: track.volumeName,
                          stableKey: track.stableKey,
                          trackId: track.id,
                          size: MediaQuery.sizeOf(context).longestSide,
                          borderRadius: 0,
                          fit: BoxFit.cover,
                          defaultIconColor: accent,
                          gaplessPlayback: false,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      theme.bg.withValues(alpha: 0.20),
                      theme.bg.withValues(alpha: 0.68),
                      theme.bg,
                    ],
                    stops: const [0, 0.56, 1],
                  ),
                ),
              ),
            ),
            _accentWash(theme, accent: accent, strength: 0.7),
          ],
        );

      case 'gradient':
      default:
        return Stack(
          children: [
            Positioned.fill(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 900),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.lerp(theme.surface, accent, 0.22)!,
                      Color.lerp(theme.bg, accent, 0.06)!,
                      theme.bg,
                    ],
                    stops: const [0, 0.34, 1],
                  ),
                ),
              ),
            ),
            _accentWash(theme, accent: accent, strength: 1),
          ],
        );
    }
  }

  Widget _accentWash(
    ThemeProvider theme, {
    required Color accent,
    required double strength,
  }) {
    return Positioned.fill(
      child: IgnorePointer(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, -1.15),
              radius: 1.05,
              colors: [
                accent.withValues(alpha: 0.12 * strength),
                accent.withValues(alpha: 0.035 * strength),
                Colors.transparent,
              ],
              stops: const [0, 0.48, 1],
            ),
          ),
        ),
      ),
    );
  }

  // ── Modal dialogs ────────────────────────────────────────────────────────

  void _showSpeedPicker(BuildContext context, MusicProvider music) {
    final theme = context.read<ThemeProvider>();
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

    showModalSheet(
      context,
      title: 'Playback Speed',
      body: 'Current: ${music.playbackSpeed}x',
      actions: [ModalAction(label: 'Done', action: () {})],
      extra: Column(
        children: speeds.map((s) {
          final isActive = music.playbackSpeed == s;

          return GestureDetector(
            onTap: () {
              Navigator.pop(context);
              music.setPlaybackSpeed(s);
              VibesToast.show(context, 'Speed: ${s}x');
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: isActive
                    ? theme.accent.withValues(alpha: 0.12)
                    : theme.surface2,
                borderRadius: BorderRadius.circular(14),
                border: isActive
                    ? Border.all(color: theme.accent.withValues(alpha: 0.4))
                    : null,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      s == 1.0 ? 'Normal (1\u00D7)' : '$s\u00D7',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: isActive ? theme.accent : theme.text,
                      ),
                    ),
                  ),
                  if (isActive)
                    Icon(Icons.check_rounded, size: 18, color: theme.accent),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _showSleepTimerPicker(BuildContext context, MusicProvider music) {
    final theme = context.read<ThemeProvider>();
    const options = [
      'Off',
      '5 min',
      '10 min',
      '15 min',
      '30 min',
      '45 min',
      '1 hour',
    ];

    showModalSheet(
      context,
      title: 'Sleep Timer',
      body: music.sleepTimer == 'Off'
          ? 'Not set'
          : 'Pauses playback in: ${music.sleepTimer}',
      actions: [ModalAction(label: 'Done', action: () {})],
      extra: Column(
        children: options.map((option) {
          final isActive = music.sleepTimer == option;

          return GestureDetector(
            onTap: () {
              Navigator.pop(context);
              music.setSleepTimer(option);
              VibesToast.show(
                context,
                option == 'Off' ? 'Sleep timer off' : 'Sleep timer: $option',
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: isActive
                    ? theme.accent.withValues(alpha: 0.12)
                    : theme.surface2,
                borderRadius: BorderRadius.circular(14),
                border: isActive
                    ? Border.all(color: theme.accent.withValues(alpha: 0.4))
                    : null,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      option,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: isActive ? theme.accent : theme.text,
                      ),
                    ),
                  ),
                  if (isActive)
                    Icon(Icons.check_rounded, size: 18, color: theme.accent),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _showTrackOptions(BuildContext context, MusicProvider music) {
    showModalSheet(
      context,
      title: 'Track Options',
      body: '${music.currentTrack.title} \u00B7 ${music.currentTrack.artist}',
      actions: [ModalAction(label: 'Close', action: () {})],
      extra: Column(
        children: [
          _modalItem(context, Icons.info_outline_rounded, 'Track info', () {
            _showTrackInfo(context, music);
          }),
          _modalItem(context, Icons.edit_rounded, 'Tag Editor', () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TagEditorScreen(track: music.currentTrack),
              ),
            );
          }),
          _modalItem(context, Icons.bedtime_rounded, 'Sleep timer', () {
            _showSleepTimerPicker(context, music);
          }),
          _modalItem(context, Icons.brush_rounded, 'Player Skin', () {
            Navigator.of(context).pushNamed('/player-skins').then((_) {
              if (mounted) {
                _loadSkinSettings();
              }
            });
          }),
        ],
      ),
    );
  }

  void _showAddToPlaylist(BuildContext context, MusicProvider music) {
    final theme = context.read<ThemeProvider>();

    if (music.playlists.isEmpty) {
      final nameCtrl = TextEditingController();

      showModalSheet(
        context,
        title: 'Create Playlist',
        body: 'Name your new playlist:',
        actions: [
          ModalAction(label: 'Cancel', action: () {}),
          ModalAction(
            label: 'Create & Add',
            cls: 'primary',
            action: () async {
              final name = nameCtrl.text.trim();

              if (name.isEmpty) {
                if (context.mounted) {
                  VibesToast.show(context, 'Enter a name');
                }
                return;
              }

              await music.createPlaylist(name);

              if (!context.mounted) return;

              if (music.playlists.isNotEmpty) {
                final pl = music.playlists.last;
                await music.addTrackToPlaylist(pl.id, music.currentTrack.id);

                if (!context.mounted) return;

                VibesToast.show(context, 'Added to "$name"');
                unawaited(InterstitialAdController.maybeShow(
                  InterstitialTrigger.playlistAction,
                ));
              }

              if (!context.mounted) return;

              Navigator.pop(context);
            },
          ),
        ],
        extra: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            decoration: BoxDecoration(
              color: theme.surface2,
              borderRadius: BorderRadius.circular(14),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: TextField(
              controller: nameCtrl,
              autofocus: true,
              style: TextStyle(color: theme.text, fontSize: 15),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'My Playlist',
                hintStyle: TextStyle(color: theme.muted),
              ),
            ),
          ),
        ),
      );

      return;
    }

    showModalSheet(
      context,
      title: 'Add to Playlist',
      body: 'Select a playlist:',
      actions: [ModalAction(label: 'Cancel', action: () {})],
      extra: Column(
        children: music.playlists.map((pl) {
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Navigator.pop(context);
              music.addTrackToPlaylist(pl.id, music.currentTrack.id);
              VibesToast.show(context, 'Added to "${pl.name}"');
              InterstitialAdController.maybeShow(
                InterstitialTrigger.playlistAction,
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: theme.surface2,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Text(pl.art, style: const TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          pl.name,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: theme.text,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          '${pl.trackCount} track${pl.trackCount != 1 ? "s" : ""}',
                          style: TextStyle(fontSize: 11, color: theme.muted),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.add_rounded, size: 18, color: theme.accent),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void _showTrackInfo(BuildContext context, MusicProvider music) {
    final t = music.currentTrack;
    final theme = context.read<ThemeProvider>();

    showModalSheet(
      context,
      title: 'Track Info',
      body: '${t.art} ${t.title}',
      actions: [ModalAction(label: 'Close', action: () {})],
      extra: Column(
        children: [
          _infoRow(theme, 'Title', t.title),
          _infoRow(theme, 'Artist', t.artist),
          if (t.albumName != null && t.albumName!.isNotEmpty)
            _infoRow(theme, 'album', t.albumName!),
          _infoRow(theme, 'Duration', t.formattedDuration),
          if (t.filePath != null && t.filePath!.isNotEmpty)
            _infoRow(theme, 'Path', t.filePath!, mono: true),
          _infoRow(theme, 'ID', '#${t.id}'),
        ],
      ),
    );
  }

  Widget _infoRow(
    ThemeProvider theme,
    String label,
    String value, {
    bool mono = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 64,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: theme.muted,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 13, color: theme.text),
              overflow: TextOverflow.ellipsis,
              maxLines: mono ? 1 : 3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _modalItem(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap,
  ) {
    final theme = context.read<ThemeProvider>();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: theme.border)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 22, color: theme.accent),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: theme.text,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
