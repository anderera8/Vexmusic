// lib/screens/now_playing/widgets/sleep_timer_badge.dart
// ─────────────────────────────────────────────────────────────────────────────
// Sleep timer countdown badge — shown on the Now Playing screen when the
// sleep timer is active, with a live countdown.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';

class SleepTimerBadge extends StatelessWidget {
  final Color accent;

  const SleepTimerBadge({super.key, required this.accent});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();

    if (!music.sleepTimerActive) return const SizedBox.shrink();

    return Positioned(
      top: 60,
      right: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: theme.surface.withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: theme.border),
        ),
        child: ValueListenableBuilder<int>(
          valueListenable: music.sleepSecondsNotifier,
          builder: (_, seconds, __) {
            final minutes = seconds ~/ 60;
            final secs = (seconds % 60).toString().padLeft(2, '0');
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.timer, size: 14, color: accent),
                const SizedBox(width: 4),
                Text(
                  '$minutes:$secs',
                  style: TextStyle(color: theme.text, fontSize: 12),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
