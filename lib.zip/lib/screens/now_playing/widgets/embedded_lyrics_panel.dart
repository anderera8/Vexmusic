import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/lyric_theme_provider.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/lyric_theme_service.dart';
import '../../../services/lyrics_file_import_service.dart';
import '../../../services/lyrics_service.dart';
import 'karaoke_lyric_line.dart';

class EmbeddedLyricsPanel extends StatefulWidget {
  final int trackId;
  final bool focusMode;
  final VoidCallback? onClose;
  final Color? accent;

  const EmbeddedLyricsPanel({
    super.key,
    required this.trackId,
    this.focusMode = false,
    this.onClose,
    this.accent,
  });

  @override
  State<EmbeddedLyricsPanel> createState() => _EmbeddedLyricsPanelState();
}

class _EmbeddedLyricsPanelState extends State<EmbeddedLyricsPanel> {
  final ScrollController _scrollController = ScrollController();

  ValueNotifier<Duration>? _positionNotifier;
  int _activeIndex = -1;
  bool _autoScroll = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final notifier = context.read<MusicProvider>().positionNotifier;
    if (_positionNotifier == notifier) return;

    _positionNotifier?.removeListener(_onPositionChanged);
    _positionNotifier = notifier;
    _positionNotifier!.addListener(_onPositionChanged);
  }

  @override
  void didUpdateWidget(covariant EmbeddedLyricsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.trackId != widget.trackId) {
      _activeIndex = -1;
      _autoScroll = true;

      if (_scrollController.hasClients) {
        _scrollController.jumpTo(0);
      }
    }
  }

  @override
  void dispose() {
    _positionNotifier?.removeListener(_onPositionChanged);
    _scrollController.dispose();
    super.dispose();
  }

  void _onPositionChanged() {
    if (!mounted) return;

    final lyrics = context.read<MusicProvider>().currentLyrics;
    if (lyrics == null || !lyrics.isSynced) return;

    final index = lyrics.activeIndexAt(_positionNotifier!.value);
    if (index < 0 || index == _activeIndex) return;

    setState(() => _activeIndex = index);

    if (_autoScroll) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_scrollController.hasClients) return;

        final target = (index * 58.0 - 120).clamp(
          0.0,
          _scrollController.position.maxScrollExtent,
        );

        _scrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final appTheme = context.watch<ThemeProvider>();
    final lyricTheme = context.watch<LyricThemeProvider>().settings;
    final lyrics = music.currentLyrics;
    final accent = widget.accent ?? appTheme.accent;

    return Container(
      key: ValueKey('embedded_lyrics_${widget.trackId}'),
      margin: widget.focusMode
          ? const EdgeInsets.fromLTRB(10, 2, 10, 10)
          : const EdgeInsets.fromLTRB(18, 12, 18, 4),
      decoration: BoxDecoration(
        color: Color(lyricTheme.backgroundColor),
        gradient: lyricTheme.showGradient
            ? LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(lyricTheme.backgroundColor),
                  accent.withValues(alpha: 0.18),
                ],
              )
            : null,
        borderRadius: BorderRadius.circular(widget.focusMode ? 18 : 22),
        border: Border.all(
          color: widget.focusMode
              ? appTheme.border.withValues(alpha: 0.45)
              : appTheme.border,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          _buildHeader(lyricTheme),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              child: music.isLyricsLoading || music.isSearchingLyricsCandidates
                  ? _LoadingState(color: accent)
                  : lyrics == null
                      ? music.lyricsCandidates != null &&
                              music.lyricsCandidates!.isNotEmpty
                          ? _CandidateList(
                              candidates: music.lyricsCandidates!,
                              onSelected: music.selectLyricsCandidate,
                              onSearchAgain: () => _showSearchDialog(music),
                            )
                          : _EmptyState(
                              message:
                                  music.lyricsError ?? 'No lyrics available.',
                              onSearch: () => _showSearchDialog(music),
                              onPickFile: () => _pickLyricsFile(music),
                            )
                      : _buildLyrics(lyrics, lyricTheme),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(LyricThemeSettings settings) {
    final color = Color(settings.inactiveColor);

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 4),
      child: Row(
        children: [
          Tooltip(
            message: 'Lyrics theme',
            child: InkWell(
              onTap: () => Navigator.pushNamed(context, '/lyric-themes'),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.palette_outlined, size: 15, color: color),
                    const SizedBox(width: 6),
                    Text(
                      'Theme',
                      style: TextStyle(
                        color: color,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Spacer(),
          Tooltip(
            message: 'Search lyrics',
            child: InkWell(
              onTap: () => _showSearchDialog(context.read<MusicProvider>()),
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Icon(Icons.search_rounded, size: 18, color: color),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Tooltip(
            message: 'Close lyrics',
            child: InkWell(
              onTap: widget.onClose ??
                  context.read<MusicProvider>().dismissLyrics,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Icon(Icons.close_rounded, size: 18, color: color),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLyrics(
    LyricsData lyrics,
    LyricThemeSettings settings,
  ) {
    final alignment = switch (settings.textAlign) {
      'left' => TextAlign.left,
      'right' => TextAlign.right,
      _ => TextAlign.center,
    };

    return NotificationListener<ScrollNotification>(
      key: ValueKey('${widget.trackId}_${lyrics.hashCode}'),
      onNotification: (notification) {
        if (notification is ScrollStartNotification &&
            notification.dragDetails != null) {
          _autoScroll = false;
        }

        if (notification is ScrollEndNotification) {
          Future<void>.delayed(const Duration(seconds: 4), () {
            if (mounted) _autoScroll = true;
          });
        }

        return false;
      },
      child: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(20, 28, 20, 80),
        itemCount: lyrics.lines.length,
        itemBuilder: (context, index) {
          final line = lyrics.lines[index];
          final active = lyrics.isSynced && index == _activeIndex;
          final useKaraoke = active && settings.karaokeMode;

          return AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 220),
            textAlign: alignment,
            style: TextStyle(
              fontFamily: settings.resolvedFontFamily,
              fontSize:
                  active ? settings.activeFontSize : settings.inactiveFontSize,
              height: 1.45,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
              color: Color(
                active ? settings.activeColor : settings.inactiveColor,
              ),
            ),
            child: SizedBox(
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: useKaraoke
                    ? KaraokeLyricLine(
                        position: _positionNotifier!,
                        line: line,
                        nextLine: index + 1 < lyrics.lines.length
                            ? lyrics.lines[index + 1]
                            : null,
                        totalDuration: lyrics.totalDuration,
                        style: TextStyle(
                          fontFamily: settings.resolvedFontFamily,
                          fontSize: settings.activeFontSize,
                          height: 1.45,
                          fontWeight: FontWeight.w700,
                        ),
                        sungColor: Color(settings.activeColor),
                        unsungColor: Color(settings.inactiveColor),
                        textAlign: alignment,
                      )
                    : Text(line.text),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _pickLyricsFile(MusicProvider music) async {
    try {
      final lyrics = await LyricsFileImportService.pickAndParse();
      if (lyrics == null || !mounted) return;

      music.useManualLyrics(lyrics);
    } catch (_) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to read that lyrics file.')),
      );
    }
  }

  Future<void> _showSearchDialog(MusicProvider music) async {
    final track = music.currentTrack;
    final theme = context.read<ThemeProvider>();

    final query = await showDialog<({String title, String artist})>(
      context: context,
      builder: (_) => _LyricsSearchDialog(
        theme: theme,
        initialTitle: track.title,
        initialArtist: track.artist,
      ),
    );

    if (query == null || !mounted) return;

    await music.searchLyricsCandidates(
      artist: query.artist,
      title: query.title,
      durationSeconds: music.totalDuration?.inSeconds ?? 0,
    );
  }
}

class _LyricsSearchDialog extends StatefulWidget {
  final ThemeProvider theme;
  final String initialTitle;
  final String initialArtist;

  const _LyricsSearchDialog({
    required this.theme,
    required this.initialTitle,
    required this.initialArtist,
  });

  @override
  State<_LyricsSearchDialog> createState() => _LyricsSearchDialogState();
}

class _LyricsSearchDialogState extends State<_LyricsSearchDialog> {
  late final TextEditingController _titleController;
  late final TextEditingController _artistController;

  @override
  void initState() {
    super.initState();

    _titleController = TextEditingController(text: widget.initialTitle);
    _artistController = TextEditingController(text: widget.initialArtist);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _artistController.dispose();
    super.dispose();
  }

  void _submit() {
    final title = _titleController.text.trim();
    if (title.isEmpty) return;

    Navigator.pop(
      context,
      (
        title: title,
        artist: _artistController.text.trim(),
      ),
    );
  }

  InputDecoration _decoration(String label) {
    final theme = widget.theme;

    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(color: theme.muted),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: theme.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: theme.accent),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = widget.theme;

    return AlertDialog(
      backgroundColor: theme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      title: Text(
        'Search Lyrics',
        style: TextStyle(color: theme.text, fontWeight: FontWeight.w700),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              key: const ValueKey('lyrics_search_title'),
              controller: _titleController,
              autofocus: true,
              textInputAction: TextInputAction.next,
              style: TextStyle(color: theme.text),
              decoration: _decoration('Song title'),
            ),
            const SizedBox(height: 12),
            TextField(
              key: const ValueKey('lyrics_search_artist'),
              controller: _artistController,
              textInputAction: TextInputAction.search,
              style: TextStyle(color: theme.text),
              decoration: _decoration('Artist (optional)'),
              onSubmitted: (_) => _submit(),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel', style: TextStyle(color: theme.muted)),
        ),
        FilledButton(
          key: const ValueKey('lyrics_search_submit'),
          onPressed: _submit,
          child: const Text('Search'),
        ),
      ],
    );
  }
}

class _LoadingState extends StatelessWidget {
  final Color color;

  const _LoadingState({required this.color});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      key: const ValueKey('lyrics_loading'),
      builder: (context, constraints) {
        final size = constraints.maxHeight < 48 ? 18.0 : 32.0;

        return Center(
          child: SizedBox(
            width: size,
            height: size,
            child: CircularProgressIndicator(
              color: color,
              strokeWidth: constraints.maxHeight < 48 ? 2 : 4,
            ),
          ),
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String message;
  final VoidCallback onSearch;
  final VoidCallback onPickFile;

  const _EmptyState({
    required this.message,
    required this.onSearch,
    required this.onPickFile,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return LayoutBuilder(
      key: const ValueKey('lyrics_empty'),
      builder: (context, constraints) {
        final veryTight = constraints.maxHeight < 96;
        final hideActions = constraints.maxHeight < 150;
        final padding = veryTight ? 4.0 : 24.0;

        final content = Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!veryTight) ...[
              Icon(Icons.lyrics_outlined, size: 42, color: theme.muted),
              const SizedBox(height: 12),
            ],
            Text(
              message,
              maxLines: veryTight ? 1 : 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(color: theme.muted),
            ),
            if (!hideActions) ...[
              const SizedBox(height: 16),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    key: const ValueKey('lyrics_search_button'),
                    onPressed: onSearch,
                    icon: const Icon(Icons.search_rounded, size: 18),
                    label: const Text('Search'),
                  ),
                  FilledButton(
                    onPressed: onPickFile,
                    child: const Text('Load file'),
                  ),
                ],
              ),
            ],
          ],
        );

        return SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: EdgeInsets.all(padding),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight:
                  constraints.hasBoundedHeight ? constraints.maxHeight : 0,
            ),
            child: Center(child: content),
          ),
        );
      },
    );
  }
}

class _CandidateList extends StatelessWidget {
  final List<LyricsCandidate> candidates;
  final ValueChanged<LyricsCandidate> onSelected;
  final VoidCallback onSearchAgain;

  const _CandidateList({
    required this.candidates,
    required this.onSelected,
    required this.onSearchAgain,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return LayoutBuilder(
      key: const ValueKey('lyrics_candidates'),
      builder: (context, constraints) {
        final tight = constraints.maxHeight < 140;

        if (tight) {
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            itemCount: candidates.length,
            separatorBuilder: (_, __) => Divider(
              height: 1,
              color: theme.border.withValues(alpha: 0.45),
            ),
            itemBuilder: (context, index) {
              return _CandidateTile(
                candidate: candidates[index],
                index: index,
                compact: true,
                onSelected: onSelected,
              );
            },
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Select the correct lyrics',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: theme.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: onSearchAgain,
                    child: const Text('Search again'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                itemCount: candidates.length,
                separatorBuilder: (_, __) => Divider(
                  height: 1,
                  color: theme.border.withValues(alpha: 0.45),
                ),
                itemBuilder: (context, index) {
                  return _CandidateTile(
                    candidate: candidates[index],
                    index: index,
                    compact: false,
                    onSelected: onSelected,
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _CandidateTile extends StatelessWidget {
  final LyricsCandidate candidate;
  final int index;
  final bool compact;
  final ValueChanged<LyricsCandidate> onSelected;

  const _CandidateTile({
    required this.candidate,
    required this.index,
    required this.compact,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return InkWell(
      key: ValueKey('lyrics_candidate_${candidate.id}_$index'),
      onTap: () => onSelected(candidate),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 6,
          vertical: compact ? 8 : 12,
        ),
        child: Row(
          children: [
            if (!compact) ...[
              _ScoreIndicator(candidate: candidate),
              const SizedBox(width: 12),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    candidate.trackName.isEmpty
                        ? 'Unknown title'
                        : candidate.trackName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.text,
                      fontSize: compact ? 12 : 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (!compact) const SizedBox(height: 2),
                  Text(
                    candidate.artistName.isEmpty
                        ? 'Unknown artist'
                        : candidate.artistName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: theme.muted,
                      fontSize: compact ? 10 : 11,
                    ),
                  ),
                  if (!compact && candidate.albumName.isNotEmpty)
                    Text(
                      candidate.albumName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: theme.muted.withValues(alpha: 0.75),
                        fontSize: 10,
                      ),
                    ),
                ],
              ),
            ),
            if (!compact) ...[
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: candidate.hasSynced
                          ? theme.accent.withValues(alpha: 0.15)
                          : theme.border.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      candidate.hasSynced ? 'SYNCED' : 'PLAIN',
                      style: TextStyle(
                        color: candidate.hasSynced ? theme.accent : theme.muted,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    candidate.durationLabel,
                    style: TextStyle(color: theme.muted, fontSize: 10),
                  ),
                ],
              ),
            ],
            const SizedBox(width: 4),
            Icon(
              Icons.chevron_right_rounded,
              color: theme.muted,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}

class _ScoreIndicator extends StatelessWidget {
  final LyricsCandidate candidate;

  const _ScoreIndicator({required this.candidate});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return SizedBox(
      width: 38,
      height: 38,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: candidate.score,
            strokeWidth: 3,
            backgroundColor: theme.border.withValues(alpha: 0.3),
            color: candidate.score >= 0.75
                ? Colors.green
                : candidate.score >= 0.45
                    ? theme.accent
                    : theme.muted,
          ),
          Text(
            '${(candidate.score * 100).round()}%',
            style: TextStyle(
              color: theme.text,
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
