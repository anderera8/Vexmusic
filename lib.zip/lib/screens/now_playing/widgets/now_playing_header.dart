import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/theme_provider.dart';
import '../../../services/player_skin_service.dart';
import 'control_buttons.dart';

class NowPlayingHeader extends StatefulWidget {
  final bool hasActiveTrack;
  final VoidCallback? onOptionsTap;
  final PlayerSkinSettings skin;
  final Color? accent;

  const NowPlayingHeader({
    super.key,
    required this.hasActiveTrack,
    this.skin = const PlayerSkinSettings(),
    this.onOptionsTap,
    this.accent,
  });

  @override
  State<NowPlayingHeader> createState() => _NowPlayingHeaderState();
}

class _NowPlayingHeaderState extends State<NowPlayingHeader>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final accent = widget.accent ?? theme.accent;

    return switch (widget.skin.headerStyle) {
      'clean' => _buildClean(theme),
      'glass' => _buildGlass(theme),
      'pill' => _buildPill(theme, accent),
      'vinyl' => _buildVinyl(theme, accent),
      _ => _buildShimmer(theme, accent),
    };
  }

  Widget _buildBaseRow({
    required ThemeProvider theme,
    required Widget title,
    EdgeInsets padding = const EdgeInsets.fromLTRB(18, 10, 18, 4),
  }) {
    return Padding(
      padding: padding,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButtonWidget(
            icon: Icons.keyboard_arrow_down,
            onTap: () => Navigator.pop(context),
            semanticLabel: 'Close player',
          ),
          title,
          IconButtonWidget(
            icon: Icons.more_horiz,
            onTap: widget.hasActiveTrack ? widget.onOptionsTap : null,
            semanticLabel: 'Track options',
          ),
        ],
      ),
    );
  }

  Widget _buildShimmer(ThemeProvider theme, Color accent) {
    return _buildBaseRow(
      theme: theme,
      title: AnimatedBuilder(
        animation: _pulse,
        builder: (context, child) {
          final t = _pulse.value;
          final glow = 0.35 + sin(t * pi) * 0.35;

          return Transform.scale(
            scale: 1 + sin(t * pi * 2) * 0.015,
            child: ShaderMask(
              shaderCallback: (bounds) {
                return LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    theme.text.withValues(alpha: 0.72),
                    theme.text,
                    accent,
                    theme.text,
                    theme.text.withValues(alpha: 0.72),
                  ],
                  stops: _stops(t),
                ).createShader(bounds);
              },
              blendMode: BlendMode.srcIn,
              child: Text(
                'NOW PLAYING',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: theme.text,
                  letterSpacing: 2.3,
                  shadows: [
                    Shadow(
                      color: accent.withValues(alpha: glow),
                      blurRadius: 12,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildClean(ThemeProvider theme) {
    return _buildBaseRow(
      theme: theme,
      title: Text(
        'Now Playing',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w800,
          color: theme.text,
          letterSpacing: 0.4,
        ),
      ),
    );
  }

  Widget _buildGlass(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: theme.surface.withValues(alpha: 0.62),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: theme.border.withValues(alpha: 0.65)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.16),
              blurRadius: 22,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          children: [
            IconButtonWidget(
              icon: Icons.keyboard_arrow_down,
              onTap: () => Navigator.pop(context),
              semanticLabel: 'Close player',
            ),
            Expanded(
              child: Center(
                child: Text(
                  'NOW PLAYING',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: theme.text,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
            IconButtonWidget(
              icon: Icons.more_horiz,
              onTap: widget.hasActiveTrack ? widget.onOptionsTap : null,
              semanticLabel: 'Track options',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPill(ThemeProvider theme, Color accent) {
    return _buildBaseRow(
      theme: theme,
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
        decoration: BoxDecoration(
          color: accent.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: accent.withValues(alpha: 0.28)),
        ),
        child: Text(
          'NOW PLAYING',
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w900,
            color: accent,
            letterSpacing: 1.9,
          ),
        ),
      ),
    );
  }

  Widget _buildVinyl(ThemeProvider theme, Color accent) {
    return _buildBaseRow(
      theme: theme,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (context, child) {
              return Transform.rotate(
                angle: _pulse.value * pi * 2,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: theme.text,
                    border: Border.all(
                      color: accent.withValues(alpha: 0.75),
                      width: 3,
                    ),
                  ),
                  child: Center(
                    child: Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: theme.bg,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(width: 9),
          Text(
            'NOW PLAYING',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: theme.text,
              letterSpacing: 1.8,
            ),
          ),
        ],
      ),
    );
  }

  static List<double> _stops(double t) {
    const width = 0.35;
    final c = t;
    final a = max(0.0, c - width);
    final b = max(0.0, c - width * 0.5);
    final d = min(1.0, c + width * 0.5);
    final e = min(1.0, c + width);
    return [a, b, c, d, e];
  }
}
