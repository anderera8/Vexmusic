// lib/screens/now_playing/widgets/secondary_controls.dart
// ─────────────────────────────────────────────────────────────────────────────
// Secondary action row: EQ, Speed, Add to Playlist, Lyrics.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/music_provider.dart';
import 'control_buttons.dart';

class SecondaryControls extends StatelessWidget {
  final bool hasActiveTrack;
  final VoidCallback onEqTap;
  final VoidCallback onSpeedTap;
  final VoidCallback? onAddToTap;
  final VoidCallback? onLyricsTap;
  final bool isLyricsVisible;
  final Color accent;

  const SecondaryControls({
    super.key,
    required this.hasActiveTrack,
    required this.onEqTap,
    required this.onSpeedTap,
    this.onAddToTap,
    this.onLyricsTap,
    this.isLyricsVisible = false,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(30, 2, 30, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          SecondaryButtonWidget(
            icon: Icons.graphic_eq_rounded,
            label: 'EQ',
            onTap: onEqTap,
            accentColor: accent,
          ),
          SecondaryButtonWidget(
            icon: Icons.speed_rounded,
            label: 'Speed',
            onTap: onSpeedTap,
            accentColor: accent,
          ),
          SecondaryButtonWidget(
            icon: Icons.playlist_add_rounded,
            label: 'Add to',
            onTap: hasActiveTrack ? onAddToTap : null,
            accentColor: accent,
          ),
          SecondaryButtonWidget(
            icon:
                music.hasLyrics ? Icons.lyrics_rounded : Icons.lyrics_outlined,
            label: 'Lyrics',
            isActive: isLyricsVisible,
            onTap: hasActiveTrack ? onLyricsTap : null,
            accentColor: accent,
          ),
        ],
      ),
    );
  }
}
