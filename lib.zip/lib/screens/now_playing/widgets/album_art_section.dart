// lib/screens/now_playing/widgets/album_art_section.dart

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/player_skin_service.dart';
import '../../../widgets/spectrum_visualizer.dart';
import '../../../widgets/track_art_widget.dart';

class AlbumArtSection extends StatelessWidget {
  final AnimationController animation;
  final PlayerSkinSettings skin;
  final Color accent;

  const AlbumArtSection({
    super.key,
    required this.animation,
    required this.skin,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();
    final track = music.currentTrack;
    final gradient = theme.gradient(track.grad);

    final metrics = _metricsForLayout(context);

    final BorderRadiusGeometry artRadius = skin.artworkShape == 'circle'
        ? BorderRadius.circular(metrics.artSize / 2)
        : skin.artworkShape == 'square'
            ? BorderRadius.zero
            : BorderRadius.circular(metrics.radius);

    final visualizerColor =
        HSVColor.fromAHSV(1, skin.visualizerHue, 1, 1).toColor();
    final showVisualizer =
        music.hasStartedPlayback && skin.visualizerMode != 'off';
    // The visualizer fills a larger square than the artwork itself so its
    // bars/wave are actually visible extending out from behind the art,
    // rather than being fully hidden behind it (they'd be identically
    // sized and directly overlapping otherwise). This scales with the
    // artwork itself, so it stays proportional across all four layouts,
    // but is capped to the width actually available within this
    // section's own padding so it can never overflow the screen.
    final screenWidth = MediaQuery.sizeOf(context).width;
    final availableWidth =
        screenWidth - metrics.padding.horizontal - 8; // 8: a hair of margin
    final visualizerSize = math.min(metrics.artSize * 1.4, availableWidth);

    return Padding(
      padding: metrics.padding,
      child: Center(
        child: SizedBox(
          width: visualizerSize,
          height: visualizerSize,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // The visualizer fills this whole section's background —
              // extending out from behind the album art on every side —
              // so the bars/waves read as a background for the artwork
              // rather than floating somewhere else on screen. It's only
              // ever placed here, inside the non-lyrics branch of the
              // now-playing screen's AnimatedSwitcher, so it's
              // structurally impossible for it to show through into the
              // lyrics view: when lyrics are shown this whole section
              // (and the visualizer with it) simply isn't built.
              if (showVisualizer)
                Positioned.fill(
                  child: IgnorePointer(
                    child: Opacity(
                      opacity: 0.7,
                      child: SpectrumVisualizer(
                        mode: SpectrumVisualizerMode.fromName(
                          skin.visualizerMode,
                        ),
                        color: visualizerColor,
                        showLabels: false,
                        animationDuration: const Duration(milliseconds: 150),
                      ),
                    ),
                  ),
                ),
              RepaintBoundary(
                child: AnimatedBuilder(
                  animation: animation,
                  builder: (context, child) {
                    final shouldAnimate =
                        music.isPlaying && skin.layoutStyle != 'classic';
                    final offset =
                        shouldAnimate ? animation.value * 8 - 4 : 0.0;
                    final scale = music.isPlaying ? 1.0 : metrics.idleScale;

                    return Transform.translate(
                      offset: Offset(0, offset),
                      child: Transform.scale(
                        scale: scale,
                        child: Container(
                          width: metrics.artSize,
                          height: metrics.artSize,
                          decoration: BoxDecoration(
                            gradient: gradient,
                            borderRadius: artRadius,
                            border: metrics.borderWidth > 0
                                ? Border.all(
                                    color: metrics.isVinyl
                                        ? Colors.black
                                            .withValues(alpha: 0.75)
                                        : theme.border
                                            .withValues(alpha: 0.85),
                                    width: metrics.borderWidth,
                                  )
                                : null,
                            boxShadow: metrics.shadows(theme, accent),
                          ),
                          alignment: Alignment.center,
                          child: ClipRRect(
                            borderRadius: artRadius,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                TrackArtWidget(
                                  key: ValueKey(
                                    'now-playing-art-'
                                    '${track.id}-'
                                    '${track.mediaStoreId}-'
                                    '${track.volumeName}-'
                                    '${track.stableKey}-'
                                    '${track.albumId ?? 0}-'
                                    '${track.artPath ?? ''}',
                                  ),
                                  artPath: track.artPath,
                                  albumId: track.albumId,
                                  mediaStoreId: track.mediaStoreId,
                                  volumeName: track.volumeName,
                                  stableKey: track.stableKey,
                                  trackId: track.id,
                                  size: metrics.artSize,
                                  borderRadius: 0,
                                  fit: BoxFit.cover,
                                  defaultIconColor: theme.text,
                                  gaplessPlayback: false,
                                ),
                                if (metrics.isVinyl)
                                  _VinylSpindle(artSize: metrics.artSize),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _AlbumArtMetrics _metricsForLayout(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final width = size.width;

    final base = switch (skin.layoutStyle) {
      'minimal' => _AlbumArtMetrics(
          artSize: (width * 0.50).clamp(120.0, 210.0),
          padding: const EdgeInsets.fromLTRB(28, 10, 28, 8),
          radius:
              skin.artworkShape == 'rounded' ? skin.artworkRadius * 0.75 : 0,
          idleScale: 0.98,
          borderWidth: 0,
          shadowStyle: _AlbumShadowStyle.soft,
        ),
      'classic' => _AlbumArtMetrics(
          artSize: (width * 0.58).clamp(150.0, 245.0),
          padding: const EdgeInsets.fromLTRB(28, 18, 28, 14),
          radius: skin.artworkShape == 'rounded' ? 10 : 0,
          idleScale: 1.0,
          borderWidth: 2,
          shadowStyle: _AlbumShadowStyle.classic,
        ),
      'modern' => _AlbumArtMetrics(
          artSize: (width * 0.74).clamp(180.0, 310.0),
          padding: const EdgeInsets.fromLTRB(22, 26, 22, 20),
          radius:
              skin.artworkShape == 'rounded' ? skin.artworkRadius * 1.25 : 0,
          idleScale: 0.96,
          borderWidth: 0,
          shadowStyle: _AlbumShadowStyle.glow,
        ),
      _ => _AlbumArtMetrics(
          artSize: (width * 0.68).clamp(150.0, 280.0),
          padding: const EdgeInsets.fromLTRB(28, 20, 28, 16),
          radius: skin.artworkRadius,
          idleScale: 0.96,
          borderWidth: 0,
          shadowStyle: _AlbumShadowStyle.normal,
        ),
    };

    // Artwork Style (Standard / Glow / Vinyl / Flat) is a separate axis
    // from the layout — it overrides just the shadow/border treatment the
    // layout picked above, so "Flat Art" always means no heavy shadows and
    // "Glow Art" always means an accent glow, no matter which layout is
    // active. "Standard" and an unrecognized value both fall through to
    // whatever the layout already chose, which is the pre-existing look.
    return switch (skin.artworkStyle) {
      'flat' => base.copyWith(
          shadowStyle: _AlbumShadowStyle.flat,
          borderWidth: 0,
        ),
      'glow' => base.copyWith(shadowStyle: _AlbumShadowStyle.glow),
      'vinyl' => base.copyWith(
          shadowStyle: _AlbumShadowStyle.classic,
          borderWidth: math.max(base.borderWidth, 3),
          isVinyl: true,
        ),
      _ => base,
    };
  }
}

enum _AlbumShadowStyle {
  soft,
  normal,
  classic,
  glow,
  flat,
}

class _AlbumArtMetrics {
  final double artSize;
  final EdgeInsets padding;
  final double radius;
  final double idleScale;
  final double borderWidth;
  final _AlbumShadowStyle shadowStyle;

  /// Whether to draw the vinyl-record spindle-hole overlay in the center
  /// of the artwork. Only true for the "Vinyl Art" artwork style.
  final bool isVinyl;

  const _AlbumArtMetrics({
    required this.artSize,
    required this.padding,
    required this.radius,
    required this.idleScale,
    required this.borderWidth,
    required this.shadowStyle,
    this.isVinyl = false,
  });

  _AlbumArtMetrics copyWith({
    double? artSize,
    EdgeInsets? padding,
    double? radius,
    double? idleScale,
    double? borderWidth,
    _AlbumShadowStyle? shadowStyle,
    bool? isVinyl,
  }) {
    return _AlbumArtMetrics(
      artSize: artSize ?? this.artSize,
      padding: padding ?? this.padding,
      radius: radius ?? this.radius,
      idleScale: idleScale ?? this.idleScale,
      borderWidth: borderWidth ?? this.borderWidth,
      shadowStyle: shadowStyle ?? this.shadowStyle,
      isVinyl: isVinyl ?? this.isVinyl,
    );
  }

  List<BoxShadow> shadows(ThemeProvider theme, Color accent) {
    switch (shadowStyle) {
      case _AlbumShadowStyle.soft:
        return [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.22),
            blurRadius: 28,
            offset: const Offset(0, 14),
          ),
        ];

      case _AlbumShadowStyle.classic:
        return [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.42),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ];

      case _AlbumShadowStyle.glow:
        return [
          BoxShadow(
            color: accent.withValues(alpha: 0.22),
            blurRadius: 72,
            offset: const Offset(0, 26),
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.55),
            blurRadius: 56,
            offset: const Offset(0, 24),
          ),
          BoxShadow(
            color: theme.text.withValues(alpha: 0.08),
            spreadRadius: 1,
          ),
        ];

      case _AlbumShadowStyle.normal:
        return [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.55),
            blurRadius: 60,
            offset: const Offset(0, 24),
          ),
          BoxShadow(
            color: theme.text.withValues(alpha: 0.08),
            spreadRadius: 1,
          ),
        ];

      case _AlbumShadowStyle.flat:
        return const [];
    }
  }
}

/// The small center "spindle hole" cutout look of a vinyl record, drawn
/// over the album art for the "Vinyl Art" artwork style. Purely
/// decorative — an IgnorePointer so it never intercepts taps meant for
/// the artwork underneath.
class _VinylSpindle extends StatelessWidget {
  final double artSize;

  const _VinylSpindle({required this.artSize});

  @override
  Widget build(BuildContext context) {
    final holeSize = artSize * 0.16;

    return IgnorePointer(
      child: Container(
        width: holeSize,
        height: holeSize,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.black.withValues(alpha: 0.82),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.18),
            width: holeSize * 0.06,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.5),
              blurRadius: 6,
            ),
          ],
        ),
        alignment: Alignment.center,
        child: Container(
          width: holeSize * 0.28,
          height: holeSize * 0.28,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}
