// lib/screens/now_playing/widgets/control_buttons.dart
// ─────────────────────────────────────────────────────────────────────────────
// Shared control button widgets used throughout Now Playing.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/theme_provider.dart';

/// Circular icon button used in the header and transport bar.
class IconButtonWidget extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final String? semanticLabel;

  const IconButtonWidget({
    super.key,
    required this.icon,
    required this.onTap,
    this.semanticLabel,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final enabled = onTap != null;

    return Semantics(
      label: semanticLabel,
      button: semanticLabel != null,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Opacity(
          opacity: enabled ? 1.0 : 0.35,
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: theme.surface.withValues(alpha: 0.82),
              shape: BoxShape.circle,
              border: Border.all(color: theme.border),
            ),
            child: Icon(icon, size: 22, color: theme.text),
          ),
        ),
      ),
    );
  }
}

/// Transport control button (shuffle, prev, next, repeat).
class ControlButtonWidget extends StatelessWidget {
  final IconData icon;
  final double size;
  final bool isActive;
  final bool enabled;
  final VoidCallback? onTap;
  final String? semanticLabel;
  final Color? accentColor;

  const ControlButtonWidget({
    super.key,
    required this.icon,
    this.size = 54,
    this.isActive = false,
    this.enabled = true,
    required this.onTap,
    this.semanticLabel,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final accent = accentColor ?? theme.accent;

    return Semantics(
      label: semanticLabel,
      button: semanticLabel != null,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: enabled ? onTap : null,
        child: Opacity(
          opacity: enabled ? 1.0 : 0.35,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: theme.surface.withValues(alpha: 0.82),
              border: Border.all(
                color: isActive ? accent : theme.border,
              ),
            ),
            child: Icon(
              icon,
              size: size > 50 ? 26 : (size * 0.42).clamp(18.0, 26.0),
              color: isActive ? accent : theme.text,
            ),
          ),
        ),
      ),
    );
  }
}

/// Secondary action button (EQ, Speed, Add to, Lyrics).
class SecondaryButtonWidget extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool isActive;
  final bool locked;
  final Color? accentColor;

  const SecondaryButtonWidget({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.isActive = false,
    this.locked = false,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    final enabled = onTap != null;
    final color = isActive ? (accentColor ?? theme.accent) : theme.muted;

    return Semantics(
      label: locked ? '$label, locked' : label,
      button: true,
      enabled: enabled,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Opacity(
          opacity: enabled ? 1.0 : 0.35,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Icon(icon, size: 22, color: color),
                  if (locked)
                    Positioned(
                      right: -5,
                      top: -3,
                      child: Container(
                        padding: const EdgeInsets.all(1.5),
                        decoration: BoxDecoration(
                          color: theme.bg,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.lock_rounded,
                          size: 11,
                          color: theme.muted,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 5),
              Text(label, style: TextStyle(fontSize: 11, color: color)),
            ],
          ),
        ),
      ),
    );
  }
}
