// lib/screens/now_playing/widgets/transport_controls.dart
// ─────────────────────────────────────────────────────────────────────────────
// Playback transport: shuffle, previous, play/pause, next, repeat.
// Responsively scales down on narrow screens to avoid overflow.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import 'control_buttons.dart';

class TransportControls extends StatelessWidget {
  final bool hasActiveTrack;
  final Color accent;

  const TransportControls({
    super.key,
    required this.hasActiveTrack,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 10, 22, 8),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final w = constraints.maxWidth;
          final scale = (w / 320).clamp(0.7, 1.0);
          final smallBtn = (46 * scale).roundToDouble();
          final medBtn = (54 * scale).roundToDouble();
          final playBtn = (72 * scale).roundToDouble();
          final playIconSize = (40 * scale).roundToDouble();
          final gapSm = (6 * scale).roundToDouble();
          final gapLg = (12 * scale).roundToDouble();

          return Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ControlButtonWidget(
                icon: Icons.shuffle_rounded,
                size: smallBtn,
                isActive: music.isShuffle,
                enabled: hasActiveTrack,
                semanticLabel: music.isShuffle ? 'Shuffle on' : 'Shuffle off',
                onTap: hasActiveTrack ? () => music.toggleShuffle() : null,
                accentColor: accent,
              ),
              SizedBox(width: gapLg),
              ControlButtonWidget(
                icon: Icons.skip_previous_rounded,
                size: medBtn,
                enabled: hasActiveTrack,
                onTap: hasActiveTrack ? () => music.previoustrack() : null,
              ),
              SizedBox(width: gapSm),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: hasActiveTrack ? () => music.togglePlayPause() : null,
                child: Semantics(
                  label: music.isPlaying ? 'Pause' : 'Play',
                  button: true,
                  child: Container(
                    width: playBtn,
                    height: playBtn,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [accent, theme.accent2],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: accent.withValues(alpha: 0.4),
                          blurRadius: 28,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Icon(
                      music.isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      size: playIconSize,
                      color: theme.currentTheme.colorScheme.onPrimary,
                    ),
                  ),
                ),
              ),
              SizedBox(width: gapSm),
              ControlButtonWidget(
                icon: Icons.skip_next_rounded,
                size: medBtn,
                enabled: hasActiveTrack,
                semanticLabel: 'Next track',
                onTap: hasActiveTrack ? () => music.nexttrack() : null,
              ),
              SizedBox(width: gapLg),
              ControlButtonWidget(
                icon: music.repeatMode == 2
                    ? Icons.repeat_one_rounded
                    : Icons.repeat_rounded,
                size: smallBtn,
                isActive: music.repeatMode > 0,
                enabled: hasActiveTrack,
                semanticLabel: [
                  'Repeat off',
                  'Repeat all',
                  'Repeat one'
                ][music.repeatMode],
                onTap: hasActiveTrack ? () => music.cycleRepeat() : null,
                accentColor: accent,
              ),
            ],
          );
        },
      ),
    );
  }
}
