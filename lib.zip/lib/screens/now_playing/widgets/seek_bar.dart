// lib/screens/now_playing/widgets/seek_bar.dart
// ─────────────────────────────────────────────────────────────────────────────
// Progress slider with elapsed / remaining time labels.  Supports tap-to-seek
// on the track as well as the standard Slider drag gesture.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';

class SeekBar extends StatefulWidget {
  final Color accent;

  const SeekBar({super.key, required this.accent});

  @override
  State<SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<SeekBar> {
  bool _seeking = false;
  double _seekValue = 0.0;

  String _formatDuration(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();

    return ValueListenableBuilder<Duration>(
      valueListenable: music.positionNotifier,
      builder: (context, position, _) {
        final totalMs =
            music.totalDurationNotifier.value?.inMilliseconds.toDouble() ?? 1.0;
        final posMs = position.inMilliseconds.toDouble().clamp(0.0, totalMs);
        final sliderValue = _seeking ? _seekValue : posMs;

        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 0),
          child: Column(
            children: [
              GestureDetector(
                onTapDown: (details) {
                  final box = context.findRenderObject() as RenderBox;
                  final localPos = box.globalToLocal(details.globalPosition);
                  final fraction =
                      (localPos.dx / box.size.width).clamp(0.0, 1.0);
                  final durMs =
                      music.totalDurationNotifier.value?.inMilliseconds ?? 0;
                  final seekPosMs = (durMs * fraction).round();
                  music.seekTo(Duration(milliseconds: seekPosMs));
                },
                child: SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 3,
                    activeTrackColor: widget.accent,
                    inactiveTrackColor: theme.border,
                    thumbColor: theme.text,
                    thumbShape:
                        const RoundSliderThumbShape(enabledThumbRadius: 7),
                    overlayColor: widget.accent.withValues(alpha: 0.2),
                    overlayShape:
                        const RoundSliderOverlayShape(overlayRadius: 16),
                  ),
                  child: Slider(
                    value: sliderValue.clamp(0.0, totalMs),
                    min: 0,
                    max: totalMs,
                    onChangeStart: (v) {
                      _seeking = true;
                      _seekValue = v;
                    },
                    onChanged: (v) => setState(() => _seekValue = v),
                    onChangeEnd: (v) {
                      _seeking = false;
                      music.seekTo(Duration(milliseconds: v.round()));
                    },
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _formatDuration(_seeking
                          ? Duration(milliseconds: _seekValue.round())
                          : position),
                      style: TextStyle(fontSize: 12, color: theme.muted),
                    ),
                    Text(
                      music.totalDurationNotifier.value != null
                          ? _formatDuration(music.totalDurationNotifier.value!)
                          : '--:--',
                      style: TextStyle(fontSize: 12, color: theme.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
