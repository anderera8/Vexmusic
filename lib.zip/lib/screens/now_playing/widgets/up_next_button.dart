// lib/screens/now_playing/widgets/up_next_button.dart
// ─────────────────────────────────────────────────────────────────────────────
// Up Next queue preview button — shows track count and pending queue badge.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../widgets/up_next_sheet.dart';

class UpNextButton extends StatelessWidget {
  final Color accent;

  const UpNextButton({super.key, required this.accent});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 4),
      child: GestureDetector(
        onTap: () => UpNextSheet.show(context),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.border),
          ),
          child: Row(
            children: [
              Icon(Icons.queue_music_rounded, size: 20, color: accent),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  music.hasUpNext
                      ? 'Up Next · ${music.upNextTracks.length} track${music.upNextTracks.length != 1 ? 's' : ''}'
                      : 'Up Next',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: theme.text,
                  ),
                ),
              ),
              if (music.hasPendingQueue)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${music.pendingQueue.length} queued',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: accent,
                    ),
                  ),
                ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, size: 20, color: theme.muted),
            ],
          ),
        ),
      ),
    );
  }
}
