// lib/screens/now_playing/widgets/track_info_section.dart
// ─────────────────────────────────────────────────────────────────────────────
// Track title, artist name, and favorite (like) toggle button.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/ads/interstitial_ad_controller.dart';

class TrackInfoSection extends StatelessWidget {
  final Track track;
  final bool hasActiveTrack;

  const TrackInfoSection({
    super.key,
    required this.track,
    required this.hasActiveTrack,
  });

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  track.title,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: theme.text,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  track.artist,
                  style: TextStyle(fontSize: 14, color: theme.muted),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: hasActiveTrack
                ? () {
                    music.toggleLike(track.id);
                    InterstitialAdController.maybeShow(
                      InterstitialTrigger.favoriteToggled,
                    );
                  }
                : null,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 4, 4),
              child: Icon(
                music.isFav ? Icons.favorite : Icons.favorite_border,
                size: 28,
                color: music.isFav ? theme.danger : theme.muted,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
