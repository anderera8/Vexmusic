// lib/screens/now_playing/widgets/karaoke_lyric_line.dart
// ─────────────────────────────────────────────────────────────────────────────
// Renders one lyric line with karaoke-style progressive word highlighting.
//
// Word timing comes from one of two places:
//   • Real per-word timestamps, when the source is enhanced LRC
//     (`<mm:ss.xx>word`) — see LyricLine.words / LyricsService.parseLrc.
//   • An estimate, when only the line-level timestamp is known (the common
//     case for most fetched/imported lyrics). The gap between this line and
//     the next is split across the line's words, weighted by word length, so
//     longer words get proportionally more time than short ones.
//
// Either way, the line is driven live off the real playback position, so the
// highlight sweeps through the words in sync with the audio rather than
// jumping once per line.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../../services/lyrics_service.dart';

typedef _WordSegment = ({String text, Duration start, Duration end});

class KaraokeLyricLine extends StatelessWidget {
  /// Live playback position. The widget listens to this directly so only
  /// this one line rebuilds as time passes, not the whole lyrics list.
  final ValueListenable<Duration> position;

  final LyricLine line;

  /// The next line in the lyrics, if any — its timestamp caps this line's
  /// estimated end so the highlight doesn't run past when the next line
  /// starts.
  final LyricLine? nextLine;

  /// Whole-track duration, used as a fallback end bound for the final line
  /// (where there's no next line to cap against).
  final Duration totalDuration;

  final TextStyle style;
  final Color sungColor;
  final Color unsungColor;
  final TextAlign textAlign;

  const KaraokeLyricLine({
    super.key,
    required this.position,
    required this.line,
    required this.nextLine,
    required this.totalDuration,
    required this.style,
    required this.sungColor,
    required this.unsungColor,
    required this.textAlign,
  });

  @override
  Widget build(BuildContext context) {
    final segments = _resolveSegments();

    if (segments.isEmpty) {
      return Text(line.text, style: style.copyWith(color: sungColor));
    }

    return ValueListenableBuilder<Duration>(
      valueListenable: position,
      builder: (context, pos, _) {
        return Text.rich(
          TextSpan(
            children: [
              for (var i = 0; i < segments.length; i++)
                TextSpan(
                  text: i == segments.length - 1
                      ? segments[i].text
                      : '${segments[i].text} ',
                  style: style.copyWith(
                    color: _colorFor(segments[i], pos),
                  ),
                ),
            ],
          ),
          textAlign: textAlign,
        );
      },
    );
  }

  Color _colorFor(_WordSegment segment, Duration pos) {
    if (pos <= segment.start) return unsungColor;
    if (pos >= segment.end) return sungColor;

    final total = segment.end - segment.start;
    if (total.inMicroseconds <= 0) return sungColor;

    final elapsed = pos - segment.start;
    final t =
        (elapsed.inMicroseconds / total.inMicroseconds).clamp(0.0, 1.0);
    return Color.lerp(unsungColor, sungColor, t) ?? sungColor;
  }

  /// The effective end of this line: the next line's start when known,
  /// otherwise the track's total duration, otherwise a flat fallback.
  Duration _lineEnd() {
    final nextStart = nextLine?.timestamp;
    if (nextStart != null && nextStart > line.timestamp) return nextStart;
    if (totalDuration > line.timestamp) return totalDuration;
    return line.timestamp + const Duration(seconds: 4);
  }

  List<_WordSegment> _resolveSegments() {
    if (line.words.isNotEmpty) return _segmentsFromWordTiming();
    return _segmentsFromEstimate();
  }

  /// Real word-level timing: each word starts at its own timestamp and ends
  /// where the next word begins (or the line ends, for the last word).
  List<_WordSegment> _segmentsFromWordTiming() {
    final lineEnd = _lineEnd();
    final words = line.words;
    final segments = <_WordSegment>[];

    for (var i = 0; i < words.length; i++) {
      final start = words[i].timestamp;
      final rawEnd = i + 1 < words.length ? words[i + 1].timestamp : lineEnd;
      final end = rawEnd > start
          ? rawEnd
          : start + const Duration(milliseconds: 300);
      segments.add((text: words[i].text, start: start, end: end));
    }

    return segments;
  }

  /// Estimated timing: split the line's [timestamp, lineEnd) span across its
  /// words, proportionally to each word's character length.
  List<_WordSegment> _segmentsFromEstimate() {
    final words = line.text
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .toList(growable: false);
    if (words.isEmpty) return const [];

    final lineEnd = _lineEnd();
    final span = lineEnd - line.timestamp;
    final totalChars = words.fold<int>(0, (sum, word) => sum + word.length);

    if (span <= Duration.zero || totalChars <= 0) {
      return [(text: line.text, start: line.timestamp, end: lineEnd)];
    }

    final segments = <_WordSegment>[];
    var cursor = line.timestamp;
    var accumulatedChars = 0;

    for (final word in words) {
      accumulatedChars += word.length;
      final end = line.timestamp + span * (accumulatedChars / totalChars);
      segments.add((text: word, start: cursor, end: end));
      cursor = end;
    }

    return segments;
  }
}
