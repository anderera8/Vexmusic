// lib/screens/home/home_bottom_nav.dart
// ─────────────────────────────────────────────────────────────────────────────
// Bottom navigation bar for the HomeScreen.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';

class BottomNav extends StatelessWidget {
  final int current;
  final ValueChanged<int> onTap;

  const BottomNav({super.key, required this.current, required this.onTap});

  static const _items = [
    (Icons.headphones_rounded, Icons.headphones_outlined, 'Audio'),
    (Icons.home_rounded, Icons.home_outlined, 'Home'),
    (Icons.radio_rounded, Icons.radio_rounded, 'Radio'),
    (Icons.library_music_rounded, Icons.library_music_outlined, 'Library'),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Container(
      decoration: BoxDecoration(
        color: theme.surface,
        border: Border(top: BorderSide(color: theme.border, width: 0.5)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: List.generate(_items.length, (i) {
              final active = i == current;
              final item = _items[i];
              return Expanded(
                child: Semantics(
                  label: '${item.$3} tab${active ? ', selected' : ''}',
                  button: true,
                  selected: active,
                  child: GestureDetector(
                    onTap: () => onTap(i),
                    behavior: HitTestBehavior.opaque,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        active
                            ? ShaderMask(
                                shaderCallback: (b) => LinearGradient(
                                  colors: [theme.accent, theme.accent2],
                                ).createShader(b),
                                child: Icon(item.$1,
                                    color: Colors.white, size: 24),
                              )
                            : Icon(item.$2, color: theme.muted, size: 24),
                        const SizedBox(height: 3),
                        Text(
                          item.$3,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight:
                                active ? FontWeight.w700 : FontWeight.w400,
                            color: active ? theme.accent : theme.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
