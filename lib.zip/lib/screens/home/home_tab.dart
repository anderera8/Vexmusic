// lib/screens/home/home_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Home tab dashboard with Recently Played, Recently Added, Favorites sections.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import 'home_dash_section.dart';
import 'home_helpers.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();
    final recentlyPlayed = HomeMediaItem.recentlyPlayed(music);
    final recentlyAdded = HomeMediaItem.recentlyAdded(music);
    final favorites =
        music.likedTracks.map(HomeMediaItem.audio).take(20).toList();

    return Column(
      children: [
        // ── Top bar ──────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Row(
            children: [
              Builder(
                builder: (ctx) => TopBarButton(
                  onTap: () => Scaffold.maybeOf(ctx)?.openDrawer(),
                  child: Semantics(
                    label: 'Open navigation menu',
                    button: true,
                    child:
                        Icon(Icons.menu_rounded, color: theme.text, size: 20),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AnimatedGradientText(
                      text: 'Vibes Player',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: theme.accent,
                        letterSpacing: 2,
                      ),
                    ),
                    Text(
                      'YOUR MUSIC YOUR WAY',
                      style: TextStyle(
                        fontSize: 10,
                        color: theme.muted,
                        letterSpacing: 2.4,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // ── Dashboard sections ────────────────────────────────────────
        Expanded(
          child: music.isLoading
              ? Center(child: CircularProgressIndicator(color: theme.accent))
              : ListView(
                  padding: const EdgeInsets.only(bottom: 24),
                  children: [
                    if (recentlyPlayed.isNotEmpty)
                      DashSection(
                        title: 'Recently Played',
                        icon: Icons.history_rounded,
                        items: recentlyPlayed,
                      ),
                    if (recentlyAdded.isNotEmpty)
                      DashSection(
                        title: 'Recently Added',
                        icon: Icons.fiber_new_rounded,
                        items: recentlyAdded,
                      ),
                    if (favorites.isNotEmpty)
                      DashSection(
                        title: 'Favorites',
                        icon: Icons.favorite_rounded,
                        items: favorites,
                      ),
                    if (recentlyPlayed.isEmpty &&
                        recentlyAdded.isEmpty &&
                        favorites.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 80),
                        child: Column(
                          children: [
                            Icon(Icons.perm_media_rounded,
                                size: 64,
                                color: theme.muted.withValues(alpha: 0.3)),
                            const SizedBox(height: 16),
                            Text('Play some music to get started',
                                style: TextStyle(
                                    color: theme.muted, fontSize: 15)),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
        const AdBannerBar(),
      ],
    );
  }
}
