// lib/screens/home/home_helpers.dart
// ─────────────────────────────────────────────────────────────────────────────
// Helper widgets for the Home screen: TopBarButton, AnimatedGradientText, AudioLibraryTab.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import 'home_audio_page.dart';
import 'home_enums.dart';

class TopBarButton extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;

  const TopBarButton({super.key, required this.child, this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: theme.border),
        ),
        alignment: Alignment.center,
        child: child,
      ),
    );
  }
}

class AnimatedGradientText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const AnimatedGradientText({
    super.key,
    required this.text,
    required this.style,
  });

  @override
  State<AnimatedGradientText> createState() => _AnimatedGradientTextState();
}

class _AnimatedGradientTextState extends State<AnimatedGradientText>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _anim = Tween<double>(begin: 0, end: 1).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        return ShaderMask(
          shaderCallback: (bounds) {
            return LinearGradient(
              colors: [theme.accent, theme.accent2],
              begin: Alignment(_anim.value - 0.5, 0),
              end: Alignment(_anim.value + 0.5, 0),
            ).createShader(bounds);
          },
          child: Text(widget.text, style: widget.style),
        );
      },
    );
  }
}

class AudioLibraryTab extends StatelessWidget {
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;
  final void Function(SortField, SortDir) onSortChanged;
  final void Function(DisplayMode, GroupBy) onDisplayChanged;

  const AudioLibraryTab({
    super.key,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
    required this.onSortChanged,
    required this.onDisplayChanged,
  });

  @override
  Widget build(BuildContext context) {
    return HomeAudioPage(
      sortField: sortField,
      sortDir: sortDir,
      displayMode: displayMode,
      onSortChanged: onSortChanged,
      onDisplayChanged: onDisplayChanged,
    );
  }
}
