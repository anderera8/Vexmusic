// lib/screens/home/home_enums.dart
// Shared enums used by HomeScreen and HomeAudioPage.

enum SortField { title, date, size }

enum SortDir { asc, desc }

enum DisplayMode { list, grid }

enum GroupBy { name, folder }
