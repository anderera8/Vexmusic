import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/track_art_widget.dart';

class HomeMediaItem {
  final Track track;
  final DateTime sortDate;
  final bool resumeFromHistory;

  const HomeMediaItem._({
    required this.track,
    required this.sortDate,
    this.resumeFromHistory = false,
  });

  factory HomeMediaItem.audio(
    Track track, [
    DateTime? sortDate,
    bool resumeFromHistory = false,
  ]) =>
      HomeMediaItem._(
        track: track,
        sortDate:
            sortDate ?? DateTime.fromMillisecondsSinceEpoch(track.dateAdded),
        resumeFromHistory: resumeFromHistory,
      );

  String get title => track.title;
  String get subtitle => track.artist;
  String get key => 'audio_${track.id}';

  static List<HomeMediaItem> recentlyAdded(MusicProvider music) {
    final items = music.tracks.map(HomeMediaItem.audio).toList()
      ..sort((a, b) => b.sortDate.compareTo(a.sortDate));
    return items.take(20).toList();
  }

  static List<HomeMediaItem> recentlyPlayed(MusicProvider music) {
    final tracksById = {for (final track in music.tracks) track.id: track};
    final items = <HomeMediaItem>[];
    final seen = <String>{};

    for (final history in music.recentHistory) {
      final track = tracksById[history.trackId];
      if (track != null && seen.add('audio_${track.id}')) {
        items.add(HomeMediaItem.audio(track, history.playedAt, true));
      }
    }
    items.sort((a, b) => b.sortDate.compareTo(a.sortDate));
    return items.take(20).toList();
  }
}

class DashSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<HomeMediaItem> items;

  const DashSection({
    super.key,
    required this.title,
    required this.icon,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final cardWidth =
        (MediaQuery.sizeOf(context).width * 0.3).clamp(104.0, 140.0);
    final textScaler = MediaQuery.textScalerOf(context);
    final scaledTextHeight =
        textScaler.scale(11) * 1.2 + textScaler.scale(10) * 1.2 + 16;
    final textAreaHeight = scaledTextHeight < 48 ? 48.0 : scaledTextHeight;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
          child: Row(
            children: [
              Icon(icon, size: 16, color: theme.accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.text,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: cardWidth + textAreaHeight,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Padding(
                key: ValueKey('dash_${item.key}'),
                padding: const EdgeInsets.only(right: 10),
                child: Material(
                  color: theme.surface,
                  borderRadius: BorderRadius.circular(14),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => _play(context, index),
                    child: SizedBox(
                      width: cardWidth,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: cardWidth,
                            height: cardWidth,
                            child: TrackArtWidget(
                              artPath: item.track.artPath,
                              albumId: item.track.albumId,
                              mediaStoreId: item.track.mediaStoreId,
                              volumeName: item.track.volumeName,
                              stableKey: item.track.stableKey,
                              trackId: item.track.id,
                              size: cardWidth,
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    item.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 11,
                                      height: 1.2,
                                      fontWeight: FontWeight.w600,
                                      color: theme.text,
                                    ),
                                  ),
                                  Text(
                                    item.subtitle,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 10,
                                      height: 1.2,
                                      color: theme.muted,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

   void _play(BuildContext context, int index) {
    if (index < 0 || index >= items.length) return;

    final music = context.read<MusicProvider>();
    final item = items[index];

    // Recently Played keeps resume behavior so the user can continue from the
    // stored position. Other dashboard sections should play their visible list
    // as the active queue, not silently fall back to the full library queue.
    if (item.resumeFromHistory) {
      music.resumeTrack(item.track);
      return;
    }

    final queue = items.map((entry) => entry.track).toList(growable: false);
    music.playQueue(queue, index);
  }
}
