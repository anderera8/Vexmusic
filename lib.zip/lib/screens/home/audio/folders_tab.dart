// lib/screens/home/audio/folders_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Folders tab — list/grid of folder groups with tap-to-navigate.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../widgets/sound_wave_indicator.dart';
import '../../folders/folder_detail_screen.dart';
import '../home_enums.dart';
import 'audio_collection_sort.dart';
import 'audio_library_index.dart';
import 'widgets/audio_empty_state.dart';

class FoldersTab extends StatelessWidget {
  final String query;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const FoldersTab({
    super.key,
    required this.query,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
  });

  @override
  Widget build(BuildContext context) {
    final tracks = context
        .select<MusicProvider, List<Track>>((provider) => provider.tracks);
    final activeFolder = context.select<MusicProvider, String>((provider) =>
        provider.activeContextType == ActiveContextType.folder
            ? provider.activeContextName
            : '');
    final theme = context.watch<ThemeProvider>();

    final index = AudioLibraryIndex.of(tracks);
    var entries = index.tracksByFolder.entries.toList()
      ..sort((a, b) => compareAudioCollections(
            leftName: a.key,
            leftTracks: a.value,
            rightName: b.key,
            rightTracks: b.value,
            field: sortField,
            direction: sortDir,
          ));

    if (query.isNotEmpty) {
      entries =
          entries.where((e) => e.key.toLowerCase().contains(query)).toList();
    }

    if (entries.isEmpty) {
      return AudioEmptyState(
        message:
            query.isNotEmpty ? 'No folders match "$query"' : 'No folders found',
        icon: Icons.folder_open_rounded,
      );
    }

    if (displayMode == DisplayMode.grid) {
      return GridView.builder(
        key: const PageStorageKey<String>('audio-folders-grid'),
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 240,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemCount: entries.length,
        itemBuilder: (ctx, i) {
          final e = entries[i];
          return GestureDetector(
            onTap: () => Navigator.push(
              ctx,
              MaterialPageRoute(
                builder: (_) =>
                    FolderDetailScreen(folderName: e.key, tracks: e.value),
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: theme.border, width: 0.5),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.folder_rounded, color: theme.accent, size: 36),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Text(e.key,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: theme.text),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center),
                  ),
                  const SizedBox(height: 2),
                  Text('${e.value.length} tracks',
                      style: TextStyle(fontSize: 10, color: theme.muted)),
                ],
              ),
            ),
          );
        },
      );
    }

    return ListView.builder(
      key: const PageStorageKey<String>('audio-folders-list'),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      itemCount: entries.length,
      itemBuilder: (ctx, i) {
        final e = entries[i];
        final isActive = activeFolder == e.key;
        return GestureDetector(
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(
              builder: (_) =>
                  FolderDetailScreen(folderName: e.key, tracks: e.value),
            ),
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: theme.surface,
              border: Border.all(
                color: isActive
                    ? theme.accent.withValues(alpha: 0.5)
                    : theme.border,
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: isActive
                        ? theme.accent.withValues(alpha: 0.15)
                        : theme.accent.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: isActive
                      ? SoundWaveIndicator(color: theme.accent, size: 28)
                      : Icon(Icons.folder_rounded,
                          color: theme.accent, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(e.key,
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: isActive ? theme.accent : theme.text),
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 3),
                      Text(
                          '${e.value.length} track${e.value.length != 1 ? 's' : ''}',
                          style: TextStyle(fontSize: 12, color: theme.muted)),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right, color: theme.muted, size: 20),
              ],
            ),
          ),
        );
      },
    );
  }
}
