// lib/screens/home/audio/tracks_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Tracks tab — list/grid view of all tracks with search filtering.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/ads/interstitial_ad_controller.dart';
import '../../../widgets/ads/ad_banner_bar.dart';
import '../../../widgets/model_sheet.dart';
import '../../../widgets/toast.dart';
import '../../../widgets/track_art_widget.dart';
import '../../../widgets/track_tile.dart';
import '../home_enums.dart';
import 'widgets/audio_empty_state.dart';

class TracksTab extends StatefulWidget {
  final String query;
  final List<Track> Function(List<Track>) sortFn;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const TracksTab({
    super.key,
    required this.query,
    required this.sortFn,
    required this.sortField,
    this.sortDir = SortDir.asc,
    required this.displayMode,
  });

  @override
  State<TracksTab> createState() => _TracksTabState();
}

class _TracksTabState extends State<TracksTab> {
  List<Track>? _source;
  String? _query;
  SortField? _sortField;
  SortDir? _sortDir;
  List<Track> _filtered = const [];

  void _refresh(List<Track> tracks) {
    if (identical(_source, tracks) &&
        _query == widget.query &&
        _sortField == widget.sortField &&
        _sortDir == widget.sortDir) {
      return;
    }

    _source = tracks;
    _query = widget.query;
    _sortField = widget.sortField;
    _sortDir = widget.sortDir;

    var filtered = widget.sortFn(tracks);

    if (widget.query.isNotEmpty) {
      final query = widget.query.toLowerCase();

      filtered = filtered
          .where(
            (track) =>
                track.title.toLowerCase().contains(query) ||
                track.artist.toLowerCase().contains(query),
          )
          .toList();
    }

    _filtered = filtered;
  }

  @override
  Widget build(BuildContext context) {
    final tracks = context.select<MusicProvider, List<Track>>((p) => p.tracks);
    final isLoading =
        context.select<MusicProvider, bool>((provider) => provider.isLoading);
    final theme = context.watch<ThemeProvider>();

    if (isLoading) {
      return Center(child: CircularProgressIndicator(color: theme.accent));
    }

    if (tracks.isEmpty) {
      return AudioEmptyState(
        message: 'No audio found on this device',
        icon: Icons.music_off_rounded,
        action: TextButton.icon(
          onPressed: context.read<MusicProvider>().loadLibrary,
          icon: const Icon(Icons.refresh),
          label: const Text('Scan again'),
        ),
      );
    }

    _refresh(tracks);

    if (_filtered.isEmpty) {
      return AudioEmptyState(
        message: 'No tracks match "${widget.query}"',
        icon: Icons.search_off_rounded,
      );
    }

    return widget.displayMode == DisplayMode.grid
        ? _TrackGrid(tracks: _filtered)
        : _TrackList(
            tracks: _filtered,
            alphabetFastScroll: widget.sortField == SortField.title,
          );
  }
}

void showTrackMenu(BuildContext context, Track track) {
  final music = context.read<MusicProvider>();
  final isLiked = track.liked;

  showSideSheet(
    context,
    title: track.title,
    body: track.artist,
    verticalActions: true,
    actions: [
      ModalAction(
        label: isLiked ? 'Unlike' : 'Like',
        cls: isLiked ? 'danger' : 'primary',
        action: () {
          music.toggleLike(track.id);
          InterstitialAdController.maybeShow(
            InterstitialTrigger.favoriteToggled,
          );
        },
      ),
      ModalAction(
        label: 'Add to queue',
        action: () => music.enqueueTrack(track),
      ),
      ModalAction(
        label: 'Add to Playlist',
        popAfter: false,
        action: () => _showAddToPlaylist(context, music, track),
      ),
      ModalAction(
        label: 'Share',
        action: () => music.shareTrack(track.id),
      ),
      ModalAction(label: 'Cancel', action: () {}),
    ],
  );
}

void _showAddToPlaylist(
  BuildContext context,
  MusicProvider music,
  Track track,
) {
  Navigator.pop(context);

  Future.delayed(const Duration(milliseconds: 350), () {
    if (!context.mounted) return;

    if (music.playlists.isEmpty) {
      VibesToast.show(context, 'Create a playlist first in the Playlists tab');
      return;
    }

    final theme = context.read<ThemeProvider>();

    showModalSheet(
      context,
      title: 'Add to Playlist',
      body: 'Select a playlist:',
      actions: [ModalAction(label: 'Cancel', action: () {})],
      extra: Column(
        children: music.playlists.map((playlist) {
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Navigator.pop(context);
              music.addTrackToPlaylist(playlist.id, track.id);
              VibesToast.show(context, 'Added to "${playlist.name}"');
              InterstitialAdController.maybeShow(
                InterstitialTrigger.playlistAction,
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: theme.surface2,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Text(playlist.art, style: const TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          playlist.name,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: theme.text,
                          ),
                        ),
                        Text(
                          '${playlist.trackCount} tracks',
                          style: TextStyle(fontSize: 11, color: theme.muted),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.add_rounded, size: 18, color: theme.accent),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  });
}

class _TrackList extends StatefulWidget {
  final List<Track> tracks;
  final bool alphabetFastScroll;

  const _TrackList({
    required this.tracks,
    required this.alphabetFastScroll,
  });

  @override
  State<_TrackList> createState() => _TrackListState();
}

class _TrackListState extends State<_TrackList> {
  static const double _rowExtent = 84;
  static const int _adEvery = 10;

  final ScrollController _scrollController = ScrollController();
  String? _activeLetter;

  /// Interleaves an ad slot (`null`) after every [_adEvery] tracks. A
  /// non-null entry is the index of that track within `widget.tracks`,
  /// so playback/tap handling keeps working against the real track list
  /// unchanged — only the *rendered* list gets ad rows spliced in.
  List<int?> get _refs {
    final refs = <int?>[];
    for (var i = 0; i < widget.tracks.length; i++) {
      refs.add(i);
      // Ads are disabled app-wide right now (AdBannerBar.adsEnabled). Skip
      // splicing in ad rows entirely in that case — with a fixed itemExtent
      // ListView, a spliced-in row still reserves _rowExtent of blank space
      // even when AdBannerBar itself renders as SizedBox.shrink(), so the
      // slot has to not exist at all rather than just render empty.
      if (!AdBannerBar.adsEnabled) continue;
      final isEndOfGroup = (i + 1) % _adEvery == 0;
      final isLastTrack = i == widget.tracks.length - 1;
      if (isEndOfGroup && !isLastTrack) refs.add(null);
    }
    return refs;
  }

  /// Converts a track's index within `widget.tracks` to its index in the
  /// ad-interleaved rendered list, so alphabet fast-scroll still lands on
  /// the right row once ad rows have shifted everything after them down.
  int _renderedIndexFor(int trackIndex) => AdBannerBar.adsEnabled
      ? trackIndex + (trackIndex ~/ _adEvery)
      : trackIndex;

  Map<String, int> get _letterIndexes {
    final indexes = <String, int>{};

    for (var index = 0; index < widget.tracks.length; index++) {
      indexes.putIfAbsent(_letterFor(widget.tracks[index].title), () => index);
    }

    return indexes;
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final keyboardOpen = MediaQuery.viewInsetsOf(context).bottom > 0;
    final bottomSafePadding = MediaQuery.viewPaddingOf(context).bottom;

    final indexes =
        widget.alphabetFastScroll ? _letterIndexes : const <String, int>{};

    final showAlphabetRail =
        widget.alphabetFastScroll && indexes.length > 1 && !keyboardOpen;

    final refs = _refs;

    return Stack(
      children: [
        ListView.builder(
          controller: _scrollController,
          key: const PageStorageKey<String>('audio-tracks-list'),
          padding: EdgeInsets.fromLTRB(
            16,
            12,
            showAlphabetRail ? 34 : 16,
            16 + bottomSafePadding,
          ),
          itemExtent: _rowExtent,
          itemCount: refs.length,
          itemBuilder: (ctx, idx) {
            final trackIndex = refs[idx];

            if (trackIndex == null) {
              return const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: AdBannerBar(inline: true),
              );
            }

            final track = widget.tracks[trackIndex];

            return KeyedSubtree(
              key: ValueKey<int>(track.id),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TrackTile(
                  track: track,
                  onTap: () {
                    final music = context.read<MusicProvider>();
                    music.playQueue(widget.tracks, trackIndex);
                  },
                  onMenuTap: () => showTrackMenu(ctx, track),
                ),
              ),
            );
          },
        ),
        if (showAlphabetRail)
          Positioned(
            top: 8,
            right: 2,
            bottom: 8,
            child: _AlphabetRail(
              key: const Key('track-alphabet-rail'),
              letters: indexes.keys.toList(growable: false),
              onLetter: (letter) => _jumpToLetter(letter, indexes),
              onEnd: () => setState(() => _activeLetter = null),
            ),
          ),
        if (_activeLetter != null)
          Center(
            child: Container(
              key: const Key('track-alphabet-overlay'),
              width: 64,
              height: 64,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: theme.surface.withValues(alpha: 0.94),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: theme.border),
              ),
              child: Text(
                _activeLetter!,
                style: TextStyle(
                  color: theme.accent,
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
      ],
    );
  }

  void _jumpToLetter(
    String letter,
    Map<String, int> indexes,
  ) {
    final index = indexes[letter];
    if (index == null || !_scrollController.hasClients) return;

    setState(() => _activeLetter = letter);

    final target = (_renderedIndexFor(index) * _rowExtent).clamp(
      0.0,
      _scrollController.position.maxScrollExtent,
    );

    _scrollController.jumpTo(target);
  }

  static String _letterFor(String title) {
    final trimmed = title.trimLeft();
    if (trimmed.isEmpty) return '#';

    final letter = trimmed[0].toUpperCase();
    return RegExp(r'[A-Z]').hasMatch(letter) ? letter : '#';
  }
}

class _AlphabetRail extends StatelessWidget {
  final List<String> letters;
  final ValueChanged<String> onLetter;
  final VoidCallback onEnd;

  const _AlphabetRail({
    super.key,
    required this.letters,
    required this.onLetter,
    required this.onEnd,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return LayoutBuilder(
      builder: (context, constraints) {
        if (letters.isEmpty || constraints.maxHeight < 180) {
          return const SizedBox.shrink();
        }

        void select(double localY) {
          final fraction =
              (localY / constraints.maxHeight).clamp(0.0, 0.999999);
          final index = (fraction * letters.length).floor();
          onLetter(letters[index]);
        }

        final fontSize = letters.length > 22
            ? 7.0
            : letters.length > 18
                ? 8.0
                : 10.0;

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (details) => select(details.localPosition.dy),
          onVerticalDragStart: (details) => select(details.localPosition.dy),
          onVerticalDragUpdate: (details) => select(details.localPosition.dy),
          onVerticalDragEnd: (_) => onEnd(),
          onVerticalDragCancel: onEnd,
          child: SizedBox(
            width: 28,
            height: double.infinity,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.center,
              child: SizedBox(
                width: 28,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final letter in letters)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 1),
                        child: Text(
                          letter,
                          style: TextStyle(
                            color: theme.accent,
                            fontSize: fontSize,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TrackGrid extends StatelessWidget {
  final List<Track> tracks;
  static const int _adEvery = 10;

  const _TrackGrid({required this.tracks});

  @override
  Widget build(BuildContext context) {
    final currentTrackId = context.select<MusicProvider, int>(
      (provider) => provider.currentTrack.id,
    );
    final bottomSafePadding = MediaQuery.viewPaddingOf(context).bottom;

    return LayoutBuilder(
      builder: (context, constraints) {
        final usableWidth = (constraints.maxWidth - 32).clamp(0.0, 10000.0);

        final crossAxisCount =
            ((usableWidth / 170).floor()).clamp(2, 4).toInt();

        final tileWidth =
            (usableWidth - ((crossAxisCount - 1) * 12)) / crossAxisCount;

        final tileHeight = (tileWidth + 64).clamp(190.0, 290.0);

        // A plain GridView.builder can't host a full-width row mid-grid,
        // so tracks are split into chunks of _adEvery and rendered as
        // their own SliverGrid, with an ad SliverToBoxAdapter (also
        // full-width) spliced in after every full chunk except the last
        // — same "never end on an ad" rule as the list view.
        final slivers = <Widget>[
          const SliverToBoxAdapter(child: SizedBox(height: 16)),
        ];

        for (var start = 0; start < tracks.length; start += _adEvery) {
          final end = (start + _adEvery < tracks.length)
              ? start + _adEvery
              : tracks.length;
          final chunkLength = end - start;

          slivers.add(
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  mainAxisExtent: tileHeight,
                ),
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    final trackIndex = start + i;
                    final track = tracks[trackIndex];
                    return _TrackGridCard(
                      track: track,
                      isActive: currentTrackId == track.id,
                      onTap: () {
                        final music = context.read<MusicProvider>();
                        music.playQueue(tracks, trackIndex);
                      },
                    );
                  },
                  childCount: chunkLength,
                ),
              ),
            ),
          );

          final isFullChunk = chunkLength == _adEvery;
          final isLastChunk = end == tracks.length;
          if (AdBannerBar.adsEnabled && isFullChunk && !isLastChunk) {
            slivers.add(
              const SliverToBoxAdapter(child: AdBannerBar(inline: true)),
            );
          }
        }

        slivers.add(
          SliverToBoxAdapter(
            child: SizedBox(height: 16 + bottomSafePadding),
          ),
        );

        return CustomScrollView(
          key: const PageStorageKey<String>('audio-tracks-grid'),
          slivers: slivers,
        );
      },
    );
  }
}

class _TrackGridCard extends StatelessWidget {
  final Track track;
  final bool isActive;
  final VoidCallback onTap;

  const _TrackGridCard({
    required this.track,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isActive
                ? theme.accent.withValues(alpha: 0.6)
                : theme.border,
            width: isActive ? 1.5 : 0.5,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 1,
              child: TrackArtWidget(
                artPath: track.artPath,
                albumId: track.albumId,
                mediaStoreId: track.mediaStoreId,
                volumeName: track.volumeName,
                stableKey: track.stableKey,
                trackId: track.id,
                size: double.infinity,
                borderRadius: 0,
                defaultIconColor: theme.accent,
              ),
            ),
            SizedBox(
              height: 58,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isActive ? theme.accent : theme.text,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      track.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 11,
                        color: theme.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
