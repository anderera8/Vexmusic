// lib/screens/home/audio/albums_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// albums tab — grid of albums with artwork and tap-to-play.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../widgets/ads/ad_banner_bar.dart';
import '../../../widgets/track_art_widget.dart';
import '../../albums/albums_detail_screen.dart';
import '../home_enums.dart';
import 'audio_collection_sort.dart';
import 'audio_library_index.dart';
import 'widgets/audio_empty_state.dart';

class AlbumsTab extends StatelessWidget {
  final String query;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const AlbumsTab({
    super.key,
    required this.query,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final sourcealbums = context
        .select<MusicProvider, List<Album>>((provider) => provider.albums);
    final tracks = context
        .select<MusicProvider, List<Track>>((provider) => provider.tracks);
    final index = AudioLibraryIndex.of(tracks);
    final albums = (query.isEmpty
        ? sourcealbums.toList()
        : sourcealbums
            .where((a) => a.name.toLowerCase().contains(query))
            .toList())
      ..sort((a, b) => compareAudioCollections(
            leftName: a.name,
            leftTracks: index.tracksByalbum[a.id] ?? const [],
            rightName: b.name,
            rightTracks: index.tracksByalbum[b.id] ?? const [],
            field: sortField,
            direction: sortDir,
          ));

    final Widget content;

    if (albums.isEmpty) {
      content = AudioEmptyState(
          message: query.isEmpty ? 'No albums found' : 'No results',
          icon: Icons.album_rounded);
    } else if (displayMode == DisplayMode.list) {
      content = ListView.builder(
        key: const PageStorageKey<String>('audio-albums-list'),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        itemCount: albums.length,
        itemBuilder: (context, i) {
          final album = albums[i];
          final albumTracks = index.tracksByalbum[album.id] ?? const <Track>[];
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: SizedBox(
              width: 52,
              height: 52,
              child: TrackArtWidget(
                artPath: albumTracks.isEmpty ? null : albumTracks.first.artPath,
                albumId: album.id,
                mediaStoreId:
                    albumTracks.isEmpty ? null : albumTracks.first.mediaStoreId,
                volumeName:
                    albumTracks.isEmpty ? null : albumTracks.first.volumeName,
                stableKey:
                    albumTracks.isEmpty ? '' : albumTracks.first.stableKey,
                trackId: albumTracks.isEmpty ? null : albumTracks.first.id,
                size: 52,
              ),
            ),
            title: Text(album.name,
                style: TextStyle(
                    color: theme.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w600)),
            subtitle: Text('${albumTracks.length} tracks',
                style: TextStyle(color: theme.muted, fontSize: 12)),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AlbumDetailScreen(album: album),
              ),
            ),
          );
        },
      );
    } else {
      content = GridView.builder(
        key: const PageStorageKey<String>('audio-albums-grid'),
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 240,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.85,
        ),
        itemCount: albums.length,
        itemBuilder: (context, i) {
          final album = albums[i];
          final albumTracks = index.tracksByalbum[album.id] ?? const <Track>[];
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AlbumDetailScreen(album: album),
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: theme.border, width: 0.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(14)),
                      child: albumTracks.isNotEmpty
                          ? TrackArtWidget(
                              artPath: albumTracks.first.artPath,
                              albumId: albumTracks.first.albumId,
                              mediaStoreId: albumTracks.first.mediaStoreId,
                              volumeName: albumTracks.first.volumeName,
                              stableKey: albumTracks.first.stableKey,
                              trackId: albumTracks.first.id,
                              size: double.infinity)
                          : Container(
                              color: theme.surface2,
                              child: Icon(Icons.album_rounded,
                                  color: theme.muted, size: 40),
                            ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(album.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: theme.text)),
                        Text('${albumTracks.length} tracks',
                            style:
                                TextStyle(fontSize: 11, color: theme.muted)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Column(
      children: [
        Expanded(child: content),
        const AdBannerBar(),
      ],
    );
  }
}
