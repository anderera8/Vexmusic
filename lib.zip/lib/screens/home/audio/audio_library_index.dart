import '../../../models/music_models.dart';

class AudioLibraryIndex {
  static final Expando<AudioLibraryIndex> _cache =
      Expando<AudioLibraryIndex>('audio-library-index');

  final Map<int, Track> trackById;
  final Map<int, List<Track>> tracksByalbum;
  final Map<String, List<Track>> tracksByArtist;
  final Map<String, List<Track>> tracksByGenre;
  final Map<String, List<Track>> tracksByFolder;

  AudioLibraryIndex._(List<Track> tracks)
      : trackById = {for (final track in tracks) track.id: track},
        tracksByalbum = _groupBy<int>(
          tracks,
          (track) => track.albumId,
        ),
        tracksByArtist = _groupBy<String>(
          tracks,
          (track) => track.artist,
        ),
        tracksByGenre = _groupBy<String>(
          tracks,
          (track) => track.genre,
        ),
        tracksByFolder = _groupBy<String>(
          tracks,
          folderNameOf,
        );

  factory AudioLibraryIndex.of(List<Track> tracks) {
    return _cache[tracks] ??= AudioLibraryIndex._(tracks);
  }

  List<Track> tracksForIds(Iterable<int> ids) {
    return [
      for (final id in ids)
        if (trackById[id] case final track?) track,
    ];
  }

  static String folderNameOf(Track track) {
    final path = track.filePath;
    if (path != null && path.isNotEmpty) {
      final parts = path.split(RegExp(r'[/\\]'));
      if (parts.length >= 2) return parts[parts.length - 2];
    }
    return track.albumName ?? 'Unknown';
  }

  static Map<K, List<Track>> _groupBy<K>(
    List<Track> tracks,
    K? Function(Track) keyOf,
  ) {
    final result = <K, List<Track>>{};
    for (final track in tracks) {
      final key = keyOf(track);
      if (key != null) result.putIfAbsent(key, () => []).add(track);
    }
    return result;
  }
}
