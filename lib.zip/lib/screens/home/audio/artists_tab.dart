// lib/screens/home/audio/artists_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Artists tab — list of artists with tap-to-play-all.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../artists/artists_screen.dart';
import '../home_enums.dart';
import 'audio_collection_sort.dart';
import 'audio_library_index.dart';
import 'widgets/audio_empty_state.dart';

class ArtistsTab extends StatelessWidget {
  final String query;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const ArtistsTab({
    super.key,
    required this.query,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final sourceArtists = context
        .select<MusicProvider, List<Artist>>((provider) => provider.artists);
    final allTracks = context
        .select<MusicProvider, List<Track>>((provider) => provider.tracks);
    final index = AudioLibraryIndex.of(allTracks);
    final artists = (query.isEmpty
        ? sourceArtists.toList()
        : sourceArtists
            .where((a) => a.name.toLowerCase().contains(query))
            .toList())
      ..sort((a, b) => compareAudioCollections(
            leftName: a.name,
            leftTracks: index.tracksByArtist[a.name] ?? const [],
            rightName: b.name,
            rightTracks: index.tracksByArtist[b.name] ?? const [],
            field: sortField,
            direction: sortDir,
          ));

    if (artists.isEmpty) {
      return AudioEmptyState(
          message: query.isEmpty ? 'No artists found' : 'No results',
          icon: Icons.person_rounded);
    }

    if (displayMode == DisplayMode.grid) {
      return GridView.builder(
        key: const PageStorageKey<String>('audio-artists-grid'),
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 220,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.15,
        ),
        itemCount: artists.length,
        itemBuilder: (context, i) {
          final artist = artists[i];
          final tracks = index.tracksByArtist[artist.name] ?? const <Track>[];
          return _ArtistCard(artistName: artist.name, tracks: tracks);
        },
      );
    }

    return ListView.builder(
      key: const PageStorageKey<String>('audio-artists-list'),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: artists.length,
      itemBuilder: (context, i) {
        final artist = artists[i];
        final tracks = index.tracksByArtist[artist.name] ?? const <Track>[];
        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
          leading: CircleAvatar(
            backgroundColor: theme.accent.withValues(alpha: 0.15),
            child: Icon(Icons.person_rounded, color: theme.accent, size: 20),
          ),
          title: Text(artist.name,
              style: TextStyle(
                  color: theme.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
          subtitle: Text('${tracks.length} tracks',
              style: TextStyle(color: theme.muted, fontSize: 12)),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ArtistDetailScreen(
                artistName: artist.name,
                tracks: tracks,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ArtistCard extends StatelessWidget {
  final String artistName;
  final List<Track> tracks;

  const _ArtistCard({
    required this.artistName,
    required this.tracks,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ArtistDetailScreen(
            artistName: artistName,
            tracks: tracks,
          ),
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.surface,
          border: Border.all(color: theme.border),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 27,
              backgroundColor: theme.accent.withValues(alpha: 0.15),
              child: Icon(Icons.person_rounded, color: theme.accent, size: 26),
            ),
            const SizedBox(height: 10),
            Text(artistName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: theme.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
            Text('${tracks.length} tracks',
                style: TextStyle(color: theme.muted, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
