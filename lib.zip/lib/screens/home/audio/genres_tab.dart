// lib/screens/home/audio/genres_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Genres tab — list of genres with tap-to-play-all.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../genres/genres_screen.dart';
import '../home_enums.dart';
import 'audio_collection_sort.dart';
import 'audio_library_index.dart';
import 'widgets/audio_empty_state.dart';

class GenresTab extends StatelessWidget {
  final String query;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const GenresTab({
    super.key,
    required this.query,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final sourceGenres = context
        .select<MusicProvider, List<Genre>>((provider) => provider.genres);
    final allTracks = context
        .select<MusicProvider, List<Track>>((provider) => provider.tracks);
    final index = AudioLibraryIndex.of(allTracks);
    final genres = (query.isEmpty
        ? sourceGenres.toList()
        : sourceGenres
            .where((g) => g.name.toLowerCase().contains(query))
            .toList())
      ..sort((a, b) => compareAudioCollections(
            leftName: a.name,
            leftTracks: index.tracksForIds(a.trackIds),
            rightName: b.name,
            rightTracks: index.tracksForIds(b.trackIds),
            field: sortField,
            direction: sortDir,
          ));

    if (genres.isEmpty) {
      return AudioEmptyState(
          message: query.isEmpty ? 'No genres found' : 'No results',
          icon: Icons.category_rounded);
    }

    if (displayMode == DisplayMode.grid) {
      return GridView.builder(
        key: const PageStorageKey<String>('audio-genres-grid'),
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 220,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.2,
        ),
        itemCount: genres.length,
        itemBuilder: (context, i) {
          final genre = genres[i];
          final tracks = index.tracksForIds(genre.trackIds);
          return InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => GenreDetailScreen(genre: genre),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: theme.surface,
                border: Border.all(color: theme.border),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.category_rounded, color: theme.accent, size: 34),
                  const SizedBox(height: 10),
                  Text(genre.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: theme.text,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                  Text('${tracks.length} tracks',
                      style: TextStyle(color: theme.muted, fontSize: 11)),
                ],
              ),
            ),
          );
        },
      );
    }

    return ListView.builder(
      key: const PageStorageKey<String>('audio-genres-list'),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: genres.length,
      itemBuilder: (context, i) {
        final genre = genres[i];
        final tracks = index.tracksByGenre[genre.name] ?? const <Track>[];
        return ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 0, vertical: 2),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: theme.accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.category_rounded, color: theme.accent, size: 20),
          ),
          title: Text(genre.name,
              style: TextStyle(
                  color: theme.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w600)),
          subtitle: Text('${tracks.length} tracks',
              style: TextStyle(color: theme.muted, fontSize: 12)),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => GenreDetailScreen(genre: genre),
            ),
          ),
        );
      },
    );
  }
}
