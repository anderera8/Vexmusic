import '../../../models/music_models.dart';
import '../home_enums.dart';

int compareAudioCollections({
  required String leftName,
  required List<Track> leftTracks,
  required String rightName,
  required List<Track> rightTracks,
  required SortField field,
  required SortDir direction,
}) {
  final result = switch (field) {
    SortField.title =>
      leftName.toLowerCase().compareTo(rightName.toLowerCase()),
    SortField.date =>
      _latestDate(leftTracks).compareTo(_latestDate(rightTracks)),
    SortField.size => _totalSize(leftTracks).compareTo(_totalSize(rightTracks)),
  };
  return direction == SortDir.asc ? result : -result;
}

int _latestDate(List<Track> tracks) {
  var latest = 0;
  for (final track in tracks) {
    if (track.dateAdded > latest) latest = track.dateAdded;
  }
  return latest;
}

int _totalSize(List<Track> tracks) {
  var total = 0;
  for (final track in tracks) {
    total += track.size;
  }
  return total;
}
