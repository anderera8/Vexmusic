// lib/screens/home/audio/playlists_tab.dart
// ─────────────────────────────────────────────────────────────────────────────
// Playlists tab — list of playlists with create-new button.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../models/music_models.dart';
import '../../../providers/music_provider.dart';
import '../../../providers/theme_provider.dart';
import '../../../services/ads/interstitial_ad_controller.dart';
import '../../playlists/playlists_detail_screen.dart';
import '../home_enums.dart';
import 'audio_collection_sort.dart';
import 'audio_library_index.dart';
import 'widgets/audio_empty_state.dart';

class PlaylistsTab extends StatelessWidget {
  final String query;
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;

  const PlaylistsTab({
    super.key,
    required this.query,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
  });

  @override
  Widget build(BuildContext context) {
    final playlistsSource = context.select<MusicProvider, List<Playlist>>(
        (provider) => provider.playlists);
    final tracks = context
        .select<MusicProvider, List<Track>>((provider) => provider.tracks);
    final index = AudioLibraryIndex.of(tracks);
    final theme = context.watch<ThemeProvider>();

    var playlists = playlistsSource.toList();
    if (query.isNotEmpty) {
      playlists =
          playlists.where((p) => p.name.toLowerCase().contains(query)).toList();
    }
    playlists.sort((a, b) => compareAudioCollections(
          leftName: a.name,
          leftTracks: index.tracksForIds(a.trackIds),
          rightName: b.name,
          rightTracks: index.tracksForIds(b.trackIds),
          field: sortField,
          direction: sortDir,
        ));

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: GestureDetector(
            onTap: () =>
                _createPlaylist(context, context.read<MusicProvider>()),
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                color: theme.accent.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: theme.accent.withValues(alpha: 0.25)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_rounded, size: 18, color: theme.accent),
                  const SizedBox(width: 6),
                  Text('New playlist',
                      style: TextStyle(
                          color: theme.accent,
                          fontWeight: FontWeight.w600,
                          fontSize: 13)),
                ],
              ),
            ),
          ),
        ),
        if (playlists.isEmpty)
          Expanded(
            child: AudioEmptyState(
              message: query.isNotEmpty
                  ? 'No playlists match "$query"'
                  : 'No playlists yet',
              icon: Icons.playlist_play_rounded,
            ),
          )
        else
          Expanded(
            child: displayMode == DisplayMode.grid
                ? GridView.builder(
                    key: const PageStorageKey<String>('audio-playlists-grid'),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 220,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.2,
                    ),
                    itemCount: playlists.length,
                    itemBuilder: (ctx, i) =>
                        _PlaylistGridCard(playlist: playlists[i]),
                  )
                : ListView.builder(
                    key: const PageStorageKey<String>('audio-playlists-list'),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: playlists.length,
                    itemBuilder: (ctx, i) {
                      final pl = playlists[i];
                      return GestureDetector(
                        onTap: () => Navigator.push(
                          ctx,
                          MaterialPageRoute(
                            builder: (_) => PlaylistDetailScreen(playlist: pl),
                          ),
                        ),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          margin: const EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                            color: theme.surface,
                            border: Border.all(color: theme.border),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: theme.accent.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                alignment: Alignment.center,
                                child: Icon(Icons.queue_music_rounded,
                                    color: theme.accent, size: 24),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(pl.name,
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w600,
                                            color: theme.text),
                                        overflow: TextOverflow.ellipsis),
                                    Text(
                                      '${pl.trackIds.length} track${pl.trackIds.length != 1 ? 's' : ''}',
                                      style: TextStyle(
                                          fontSize: 12, color: theme.muted),
                                    ),
                                  ],
                                ),
                              ),
                              Icon(Icons.chevron_right,
                                  color: theme.muted, size: 20),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
      ],
    );
  }

  Future<void> _createPlaylist(
      BuildContext context, MusicProvider music) async {
    final ctrl = TextEditingController();
    final theme = context.read<ThemeProvider>();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: theme.surface,
        title: Text('New playlist', style: TextStyle(color: theme.text)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: TextStyle(color: theme.text),
          decoration: InputDecoration(
            hintText: 'Playlist name',
            hintStyle: TextStyle(color: theme.muted),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: theme.muted))),
          TextButton(
              onPressed: () => Navigator.pop(context, ctrl.text),
              child: Text('Create', style: TextStyle(color: theme.accent))),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) {
      await music.createPlaylist(name.trim());
      unawaited(
        InterstitialAdController.maybeShow(InterstitialTrigger.playlistAction),
      );
    }
  }
}

class _PlaylistGridCard extends StatelessWidget {
  final Playlist playlist;
  const _PlaylistGridCard({required this.playlist});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PlaylistDetailScreen(playlist: playlist),
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.surface,
          border: Border.all(color: theme.border),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.queue_music_rounded, color: theme.accent, size: 36),
            const SizedBox(height: 10),
            Text(playlist.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: theme.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
            Text('${playlist.trackIds.length} tracks',
                style: TextStyle(color: theme.muted, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}
