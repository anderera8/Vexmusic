// lib/screens/home/audio/widgets/audio_search_bar.dart
// ─────────────────────────────────────────────────────────────────────────────
// Search bar used in the Audio page — text field with close button.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../providers/theme_provider.dart';

class AudioSearchBar extends StatelessWidget {
  final TextEditingController ctrl;
  final ValueChanged<String> onChanged;
  final VoidCallback onClose;

  const AudioSearchBar({
    super.key,
    required this.ctrl,
    required this.onChanged,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: ctrl,
            autofocus: true,
            style: TextStyle(color: theme.text),
            cursorColor: theme.accent,
            decoration: InputDecoration(
              hintText: 'Search audio\u2026',
              hintStyle: TextStyle(color: theme.muted),
              prefixIcon:
                  Icon(Icons.search_rounded, color: theme.muted, size: 18),
              filled: true,
              fillColor: theme.surface,
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: theme.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: theme.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: theme.accent),
              ),
            ),
            onChanged: onChanged,
          ),
        ),
        IconButton(
          icon: Icon(Icons.close_rounded, color: theme.muted, size: 20),
          onPressed: onClose,
        ),
      ],
    );
  }
}
