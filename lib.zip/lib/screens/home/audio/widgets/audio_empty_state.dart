// lib/screens/home/audio/widgets/audio_empty_state.dart
// ─────────────────────────────────────────────────────────────────────────────
// Shared empty-state placeholder used across all audio tabs.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../providers/theme_provider.dart';

class AudioEmptyState extends StatelessWidget {
  final String message;
  final IconData icon;
  final Widget? action;

  const AudioEmptyState({
    super.key,
    required this.message,
    required this.icon,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return LayoutBuilder(
      builder: (context, constraints) {
        final tight = constraints.maxHeight < 150;
        final veryTight = constraints.maxHeight < 90;

        final content = Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!veryTight) ...[
              Icon(
                icon,
                size: tight ? 36 : 56,
                color: theme.muted.withValues(alpha: 0.4),
              ),
              SizedBox(height: tight ? 8 : 16),
            ],
            Text(
              message,
              maxLines: tight ? 1 : 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: theme.muted, fontSize: tight ? 12 : 14),
              textAlign: TextAlign.center,
            ),
            if (action != null && !tight) ...[
              const SizedBox(height: 16),
              action!,
            ],
          ],
        );

        return SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          padding: EdgeInsets.all(tight ? 8 : 16),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight:
                  constraints.hasBoundedHeight ? constraints.maxHeight : 0,
            ),
            child: Center(child: content),
          ),
        );
      },
    );
  }
}
