// lib/screens/home/home_exit_dialog.dart
// ─────────────────────────────────────────────────────────────────────────────
// Exit confirmation dialog for the Home screen.

import 'package:flutter/material.dart';
import '../../providers/theme_provider.dart';

class ExitDialog extends StatelessWidget {
  final ThemeProvider theme;

  const ExitDialog({super.key, required this.theme});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: theme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Text('Exit', style: TextStyle(fontSize: 18, color: theme.text)),
      content: Text('Music is playing. Do you want to close the app?',
          style: TextStyle(fontSize: 14, color: theme.muted)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text('Minimise',
              style: TextStyle(color: theme.accent, fontSize: 14)),
        ),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
            backgroundColor: theme.danger,
            foregroundColor: Colors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          child: const Text('Close', style: TextStyle(fontSize: 14)),
        ),
      ],
    );
  }
}
