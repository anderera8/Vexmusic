// lib/screens/home/home_screen.dart
// ─────────────────────────────────────────────────────────────────────────────
// Root shell of Vibes Player after onboarding.
//
// Bottom nav: Audio | Home | Radio | Library
//
// Audio tab  → AudioLibraryTab
// Home tab   → dashboard
// Radio tab  → live internet radio (self-contained, see providers/radio_provider.dart)
// Library    → phone storage browser
//
// MiniPlayer sits above the bottom nav and shows only when local audio is
// loaded; RadioMiniPlayer takes its place whenever radio is the more
// recently active surface, so exactly one mini player is ever visible at
// once (see _buildMiniPlayer).
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../providers/music_provider.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/radio/radio_mini_player.dart';
import '../../widgets/side_drawer.dart';
import '../library/library_screen.dart';
import '../radio/radio_home_screen.dart';
import '../radio/radio_player_screen.dart';
import 'home_bottom_nav.dart';
import 'home_enums.dart';
import 'home_exit_dialog.dart';
import 'home_helpers.dart';
import 'home_tab.dart';

// ── Bottom nav indices ────────────────────────────────────────────────────────
const _kTabAudio = 0;
const _kTabHome = 1;
const _kTabRadio = 2;
const _kTabLibrary = 3;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = _kTabHome;

  // Sort / display state — shared across Home pager pages.
  SortField _sortField = SortField.title;
  SortDir _sortDir = SortDir.asc;
  DisplayMode _displayMode = DisplayMode.list;

  @override
  void initState() {
    super.initState();

    // Release-safe startup:
    // Always ask the provider to load the library when Home mounts.
    // MusicProvider.loadLibrary() now handles no-op cases internally,
    // so this does not force unnecessary rescans.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<MusicProvider>().loadLibrary();
    });
  }

  // ── Back button ───────────────────────────────────────────────────────────

  Future<bool> _onWillPop() async {
    final music = context.read<MusicProvider>();

    if (!music.hasStartedPlayback) return true;

    if (music.isPlaying && music.bgPlayback) {
      await SystemNavigator.pop();
      return false;
    }

    final theme = context.read<ThemeProvider>();

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => ExitDialog(theme: theme),
    );

    if (result == true) {
      await music.stopAndClear();
      return true;
    }

    if (result == false) {
      music.allowNextBackgroundTransition();
      await SystemNavigator.pop(animated: true);
      return false;
    }

    return false;
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;

        final shouldExit = await _onWillPop();

        if (shouldExit && mounted) {
          SystemChannels.platform.invokeMethod('SystemNavigator.pop');
        }
      },
      child: Scaffold(
        backgroundColor: theme.bg,
        drawer: const SideDrawer(),
        body: SafeArea(
          bottom: false,
          child: Column(
            children: [
              Expanded(child: _buildBody()),
              _buildMiniPlayer(),
              BottomNav(
                current: _navIndex,
                onTap: _onNavTap,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Both MiniPlayer and RadioMiniPlayer already self-hide when there's
  /// nothing loaded on their own side, but that's not enough on its own:
  /// starting music pauses radio (and vice versa) without clearing the
  /// paused side's loaded track/station — that's deliberate, so the mini
  /// player for whichever one you paused is still there, resumable in one
  /// tap, if you switch back. Which means both `radio.hasActiveStation` and
  /// `music.hasStartedPlayback` can genuinely be true at once, and mounting
  /// both widgets unconditionally would stack two mini players in this one
  /// slot. So: show whichever side is actually playing; if neither is,
  /// fall back to whichever has ever been engaged (defaulting to music,
  /// which preserves this app's exact pre-Radio behavior for anyone who's
  /// never touched the Radio tab).
  Widget _buildMiniPlayer() {
    return Consumer2<MusicProvider, RadioProvider>(
      builder: (context, music, radio, _) {
        final showRadio = radio.isPlaying ||
            (!music.isPlaying &&
                !music.hasStartedPlayback &&
                radio.hasActiveStation);

        if (showRadio) {
          return RadioMiniPlayer(
            onTap: () => RadioPlayerScreen.showCurrent(context),
          );
        }
        return MiniPlayer(
          onTap: () => Navigator.pushNamed(context, '/now-playing'),
        );
      },
    );
  }

  Widget _buildBody() {
    switch (_navIndex) {
      case _kTabAudio:
        return AudioLibraryTab(
          sortField: _sortField,
          sortDir: _sortDir,
          displayMode: _displayMode,
          onSortChanged: (field, direction) {
            setState(() {
              _sortField = field;
              _sortDir = direction;
            });
          },
          onDisplayChanged: (mode, _) {
            setState(() => _displayMode = mode);
          },
        );

      case _kTabHome:
        return const HomeTab();

      case _kTabRadio:
        return const RadioHomeScreen();

      case _kTabLibrary:
      default:
        return const LibraryScreen(embedded: true);
    }
  }

  void _onNavTap(int index) {
    if (index == _navIndex) return;
    setState(() => _navIndex = index);

    if (index == _kTabRadio) {
      // RadioProvider.loadDiscover() no-ops once its cached sections are already
      // populated, so it's safe to call this on every visit rather than
      // tracking "first visit" separately — matching how loadLibrary()
      // above already handles its own no-op case internally.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        context.read<RadioProvider>().loadDiscover();
      });
    }
  }
}
