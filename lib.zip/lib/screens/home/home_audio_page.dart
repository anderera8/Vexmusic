import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/library_options_drawer.dart';
import 'audio/albums_tab.dart';
import 'audio/artists_tab.dart';
import 'audio/folders_tab.dart';
import 'audio/genres_tab.dart';
import 'audio/playlists_tab.dart';
import 'audio/tracks_tab.dart';
import 'audio/widgets/audio_search_bar.dart';
import 'home_enums.dart';

class HomeAudioPage extends StatefulWidget {
  final SortField sortField;
  final SortDir sortDir;
  final DisplayMode displayMode;
  final void Function(SortField, SortDir) onSortChanged;
  final void Function(DisplayMode, GroupBy) onDisplayChanged;

  const HomeAudioPage({
    super.key,
    required this.sortField,
    required this.sortDir,
    required this.displayMode,
    required this.onSortChanged,
    required this.onDisplayChanged,
  });

  @override
  State<HomeAudioPage> createState() => _HomeAudioPageState();
}

class _HomeAudioPageState extends State<HomeAudioPage>
    with AutomaticKeepAliveClientMixin, SingleTickerProviderStateMixin {
  static const _tabLabels = [
    'Tracks',
    'albums',
    'Artists',
    'Genres',
    'Playlists',
    'Folders',
  ];

  late final TabController _tabs;
  final _searchCtrl = TextEditingController();
  String _query = '';
  bool _searchOpen = false;
  Timer? _searchDebounce;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: _tabLabels.length, vsync: this);
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _tabs.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    _searchDebounce?.cancel();
    final normalized = value.toLowerCase();
    if (normalized.isEmpty) {
      setState(() => _query = '');
      return;
    }
    _searchDebounce = Timer(const Duration(milliseconds: 250), () {
      if (mounted) setState(() => _query = normalized);
    });
  }

  List<Track> _sortedTracks(List<Track> source) {
    final tracks = source.toList();
    switch (widget.sortField) {
      case SortField.title:
        tracks.sort((a, b) => widget.sortDir == SortDir.asc
            ? a.title.toLowerCase().compareTo(b.title.toLowerCase())
            : b.title.toLowerCase().compareTo(a.title.toLowerCase()));
      case SortField.date:
        tracks.sort((a, b) => widget.sortDir == SortDir.asc
            ? a.dateAdded.compareTo(b.dateAdded)
            : b.dateAdded.compareTo(a.dateAdded));
      case SortField.size:
        tracks.sort((a, b) => widget.sortDir == SortDir.asc
            ? a.size.compareTo(b.size)
            : b.size.compareTo(a.size));
    }
    return tracks;
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final theme = context.watch<ThemeProvider>();

    return NestedScrollView(
      headerSliverBuilder: (context, innerBoxIsScrolled) => [
        SliverToBoxAdapter(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 12, 4),
                child: Row(
                  children: [
                    LibraryOptionsButton(
                      title: 'Audio options',
                      sections: _optionSections(),
                    ),
                    Text(
                      'Audio',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: theme.text,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      tooltip: 'Search audio',
                      icon: Icon(
                        Icons.search_rounded,
                        size: 20,
                        color: theme.muted,
                      ),
                      onPressed: () =>
                          setState(() => _searchOpen = !_searchOpen),
                    ),
                  ],
                ),
              ),
              if (_searchOpen)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: AudioSearchBar(
                    ctrl: _searchCtrl,
                    onChanged: _onSearchChanged,
                    onClose: () => setState(() {
                      _searchDebounce?.cancel();
                      _searchOpen = false;
                      _searchCtrl.clear();
                      _query = '';
                    }),
                  ),
                ),
            ],
          ),
        ),
        SliverPersistentHeader(
          pinned: true,
          delegate: _PinnedTabBarDelegate(
            color: theme.bg,
            tabBar: TabBar(
              controller: _tabs,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicator: UnderlineTabIndicator(
                borderSide: BorderSide(width: 2, color: theme.accent),
                insets: const EdgeInsets.symmetric(horizontal: 16),
              ),
              labelColor: theme.text,
              unselectedLabelColor: theme.muted,
              labelStyle:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              unselectedLabelStyle:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
              dividerColor: theme.border,
              tabs: _tabLabels.map((label) => Tab(text: label)).toList(),
            ),
          ),
        ),
      ],
      body: TabBarView(
        controller: _tabs,
        children: [
          TracksTab(
            query: _query,
            sortFn: _sortedTracks,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
          AlbumsTab(
            query: _query,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
          ArtistsTab(
            query: _query,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
          GenresTab(
            query: _query,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
          PlaylistsTab(
            query: _query,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
          FoldersTab(
            query: _query,
            sortField: widget.sortField,
            sortDir: widget.sortDir,
            displayMode: widget.displayMode,
          ),
        ],
      ),
    );
  }

  List<LibraryOptionSection> _optionSections() => [
        LibraryOptionSection(
          title: 'Sort',
          options: [
            _sortOption('Title A-Z', 'title_asc', Icons.sort_by_alpha_rounded),
            _sortOption('Title Z-A', 'title_desc', Icons.sort_by_alpha_rounded),
            _sortOption('Date: Newest', 'date_desc', Icons.today_rounded),
            _sortOption('Date: Oldest', 'date_asc', Icons.history_rounded),
            _sortOption('Size: Largest', 'size_desc', Icons.data_usage_rounded),
            _sortOption('Size: Smallest', 'size_asc', Icons.compress_rounded),
          ],
        ),
        LibraryOptionSection(
          title: 'Display',
          options: [
            LibraryOption(
              label: 'List',
              icon: Icons.view_list_rounded,
              selected: widget.displayMode == DisplayMode.list,
              onTap: () =>
                  widget.onDisplayChanged(DisplayMode.list, GroupBy.name),
            ),
            LibraryOption(
              label: 'Grid',
              icon: Icons.grid_view_rounded,
              selected: widget.displayMode == DisplayMode.grid,
              onTap: () =>
                  widget.onDisplayChanged(DisplayMode.grid, GroupBy.name),
            ),
          ],
        ),
      ];

  LibraryOption _sortOption(String label, String value, IconData icon) {
    final parts = value.split('_');
    final field = parts.first == 'title'
        ? SortField.title
        : parts.first == 'date'
            ? SortField.date
            : SortField.size;
    final direction = parts.last == 'asc' ? SortDir.asc : SortDir.desc;
    return LibraryOption(
      label: label,
      icon: icon,
      selected: widget.sortField == field && widget.sortDir == direction,
      onTap: () => widget.onSortChanged(field, direction),
    );
  }
}

class _PinnedTabBarDelegate extends SliverPersistentHeaderDelegate {
  final Color color;
  final TabBar tabBar;

  const _PinnedTabBarDelegate({
    required this.color,
    required this.tabBar,
  });

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return ColoredBox(color: color, child: tabBar);
  }

  @override
  bool shouldRebuild(covariant _PinnedTabBarDelegate oldDelegate) {
    return oldDelegate.color != color || oldDelegate.tabBar != tabBar;
  }
}
