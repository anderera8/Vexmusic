import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../models/radio_models.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/radio/radio_player_service.dart';
import '../../widgets/radio/radio_art.dart';
import '../../widgets/radio/radio_visualizer.dart';

class RadioPlayerScreen extends StatefulWidget {
  const RadioPlayerScreen({super.key});

  @override
  State<RadioPlayerScreen> createState() => _RadioPlayerScreenState();

  static Future<void> open(BuildContext context, RadioStation station) async {
    final radio = context.read<RadioProvider>();
    unawaited(radio.playStation(station));
    Navigator.push(context, _route());

    if (!station.lastCheckOk && context.mounted) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          const SnackBar(
            content: Text(
              "This station was last reported offline. We'll still try to connect.",
            ),
            behavior: SnackBarBehavior.floating,
          ),
        );
    }
  }

  static void showCurrent(BuildContext context) {
    Navigator.push(context, _route());
  }

  static Route<void> _route() => PageRouteBuilder(
        pageBuilder: (_, __, ___) => const RadioPlayerScreen(),
        transitionsBuilder: (_, animation, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 1),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 320),
      );

}

class _RadioPlayerScreenState extends State<RadioPlayerScreen> {
  String? _lastShownError;
  late final RadioProvider _radioProvider;

  @override
  void initState() {
    super.initState();
    _radioProvider = context.read<RadioProvider>();
    _radioProvider.addListener(_onRadioChanged);
  }

  void _onRadioChanged() {
    if (!mounted) return;
    final radio = _radioProvider;
    final error = radio.playbackError;
    if (radio.playbackStatus != RadioPlaybackStatus.error ||
        error == null ||
        error == _lastShownError) {
      return;
    }
    _lastShownError = error;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(error),
            behavior: SnackBarBehavior.floating,
          ),
        );
    });
  }

  @override
  void dispose() {
    _radioProvider.removeListener(_onRadioChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();
    final station = radio.currentStation;

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: station == null
            ? _NothingPlaying(theme: theme)
            : _PlayerBody(theme: theme, radio: radio, station: station),
      ),
    );
  }
}

class _NothingPlaying extends StatelessWidget {
  final ThemeProvider theme;
  const _NothingPlaying({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: Row(
            children: [
              IconButton(
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: theme.text, size: 28),
                onPressed: () => Navigator.maybePop(context),
              ),
            ],
          ),
        ),
        Expanded(
          child: Center(
            child: Text('Nothing playing', style: TextStyle(color: theme.muted)),
          ),
        ),
      ],
    );
  }
}

class _PlayerBody extends StatelessWidget {
  final ThemeProvider theme;
  final RadioProvider radio;
  final RadioStation station;

  const _PlayerBody({
    required this.theme,
    required this.radio,
    required this.station,
  });

  bool get _isBusy =>
      radio.playbackStatus == RadioPlaybackStatus.loading ||
      radio.playbackStatus == RadioPlaybackStatus.buffering;

  bool get _hasError => radio.playbackStatus == RadioPlaybackStatus.error;

  @override
  Widget build(BuildContext context) {
    final artSize =
        (MediaQuery.sizeOf(context).width * 0.68).clamp(220.0, 300.0).toDouble();
    final isFavorite = radio.isFavorite(station);

    return Column(
      children: [
        // ── Top bar ──────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
          child: Row(
            children: [
              IconButton(
                icon: Icon(Icons.keyboard_arrow_down_rounded,
                    color: theme.text, size: 28),
                onPressed: () => Navigator.maybePop(context),
                tooltip: 'Minimize',
              ),
              Expanded(
                child: Text(
                  'PLAYING FROM RADIO',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                    color: theme.muted,
                  ),
                ),
              ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _share(context),
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Icon(Icons.share_rounded, color: theme.text, size: 20),
                ),
              ),
            ],
          ),
        ),

        // ── Art + info + controls ───────────────────────────────────
        Expanded(
          child: SingleChildScrollView(
            physics: const ClampingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              children: [
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [
                      BoxShadow(
                        color: theme.accent.withValues(alpha: 0.32),
                        blurRadius: 40,
                        spreadRadius: -6,
                        offset: const Offset(0, 18),
                      ),
                    ],
                  ),
                  child: RadioArt(
                    favicon: station.favicon,
                    stationName: station.name,
                    size: artSize,
                    borderRadius: 28,
                  ),
                ),
                const SizedBox(height: 26),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: theme.danger,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _LiveDot(),
                          SizedBox(width: 5),
                          Text(
                            'LIVE',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                              letterSpacing: 0.6,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (station.bitrate > 0) ...[
                      const SizedBox(width: 8),
                      Text(
                        '${station.codec} · ${station.bitrate}kbps',
                        style: TextStyle(fontSize: 11, color: theme.muted),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 18),

                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [theme.accent, theme.accent2],
                  ).createShader(bounds),
                  child: Text(
                    station.name,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1.15,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  station.subtitle.isEmpty ? 'Internet radio' : station.subtitle,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 13, color: theme.muted),
                ),

                if (radio.nowPlayingText?.isNotEmpty == true) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: theme.surface,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: theme.border),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.music_note_rounded, size: 13, color: theme.accent),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            radio.nowPlayingText!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12, color: theme.text),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 30),

                if (_hasError)
                  _ErrorPanel(theme: theme, radio: radio)
                else ...[
                  RadioVisualizer(
                    colors: [theme.accent2, theme.accent],
                    active: radio.isPlaying,
                    height: 56,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isBusy
                        ? 'Connecting…'
                        : (radio.isPlaying ? 'On air' : 'Paused'),
                    style: TextStyle(fontSize: 12, color: theme.muted),
                  ),
                ],

                const SizedBox(height: 34),

                // ── Transport controls ──────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _SecondaryButton(
                      icon: isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      color: isFavorite ? theme.danger : theme.text,
                      onTap: () => radio.toggleFavorite(station),
                      label: isFavorite ? 'Remove from favorites' : 'Add to favorites',
                    ),
                    const SizedBox(width: 26),
                    _PlayPauseButton(theme: theme, radio: radio),
                    const SizedBox(width: 26),
                    _SecondaryButton(
                      icon: Icons.stop_rounded,
                      color: theme.text,
                      onTap: () async {
                        await radio.stopAndClear();
                        if (context.mounted) Navigator.maybePop(context);
                      },
                      label: 'Stop',
                    ),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _share(BuildContext context) {
    final link = station.homepage.isNotEmpty ? '\n${station.homepage}' : '';
    SharePlus.instance.share(
      ShareParams(
        text: 'Listening to ${station.name} on Vibes Player 📻$link',
      ),
    );
  }
}

class _LiveDot extends StatefulWidget {
  const _LiveDot();
  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween(begin: 0.4, end: 1.0).animate(_ctrl),
      child: const SizedBox(
        width: 6,
        height: 6,
        child: DecoratedBox(
          decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
        ),
      ),
    );
  }
}

class _PlayPauseButton extends StatelessWidget {
  final ThemeProvider theme;
  final RadioProvider radio;
  const _PlayPauseButton({required this.theme, required this.radio});

  bool get _isBusy =>
      radio.playbackStatus == RadioPlaybackStatus.loading ||
      radio.playbackStatus == RadioPlaybackStatus.buffering;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => radio.togglePlayPause(),
      child: Semantics(
        label: radio.isPlaying ? 'Pause' : 'Play',
        button: true,
        child: Container(
          width: 76,
          height: 76,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [theme.accent, theme.accent2],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: theme.accent.withValues(alpha: 0.4),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: _isBusy
              ? const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                )
              : Icon(
                  radio.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 36,
                ),
        ),
      ),
    );
  }
}

class _SecondaryButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final String label;

  const _SecondaryButton({
    required this.icon,
    required this.color,
    required this.onTap,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Semantics(
        label: label,
        button: true,
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withValues(alpha: 0.08),
          ),
          alignment: Alignment.center,
          child: Icon(icon, color: color, size: 22),
        ),
      ),
    );
  }
}

class _ErrorPanel extends StatelessWidget {
  final ThemeProvider theme;
  final RadioProvider radio;
  const _ErrorPanel({required this.theme, required this.radio});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(
          radio.isOffline
              ? Icons.cloud_off_rounded
              : Icons.error_outline_rounded,
          size: 34,
          color: theme.danger,
        ),
        const SizedBox(height: 10),
        Text(
          radio.playbackError ?? "Couldn't play this station.",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 13, color: theme.muted),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => radio.retryCurrentStation(),
          style: FilledButton.styleFrom(backgroundColor: theme.accent),
          icon: const Icon(Icons.refresh_rounded, size: 18),
          label: const Text('Try again'),
        ),
      ],
    );
  }
}
