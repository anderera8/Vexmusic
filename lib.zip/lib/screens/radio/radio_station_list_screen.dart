import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/radio_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/radio/radio_station_tile.dart';
import 'radio_player_screen.dart';

class RadioStationListScreen extends StatefulWidget {
  final String title;
  final Future<List<RadioStation>> Function() fetcher;
  final String emptyMessage;

  const RadioStationListScreen({
    super.key,
    required this.title,
    required this.fetcher,
    this.emptyMessage = 'No stations found here yet.',
  });

  @override
  State<RadioStationListScreen> createState() =>
      _RadioStationListScreenState();
}

class _RadioStationListScreenState extends State<RadioStationListScreen> {
  List<RadioStation>? _stations;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final music = context.read<MusicProvider>();
      final radio = context.read<RadioProvider>();
      if (!music.isPlaying && !radio.isPlaying) {
        unawaited(
          InterstitialAdController.maybeShow(InterstitialTrigger.radioBrowse),
        );
      }
    });
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await widget.fetcher();
      if (!mounted) return;
      setState(() {
        _stations = result;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(
        backgroundColor: theme.bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: theme.text),
        title: Text(
          widget.title,
          style: TextStyle(color: theme.text, fontWeight: FontWeight.w700),
        ),
      ),
      body: Column(
        children: [
          Expanded(child: _buildBody(theme, radio)),
          const AdBannerBar(),
        ],
      ),
    );
  }

  Widget _buildBody(ThemeProvider theme, RadioProvider radio) {
    if (_loading) {
      return Center(child: CircularProgressIndicator(color: theme.accent));
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded,
                  size: 44, color: theme.muted.withValues(alpha: 0.5)),
              const SizedBox(height: 12),
              Text(
                "Couldn't load stations. Check your connection.",
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.muted, fontSize: 14),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _load,
                style: FilledButton.styleFrom(backgroundColor: theme.accent),
                child: const Text('Try again'),
              ),
            ],
          ),
        ),
      );
    }

    final stations = _stations ?? const [];
    if (stations.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.radio_rounded,
                  size: 44, color: theme.muted.withValues(alpha: 0.4)),
              const SizedBox(height: 12),
              Text(
                widget.emptyMessage,
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.muted, fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      color: theme.accent,
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: stations.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final station = stations[index];
          final isActive = radio.currentStation?.uuid == station.uuid;
          return RadioStationTile(
            key: ValueKey('radio_list_${station.uuid}'),
            station: station,
            isActive: isActive,
            isPlaying: isActive && radio.isPlaying,
            isFavorite: radio.isFavorite(station),
            onTap: () => RadioPlayerScreen.open(context, station),
            onFavoriteTap: () => radio.toggleFavorite(station),
          );
        },
      ),
    );
  }
}
