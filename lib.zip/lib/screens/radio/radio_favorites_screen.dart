import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/radio/radio_station_tile.dart';
import 'radio_player_screen.dart';

class RadioFavoritesScreen extends StatefulWidget {
  const RadioFavoritesScreen({super.key});

  @override
  State<RadioFavoritesScreen> createState() => _RadioFavoritesScreenState();
}

class _RadioFavoritesScreenState extends State<RadioFavoritesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;

      final music = context.read<MusicProvider>();
      final radio = context.read<RadioProvider>();
      if (!music.isPlaying && !radio.isPlaying) {
        unawaited(
          InterstitialAdController.maybeShow(InterstitialTrigger.radioBrowse),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();
    final favorites = radio.favorites;

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(
        backgroundColor: theme.bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: theme.text),
        title: Text(
          'Your Favorites',
          style: TextStyle(color: theme.text, fontWeight: FontWeight.w700),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: favorites.isEmpty
                ? _emptyState(theme)
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: favorites.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final station = favorites[index];
                      final isActive =
                          radio.currentStation?.uuid == station.uuid;
                      return RadioStationTile(
                        key: ValueKey('radio_fav_${station.uuid}'),
                        station: station,
                        isActive: isActive,
                        isPlaying: isActive && radio.isPlaying,
                        isFavorite: true,
                        onTap: () => RadioPlayerScreen.open(context, station),
                        onFavoriteTap: () => radio.toggleFavorite(station),
                      );
                    },
                  ),
          ),
          const AdBannerBar(),
        ],
      ),
    );
  }

  Widget _emptyState(ThemeProvider theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.favorite_border_rounded,
                size: 44, color: theme.muted.withValues(alpha: 0.4)),
            const SizedBox(height: 12),
            Text(
              'No favorite stations yet',
              style: TextStyle(
                color: theme.text,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Tap the heart on any station to save it here.',
              textAlign: TextAlign.center,
              style: TextStyle(color: theme.muted, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
