import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/radio_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/radio/radio_station_tile.dart';
import 'radio_player_screen.dart';

class RadioSearchScreen extends StatefulWidget {
  const RadioSearchScreen({super.key});

  @override
  State<RadioSearchScreen> createState() => _RadioSearchScreenState();
}

class _RadioSearchScreenState extends State<RadioSearchScreen> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  Timer? _debounce;

  List<RadioStation>? _results;
  bool _loading = false;
  String? _error;
  bool _hasShownInterstitial = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    setState(() {});

    _debounce?.cancel();
    final query = value.trim();
    if (query.isEmpty) {
      _results = null;
      _error = null;
      _loading = false;
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 500), () => _search(query));
  }

  Future<void> _search(String query) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results =
          await context.read<RadioProvider>().searchStations(query);
      if (!mounted || query != _controller.text.trim()) return;
      setState(() {
        _results = results;
        _loading = false;
      });
      if (results.isNotEmpty && !_hasShownInterstitial) {
        final music = context.read<MusicProvider>();
        final radio = context.read<RadioProvider>();
        if (!music.isPlaying && !radio.isPlaying) {
          _hasShownInterstitial = true;
          unawaited(
            InterstitialAdController.maybeShow(
              InterstitialTrigger.radioBrowse,
            ),
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(
        backgroundColor: theme.bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: theme.text),
        titleSpacing: 0,
        title: Container(
          height: 42,
          margin: const EdgeInsets.only(right: 12),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: theme.border),
          ),
          child: Row(
            children: [
              Icon(Icons.search_rounded, size: 18, color: theme.muted),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  onChanged: _onChanged,
                  style: TextStyle(color: theme.text, fontSize: 14),
                  cursorColor: theme.accent,
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: 'Search stations, genres, cities…',
                    hintStyle: TextStyle(color: theme.muted, fontSize: 13),
                    border: InputBorder.none,
                  ),
                ),
              ),
              if (_controller.text.isNotEmpty)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    _controller.clear();
                    _onChanged('');
                  },
                  child: Icon(Icons.close_rounded, size: 18, color: theme.muted),
                ),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(child: _buildBody(theme, radio)),
          const AdBannerBar(),
        ],
      ),
    );
  }

  Widget _buildBody(ThemeProvider theme, RadioProvider radio) {
    final query = _controller.text.trim();

    if (query.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.search_rounded,
                  size: 44, color: theme.muted.withValues(alpha: 0.4)),
              const SizedBox(height: 12),
              Text(
                'Find a station by name, genre, or city',
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.muted, fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    if (_loading && _results == null) {
      return Center(child: CircularProgressIndicator(color: theme.accent));
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded,
                  size: 44, color: theme.muted.withValues(alpha: 0.5)),
              const SizedBox(height: 12),
              Text(
                radio.isOffline
                    ? "You're offline — connect to search stations."
                    : "Couldn't search right now. Check your connection.",
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.muted, fontSize: 14),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: () => _search(query),
                style: FilledButton.styleFrom(backgroundColor: theme.accent),
                child: const Text('Try again'),
              ),
            ],
          ),
        ),
      );
    }

    final results = _results ?? const [];
    if (results.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.search_off_rounded,
                  size: 44, color: theme.muted.withValues(alpha: 0.4)),
              const SizedBox(height: 12),
              Text(
                'No stations found for "$query"',
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.muted, fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: results.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final station = results[index];
        final isActive = radio.currentStation?.uuid == station.uuid;
        return RadioStationTile(
          key: ValueKey('radio_search_${station.uuid}'),
          station: station,
          isActive: isActive,
          isPlaying: isActive && radio.isPlaying,
          isFavorite: radio.isFavorite(station),
          onTap: () => RadioPlayerScreen.open(context, station),
          onFavoriteTap: () => radio.toggleFavorite(station),
        );
      },
    );
  }
}
