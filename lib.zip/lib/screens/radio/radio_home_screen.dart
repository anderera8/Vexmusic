// lib/screens/radio/radio_home_screen.dart
// ─────────────────────────────────────────────────────────────────────────────
// Discover hub for the Radio tab: Recently Played, Favorites, Trending Now,
// a genre grid, and a country rail. This is the screen the bottom nav
// "Radio" tab shows.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/radio_models.dart';
import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/radio/radio_station_card.dart';
import '../../widgets/toast.dart';
import '../home/home_helpers.dart';
import 'radio_favorites_screen.dart';
import 'radio_player_screen.dart';
import 'radio_search_screen.dart';
import 'radio_station_list_screen.dart';

class RadioHomeScreen extends StatefulWidget {
  const RadioHomeScreen({super.key});

  @override
  State<RadioHomeScreen> createState() => _RadioHomeScreenState();
}

class _RadioHomeScreenState extends State<RadioHomeScreen> {
  bool? _lastKnownOffline;

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();

    // Edge-triggered: fires the toast once on the false→true transition,
    // not on every rebuild while already offline, and not on first build
    // (when _lastKnownOffline is still null) — the offline banner below
    // already covers "already known offline when this screen opens".
    if (_lastKnownOffline != null &&
        _lastKnownOffline == false &&
        radio.isOffline) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        VibesToast.show(
          context,
          "You're offline — radio can't play until you reconnect.",
          duration: const Duration(seconds: 3),
        );
      });
    }
    _lastKnownOffline = radio.isOffline;

    return Column(
      children: [
        // ── Top bar ──────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Row(
            children: [
              Builder(
                builder: (ctx) => TopBarButton(
                  onTap: () => Scaffold.maybeOf(ctx)?.openDrawer(),
                  child: Semantics(
                    label: 'Open navigation menu',
                    button: true,
                    child: Icon(Icons.menu_rounded, color: theme.text, size: 20),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AnimatedGradientText(
                      text: 'Radio',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: theme.accent,
                        letterSpacing: 2,
                      ),
                    ),
                    Text(
                      'LIVE STATIONS WORLDWIDE',
                      style: TextStyle(
                        fontSize: 10,
                        color: theme.muted,
                        letterSpacing: 2.2,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              TopBarButton(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const RadioSearchScreen()),
                ),
                child: Semantics(
                  label: 'Search stations',
                  button: true,
                  child: Icon(Icons.search_rounded, color: theme.text, size: 20),
                ),
              ),
              const SizedBox(width: 8),
              TopBarButton(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const RadioFavoritesScreen(),
                  ),
                ),
                child: Semantics(
                  label: 'Your favorite stations',
                  button: true,
                  child: Icon(Icons.favorite_rounded,
                      color: theme.text, size: 20),
                ),
              ),
            ],
          ),
        ),

        // ── Content ──────────────────────────────────────────────────
        Expanded(
          child: RefreshIndicator(
            color: theme.accent,
            onRefresh: () => radio.loadDiscover(forceRefresh: true),
            child: ListView(
              padding: const EdgeInsets.only(bottom: 8),
              children: [
                if (radio.isOffline) _OfflineBanner(theme: theme),

                if (radio.recentlyPlayed.isNotEmpty)
                  _StationCarousel(
                    title: 'Recently Played',
                    icon: Icons.history_rounded,
                    stations: radio.recentlyPlayed.take(10).toList(),
                  ),

                if (radio.favorites.isNotEmpty)
                  _StationCarousel(
                    title: 'Your Favorites',
                    icon: Icons.favorite_rounded,
                    stations: radio.favorites.take(10).toList(),
                    onSeeAll: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const RadioFavoritesScreen(),
                      ),
                    ),
                  ),

                _UgandaSection(radio: radio),

                _EastAfricaSection(radio: radio),

                _TrendingSection(radio: radio),

                _GenreGrid(theme: theme),

                _CountryRail(theme: theme),

                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
        const AdBannerBar(),
      ],
    );
  }
}

// ── Offline banner ───────────────────────────────────────────────────────

/// Persistent inline notice shown at the top of the Discover list whenever
/// [RadioProvider.isOffline] is true — covers the case where the person
/// opens the Radio tab while already offline (the edge-triggered
/// [VibesToast] in [_RadioHomeScreenState] only fires on the transition
/// into offline, so this is what's visible on a cold, already-offline
/// open). Clears itself automatically the moment connectivity returns,
/// since it's driven by the same reactive [RadioProvider.isOffline] flag.
class _OfflineBanner extends StatelessWidget {
  final ThemeProvider theme;
  const _OfflineBanner({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: theme.surface2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: theme.accent.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(Icons.cloud_off_rounded, size: 18, color: theme.accent),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                "You're offline — connect to browse and play stations.",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: theme.text,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Uganda ───────────────────────────────────────────────────────────────

class _UgandaSection extends StatelessWidget {
  final RadioProvider radio;
  const _UgandaSection({required this.radio});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    if (radio.ugandaLoading && radio.ugandaStations.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Center(child: CircularProgressIndicator(color: theme.accent)),
      );
    }

    if (radio.ugandaError != null && radio.ugandaStations.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 22, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Uganda Radio',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: theme.text,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              radio.isOffline
                  ? "You're offline — connect to load Uganda stations."
                  : "Couldn't load Uganda stations. Check your connection.",
              style: TextStyle(fontSize: 12, color: theme.muted),
            ),
            TextButton(
              onPressed: () => radio.loadUganda(forceRefresh: true),
              child: Text('Try again', style: TextStyle(color: theme.accent)),
            ),
          ],
        ),
      );
    }

    if (radio.ugandaStations.isEmpty) return const SizedBox.shrink();

    return _StationCarousel(
      title: '🇺🇬 Uganda Radio',
      icon: Icons.radio_rounded,
      stations: radio.ugandaStations.take(24).toList(),
      onSeeAll: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RadioStationListScreen(
            title: '🇺🇬 Uganda Radio',
            fetcher: () => radio.fetchByCountry(
              RadioCountryDef(
                radio.featuredCountryName ?? 'Uganda',
                RadioProvider.featuredCountryCode,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── East Africa ─────────────────────────────────────────────────────────

class _EastAfricaSection extends StatelessWidget {
  final RadioProvider radio;
  const _EastAfricaSection({required this.radio});

  @override
  Widget build(BuildContext context) {
    if (radio.eastAfricaLoading && radio.eastAfricaStations.isEmpty) {
      return const SizedBox(
        height: 116,
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (radio.eastAfricaStations.isEmpty) return const SizedBox.shrink();

    return _StationCarousel(
      title: '🌍 East Africa Radio',
      icon: Icons.public_rounded,
      stations: radio.eastAfricaStations.take(28).toList(),
      onSeeAll: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RadioStationListScreen(
            title: '🌍 East Africa Radio',
            fetcher: () => context.read<RadioProvider>().loadEastAfricaAndReturn(),
          ),
        ),
      ),
    );
  }
}

// ── Trending ─────────────────────────────────────────────────────────────

class _TrendingSection extends StatelessWidget {
  final RadioProvider radio;
  const _TrendingSection({required this.radio});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    if (radio.trendingLoading && radio.trending.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: CircularProgressIndicator(color: theme.accent),
        ),
      );
    }

    if (radio.trendingError != null && radio.trending.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 32, 16, 16),
        child: Column(
          children: [
            Icon(Icons.wifi_off_rounded,
                size: 40, color: theme.muted.withValues(alpha: 0.5)),
            const SizedBox(height: 10),
            Text(
              "Couldn't load stations. Check your connection.",
              textAlign: TextAlign.center,
              style: TextStyle(color: theme.muted, fontSize: 13),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => radio.loadTrending(forceRefresh: true),
              child: Text('Try again',
                  style: TextStyle(color: theme.accent)),
            ),
          ],
        ),
      );
    }

    if (radio.trending.isEmpty) return const SizedBox.shrink();

    return _StationCarousel(
      title: 'Trending Now',
      icon: Icons.trending_up_rounded,
      stations: radio.trending,
      onSeeAll: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => RadioStationListScreen(
            title: 'Trending Now',
            fetcher: () => radio.fetchMoreTrending(),
          ),
        ),
      ),
    );
  }
}

// ── Shared horizontal carousel ──────────────────────────────────────────

class _StationCarousel extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<RadioStation> stations;
  final VoidCallback? onSeeAll;

  const _StationCarousel({
    required this.title,
    required this.icon,
    required this.stations,
    this.onSeeAll,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();
    final cardWidth =
        (MediaQuery.sizeOf(context).width * 0.32).clamp(112.0, 148.0).toDouble();

    // Text block below the art: station name (12px) + subtitle (10px) in
    // RadioStationCard, both at line-height 1.2, plus the 14px (6+8) of
    // vertical padding wrapping them. Scaled by the device's actual text
    // size setting rather than a fixed pixel budget — a fixed budget here
    // is exactly what let this overflow at larger accessibility text
    // sizes (Crashlytics issue fd08f638...5e0498): two 1.2-line-height
    // lines need noticeably more than the ~40px a 1.0x assumption gives
    // once the system text scale climbs past roughly 1.3x. +4 is slack
    // for sub-pixel/font-metric rounding, not a substitute for scaling.
    final textScaler = MediaQuery.textScalerOf(context);
    final captionBlockHeight =
        textScaler.scale(12) * 1.2 + textScaler.scale(10) * 1.2;
    final cardHeight = cardWidth + 14 + captionBlockHeight + 4;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
          child: Row(
            children: [
              Icon(icon, size: 16, color: theme.accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: theme.text,
                  ),
                ),
              ),
              if (onSeeAll != null)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: onSeeAll,
                  child: Text(
                    'See all',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: theme.accent,
                    ),
                  ),
                ),
            ],
          ),
        ),
        SizedBox(
          height: cardHeight,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: stations.length,
            itemBuilder: (context, index) {
              final station = stations[index];
              final isActive = radio.currentStation?.uuid == station.uuid;
              return Padding(
                key: ValueKey('radio_card_${station.uuid}'),
                padding: const EdgeInsets.only(right: 10),
                child: RadioStationCard(
                  station: station,
                  width: cardWidth,
                  isActive: isActive,
                  isPlaying: isActive && radio.isPlaying,
                  onTap: () => RadioPlayerScreen.open(context, station),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

// ── Genre grid ───────────────────────────────────────────────────────────

const List<List<Color>> _kGenreGradients = [
  [Color(0xFFFFC542), Color(0xFFFF7A45)],
  [Color(0xFF7F5AF0), Color(0xFF2B2450)],
  [Color(0xFF00C2A8), Color(0xFF00707A)],
  [Color(0xFFFF5E7E), Color(0xFF7A1E45)],
  [Color(0xFF3E8EF7), Color(0xFF1B2A6B)],
  [Color(0xFF35D07F), Color(0xFF0E6B4F)],
];

class _GenreGrid extends StatelessWidget {
  final ThemeProvider theme;
  const _GenreGrid({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
          child: Row(
            children: [
              Icon(Icons.category_rounded, size: 16, color: theme.accent),
              const SizedBox(width: 6),
              Text(
                'Browse Genres',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: theme.text,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: kRadioGenres.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.6,
            ),
            itemBuilder: (context, index) {
              final genre = kRadioGenres[index];
              final colors = _kGenreGradients[index % _kGenreGradients.length];
              return _GenreTile(genre: genre, colors: colors);
            },
          ),
        ),
      ],
    );
  }
}

class _GenreTile extends StatelessWidget {
  final RadioGenreDef genre;
  final List<Color> colors;
  const _GenreTile({required this.genre, required this.colors});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => RadioStationListScreen(
              title: genre.label,
              fetcher: () =>
                  context.read<RadioProvider>().fetchByGenre(genre),
            ),
          ),
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: colors,
            ),
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            children: [
              Text(genre.emoji, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  genre.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Country rail ─────────────────────────────────────────────────────────

class _CountryRail extends StatefulWidget {
  final ThemeProvider theme;
  const _CountryRail({required this.theme});

  @override
  State<_CountryRail> createState() => _CountryRailState();
}

class _CountryRailState extends State<_CountryRail> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<RadioProvider>().loadCountries();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = widget.theme;
    final radio = context.watch<RadioProvider>();

    if (radio.countriesLoading && radio.allCountries.isEmpty) {
      return SizedBox(
        height: 44,
        child: Center(
          child: SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: theme.accent,
            ),
          ),
        ),
      );
    }

    if (radio.allCountries.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
          child: Row(
            children: [
              Icon(Icons.public, size: 16, color: theme.accent),
              const SizedBox(width: 6),
              Text(
                'Browse by Country',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: theme.text,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: radio.allCountries.length,
            itemBuilder: (context, index) {
              final country = radio.allCountries[index];
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Material(
                  color: theme.surface,
                  borderRadius: BorderRadius.circular(22),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RadioStationListScreen(
                          title: country.name,
                          fetcher: () => context
                              .read<RadioProvider>()
                              .fetchByCountry(country),
                        ),
                      ),
                    ),
                    child: Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: theme.border),
                      ),
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(country.flagEmoji,
                              style: const TextStyle(fontSize: 15)),
                          const SizedBox(width: 6),
                          Text(
                            country.name,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: theme.text,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
