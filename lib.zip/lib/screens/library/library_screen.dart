// lib/screens/library/library_screen.dart
// ─────────────────────────────────────────────────────────────────────────────
// Library tab — MediaStore-backed phone storage browser.
//
// Important:
// This screen intentionally does NOT browse raw Android directories with
// Directory.list(). On Android 10+ scoped storage can make raw folder browsing
// appear empty even when MediaStore audio access works.
//
// Source of truth:
// MusicProvider.tracks → track.filePath
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/track_art_widget.dart';

const _kStorageRoot = '/storage/emulated/0';

const _kRoots = [
  _StorageRoot('Downloads', '$_kStorageRoot/Download', Icons.download_rounded),
  _StorageRoot('Music', '$_kStorageRoot/Music', Icons.library_music_rounded),
  _StorageRoot(
    'WhatsApp',
    '$_kStorageRoot/Android/media/com.whatsapp/WhatsApp/Media',
    Icons.chat_rounded,
  ),
  _StorageRoot('Internal Storage', _kStorageRoot, Icons.phone_android_rounded),
];

class _StorageRoot {
  final String label;
  final String path;
  final IconData icon;

  const _StorageRoot(this.label, this.path, this.icon);
}

class LibraryScreen extends StatefulWidget {
  final bool embedded;

  const LibraryScreen({super.key, this.embedded = false});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();
    final tracks = music.tracks;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Row(
            children: [
              Icon(Icons.folder_rounded, size: 20, color: theme.accent),
              const SizedBox(width: 10),
              Text(
                'Library',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: theme.text,
                  decoration: TextDecoration.none,
                ),
              ),
            ],
          ),
        ),
        Divider(height: 1, thickness: 0.5, color: theme.border),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(top: 8, bottom: 24),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
                child: Text(
                  'Phone Storage',
                  style: TextStyle(
                    color: theme.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.4,
                    decoration: TextDecoration.none,
                  ),
                ),
              ),
              ..._kRoots.map((root) {
                final rootTracks = _tracksForRoot(tracks, root.path);
                final count = rootTracks.length;

                return _RootTile(
                  root: root,
                  count: count,
                  enabled: count > 0,
                  onTap: count > 0
                      ? () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => _MediaStoreFolderBrowserScreen(
                                startPath: _normalizePath(root.path),
                                title: root.label,
                              ),
                            ),
                          )
                      : null,
                );
              }),
            ],
          ),
        ),
        const AdBannerBar(),
      ],
    );
  }
}

class _RootTile extends StatelessWidget {
  final _StorageRoot root;
  final int count;
  final bool enabled;
  final VoidCallback? onTap;

  const _RootTile({
    required this.root,
    required this.count,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 160),
          opacity: enabled ? 1 : 0.45,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            decoration: BoxDecoration(
              color: theme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: theme.border, width: 0.5),
            ),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: theme.surface2,
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Icon(root.icon, color: theme.accent, size: 21),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        root.label,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: theme.text,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          decoration: TextDecoration.none,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        count == 0
                            ? 'No indexed audio found'
                            : '$count audio file${count == 1 ? '' : 's'}',
                        style: TextStyle(
                          color: theme.muted,
                          fontSize: 12,
                          decoration: TextDecoration.none,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: enabled ? theme.muted : theme.border,
                  size: 24,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MediaStoreFolderBrowserScreen extends StatelessWidget {
  final String startPath;
  final String title;

  const _MediaStoreFolderBrowserScreen({
    required this.startPath,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();
    final currentTracks = _tracksForRoot(music.tracks, startPath);
    final view = _FolderView.fromTracks(startPath, currentTracks);

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _FolderHeader(
              title: title,
              path: startPath,
              fileCount: currentTracks.length,
            ),
            Expanded(
              child: view.isEmpty
                  ? const _StorageEmptyState()
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
                      children: [
                        ...view.folders.map(
                          (folder) => _FolderRow(
                            folder: folder,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => _MediaStoreFolderBrowserScreen(
                                  startPath: folder.path,
                                  title: folder.name,
                                ),
                              ),
                            ),
                          ),
                        ),
                        ...view.files.asMap().entries.map(
                          (entry) {
                            final index = entry.key;
                            final track = entry.value;

                            return _TrackRow(
                              track: track,
                              onTap: () async {
                                final playable = view.files;

                                await context.read<MusicProvider>().playQueue(
                                      playable,
                                      index,
                                      contextType: ActiveContextType.folder,
                                      contextName: title,
                                    );

                                if (context.mounted) {
                                  Navigator.pushNamed(context, '/now-playing');
                                }
                              },
                            );
                          },
                        ),
                      ],
                    ),
            ),
            const AdBannerBar(),
            MiniPlayer(
              onTap: () => Navigator.pushNamed(context, '/now-playing'),
            ),
          ],
        ),
      ),
    );
  }
}

class _FolderHeader extends StatelessWidget {
  final String title;
  final String path;
  final int fileCount;

  const _FolderHeader({
    required this.title,
    required this.path,
    required this.fileCount,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: Row(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: theme.text,
                size: 18,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.text,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    decoration: TextDecoration.none,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$fileCount audio file${fileCount == 1 ? '' : 's'} • $path',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.muted,
                    fontSize: 11,
                    decoration: TextDecoration.none,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FolderRow extends StatelessWidget {
  final _FolderNode folder;
  final VoidCallback onTap;

  const _FolderRow({
    required this.folder,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: theme.border, width: 0.5),
          ),
          child: Row(
            children: [
              Icon(Icons.folder_rounded, color: theme.accent, size: 25),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  folder.name,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    decoration: TextDecoration.none,
                  ),
                ),
              ),
              Text(
                '${folder.count}',
                style: TextStyle(
                  color: theme.muted,
                  fontSize: 12,
                  decoration: TextDecoration.none,
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, color: theme.muted, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrackRow extends StatelessWidget {
  final Track track;
  final VoidCallback onTap;

  const _TrackRow({
    required this.track,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: theme.border, width: 0.5),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(11),
                child: TrackArtWidget(
                  artPath: track.artPath,
                  albumId: track.albumId,
                  mediaStoreId: track.mediaStoreId,
                  volumeName: track.volumeName,
                  stableKey: track.stableKey,
                  trackId: track.id,
                  size: 44,
                  borderRadius: 11,
                  defaultIconColor: theme.accent,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: theme.text,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _trackSubtitle(track),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: theme.muted,
                        fontSize: 12,
                        decoration: TextDecoration.none,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.play_arrow_rounded, color: theme.accent, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}

class _StorageEmptyState extends StatelessWidget {
  const _StorageEmptyState();

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.folder_open_rounded,
              size: 62,
              color: theme.muted.withValues(alpha: 0.35),
            ),
            const SizedBox(height: 14),
            Text(
              'No indexed audio found here',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: theme.text,
                fontSize: 15,
                fontWeight: FontWeight.w800,
                decoration: TextDecoration.none,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Files appear here only after Android MediaStore indexes them.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: theme.muted,
                fontSize: 12,
                height: 1.35,
                decoration: TextDecoration.none,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FolderView {
  final List<_FolderNode> folders;
  final List<Track> files;

  const _FolderView({
    required this.folders,
    required this.files,
  });

  bool get isEmpty => folders.isEmpty && files.isEmpty;

  factory _FolderView.fromTracks(String currentPath, List<Track> tracks) {
    final normalizedCurrent = _normalizePath(currentPath);
    final folders = <String, _FolderNode>{};
    final files = <Track>[];

    for (final track in tracks) {
      final filePath = _normalizePath(track.filePath ?? '');

      if (filePath.isEmpty) continue;
      if (!_isUnderPath(filePath, normalizedCurrent)) continue;

      final parent = _parentPath(filePath);

      if (parent == normalizedCurrent) {
        files.add(track);
        continue;
      }

      final relative = _relativePath(filePath, normalizedCurrent);
      final firstSegment = relative.split('/').first;

      if (firstSegment.isEmpty) continue;

      final folderPath = '$normalizedCurrent/$firstSegment';
      final existing = folders[folderPath];

      if (existing == null) {
        folders[folderPath] = _FolderNode(
          name: firstSegment,
          path: folderPath,
          count: 1,
        );
      } else {
        folders[folderPath] = existing.copyWith(count: existing.count + 1);
      }
    }

    final sortedFolders = folders.values.toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    files
        .sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));

    return _FolderView(
      folders: sortedFolders,
      files: files,
    );
  }
}

class _FolderNode {
  final String name;
  final String path;
  final int count;

  const _FolderNode({
    required this.name,
    required this.path,
    required this.count,
  });

  _FolderNode copyWith({int? count}) {
    return _FolderNode(
      name: name,
      path: path,
      count: count ?? this.count,
    );
  }
}

List<Track> _tracksForRoot(List<Track> tracks, String rootPath) {
  final normalizedRoot = _normalizePath(rootPath);

  final result = <Track>[];

  for (final track in tracks) {
    final filePath = _normalizePath(track.filePath ?? '');

    if (filePath.isEmpty) continue;

    if (_isUnderPath(filePath, normalizedRoot)) {
      result.add(track);
    }
  }

  return result;
}

bool _isUnderPath(String filePath, String folderPath) {
  final file = _normalizePath(filePath);
  final folder = _normalizePath(folderPath);

  if (file.isEmpty || folder.isEmpty) return false;
  if (file == folder) return true;

  return file.startsWith('$folder/');
}

String _normalizePath(String path) {
  var value = path.trim().replaceAll('\\', '/');

  while (value.contains('//')) {
    value = value.replaceAll('//', '/');
  }

  while (value.length > 1 && value.endsWith('/')) {
    value = value.substring(0, value.length - 1);
  }

  return value;
}

String _parentPath(String filePath) {
  final normalized = _normalizePath(filePath);
  final index = normalized.lastIndexOf('/');

  if (index <= 0) return '';

  return normalized.substring(0, index);
}

String _relativePath(String filePath, String folderPath) {
  final file = _normalizePath(filePath);
  final folder = _normalizePath(folderPath);

  if (!file.startsWith('$folder/')) return '';

  return file.substring(folder.length + 1);
}

String _trackSubtitle(Track track) {
  final artist = track.artist.trim().isEmpty ? 'Unknown Artist' : track.artist;
  final folder = _parentPath(track.filePath ?? '').split('/').last;

  if (folder.isEmpty) return artist;

  return '$artist • $folder';
}
