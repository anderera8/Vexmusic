import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/artwork_cache_service.dart';
import '../../services/artwork_edit_service.dart';
import '../../widgets/track_art_widget.dart';

enum _ArtworkStatus {
  checking,
  hasArtwork,
  missingArtwork,
}

class ArtworkManagerScreen extends StatefulWidget {
  final List<Track> tracks;

  const ArtworkManagerScreen({
    super.key,
    required this.tracks,
  });

  @override
  State<ArtworkManagerScreen> createState() => _ArtworkManagerScreenState();
}

class _ArtworkManagerScreenState extends State<ArtworkManagerScreen> {
  final TextEditingController _searchController = TextEditingController();

  final Map<int, _ArtworkStatus> _statusByTrackId = {};
  final Set<int> _updatingTrackIds = {};

  String _query = '';
  bool _missingOnly = false;
  int _scanGeneration = 0;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scanArtworkStatuses();
    });
  }

  @override
  void didUpdateWidget(covariant ArtworkManagerScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (!identical(oldWidget.tracks, widget.tracks) ||
        oldWidget.tracks.length != widget.tracks.length) {
      _statusByTrackId.clear();
      _scanArtworkStatuses();
    }
  }

  @override
  void dispose() {
    _scanGeneration++;
    _searchController.dispose();
    super.dispose();
  }

  List<Track> get _visibleTracks {
    final q = _query.trim().toLowerCase();

    return widget.tracks.where((track) {
      if (_missingOnly &&
          _statusByTrackId[track.id] != _ArtworkStatus.missingArtwork) {
        return false;
      }

      if (q.isEmpty) return true;

      return track.title.toLowerCase().contains(q) ||
          track.artist.toLowerCase().contains(q) ||
          (track.albumName?.toLowerCase().contains(q) ?? false);
    }).toList(growable: false);
  }

  int get _knownMissingCount {
    return _statusByTrackId.values
        .where((status) => status == _ArtworkStatus.missingArtwork)
        .length;
  }

  int get _knownHasArtworkCount {
    return _statusByTrackId.values
        .where((status) => status == _ArtworkStatus.hasArtwork)
        .length;
  }

  int get _checkingCount {
    return widget.tracks.length - _statusByTrackId.length;
  }

  void _filter(String value) {
    setState(() {
      _query = value;
    });
  }

  Future<void> _scanArtworkStatuses() async {
    final generation = ++_scanGeneration;

    for (var i = 0; i < widget.tracks.length; i++) {
      if (!mounted || generation != _scanGeneration) return;

      final track = widget.tracks[i];

      if (_statusByTrackId.containsKey(track.id)) continue;

      if (mounted) {
        setState(() {
          _statusByTrackId[track.id] = _ArtworkStatus.checking;
        });
      }

      final hasArtwork = await ArtworkCacheService.hasArtwork(
        albumId: track.albumId,
        mediaStoreId: track.mediaStoreId,
        stableKey: track.stableKey,
        trackId: track.id,
        artPath: track.artPath,
      );

      if (!mounted || generation != _scanGeneration) return;

      setState(() {
        _statusByTrackId[track.id] = hasArtwork
            ? _ArtworkStatus.hasArtwork
            : _ArtworkStatus.missingArtwork;
      });

      // Avoid doing too many UI updates/platform artwork calls in one burst.
      if (i % 8 == 0) {
        await Future<void>.delayed(const Duration(milliseconds: 10));
      }
    }
  }

  Future<void> _refreshTrackStatus(Track track) async {
    if (!mounted) return;

    setState(() {
      _statusByTrackId[track.id] = _ArtworkStatus.checking;
    });

    final hasArtwork = await ArtworkCacheService.hasArtwork(
      albumId: track.albumId,
      mediaStoreId: track.mediaStoreId,
      stableKey: track.stableKey,
      trackId: track.id,
      artPath: track.artPath,
      forceRefresh: true,
    );

    if (!mounted) return;

    setState(() {
      _statusByTrackId[track.id] = hasArtwork
          ? _ArtworkStatus.hasArtwork
          : _ArtworkStatus.missingArtwork;
    });
  }

  Future<void> _setArtwork(Track track) async {
    if (_updatingTrackIds.contains(track.id)) return;

    final music = context.read<MusicProvider>();

    setState(() {
      _updatingTrackIds.add(track.id);
    });

    final result = await ArtworkEditService.pickAndSetArtwork(track: track);

    if (!mounted) return;

    setState(() {
      _updatingTrackIds.remove(track.id);
    });

    if (result.cancelled) return;

    if (!result.success) {
      _showSnack(result.message, isError: true);
      return;
    }

    await music.refreshTrackArtwork(
      track,
      freshBytes: result.imageBytes,
    );

    if (!mounted) return;

    setState(() {
      _statusByTrackId[track.id] = _ArtworkStatus.hasArtwork;
    });

    _showSnack('Artwork updated');
    unawaited(
      InterstitialAdController.maybeShow(InterstitialTrigger.artworkEdited),
    );
  }

  void _showSnack(String message, {bool isError = false}) {
    final theme = context.read<ThemeProvider>();

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isError ? Colors.red.shade700 : theme.surface2,
        content: Text(
          message,
          style: TextStyle(
            color: isError ? Colors.white : theme.text,
            fontWeight: FontWeight.w600,
          ),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String _statusLabel(_ArtworkStatus status) {
    return switch (status) {
      _ArtworkStatus.checking => 'Checking',
      _ArtworkStatus.hasArtwork => 'Has artwork',
      _ArtworkStatus.missingArtwork => 'Missing artwork',
    };
  }

  Color _statusColor(_ArtworkStatus status, ThemeProvider theme) {
    return switch (status) {
      _ArtworkStatus.checking => theme.muted,
      _ArtworkStatus.hasArtwork => Colors.green,
      _ArtworkStatus.missingArtwork => Colors.orange,
    };
  }

  IconData _statusIcon(_ArtworkStatus status) {
    return switch (status) {
      _ArtworkStatus.checking => Icons.hourglass_empty_rounded,
      _ArtworkStatus.hasArtwork => Icons.check_circle_rounded,
      _ArtworkStatus.missingArtwork => Icons.warning_amber_rounded,
    };
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final tracks = _visibleTracks;

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _Header(theme: theme),
            _SearchBar(
              theme: theme,
              controller: _searchController,
              onChanged: _filter,
            ),
            const SizedBox(height: 10),
            _SummaryRow(
              theme: theme,
              visibleCount: tracks.length,
              totalCount: widget.tracks.length,
              hasArtworkCount: _knownHasArtworkCount,
              missingCount: _knownMissingCount,
              checkingCount: _checkingCount,
              missingOnly: _missingOnly,
              onToggleMissingOnly: () {
                setState(() {
                  _missingOnly = !_missingOnly;
                });
              },
            ),
            const SizedBox(height: 10),
            Expanded(
              child: tracks.isEmpty
                  ? _EmptyState(theme: theme, missingOnly: _missingOnly)
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      itemCount: tracks.length,
                      itemBuilder: (context, index) {
                        final track = tracks[index];
                        final status = _statusByTrackId[track.id] ??
                            _ArtworkStatus.checking;
                        final updating = _updatingTrackIds.contains(track.id);

                        return _ArtworkTrackTile(
                          theme: theme,
                          track: track,
                          status: status,
                          updating: updating,
                          statusLabel: _statusLabel(status),
                          statusColor: _statusColor(status, theme),
                          statusIcon: _statusIcon(status),
                          onSetArtwork: () => _setArtwork(track),
                          onRefreshStatus: () => _refreshTrackStatus(track),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final ThemeProvider theme;

  const _Header({
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: theme.text,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              'Artwork Manager',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: theme.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchBar extends StatelessWidget {
  final ThemeProvider theme;
  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  const _SearchBar({
    required this.theme,
    required this.controller,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: theme.border),
        ),
        child: TextField(
          controller: controller,
          onChanged: onChanged,
          style: TextStyle(color: theme.text),
          decoration: InputDecoration(
            hintText: 'Search tracks',
            hintStyle: TextStyle(color: theme.muted),
            prefixIcon: Icon(
              Icons.search_rounded,
              color: theme.muted,
              size: 20,
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
          ),
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final ThemeProvider theme;
  final int visibleCount;
  final int totalCount;
  final int hasArtworkCount;
  final int missingCount;
  final int checkingCount;
  final bool missingOnly;
  final VoidCallback onToggleMissingOnly;

  const _SummaryRow({
    required this.theme,
    required this.visibleCount,
    required this.totalCount,
    required this.hasArtworkCount,
    required this.missingCount,
    required this.checkingCount,
    required this.missingOnly,
    required this.onToggleMissingOnly,
  });

  @override
  Widget build(BuildContext context) {
    final checkingLabel = checkingCount > 0 ? ' · $checkingCount checking' : '';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '$visibleCount shown · $hasArtworkCount with art · '
              '$missingCount missing$checkingLabel',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                color: theme.muted,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: onToggleMissingOnly,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
              decoration: BoxDecoration(
                color: missingOnly
                    ? Colors.orange.withValues(alpha: 0.18)
                    : theme.surface,
                borderRadius: BorderRadius.circular(9),
                border: Border.all(
                  color: missingOnly
                      ? Colors.orange.withValues(alpha: 0.55)
                      : theme.border,
                ),
              ),
              child: Text(
                missingOnly ? 'Missing only' : 'All tracks',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: missingOnly ? Colors.orange : theme.text,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ArtworkTrackTile extends StatelessWidget {
  final ThemeProvider theme;
  final Track track;
  final _ArtworkStatus status;
  final bool updating;
  final String statusLabel;
  final Color statusColor;
  final IconData statusIcon;
  final VoidCallback onSetArtwork;
  final VoidCallback onRefreshStatus;

  const _ArtworkTrackTile({
    required this.theme,
    required this.track,
    required this.status,
    required this.updating,
    required this.statusLabel,
    required this.statusColor,
    required this.statusIcon,
    required this.onSetArtwork,
    required this.onRefreshStatus,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        children: [
          TrackArtWidget(
            artPath: track.artPath,
            albumId: track.albumId,
            mediaStoreId: track.mediaStoreId,
            volumeName: track.volumeName,
            stableKey: track.stableKey,
            trackId: track.id,
            size: 52,
            borderRadius: 11,
            defaultIconColor: theme.accent.withValues(alpha: 0.55),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _TrackTexts(theme: theme, track: track),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _StatusPill(
                label: statusLabel,
                color: statusColor,
                icon: statusIcon,
              ),
              const SizedBox(height: 7),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (status == _ArtworkStatus.checking)
                    SizedBox(
                      width: 28,
                      height: 28,
                      child: Padding(
                        padding: const EdgeInsets.all(7),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: theme.accent,
                        ),
                      ),
                    )
                  else
                    _TinyButton(
                      icon: Icons.refresh_rounded,
                      color: theme.muted,
                      onTap: updating ? null : onRefreshStatus,
                    ),
                  const SizedBox(width: 6),
                  _TinyButton(
                    icon: updating
                        ? Icons.hourglass_empty_rounded
                        : Icons.image_rounded,
                    color: theme.accent,
                    onTap: updating ? null : onSetArtwork,
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TrackTexts extends StatelessWidget {
  final ThemeProvider theme;
  final Track track;

  const _TrackTexts({
    required this.theme,
    required this.track,
  });

  @override
  Widget build(BuildContext context) {
    final album = track.albumName?.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          track.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: theme.text,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          track.artist,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 12,
            color: theme.muted,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (album != null && album.isNotEmpty) ...[
          const SizedBox(height: 2),
          Text(
            album,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              color: theme.muted.withValues(alpha: 0.82),
            ),
          ),
        ],
      ],
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;

  const _StatusPill({
    required this.label,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 116),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 4),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TinyButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _TinyButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;

    return GestureDetector(
      onTap: onTap,
      child: Opacity(
        opacity: enabled ? 1 : 0.45,
        child: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(9),
          ),
          child: Icon(icon, size: 17, color: color),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final ThemeProvider theme;
  final bool missingOnly;

  const _EmptyState({
    required this.theme,
    required this.missingOnly,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        missingOnly ? 'No missing artwork found' : 'No tracks found',
        style: TextStyle(
          color: theme.muted,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
