import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/audio_file_operations_service.dart';
import '../../widgets/track_art_widget.dart';

class TagEditorScreen extends StatefulWidget {
  final Track track;

  const TagEditorScreen({
    super.key,
    required this.track,
  });

  @override
  State<TagEditorScreen> createState() => _TagEditorScreenState();
}

class _TagEditorScreenState extends State<TagEditorScreen> {
  late final TextEditingController _titleCtrl;
  late final TextEditingController _artistCtrl;
  late final TextEditingController _albumCtrl;

  bool _saving = false;

  @override
  void initState() {
    super.initState();

    _titleCtrl = TextEditingController(text: widget.track.title);
    _artistCtrl = TextEditingController(text: widget.track.artist);
    _albumCtrl = TextEditingController(text: widget.track.albumName ?? '');
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _artistCtrl.dispose();
    _albumCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;

    final title = _titleCtrl.text.trim();
    final artist = _artistCtrl.text.trim();
    final album = _albumCtrl.text.trim();

    setState(() => _saving = true);

    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);
    final musicProvider = context.read<MusicProvider>();

    // Resolved once and reused for both the actual write and the local
    // library update below, so the in-memory Track this screen leaves
    // behind reflects exactly what was written to the file - not the raw
    // (possibly blank) field value, which the write call itself doesn't
    // use either.
    final resolvedArtist = artist.isNotEmpty ? artist : widget.track.artist;

    try {
      await AudioFileOperationsService().writeTags(
        track: widget.track,
        title: title,
        artist: resolvedArtist,
        album: album,
      );

      if (!mounted) return;

      // A narrow, single-track update - writeTags already verified the
      // edit persisted to the exact file before returning, so this only
      // needs to make that already-successful edit visible in the UI. A
      // full musicProvider.refreshLibrary() would rescan the entire
      // MediaStore library and reload every playlist and all history for
      // a change that touched exactly one track.
      musicProvider.refreshTrackTags(
        widget.track.id,
        title: title,
        artist: resolvedArtist,
        album: album,
      );

      messenger.hideCurrentSnackBar();
      messenger.showSnackBar(
        const SnackBar(content: Text('Successfully edited')),
      );
      unawaited(
        InterstitialAdController.maybeShow(InterstitialTrigger.tagsEdited),
      );

      navigator.pop();
    } on AudioFileEditException {
      if (!mounted) return;
      _showSnack("File can't be edited", isError: true);
    } catch (_) {
      if (!mounted) return;
      _showSnack("File can't be edited", isError: true);
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }

  void _showSnack(String message, {bool isError = false}) {
    if (!mounted) return;

    final theme = context.read<ThemeProvider>();

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red.shade700 : theme.accent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildTrackCard(theme),
                    const SizedBox(height: 16),
                    const SizedBox(height: 24),
                    _TagField(
                      label: 'Title',
                      controller: _titleCtrl,
                      icon: Icons.music_note_rounded,
                      textInputAction: TextInputAction.next,
                    ),
                    const SizedBox(height: 14),
                    _TagField(
                      label: 'Artist',
                      controller: _artistCtrl,
                      icon: Icons.person_rounded,
                      textInputAction: TextInputAction.next,
                    ),
                    const SizedBox(height: 14),
                    _TagField(
                      label: 'album',
                      controller: _albumCtrl,
                      icon: Icons.album_rounded,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _save(),
                    ),
                    const SizedBox(height: 24),
                    _buildPathCard(theme),
                  ],
                ),
              ),
            ),
            _buildSaveButton(theme),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: _saving ? null : () => Navigator.pop(context),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: _saving ? theme.muted : theme.text,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              'Tag Editor',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: theme.text,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrackCard(ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        children: [
          TrackArtWidget(
            artPath: widget.track.artPath,
            albumId: widget.track.albumId,
            mediaStoreId: widget.track.mediaStoreId,
            volumeName: widget.track.volumeName,
            stableKey: widget.track.stableKey,
            trackId: widget.track.id,
            size: 72,
            borderRadius: 12,
            defaultIconColor: theme.accent,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.track.title.isNotEmpty
                      ? widget.track.title
                      : 'Unknown track',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: theme.text,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  widget.track.artist.isNotEmpty
                      ? widget.track.artist
                      : 'Unknown Artist',
                  style: TextStyle(
                    fontSize: 12,
                    color: theme.muted,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(
                      Icons.schedule_rounded,
                      size: 13,
                      color: theme.muted,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      widget.track.formattedDuration,
                      style: TextStyle(
                        fontSize: 11,
                        color: theme.muted,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPathCard(ThemeProvider theme) {
    final path = widget.track.filePath?.trim();
    final uri = widget.track.playbackUri?.trim();

    final display = path != null && path.isNotEmpty
        ? path
        : uri != null && uri.isNotEmpty
            ? uri
            : 'Unknown path';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        children: [
          Icon(
            Icons.folder_rounded,
            size: 18,
            color: theme.muted,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              display,
              style: TextStyle(
                fontSize: 11,
                color: theme.muted,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSaveButton(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: SizedBox(
        width: double.infinity,
        height: 52,
        child: ElevatedButton(
          onPressed: _saving ? null : _save,
          style: ElevatedButton.styleFrom(
            backgroundColor: theme.accent,
            foregroundColor: Colors.white,
            disabledBackgroundColor: theme.surface2,
            disabledForegroundColor: theme.muted,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          child: _saving
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(
                  'Save Tags',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
        ),
      ),
    );
  }
}

class _TagField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final IconData icon;
  final TextInputAction textInputAction;
  final ValueChanged<String>? onSubmitted;

  const _TagField({
    required this.label,
    required this.controller,
    required this.icon,
    this.textInputAction = TextInputAction.next,
    this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: theme.muted,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.border),
          ),
          child: TextField(
            controller: controller,
            textInputAction: textInputAction,
            onSubmitted: onSubmitted,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: theme.text,
            ),
            decoration: InputDecoration(
              prefixIcon: Icon(
                icon,
                size: 20,
                color: theme.muted,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
