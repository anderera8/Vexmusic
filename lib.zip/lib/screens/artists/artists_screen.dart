import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/track_tile.dart';
import '../../widgets/model_sheet.dart';
import '../../widgets/toast.dart';

class ArtistDetailScreen extends StatelessWidget {
  final String artistName;
  final List<Track> tracks;

  const ArtistDetailScreen({
    super.key,
    required this.artistName,
    required this.tracks,
  });

  @override
  Widget build(BuildContext context) {
    // Guard: tracks should never be empty here, but a library refresh during
    // navigation could cause a race. Pop safely instead of crashing on .first.
    if (tracks.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted && Navigator.canPop(context)) {
          Navigator.pop(context);
        }
      });
      return const SizedBox.shrink();
    }

    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();
    final gradient = theme.gradient(tracks.first.grad);

    return Scaffold(
      backgroundColor: theme.bg,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: theme.border),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(13),
                            border: Border.all(
                                color: Colors.white.withValues(alpha: 0.15)),
                          ),
                          child: const Icon(Icons.arrow_back_ios_new_rounded,
                              size: 16, color: Colors.white),
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () {
                          // Play the artist's tracks as a self-contained queue
                          music.playQueue(tracks, 0);
                          Navigator.pushNamed(context, '/now-playing');
                        },
                        child: Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.15),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 26),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.15),
                    ),
                    alignment: Alignment.center,
                    child: Text(tracks.first.art,
                        style: const TextStyle(fontSize: 40)),
                  ),
                  const SizedBox(height: 14),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      artistName,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${tracks.length} track${tracks.length != 1 ? 's' : ''}',
                    style: const TextStyle(fontSize: 13, color: Colors.white70),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 4),
              child: Text(
                'tracks',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: theme.muted,
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.only(bottom: 30),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, i) {
                  final track = tracks[i];
                  return TrackTile(
                    track: track,
                    onTap: () {
                      // Load artist queue at position i so next/prev
                      // navigates within this artist, not the full library.
                      music.playQueue(tracks, i);
                      Navigator.pushNamed(context, '/now-playing');
                    },
                    onMenuTap: () => _showtrackMenu(context, music, track),
                  );
                },
                childCount: tracks.length,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showtrackMenu(BuildContext context, MusicProvider music, Track track) {
    showModalSheet(
      context,
      title: track.title,
      body: track.artist,
      actions: [
        ModalAction(
          label: track.liked ? 'Unlike ♥' : 'Like ♥',
          cls: 'primary',
          action: () {
            music.toggleLike(track.id);
            InterstitialAdController.maybeShow(
              InterstitialTrigger.favoriteToggled,
            );
          },
        ),
        ModalAction(
          label: 'Add to playlist',
          popAfter: false,
          action: () => _showAddToPlaylist(context, music, track),
        ),
        ModalAction(label: 'Cancel', action: () {}),
      ],
    );
  }

  void _showAddToPlaylist(
      BuildContext context, MusicProvider music, Track track) {
    // Close the track-menu modal first, then show the playlist picker.
    Navigator.pop(context);

    if (music.playlists.isEmpty) {
      VibesToast.show(context, 'Create a playlist first in the Library');
      return;
    }

    // Wait for the pop animation to finish before showing the second modal.
    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      final theme = context.read<ThemeProvider>();

      showModalSheet(
        context,
        title: 'Add to Playlist',
        body: 'Select a playlist:',
        actions: [ModalAction(label: 'Cancel', action: () {})],
        extra: Column(
          children: music.playlists.map((pl) {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.pop(context);
                music.addTrackToPlaylist(pl.id, track.id);
                VibesToast.show(context, 'Added to "${pl.name}"');
                InterstitialAdController.maybeShow(
                  InterstitialTrigger.playlistAction,
                );
              },
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: theme.surface2,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Text(pl.art, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            pl.name,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: theme.text,
                            ),
                          ),
                          Text(
                            '${pl.trackCount} tracks',
                            style: TextStyle(fontSize: 11, color: theme.muted),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.add_rounded, size: 18, color: theme.accent),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      );
    });
  }
}
