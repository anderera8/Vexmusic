import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../models/music_models.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/track_art_widget.dart';

class AlbumDetailScreen extends StatelessWidget {
  final Album album;
  const AlbumDetailScreen({super.key, required this.album});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Consumer<MusicProvider>(
          builder: (context, music, _) {
            // Match by albumId not name — albums with the same name from
            // different artists would otherwise show each other's tracks.
            // Guard albumId != 0: on_audio_query sets albumId=0 when the
            // device returns null, which must not match a real album.
            final albumtracks = music.tracks
                .where((t) => t.albumId != 0 && t.albumId == album.id)
                .toList();

            return Column(
              children: [
                _AlbumHero(album: album, trackCount: albumtracks.length),
                Expanded(
                  child: albumtracks.isEmpty
                      ? _Notracks()
                      : _TrackList(tracks: albumtracks, album: album),
                ),
                const AdBannerBar(),
                MiniPlayer(
                  onTap: () => Navigator.pushNamed(context, '/now-playing'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Notracks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Center(
      child: Text(
        'No tracks in this album',
        style: TextStyle(color: theme.muted, fontSize: 14),
      ),
    );
  }
}

class _AlbumHero extends StatelessWidget {
  final Album album;
  final int trackCount;
  const _AlbumHero({required this.album, required this.trackCount});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final gradient = theme.gradient(album.grad);

    return Stack(
      children: [
        Container(
          width: double.infinity,
          height: 220,
          decoration: BoxDecoration(gradient: gradient),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: TrackArtWidget(
                  albumId: album.id,
                  size: 120,
                  borderRadius: 0,
                  fit: BoxFit.cover,
                  defaultIconColor: Colors.white70,
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  album.name,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  '${album.artist} · $trackCount tracks',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.white70,
                  ),
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 16,
          left: 16,
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: theme.text, size: 17),
            ),
          ),
        ),
      ],
    );
  }
}

class _TrackList extends StatelessWidget {
  final List<Track> tracks;
  final Album album;
  const _TrackList({required this.tracks, required this.album});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
      itemCount: tracks.length,
      itemBuilder: (context, i) {
                final track = tracks[i];
        return GestureDetector(
          onTap: () {
            music.playQueue(
              tracks,
              i,
              contextName: album.name,
              contextId: album.id,
            );
            Navigator.pushNamed(context, '/now-playing');
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: theme.surface,
              border: Border.all(color: theme.border),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: theme.surface2,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '${i + 1}',
                    style: TextStyle(
                      fontSize: 12,
                      color: theme.muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: theme.text,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        track.formattedDuration,
                        style: TextStyle(
                          fontSize: 11,
                          color: theme.muted,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                if (track.liked)
                  Icon(Icons.favorite_rounded, color: theme.danger, size: 16),
                const SizedBox(width: 8),
                Icon(Icons.play_arrow_rounded, color: theme.muted, size: 22),
              ],
            ),
          ),
        );
      },
    );
  }
}
