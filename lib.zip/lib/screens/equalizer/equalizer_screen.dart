import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/unified_audio_effects_service.dart';
import '../../services/platform/android_audio_effects.dart';
import '../../services/platform/audio_spectrum_service.dart';
import '../../widgets/spectrum_visualizer.dart';

class EqualizerScreen extends StatefulWidget {
  const EqualizerScreen({super.key});

  @override
  State<EqualizerScreen> createState() => _EqualizerScreenState();
}

class _EqualizerScreenState extends State<EqualizerScreen> {
  EqState? _state;
  List<String> _presets = [];
  bool _loading = true;
  bool _enabled = true;
  bool _available = false;
  double _bassBoost = 0.0;
  double _volumeBoost = 0.0;
  double _virtualizerStrength = 0.0;
  Timer? _bandCommitTimer;
  Timer? _bassCommitTimer;
  Timer? _volumeCommitTimer;
  Timer? _virtualizerCommitTimer;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await UnifiedAudioEffectsService.ensureInitialized();
      final available = await AndroidAudioEffects.instance.initialize();
      final presets = UnifiedAudioEffectsService.getAllPresetNames();
      final state = await UnifiedAudioEffectsService.getState();
      if (!mounted) return;
      setState(() {
        _available = available;
        _presets = presets;
        _state = state;
        _enabled = state.enabled;
        _bassBoost = state.bassBoost / 100.0;
        _volumeBoost = state.volumeBoost / 100.0;
        _virtualizerStrength = state.virtualizer / 100.0;
        _loading = false;
      });
    } catch (error, stackTrace) {
      debugPrint('[EqualizerScreen] Initialization failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        setState(() {
          _available = false;
          _loading = false;
        });
      }
    }
  }

  /// Updates the local curve immediately and coalesces persistence/native work.
  void _setBandGain(int bandIndex, double gainDb) {
    final state = _state;
    if (state == null || bandIndex < 0 || bandIndex >= state.bands.length) {
      return;
    }

    final bands = List<EqBand>.from(state.bands);
    bands[bandIndex] = bands[bandIndex].copyWith(
      gainDb: gainDb.clamp(
        UnifiedAudioEffectsService.minGainDb,
        UnifiedAudioEffectsService.maxGainDb,
      ).toDouble(),
    );

    setState(() {
      _state = state.copyWith(
        bands: List<EqBand>.unmodifiable(bands),
        currentPreset:
            UnifiedAudioEffectsService.getAllPresetNames().indexOf('Custom'),
      );
    });

    _bandCommitTimer?.cancel();
    _bandCommitTimer = Timer(const Duration(milliseconds: 55), () {
      unawaited(
        UnifiedAudioEffectsService.setBandGains(
          bands.map((band) => band.gainDb).toList(growable: false),
        ),
      );
    });
  }

  Future<void> _applyPreset(String presetName) async {
    if (presetName == 'Custom') {
      await _saveCustomPreset();
      return;
    }
    await UnifiedAudioEffectsService.applyPresetCurve(presetName);
    final state = await UnifiedAudioEffectsService.getState();
    if (!mounted) return;
    setState(() {
      _state = state;
      _bassBoost = state.bassBoost / 100.0;
      _volumeBoost = state.volumeBoost / 100.0;
      _virtualizerStrength = state.virtualizer / 100.0;
    });
  }

  void _setBassBoost(double level) {
    final safe = level.clamp(0.0, 1.0).toDouble();
    setState(() {
      _bassBoost = safe;
      _state = _state?.copyWith(bassBoost: (safe * 100).round());
    });
    _bassCommitTimer?.cancel();
    _bassCommitTimer = Timer(
      const Duration(milliseconds: 55),
      () => unawaited(UnifiedAudioEffectsService.setBassBoost(safe)),
    );
  }

  void _setVolumeBoost(double level) {
    final safe = level.clamp(0.0, 1.0).toDouble();
    setState(() {
      _volumeBoost = safe;
      _state = _state?.copyWith(volumeBoost: (safe * 100).round());
    });
    _volumeCommitTimer?.cancel();
    _volumeCommitTimer = Timer(
      const Duration(milliseconds: 55),
      () => unawaited(UnifiedAudioEffectsService.setVolumeBoost(safe)),
    );
  }

  void _setVirtualizer(double level) {
    final safe = level.clamp(0.0, 1.0).toDouble();
    setState(() {
      _virtualizerStrength = safe;
      _state = _state?.copyWith(virtualizer: (safe * 100).round());
    });
    _virtualizerCommitTimer?.cancel();
    _virtualizerCommitTimer = Timer(
      const Duration(milliseconds: 55),
      () => unawaited(UnifiedAudioEffectsService.setVirtualizer(safe)),
    );
  }

  Future<void> _setNormalization(bool enabled) async {
    await UnifiedAudioEffectsService.setNormalization(enabled);
    final state = await UnifiedAudioEffectsService.getState();
    if (mounted) {
      setState(() => _state = state);
    }
  }

  Future<void> _resetAll() async {
    await UnifiedAudioEffectsService.resetAll();
    final state = await UnifiedAudioEffectsService.getState();
    if (!mounted) return;
    setState(() {
      _state = state;
      _enabled = state.enabled;
      _bassBoost = 0;
      _volumeBoost = 0;
      _virtualizerStrength = 0;
    });
  }

  Future<void> _saveCustomPreset() async {
    String? resultText;
    var name = await showDialog<String>(
      context: context,
      builder: (context) {
        final theme = context.watch<ThemeProvider>();
        final controller = TextEditingController();
        return AlertDialog(
          backgroundColor: theme.surface,
          title: Text('Save Custom Effect',
              style: TextStyle(color: theme.text, fontWeight: FontWeight.w800)),
          content: TextField(
            controller: controller,
            autofocus: true,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              hintText: 'My movie bass',
              hintStyle: TextStyle(color: theme.muted),
            ),
            style: TextStyle(color: theme.text),
            onSubmitted: (value) => Navigator.pop(context, value),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: theme.muted)),
            ),
            FilledButton(
              onPressed: () {
                resultText = controller.text;
                Navigator.pop(context, controller.text);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
    name = resultText ?? name;
    if (name == null) return;
    final saved = await UnifiedAudioEffectsService.saveCustomPreset(name);
    if (!mounted) return;
    if (!saved) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Use a unique custom effect name.')),
      );
      return;
    }
    final state = await UnifiedAudioEffectsService.getState();
    setState(() {
      _presets = UnifiedAudioEffectsService.getAllPresetNames();
      _state = state;
      _bassBoost = state.bassBoost / 100.0;
      _volumeBoost = state.volumeBoost / 100.0;
      _virtualizerStrength = state.virtualizer / 100.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
              child: Row(
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: theme.surface,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: theme.border),
                      ),
                      child: Icon(Icons.arrow_back_ios_new_rounded,
                          size: 16, color: theme.text),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Equaliser',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: theme.text,
                      ),
                    ),
                  ),
                  if (_available && !_loading)
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () async {
                        final next = !_enabled;
                        await UnifiedAudioEffectsService.setEnabled(next);
                        final state =
                            await UnifiedAudioEffectsService.getState();
                        if (mounted) {
                          setState(() {
                            _enabled = state.enabled;
                            _state = state;
                          });
                        }
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 52,
                        height: 28,
                        decoration: BoxDecoration(
                          color: _enabled ? theme.accent : theme.surface2,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: _enabled ? theme.accent : theme.border,
                          ),
                        ),
                        child: AnimatedAlign(
                          duration: const Duration(milliseconds: 200),
                          alignment: _enabled
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 3),
                            child: Container(
                              width: 22,
                              height: 22,
                              decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // ── Body ────────────────────────────────────────────────────────
            if (_loading)
              Expanded(
                child: Center(
                  child: CircularProgressIndicator(color: theme.accent),
                ),
              )
            else if (!_available)
              _UnavailableState(onRetry: _retry)
            else if (_state == null)
              Expanded(
                child: Center(
                  child: Text(
                    'Could not read EQ state',
                    style: TextStyle(color: theme.muted),
                  ),
                ),
              )
            else
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
                  children: [
                    const _SectionLabel('Presets'),
                    const SizedBox(height: 12),
                    _PresetsRow(
                      presets: _presets,
                      current: _state!.currentPreset,
                      onSelect: _applyPreset,
                    ),
                    const SizedBox(height: 24),

                    // ── Live spectrum analyser ─────────────────────────
                    if (AudioSpectrumService.isSupported) ...[
                      const _SectionLabel('Spectrum'),
                      const SizedBox(height: 10),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          decoration: BoxDecoration(
                            color: theme.surface.withValues(alpha: 0.5),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 16,
                          ),
                          child: const SpectrumVisualizer(height: 90),
                        ),
                      ),
                      const SizedBox(height: 28),
                    ],

                    const _SectionLabel('Bands'),
                    const SizedBox(height: 6),
                    _BandSliders(
                      bands: _state!.bands,
                      onBandChanged: _setBandGain,
                    ),
                    const SizedBox(height: 20),

                    // ── Bass Boost ───────────────────────────────────
                    _BoostSlider(
                      label: 'Bass Boost',
                      icon: Icons.speaker_group,
                      value: _bassBoost,
                      minLabel: 'Off',
                      maxLabel: '100%',
                      activeColor: const Color(0xFFFF6B35),
                      onChanged: _setBassBoost,
                    ),
                    const SizedBox(height: 12),

                    // ── Volume Boost ─────────────────────────────────
                    _BoostSlider(
                      label: 'Volume Boost',
                      icon: Icons.volume_up,
                      value: _volumeBoost,
                      minLabel: 'Normal',
                      maxLabel: 'Max',
                      activeColor: const Color(0xFF4CAF50),
                      onChanged: _setVolumeBoost,
                    ),
                    const SizedBox(height: 12),

                    // ── Virtualizer (3D / Spatial) ──────────────────
                    _BoostSlider(
                      label: '3D Virtualizer',
                      icon: Icons.surround_sound_rounded,
                      value: _virtualizerStrength,
                      minLabel: 'Off',
                      maxLabel: 'Wide',
                      activeColor: const Color(0xFF7C4DFF),
                      onChanged: _setVirtualizer,
                    ),
                    const SizedBox(height: 12),
                    _NormalizationTile(
                      enabled: _state!.normalization,
                      onChanged: (value) => unawaited(_setNormalization(value)),
                    ),
                    const SizedBox(height: 20),

                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: _resetAll,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: theme.surface,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: theme.border),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'Reset to Normal',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: theme.muted,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _bandCommitTimer?.cancel();
    _bassCommitTimer?.cancel();
    _volumeCommitTimer?.cancel();
    _virtualizerCommitTimer?.cancel();

    final state = _state;
    if (state != null) {
      unawaited(
        UnifiedAudioEffectsService.setStateSnapshot(
          state,
          immediatePersistence: true,
        ),
      );
    } else {
      unawaited(UnifiedAudioEffectsService.flushPendingPersistence());
    }
    super.dispose();
  }

  void _retry() {
    setState(() {
      _loading = true;
      _available = false;
      _state = null;
    });
    _load();
  }
}

// ── Unavailable state ─────────────────────────────────────────────────────────

class _UnavailableState extends StatelessWidget {
  final VoidCallback onRetry;

  const _UnavailableState({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Expanded(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.equalizer_rounded, size: 52, color: theme.muted),
              const SizedBox(height: 16),
              Text(
                'Equaliser not available',
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: theme.text,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Audio effects are not supported by this device or platform.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                  color: theme.muted,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Section label ─────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: theme.muted,
        letterSpacing: 1.6,
      ),
    );
  }
}

// ── Presets row ───────────────────────────────────────────────────────────────

class _PresetsRow extends StatelessWidget {
  final List<String> presets;
  final int current;
  final void Function(String presetName) onSelect;

  const _PresetsRow({
    required this.presets,
    required this.current,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    if (presets.isEmpty) {
      return Text(
        'No presets available',
        style: TextStyle(color: theme.muted, fontSize: 13),
      );
    }
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: presets.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final active = i == current;
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => onSelect(presets[i]),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: active ? theme.accent : theme.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: active ? theme.accent : theme.border,
                ),
              ),
              child: Text(
                presets[i],
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: active ? Colors.white : theme.muted,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Band sliders ──────────────────────────────────────────────────────────────

class _BandSliders extends StatelessWidget {
  final List<EqBand> bands;
  final void Function(int bandIndex, double gainDb) onBandChanged;

  const _BandSliders({required this.bands, required this.onBandChanged});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: bands.map((band) {
          return Expanded(
            child: _SingleBand(band: band, onChanged: onBandChanged),
          );
        }).toList(),
      ),
    );
  }
}

class _SingleBand extends StatelessWidget {
  final EqBand band;
  final void Function(int, double) onChanged;

  const _SingleBand({required this.band, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final range = band.maxDb - band.minDb;
    // Normalize gain to 0.0–1.0 for the Slider
    final normalized = ((band.gainDb - band.minDb) / range).clamp(0.0, 1.0);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Gain label: "+3", "0", "-2" (in dB)
        Text(
          band.gainLabel,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: band.gainDb > 0
                ? theme.accent
                : band.gainDb < 0
                    ? theme.accent2
                    : theme.muted,
          ),
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 120,
          child: RotatedBox(
            quarterTurns: 3,
            child: SliderTheme(
              data: SliderThemeData(
                trackHeight: 4,
                activeTrackColor: theme.accent,
                inactiveTrackColor: theme.surface2,
                thumbColor: Colors.white,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                overlayColor: theme.accent.withValues(alpha: 0.2),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
              ),
              child: Slider(
                value: normalized,
                min: 0,
                max: 1,
                onChanged: (v) {
                  // Convert normalised 0–1 back to dB
                  final gainDb = band.minDb + v * range;
                  onChanged(band.index, gainDb);
                },
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          band.freqLabel,
          style: TextStyle(fontSize: 9, color: theme.muted),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

class _NormalizationTile extends StatelessWidget {
  const _NormalizationTile({
    required this.enabled,
    required this.onChanged,
  });

  final bool enabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.multiline_chart_rounded, color: Color(0xFF29B6F6)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Loudness normalization',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.text,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Balances quiet and loud tracks before the safety limiter.',
                  style: TextStyle(fontSize: 11, color: theme.muted),
                ),
              ],
            ),
          ),
          Switch.adaptive(value: enabled, onChanged: onChanged),
        ],
      ),
    );
  }
}

// ── Boost slider (bass / volume) ──────────────────────────────────────────────

class _BoostSlider extends StatelessWidget {
  final String label;
  final IconData icon;
  final double value;
  final String minLabel;
  final String maxLabel;
  final Color activeColor;
  final void Function(double) onChanged;

  const _BoostSlider({
    required this.label,
    required this.icon,
    required this.value,
    required this.minLabel,
    required this.maxLabel,
    required this.activeColor,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final pct = (value * 100).round();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: activeColor),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: theme.text,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: activeColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '$pct%',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: activeColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(minLabel,
                  style: TextStyle(fontSize: 10, color: theme.muted)),
              Expanded(
                child: SliderTheme(
                  data: SliderThemeData(
                    trackHeight: 5,
                    activeTrackColor: activeColor,
                    inactiveTrackColor: theme.surface2,
                    thumbColor: Colors.white,
                    thumbShape:
                        const RoundSliderThumbShape(enabledThumbRadius: 8),
                    overlayColor: activeColor.withValues(alpha: 0.15),
                    overlayShape:
                        const RoundSliderOverlayShape(overlayRadius: 16),
                  ),
                  child: Slider(
                    value: value,
                    min: 0,
                    max: 1,
                    onChanged: onChanged,
                  ),
                ),
              ),
              Text(maxLabel,
                  style: TextStyle(fontSize: 10, color: theme.muted)),
            ],
          ),
        ],
      ),
    );
  }
}
