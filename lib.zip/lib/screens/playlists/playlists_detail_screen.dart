import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../models/music_models.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/track_art_widget.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/model_sheet.dart';
import '../../widgets/toast.dart';
import '../../widgets/info_row.dart';

class PlaylistDetailScreen extends StatelessWidget {
  final Playlist playlist;
  const PlaylistDetailScreen({super.key, required this.playlist});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Consumer<MusicProvider>(
          builder: (context, music, _) {
            final currentPlaylist = music.playlists
                .cast<Playlist?>()
                .firstWhere((p) => p!.id == playlist.id, orElse: () => null);

            if (currentPlaylist == null) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                final route = ModalRoute.of(context);
                if (context.mounted &&
                    (route?.isCurrent ?? false) &&
                    Navigator.canPop(context)) {
                  Navigator.pop(context);
                }
              });
              return const SizedBox.shrink();
            }

            final entries = music.entriesForPlaylist(currentPlaylist);
            final tracks = entries
                .map((entry) => entry.track)
                .toList(growable: false);

            return Column(
              children: [
                _Hero(playlist: currentPlaylist, trackCount: tracks.length),
                Expanded(
                  child: tracks.isEmpty
                      ? _EmptyState(playlistName: currentPlaylist.name)
                      : _TrackList(
                          entries: entries,
                          playbackTracks: tracks,
                          playlist: currentPlaylist,
                        ),
                ),
                const AdBannerBar(),
                MiniPlayer(
                  onTap: () => Navigator.pushNamed(context, '/now-playing'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final Playlist playlist;
  final int trackCount;
  const _Hero({required this.playlist, required this.trackCount});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final gradKey = gradKeys[playlist.id % gradKeys.length];

    return Stack(
      children: [
        Container(
          width: double.infinity,
          height: 200,
          decoration: BoxDecoration(
            gradient: theme.gradient(gradKey),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(playlist.art, style: const TextStyle(fontSize: 64)),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  playlist.name,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  '$trackCount track${trackCount != 1 ? 's' : ''}',
                  style: const TextStyle(
                    fontSize: 13,
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 16,
          left: 16,
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: Colors.white,
                size: 17,
              ),
            ),
          ),
        ),
        Positioned(
          top: 16,
          right: 16,
          child: GestureDetector(
            onTap: () => _showPlaylistMenu(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.more_vert, color: Colors.white, size: 18),
            ),
          ),
        ),
      ],
    );
  }

  void _showPlaylistMenu(BuildContext context) {
    final theme = context.read<ThemeProvider>();

    showModalSheet(
      context,
      title: playlist.name,
      body: '$trackCount tracks',
      actions: [
        ModalAction(label: 'Cancel', action: () {}),
      ],
      extra: Column(
        children: [
          _SheetMenuItem(
            icon: Icons.drive_file_rename_outline_rounded,
            label: 'Rename',
            color: theme.accent,
            onTap: () {
              Navigator.pop(context);
              Future.delayed(const Duration(milliseconds: 250), () {
                if (!context.mounted) return;
                _showRenameDialog(context);
              });
            },
          ),
          const SizedBox(height: 8),
          _SheetMenuItem(
            icon: Icons.delete_outline_rounded,
            label: 'Delete',
            color: Colors.redAccent,
            onTap: () {
              Navigator.pop(context);
              Future.delayed(const Duration(milliseconds: 250), () {
                if (!context.mounted) return;
                _confirmDelete(context);
              });
            },
          ),
        ],
      ),
    );
  }

  void _showRenameDialog(BuildContext context) {
    final controller = TextEditingController(text: playlist.name);

    showModalSheet(
      context,
      title: 'Rename Playlist',
      body: '',
      actions: [
        ModalAction(label: 'Cancel', action: () {}),
        ModalAction(
          label: 'Save',
          cls: 'primary',
          popAfter: false,
          action: () async {
            final newName = controller.text.trim();
            if (newName.isEmpty) {
              VibesToast.show(context, 'Enter a playlist name');
              return;
            }

            await context.read<MusicProvider>().renamePlaylist(
                  playlist.id,
                  newName,
                );

            if (!context.mounted) return;
            Navigator.pop(context);
            VibesToast.show(context, 'Renamed to "$newName"');
          },
        ),
      ],
      extra: TextField(
        controller: controller,
        autofocus: true,
        maxLength: 40,
        style: const TextStyle(fontSize: 15, color: Colors.white),
        decoration: InputDecoration(
          hintText: 'Playlist name…',
          hintStyle: const TextStyle(color: Colors.grey),
          filled: true,
          fillColor: Colors.white10,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showModalSheet(
      context,
      title: 'Delete "${playlist.name}"?',
      body: 'This cannot be undone. The tracks themselves will not be deleted.',
      actions: [
        ModalAction(label: 'Cancel', action: () {}),
      ],
      extra: _DangerConfirmButton(
        label: 'Delete Playlist',
        onTap: () async {
          try {
            await context.read<MusicProvider>().deletePlaylist(playlist.id);

            if (!context.mounted) return;

            Navigator.pop(context);
            VibesToast.show(context, 'Playlist deleted');

            Future.delayed(const Duration(milliseconds: 180), () {
              if (context.mounted && Navigator.canPop(context)) {
                Navigator.pop(context);
              }
            });
          } catch (error) {
            if (!context.mounted) return;
            Navigator.pop(context);
            VibesToast.show(context, 'Delete failed: $error');
          }
        },
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String playlistName;
  const _EmptyState({required this.playlistName});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('🎵', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(
            '"$playlistName" is empty',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: theme.text,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add tracks from the Library by tapping the ⋮ menu on any track.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color: theme.muted,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackList extends StatelessWidget {
  final List<PlaylistTrackEntry> entries;
  final List<Track> playbackTracks;
  final Playlist playlist;

  const _TrackList({
    required this.entries,
    required this.playbackTracks,
    required this.playlist,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
      itemCount: entries.length,
      itemBuilder: (context, i) {
        final entry = entries[i];
        final track = entry.track;

        return GestureDetector(
          key: ValueKey(
            'playlist-${playlist.id}-entry-${entry.entryId}',
          ),
          onTap: () {
            music.playQueue(
              playbackTracks,
              i,
              contextType: ActiveContextType.playlist,
              contextName: playlist.name,
              contextId: playlist.id,
            );
            Navigator.pushNamed(context, '/now-playing');
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: theme.surface,
              border: Border.all(color: theme.border),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: theme.gradient(track.grad),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: TrackArtWidget(
                      artPath: track.artPath,
                      albumId: track.albumId,
                      trackId: track.id,
                      size: 48,
                      borderRadius: 0,
                      defaultIconColor: theme.accent,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: theme.text,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '${track.artist} · ${track.formattedDuration}',
                        style: TextStyle(
                          fontSize: 12,
                          color: theme.muted,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => _showMenu(context, music, entry),
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Icon(Icons.more_vert, size: 20, color: theme.muted),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showMenu(
    BuildContext context,
    MusicProvider music,
    PlaylistTrackEntry entry,
  ) {
    final track = entry.track;

    showSideSheet(
      context,
      title: '${track.art} ${track.title}',
      body: '${track.artist} · ${track.formattedDuration}',
      verticalActions: true,
      actions: [
        ModalAction(
          label: 'Info',
          cls: 'primary',
          action: () => _showInfoDialog(context, track),
        ),
        ModalAction(
          label: 'Share',
          action: () {
            music.shareTrack(track.id);
            VibesToast.show(context, 'Sharing…');
          },
        ),
        ModalAction(
          label: 'Remove from Playlist',
          cls: 'danger',
          action: () {
            music.removePlaylistEntryById(
              playlist.id,
              entry.entryId,
            );
            VibesToast.show(context, 'Removed from playlist');
          },
        ),
      ],
    );
  }

  void _showInfoDialog(BuildContext context, Track track) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      final theme = context.read<ThemeProvider>();
      showModalSheet(
        context,
        title: 'track Info',
        body: '',
        actions: [ModalAction(label: 'Close', action: () {})],
        extra: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InfoRow(label: 'Title', value: track.title, theme: theme),
            InfoRow(label: 'Artist', value: track.artist, theme: theme),
            InfoRow(
              label: 'album',
              value: track.albumName ?? 'Unknown',
              theme: theme,
            ),
            InfoRow(
              label: 'Genre',
              value: track.genre.isNotEmpty ? track.genre : 'Unknown',
              theme: theme,
            ),
            InfoRow(
              label: 'Duration',
              value: track.formattedDuration,
              theme: theme,
            ),
            if (track.formattedSize.isNotEmpty)
              InfoRow(
                label: 'File Size',
                value: track.formattedSize,
                theme: theme,
              ),
            if (track.filePath != null && track.filePath!.isNotEmpty)
              InfoRow(label: 'Path', value: track.filePath!, theme: theme),
          ],
        ),
      );
    });
  }
}

class _SheetMenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _SheetMenuItem({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: theme.surface2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: 0.22)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DangerConfirmButton extends StatelessWidget {
  final String label;
  final Future<void> Function() onTap;

  const _DangerConfirmButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        decoration: BoxDecoration(
          color: Colors.redAccent.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.redAccent.withValues(alpha: 0.45)),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delete_forever_rounded, color: Colors.redAccent),
            SizedBox(width: 10),
            Text(
              'Delete Playlist',
              style: TextStyle(
                color: Colors.redAccent,
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
