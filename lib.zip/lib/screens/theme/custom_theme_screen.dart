import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/theme_customization_service.dart';

class CustomThemeScreen extends StatefulWidget {
  const CustomThemeScreen({super.key});

  @override
  State<CustomThemeScreen> createState() => _CustomThemeScreenState();
}

class _CustomThemeScreenState extends State<CustomThemeScreen> {
  List<CustomThemeData> _themes = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final themes = await ThemeCustomizationService.getThemes();
    if (mounted) {
      setState(() {
        _themes = themes;
        _loading = false;
      });
    }
  }

  Future<void> _createNewTheme() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const _ThemeEditor(theme: null),
      ),
    );
    if (result == true) await _load();
  }

  Future<void> _editTheme(CustomThemeData theme) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _ThemeEditor(theme: theme),
      ),
    );
    if (result == true) await _load();
  }

  Future<void> _deleteTheme(CustomThemeData theme) async {
    final provider = context.read<ThemeProvider>();
    final wasActive = provider.activeCustomTheme?.id == theme.id;
    await ThemeCustomizationService.deleteTheme(theme.id);
    if (wasActive) await provider.clearCustomTheme();
    await _load();
  }

  Future<void> _setActiveTheme(CustomThemeData? theme) async {
    await context.read<ThemeProvider>().applyCustomTheme(theme);
    await _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(theme != null
              ? 'Theme "${theme.name}" applied'
              : 'System theme restored'),
        ),
      );
    }

    // Only applying a real custom theme triggers the interstitial;
    // restoring the system default is always free and ad-free.
    if (theme != null) {
      unawaited(
        InterstitialAdController.maybeShow(
          InterstitialTrigger.customThemeApplied,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            if (_loading)
              Expanded(
                child: Center(
                    child: CircularProgressIndicator(color: theme.accent)),
              )
            else
              Expanded(
                child: _themes.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.palette_outlined,
                                size: 56, color: theme.muted),
                            const SizedBox(height: 16),
                            Text('No custom themes yet',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: theme.text)),
                            const SizedBox(height: 8),
                            Text('Create your first theme to get started',
                                style: TextStyle(
                                    fontSize: 13, color: theme.muted)),
                            const SizedBox(height: 24),
                            _CreateButton(onTap: _createNewTheme),
                          ],
                        ),
                      )
                    : ListView(
                        padding: const EdgeInsets.all(20),
                        children: [
                          _CreateButton(onTap: _createNewTheme),
                          const SizedBox(height: 16),
                          ..._themes.map((t) => _ThemeCard(
                                themeData: t,
                                onEdit: () => _editTheme(t),
                                onDelete: () => _deleteTheme(t),
                                onApply: () => _setActiveTheme(t),
                              )),
                        ],
                      ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(dynamic theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  size: 16, color: theme.text),
            ),
          ),
          const SizedBox(width: 16),
          Text(
            'Custom Themes',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: theme.text,
            ),
          ),
        ],
      ),
    );
  }
}

class _CreateButton extends StatelessWidget {
  final VoidCallback onTap;
  const _CreateButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(
            color: theme.accent.withValues(alpha: 0.3),
            strokeAlign: BorderSide.strokeAlignInside,
          ),
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            colors: [
              theme.accent.withValues(alpha: 0.1),
              theme.accent.withValues(alpha: 0.05),
            ],
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_rounded, color: theme.accent, size: 20),
            const SizedBox(width: 8),
            Text(
              'Create New Theme',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: theme.accent,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final CustomThemeData themeData;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onApply;

  const _ThemeCard({
    required this.themeData,
    required this.onEdit,
    required this.onDelete,
    required this.onApply,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Color preview dots
              ...['primary', 'background', 'accent', 'text'].map((label) {
                Color c;
                switch (label) {
                  case 'primary':
                    c = themeData.primary;
                    break;
                  case 'background':
                    c = themeData.background;
                    break;
                  case 'accent':
                    c = themeData.accent;
                    break;
                  default:
                    c = themeData.text;
                }
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: c,
                      shape: BoxShape.circle,
                      border: Border.all(color: theme.border),
                    ),
                  ),
                );
              }),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  themeData.name,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: theme.text,
                  ),
                ),
              ),
              PopupMenuButton<String>(
                icon: Icon(Icons.more_horiz, color: theme.muted, size: 20),
                color: theme.surface,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                onSelected: (action) {
                  switch (action) {
                    case 'apply':
                      onApply();
                      break;
                    case 'edit':
                      onEdit();
                      break;
                    case 'delete':
                      onDelete();
                      break;
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                      value: 'apply',
                      child: Row(children: const [
                        Icon(Icons.check, size: 18),
                        SizedBox(width: 8),
                        Text('Apply Theme')
                      ])),
                  PopupMenuItem(
                      value: 'edit',
                      child: Row(children: const [
                        Icon(Icons.edit, size: 18),
                        SizedBox(width: 8),
                        Text('Edit')
                      ])),
                  PopupMenuItem(
                      value: 'delete',
                      child: Row(children: [
                        const Icon(Icons.delete, size: 18, color: Colors.red),
                        const SizedBox(width: 8),
                        const Text('Delete',
                            style: TextStyle(color: Colors.red))
                      ])),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Theme editor screen ───────────────────────────────────────────────────────

class _ThemeEditor extends StatefulWidget {
  final CustomThemeData? theme;
  const _ThemeEditor({this.theme});

  @override
  State<_ThemeEditor> createState() => _ThemeEditorState();
}

class _ThemeEditorState extends State<_ThemeEditor> {
  late TextEditingController _nameCtrl;
  late Color _primary, _background, _surface, _accent, _text;
  bool _isDark = true;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.theme?.name ?? 'My Theme');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    final scheme = Theme.of(context).colorScheme;
    _primary = widget.theme?.primary ?? scheme.primary;
    _background = widget.theme?.background ?? scheme.surface;
    _surface = widget.theme?.surface ?? scheme.surfaceContainer;
    _accent = widget.theme?.accent ?? scheme.secondary;
    _text = widget.theme?.text ?? scheme.onSurface;
    _isDark =
        widget.theme?.isDark ?? Theme.of(context).brightness == Brightness.dark;
    _initialized = true;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final theme = CustomThemeData(
      id: widget.theme?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameCtrl.text.trim(),
      primaryColor: _primary.toARGB32(),
      backgroundColor: _background.toARGB32(),
      surfaceColor: _surface.toARGB32(),
      accentColor: _accent.toARGB32(),
      textColor: _text.toARGB32(),
      isDark: _isDark,
      createdAt: widget.theme?.createdAt ?? DateTime.now(),
    );
    await ThemeCustomizationService.saveTheme(theme);
    if (mounted) Navigator.pop(context, true);
  }

  Future<void> _pickColor(Color current, ValueChanged<Color> onPicked) async {
    final result = await showDialog<Color>(
      context: context,
      builder: (_) => _ColorPickerDialog(initialColor: current),
    );
    if (result != null) onPicked(result);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: theme.surface,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: theme.border),
                      ),
                      child: Icon(Icons.close, size: 18, color: theme.text),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      widget.theme != null ? 'Edit Theme' : 'New Theme',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: theme.text,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: _save,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: theme.accent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text('Save',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600)),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  // Name field
                  Container(
                    decoration: BoxDecoration(
                      color: theme.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: theme.border),
                    ),
                    child: TextField(
                      controller: _nameCtrl,
                      style: TextStyle(color: theme.text),
                      decoration: const InputDecoration(
                        labelText: 'Theme Name',
                        border: InputBorder.none,
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Color pickers
                  _colorRow(
                      'Primary', _primary, (c) => setState(() => _primary = c)),
                  _colorRow('Background', _background,
                      (c) => setState(() => _background = c)),
                  _colorRow(
                      'Surface', _surface, (c) => setState(() => _surface = c)),
                  _colorRow(
                      'Accent', _accent, (c) => setState(() => _accent = c)),
                  _colorRow('Text', _text, (c) => setState(() => _text = c)),
                  const SizedBox(height: 20),

                  // Preview
                  Text('Preview',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: theme.text)),
                  const SizedBox(height: 10),
                  Container(
                    height: 120,
                    decoration: BoxDecoration(
                      color: _background,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _surface,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _nameCtrl.text,
                          style: TextStyle(
                            color: _text,
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _colorRow(String label, Color color, ValueChanged<Color> onPick) {
    final theme = context.watch<ThemeProvider>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        onTap: () => _pickColor(color, onPick),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.border),
          ),
          child: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  border: Border.all(color: theme.border),
                ),
              ),
              const SizedBox(width: 12),
              Text(label,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: theme.text)),
              const Spacer(),
              Text(
                  '#${color.toARGB32().toRadixString(16).substring(2).toUpperCase()}',
                  style: TextStyle(fontSize: 12, color: theme.muted)),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right, color: theme.muted, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

/// Simple color picker dialog with preset colors.
class _ColorPickerDialog extends StatefulWidget {
  final Color initialColor;
  const _ColorPickerDialog({required this.initialColor});

  @override
  State<_ColorPickerDialog> createState() => _ColorPickerDialogState();
}

class _ColorPickerDialogState extends State<_ColorPickerDialog> {
  late Color _selected;

  static const _presets = [
    0xFF000000,
    0xFFFFFFFF,
    0xFFFF0000,
    0xFFFF6B35,
    0xFFFF9800,
    0xFFFFEB3B,
    0xFF4CAF50,
    0xFF2196F3,
    0xFF7C4DFF,
    0xFF9C27B0,
    0xFFE91E63,
    0xFF795548,
    0xFF607D8B,
    0xFF0A0A14,
    0xFF1A1A2E,
    0xFF2D1B69,
    0xFF00BCD4,
    0xFF8BC34A,
    0xFFCDDC39,
    0xFFFFC107,
  ];

  @override
  void initState() {
    super.initState();
    _selected = widget.initialColor;
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return AlertDialog(
      backgroundColor: theme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Text('Pick a Color'),
      content: SizedBox(
        width: 280,
        child: Wrap(
          spacing: 10,
          runSpacing: 10,
          children: _presets.map((c) {
            final color = Color(c);
            final isSelected = c == _selected.toARGB32();
            return GestureDetector(
              onTap: () => setState(() => _selected = color),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isSelected
                        ? theme.text
                        : theme.text.withValues(alpha: 0),
                    width: 3,
                  ),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                              color: color.withValues(alpha: 0.5),
                              blurRadius: 8)
                        ]
                      : null,
                ),
              ),
            );
          }).toList(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, _selected),
          style: ElevatedButton.styleFrom(backgroundColor: theme.accent),
          child: const Text('Select'),
        ),
      ],
    );
  }
}
