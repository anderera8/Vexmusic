import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/player_skin_service.dart';
import '../../widgets/hue_slider.dart';

class PlayerSkinScreen extends StatefulWidget {
  const PlayerSkinScreen({super.key});

  @override
  State<PlayerSkinScreen> createState() => _PlayerSkinScreenState();
}

class _PlayerSkinScreenState extends State<PlayerSkinScreen> {
  PlayerSkinSettings _settings = const PlayerSkinSettings();
  bool _loading = true;

  /// Whether the person has actually changed a skin setting this visit.
  /// The interstitial fires once, on the way out, but only if they made a
  /// change — just opening the screen and backing out shouldn't trigger it.
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final settings = await PlayerSkinService.getSettings();

    if (!mounted) return;

    setState(() {
      _settings = settings;
      _loading = false;
    });
  }

  Future<void> _update(
    PlayerSkinSettings Function(PlayerSkinSettings) fn,
  ) async {
    final updated = fn(_settings);

    setState(() {
      _settings = updated;
      _dirty = true;
    });

    await PlayerSkinService.saveSettings(updated);
  }

  void _handleBack() {
    if (_dirty) {
      unawaited(
        InterstitialAdController.maybeShow(
          InterstitialTrigger.playerSkinApplied,
        ),
      );
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    if (_loading) {
      return Scaffold(
        backgroundColor: theme.bg,
        body: Center(
          child: CircularProgressIndicator(color: theme.accent),
        ),
      );
    }

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const _SectionLabel('Layout'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Default',
                    description: 'Standard layout with all controls',
                    icon: Icons.view_agenda_rounded,
                    selected: _settings.layoutStyle == 'default',
                    onTap: () {
                      _update((s) => s.copyWith(layoutStyle: 'default'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Minimal',
                    description: 'Clean, minimal controls',
                    icon: Icons.view_stream_rounded,
                    selected: _settings.layoutStyle == 'minimal',
                    onTap: () {
                      _update((s) => s.copyWith(layoutStyle: 'minimal'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Classic',
                    description: 'Retro music player style',
                    icon: Icons.radio_rounded,
                    selected: _settings.layoutStyle == 'classic',
                    onTap: () {
                      _update((s) => s.copyWith(layoutStyle: 'classic'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Modern',
                    description: 'Sleek contemporary design',
                    icon: Icons.auto_awesome_rounded,
                    selected: _settings.layoutStyle == 'modern',
                    onTap: () {
                      _update((s) => s.copyWith(layoutStyle: 'modern'));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Header Design'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Shimmer',
                    description: 'Animated glowing NOW PLAYING title',
                    icon: Icons.auto_awesome_rounded,
                    selected: _settings.headerStyle == 'shimmer',
                    onTap: () {
                      _update((s) => s.copyWith(headerStyle: 'shimmer'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Clean',
                    description: 'Simple modern title bar',
                    icon: Icons.title_rounded,
                    selected: _settings.headerStyle == 'clean',
                    onTap: () {
                      _update((s) => s.copyWith(headerStyle: 'clean'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Glass',
                    description: 'Floating translucent header',
                    icon: Icons.blur_on_rounded,
                    selected: _settings.headerStyle == 'glass',
                    onTap: () {
                      _update((s) => s.copyWith(headerStyle: 'glass'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Pill',
                    description: 'Compact centered capsule title',
                    icon: Icons.label_rounded,
                    selected: _settings.headerStyle == 'pill',
                    onTap: () {
                      _update((s) => s.copyWith(headerStyle: 'pill'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Vinyl',
                    description: 'Retro disc-style header',
                    icon: Icons.album_rounded,
                    selected: _settings.headerStyle == 'vinyl',
                    onTap: () {
                      _update((s) => s.copyWith(headerStyle: 'vinyl'));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Artwork Shape'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Rounded',
                    description: 'Soft rounded album artwork',
                    icon: Icons.rounded_corner_rounded,
                    selected: _settings.artworkShape == 'rounded',
                    onTap: () {
                      _update((s) => s.copyWith(artworkShape: 'rounded'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Circle',
                    description: 'Circular disc-style artwork',
                    icon: Icons.circle_rounded,
                    selected: _settings.artworkShape == 'circle',
                    onTap: () {
                      _update((s) => s.copyWith(artworkShape: 'circle'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Square',
                    description: 'Sharp square artwork',
                    icon: Icons.square_rounded,
                    selected: _settings.artworkShape == 'square',
                    onTap: () {
                      _update((s) => s.copyWith(artworkShape: 'square'));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Artwork Style'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Standard Art',
                    description: 'Clean album art card',
                    icon: Icons.image_rounded,
                    selected: _settings.artworkStyle == 'standard',
                    onTap: () {
                      _update((s) => s.copyWith(artworkStyle: 'standard'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Glow Art',
                    description: 'album art with accent glow',
                    icon: Icons.lightbulb_rounded,
                    selected: _settings.artworkStyle == 'glow',
                    onTap: () {
                      _update((s) => s.copyWith(artworkStyle: 'glow'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Vinyl Art',
                    description: 'Retro framed album artwork',
                    icon: Icons.album_rounded,
                    selected: _settings.artworkStyle == 'vinyl',
                    onTap: () {
                      _update((s) => s.copyWith(artworkStyle: 'vinyl'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Flat Art',
                    description: 'No heavy shadows',
                    icon: Icons.crop_square_rounded,
                    selected: _settings.artworkStyle == 'flat',
                    onTap: () {
                      _update((s) => s.copyWith(artworkStyle: 'flat'));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Background'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Solid Color',
                    description: 'Use the app background color',
                    icon: Icons.format_paint_rounded,
                    selected: _settings.backgroundStyle == 'solid',
                    onTap: () {
                      _update((s) => s.copyWith(backgroundStyle: 'solid'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Gradient',
                    description: 'Smooth layered player gradient',
                    icon: Icons.gradient_rounded,
                    selected: _settings.backgroundStyle == 'gradient',
                    onTap: () {
                      _update((s) => s.copyWith(backgroundStyle: 'gradient'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Blurred Artwork',
                    description: 'Use blurred album art as background',
                    icon: Icons.blur_on_rounded,
                    selected: _settings.backgroundStyle == 'blurArt',
                    onTap: () {
                      _update((s) => s.copyWith(backgroundStyle: 'blurArt'));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Adaptive Appearance'),
                  const SizedBox(height: 12),
                  _ToggleOption(
                    label: 'Artwork Adaptive Colors',
                    description:
                        'Tint the player background and visualizer from album art',
                    value: _settings.adaptiveColors,
                    onChanged: (value) {
                      _update((s) => s.copyWith(adaptiveColors: value));
                    },
                  ),
                  _ToggleOption(
                    label: 'Lyrics Focus Mode',
                    description:
                        'Hide playback chrome while full-screen lyrics are open',
                    value: _settings.lyricsFocusMode,
                    onChanged: (value) {
                      _update((s) => s.copyWith(lyricsFocusMode: value));
                    },
                  ),
                  const SizedBox(height: 24),
                  const _SectionLabel('Visualizer'),
                  const SizedBox(height: 12),
                  _LayoutOption(
                    label: 'Off',
                    description: 'Keep the player background still',
                    icon: Icons.visibility_off_rounded,
                    selected: _settings.visualizerMode == 'off',
                    onTap: () {
                      _update((s) => s.copyWith(visualizerMode: 'off'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Spectrum Bars',
                    description: 'Ten responsive frequency bars',
                    icon: Icons.graphic_eq_rounded,
                    selected: _settings.visualizerMode == 'bars',
                    onTap: () {
                      _update((s) => s.copyWith(visualizerMode: 'bars'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Wave',
                    description: 'A smooth audio-reactive waveform',
                    icon: Icons.waves_rounded,
                    selected: _settings.visualizerMode == 'wave',
                    onTap: () {
                      _update((s) => s.copyWith(visualizerMode: 'wave'));
                    },
                  ),
                  _LayoutOption(
                    label: 'Mirror',
                    description: 'Mirrored spectrum around the center line',
                    icon: Icons.align_vertical_center_rounded,
                    selected: _settings.visualizerMode == 'mirror',
                    onTap: () {
                      _update((s) => s.copyWith(visualizerMode: 'mirror'));
                    },
                  ),
                  if (_settings.visualizerMode != 'off') ...[
                    const SizedBox(height: 16),
                    _VisualizerColorPicker(
                      hue: _settings.visualizerHue,
                      onChanged: (hue) {
                        _update((s) => s.copyWith(visualizerHue: hue));
                      },
                    ),
                  ],
                  const SizedBox(height: 24),
                  const _SectionLabel('Visibility'),
                  const SizedBox(height: 12),
                  _ToggleOption(
                    label: 'Show album Art',
                    value: _settings.showalbumArt,
                    onChanged: (v) {
                      _update((s) => s.copyWith(showalbumArt: v));
                    },
                  ),
                  _ToggleOption(
                    label: 'Show Seek Bar',
                    value: _settings.showSeekBar,
                    onChanged: (v) {
                      _update((s) => s.copyWith(showSeekBar: v));
                    },
                  ),
                  _ToggleOption(
                    label: 'Show Queue Info',
                    value: _settings.showQueueInfo,
                    onChanged: (v) {
                      _update((s) => s.copyWith(showQueueInfo: v));
                    },
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeProvider theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: _handleBack,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                size: 16,
                color: theme.text,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              'Player Skins',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: theme.text,
              ),
            ),
          ),
        ],
      ),
    );
  }

}

class _SectionLabel extends StatelessWidget {
  final String text;

  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Text(
      text.toUpperCase(),
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: theme.muted,
        letterSpacing: 1.6,
      ),
    );
  }
}

class _LayoutOption extends StatelessWidget {
  final String label;
  final String? description;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _LayoutOption({
    required this.label,
    this.description,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? theme.accent.withValues(alpha: 0.1) : theme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? theme.accent : theme.border,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: selected ? theme.accent : theme.muted,
              size: 22,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: selected ? theme.accent : theme.text,
                    ),
                  ),
                  if (description != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      description!,
                      style: TextStyle(
                        fontSize: 11,
                        color: theme.muted,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (selected)
              Icon(
                Icons.check_circle_rounded,
                color: theme.accent,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }
}

class _VisualizerColorPicker extends StatelessWidget {
  final double hue;
  final ValueChanged<double> onChanged;

  const _VisualizerColorPicker({
    required this.hue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final previewColor = HSVColor.fromAHSV(1, hue, 1, 1).toColor();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: previewColor,
                  border: Border.all(
                    color: theme.border,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  'Visualizer Color',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: theme.text,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 36),
            child: Text(
              'Slide to pick any color. This only affects the visualizer '
              '— your album-based background tint stays the same.',
              style: TextStyle(fontSize: 11, color: theme.muted),
            ),
          ),
          const SizedBox(height: 14),
          HueSlider(hue: hue, onChanged: onChanged),
        ],
      ),
    );
  }
}

class _ToggleOption extends StatelessWidget {
  final String label;
  final String? description;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleOption({
    required this.label,
    this.description,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: theme.text,
                  ),
                ),
                if (description != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    description!,
                    style: TextStyle(
                      fontSize: 11,
                      color: theme.muted,
                    ),
                  ),
                ],
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: theme.accent,
          ),
        ],
      ),
    );
  }
}
