import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/theme_provider.dart';
import '../../providers/lyric_theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../services/lyric_theme_service.dart';
import '../../services/lyrics_service.dart';
import '../now_playing/widgets/karaoke_lyric_line.dart';

class LyricThemeScreen extends StatefulWidget {
  const LyricThemeScreen({super.key});

  @override
  State<LyricThemeScreen> createState() => _LyricThemeScreenState();
}

class _LyricThemeScreenState extends State<LyricThemeScreen> {
  static const _fonts = ['Default', 'Serif', 'Monospace', 'Cursive', 'Fantasy'];

  /// Whether the person has actually changed a lyric theme setting this
  /// visit. The interstitial fires once, on the way out, but only if they
  /// made a change — just opening the screen and backing out shouldn't
  /// trigger it.
  bool _dirty = false;

  Future<void> _update(
      LyricThemeSettings Function(LyricThemeSettings) fn) async {
    _dirty = true;
    await context.read<LyricThemeProvider>().update(fn);
  }

  void _handleBack() {
    if (_dirty) {
      unawaited(
        InterstitialAdController.maybeShow(
          InterstitialTrigger.lyricThemeApplied,
        ),
      );
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final lyricTheme = context.watch<LyricThemeProvider>();
    final settings = lyricTheme.settings;
    if (lyricTheme.isLoading) {
      return Scaffold(
        backgroundColor: theme.bg,
        body: Center(child: CircularProgressIndicator(color: theme.accent)),
      );
    }

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(theme),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  // Font family
                  const _SectionLabel('Font'),
                  const SizedBox(height: 12),
                  ..._fonts.map((font) => _LayoutOption(
                        label: font,
                        icon: Icons.text_fields,
                        selected: settings.fontFamily == font,
                        onTap: () =>
                            _update((s) => s.copyWith(fontFamily: font)),
                      )),
                  const SizedBox(height: 24),

                  // Font sizes
                  const _SectionLabel('Font Size'),
                  const SizedBox(height: 12),
                  _SliderOption(
                    label: 'Active Line Size',
                    value: settings.activeFontSize,
                    min: 16,
                    max: 36,
                    onChanged: (v) =>
                        _update((s) => s.copyWith(activeFontSize: v)),
                  ),
                  _SliderOption(
                    label: 'Inactive Line Size',
                    value: settings.inactiveFontSize,
                    min: 10,
                    max: 24,
                    onChanged: (v) =>
                        _update((s) => s.copyWith(inactiveFontSize: v)),
                  ),
                  const SizedBox(height: 24),

                  // Colors
                  const _SectionLabel('Colors'),
                  const SizedBox(height: 12),
                  _ColorOption(
                    label: 'Active Line Color',
                    color: Color(settings.activeColor),
                    onTap: () => _pickColor(
                        Color(settings.activeColor),
                        (c) => _update(
                            (s) => s.copyWith(activeColor: c.toARGB32()))),
                  ),
                  _ColorOption(
                    label: 'Inactive Line Color',
                    color: Color(settings.inactiveColor),
                    onTap: () => _pickColor(
                        Color(settings.inactiveColor),
                        (c) => _update(
                            (s) => s.copyWith(inactiveColor: c.toARGB32()))),
                  ),
                  _ColorOption(
                    label: 'Background Color',
                    color: Color(settings.backgroundColor),
                    onTap: () => _pickColor(
                        Color(settings.backgroundColor),
                        (c) => _update(
                            (s) => s.copyWith(backgroundColor: c.toARGB32()))),
                  ),
                  const SizedBox(height: 24),

                  const _SectionLabel('Layout'),
                  const SizedBox(height: 12),
                  ...[
                    ('Left', 'left', Icons.format_align_left_rounded),
                    ('Center', 'center', Icons.format_align_center_rounded),
                    ('Right', 'right', Icons.format_align_right_rounded),
                  ].map((option) => _LayoutOption(
                        label: option.$1,
                        icon: option.$3,
                        selected: settings.textAlign == option.$2,
                        onTap: () => _update(
                          (s) => s.copyWith(textAlign: option.$2),
                        ),
                      )),
                  SwitchListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                    title: Text(
                      'Background gradient',
                      style: TextStyle(color: theme.text),
                    ),
                    subtitle: Text(
                      'Blend the lyric background with the active accent',
                      style: TextStyle(color: theme.muted, fontSize: 12),
                    ),
                    activeThumbColor: theme.accent,
                    value: settings.showGradient,
                    onChanged: (value) => _update(
                      (s) => s.copyWith(showGradient: value),
                    ),
                  ),
                  const SizedBox(height: 24),

                  const _SectionLabel('Karaoke'),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                    title: Text(
                      'Karaoke Mode',
                      style: TextStyle(color: theme.text),
                    ),
                    subtitle: Text(
                      'Highlight the active line word-by-word as it plays, '
                      'using precise timing when the lyrics include it, or '
                      'an estimate for line-synced lyrics.',
                      style: TextStyle(color: theme.muted, fontSize: 12),
                    ),
                    activeThumbColor: theme.accent,
                    value: settings.karaokeMode,
                    onChanged: (value) => _update(
                      (s) => s.copyWith(karaokeMode: value),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Preview
                  const _SectionLabel('Preview'),
                  const SizedBox(height: 12),
                  Container(
                    height: 140,
                    decoration: BoxDecoration(
                      color: Color(settings.backgroundColor),
                      gradient: settings.showGradient
                          ? LinearGradient(
                              colors: [
                                Color(settings.backgroundColor),
                                theme.accent.withValues(alpha: 0.18),
                              ],
                            )
                          : null,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      crossAxisAlignment: switch (settings.textAlign) {
                        'left' => CrossAxisAlignment.start,
                        'right' => CrossAxisAlignment.end,
                        _ => CrossAxisAlignment.center,
                      },
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: Text(
                            'Inactive lyric line',
                            textAlign: switch (settings.textAlign) {
                              'left' => TextAlign.left,
                              'right' => TextAlign.right,
                              _ => TextAlign.center,
                            },
                            style: TextStyle(
                              fontFamily: settings.resolvedFontFamily,
                              fontSize: settings.inactiveFontSize,
                              color: Color(settings.inactiveColor),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: settings.karaokeMode
                              ? _KaraokePreview(settings: settings)
                              : Text(
                                  'Active lyric line',
                                  textAlign: switch (settings.textAlign) {
                                    'left' => TextAlign.left,
                                    'right' => TextAlign.right,
                                    _ => TextAlign.center,
                                  },
                                  style: TextStyle(
                                    fontFamily: settings.resolvedFontFamily,
                                    fontSize: settings.activeFontSize,
                                    fontWeight: FontWeight.w700,
                                    color: Color(settings.activeColor),
                                  ),
                                ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickColor(Color current, ValueChanged<Color> onPicked) async {
    final presets = [
      0xFFFFFFFF,
      0xFFE0E0E0,
      0xFFFFD54F,
      0xFF7C4DFF,
      0xFF4CAF50,
      0xFF2196F3,
      0xFFFF6B35,
      0xFFE91E63,
      0xFF000000,
      0xFF0A0A14,
    ];
    final result = await showDialog<Color>(
      context: context,
      builder: (ctx) {
        final theme = context.watch<ThemeProvider>();
        return AlertDialog(
          backgroundColor: theme.surface,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('Pick a Color'),
          content: SizedBox(
            width: 260,
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: presets.map((c) {
                final color = Color(c);
                return GestureDetector(
                  onTap: () => Navigator.pop(ctx, color),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: c == current.toARGB32()
                              ? Colors.white
                              : Colors.transparent,
                          width: 3),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
          ],
        );
      },
    );
    if (result != null) onPicked(result);
  }

  Widget _buildHeader(dynamic theme) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
      child: Row(
        children: [
          GestureDetector(
            onTap: _handleBack,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  size: 16, color: theme.text),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text('Lyric Themes',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: theme.text)),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Text(text.toUpperCase(),
        style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: theme.muted,
            letterSpacing: 1.6));
  }
}

class _LayoutOption extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _LayoutOption(
      {required this.label,
      required this.icon,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? theme.accent.withValues(alpha: 0.1) : theme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? theme.accent : theme.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: selected ? theme.accent : theme.muted, size: 22),
            const SizedBox(width: 14),
            Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: selected ? theme.accent : theme.text))),
            if (selected)
              Icon(Icons.check_circle, color: theme.accent, size: 20),
          ],
        ),
      ),
    );
  }
}

class _SliderOption extends StatelessWidget {
  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  const _SliderOption(
      {required this.label,
      required this.value,
      required this.min,
      required this.max,
      required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                  child: Text(label,
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: theme.text))),
              Text('${value.round()}px',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: theme.accent)),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            activeColor: theme.accent,
            inactiveColor: theme.surface2,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _ColorOption extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ColorOption(
      {required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: theme.border),
        ),
        child: Row(
          children: [
            Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(color: theme.border))),
            const SizedBox(width: 14),
            Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: theme.text))),
            Icon(Icons.chevron_right, color: theme.muted, size: 18),
          ],
        ),
      ),
    );
  }
}

/// A small looping demo of the karaoke word-highlight, so the effect is
/// visible right in settings without needing a track to be playing.
/// Reuses the real [KaraokeLyricLine] renderer against a synthetic clock.
class _KaraokePreview extends StatefulWidget {
  final LyricThemeSettings settings;

  const _KaraokePreview({required this.settings});

  @override
  State<_KaraokePreview> createState() => _KaraokePreviewState();
}

class _KaraokePreviewState extends State<_KaraokePreview>
    with SingleTickerProviderStateMixin {
  static const _demoLine = LyricLine(
    timestamp: Duration.zero,
    text: 'Sing along with the music',
  );
  static const _demoDuration = Duration(seconds: 3);

  late final AnimationController _controller;
  final ValueNotifier<Duration> _position = ValueNotifier(Duration.zero);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: _demoDuration)
      ..addListener(() {
        _position.value = _demoDuration * _controller.value;
      })
      ..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    _position.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = widget.settings;

    return KaraokeLyricLine(
      position: _position,
      line: _demoLine,
      nextLine: null,
      totalDuration: _demoDuration,
      style: TextStyle(
        fontFamily: settings.resolvedFontFamily,
        fontSize: settings.activeFontSize,
        fontWeight: FontWeight.w700,
        height: 1.3,
      ),
      sungColor: Color(settings.activeColor),
      unsungColor: Color(settings.inactiveColor),
      textAlign: switch (settings.textAlign) {
        'left' => TextAlign.left,
        'right' => TextAlign.right,
        _ => TextAlign.center,
      },
    );
  }
}
