import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_theme.dart';
import '../../providers/theme_provider.dart';

class ThemeSelectionScreen extends StatelessWidget {
  const ThemeSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Single provider reference — context.watch handles both listening and reading.
    final theme = context.watch<ThemeProvider>();
    final currentTheme = theme.themeType;

    return Scaffold(
      backgroundColor: theme.bg,
      appBar: AppBar(
        backgroundColor: theme.bg,
        elevation: 0,
        title: const Text(
          'Choose Theme',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              size: 18, color: theme.text),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: ThemeType.values.map((themeType) {
          final isSelected = !theme.hasCustomTheme && currentTheme == themeType;
          return _ThemeOption(
            themeType: themeType,
            isSelected: isSelected,
            onTap: () => theme.setTheme(themeType),
          );
        }).toList(),
      ),
    );
  }
}

class _ThemeOption extends StatelessWidget {
  final ThemeType themeType;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeOption({
    required this.themeType,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      // HitTestBehavior.opaque ensures the entire tile — including the padding
      // and any transparent space between the icon and the text — fires onTap.
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color:
              isSelected ? theme.accent.withValues(alpha: 0.15) : theme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? theme.accent : theme.border,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.accent.withValues(alpha: 0.2)
                    : theme.surface2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                themeType.icon,
                color: isSelected ? theme.accent : theme.muted,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    themeType.label,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? theme.accent : theme.text,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    themeType.description,
                    style: TextStyle(
                      fontSize: 13,
                      color: theme.muted,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: theme.accent,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check,
                  size: 16,
                  color: Theme.of(context).colorScheme.onPrimary,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
