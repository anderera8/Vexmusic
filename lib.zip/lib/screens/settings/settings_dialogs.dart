import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../providers/theme_provider.dart';

const _privacyPolicyUrl = 'https://appland.info/app/33260/privacy-policy';

Future<void> _openPrivacyPolicy() async {
  final uri = Uri.parse(_privacyPolicyUrl);

  try {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {
    // Browser unavailable — silently ignore.
  }
}

void showVibesAboutDialog(BuildContext context) {
  final theme = context.read<ThemeProvider>();

  showDialog(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: theme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.accent, theme.accent2],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.music_note,
                size: 40,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Vibes Player',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: theme.text,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Stylish Music Player',
              style: TextStyle(fontSize: 14, color: theme.muted),
            ),
            const SizedBox(height: 16),
            Divider(color: theme.border),
            const SizedBox(height: 16),
            Text(
              'Version 2.2.1+11\n\n'
              '• Smooth listening experience\n\n'
              '• No account required\n'
              '• All in one place\n'
              '• Your music stays on your device',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: theme.muted),
            ),
            const SizedBox(height: 8),
            Text(
              '© 2026 Vibes Player. All rights reserved.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: theme.muted),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              style: ElevatedButton.styleFrom(
                backgroundColor: theme.accent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text('OK'),
            ),
          ],
        ),
      ),
    ),
  );
}

void showVibesPrivacyDialog(BuildContext context) {
  final theme = context.read<ThemeProvider>();

  showDialog(
    context: context,
    builder: (ctx) => Dialog(
      backgroundColor: theme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Privacy Policy',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: theme.text,
              ),
            ),
            const SizedBox(height: 16),
            Flexible(
              child: SingleChildScrollView(
                child: Text(
                  'Vibes Player does not require an account\n\n'
                  '• Your music files stay on your device\n'
                  'Third-Party Services\n'
                  '• Firebase Crashlytics\n'
                  '• Firebase Performance'
                  '• Unity Ads\n'
                  '• Radio Browse API\n'
                  '• LRCLIB.',
                  style: TextStyle(fontSize: 13, color: theme.muted),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.accent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: const Text('Close'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    onPressed: _openPrivacyPolicy,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: theme.accent,
                      side: BorderSide(
                        color: theme.accent.withValues(alpha: 0.4),
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: const Text('View Full Policy'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
