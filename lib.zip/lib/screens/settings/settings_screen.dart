import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/settings_tiles.dart';
import '../../widgets/toast.dart';
import 'settings_dialogs.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _closeSettings(BuildContext context) {
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _Header(onBack: () => _closeSettings(context)),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
                children: [
                  const SettingsSectionHeader('Appearance'),
                  SettingsSection(
                    children: [
                      SettingsActionTile(
                        icon: Icons.palette_outlined,
                        label: 'Theme',
                        subtitle: theme.themeLabel,
                        onTap: () =>
                            Navigator.pushNamed(context, '/theme-selection'),
                      ),
                      SettingsActionTile(
                        icon: Icons.brush_rounded,
                        label: 'Custom Theme',
                        subtitle: 'Create your own colour scheme',
                        onTap: () =>
                            Navigator.pushNamed(context, '/custom-themes'),
                      ),
                    ],
                  ),
                  const SettingsSectionHeader('Playback'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.equalizer_rounded,
                        label: 'Volume normalisation',
                        subtitle: 'Keep all tracks at consistent loudness',
                        value: music.normEnabled,
                        onChanged: (_) => music.toggleNorm(),
                      ),
                      SettingsSliderTile(
                        icon: Icons.speed_rounded,
                        label: 'Playback speed',
                        value: music.playbackSpeed,
                        min: 0.5,
                        max: 2.0,
                        divisions: 6,
                        format: (value) => '${value.toStringAsFixed(1)}x',
                        onChanged: music.setPlaybackSpeed,
                      ),
                      SettingsSliderTile(
                        icon: Icons.blur_on_rounded,
                        label: 'Crossfade',
                        value: music.crossfadeSeconds.toDouble(),
                        min: 0,
                        max: 12,
                        divisions: 6,
                        format: (value) =>
                            value == 0 ? 'Off' : '${value.toInt()} sec',
                        onChanged: (value) => music.setCrossfade(value.toInt()),
                      ),
                      SettingsPickerTile(
                        icon: Icons.timer_outlined,
                        label: 'Sleep timer',
                        current: music.sleepTimer,
                        options: const [
                          'Off',
                          '5 min',
                          '10 min',
                          '15 min',
                          '30 min',
                          '45 min',
                          '1 hour',
                        ],
                        onPick: (value) {
                          music.setSleepTimer(value);
                          VibesToast.show(
                            context,
                            value == 'Off'
                                ? 'Sleep timer off'
                                : 'Sleep timer: $value',
                          );
                        },
                      ),
                    ],
                  ),
                  const SettingsSectionHeader('Library'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.copy_all_rounded,
                        label: 'Allow duplicates',
                        subtitle: 'Show multiple copies of the same track',
                        value: music.allowDuplicates,
                        onChanged: (_) => music.toggleDuplicates(),
                      ),
                      SettingsPickerTile(
                        icon: Icons.queue_music_rounded,
                        label: 'Queue mode',
                        current: music.queueMode,
                        options: const [
                          'Add to end',
                          'Play next',
                          'Shuffle in',
                        ],
                        onPick: music.setQueueMode,
                      ),
                    ],
                  ),
                  const SettingsSectionHeader('System'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.play_circle_outline_rounded,
                        label: 'Background playback',
                        subtitle: 'Keep playing when app is backgrounded',
                        value: music.bgPlayback,
                        onChanged: (_) => music.toggleBgPlayback(),
                      ),
                      SettingsToggleTile(
                        icon: Icons.lock_outline_rounded,
                        label: 'Lock screen controls',
                        subtitle: 'Show controls on device lock screen',
                        value: music.lockScreenControls,
                        onChanged: (_) => music.toggleLockScreen(),
                      ),
                      SettingsActionTile(
                        icon: Icons.info_outline_rounded,
                        label: 'About',
                        subtitle: 'Version 2.2.1+11',
                        onTap: () => showVibesAboutDialog(context),
                      ),
                      SettingsActionTile(
                        icon: Icons.privacy_tip_rounded,
                        label: 'Privacy Policy',
                        subtitle: 'View our privacy policy',
                        onTap: () => showVibesPrivacyDialog(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: Text(
                      'Vibes Player 2.2.1+11',
                      style: TextStyle(fontSize: 12, color: theme.muted),
                    ),
                  ),
                ],
              ),
            ),
            const AdBannerBar(),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final VoidCallback onBack;

  const _Header({required this.onBack});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
      child: Row(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: onBack,
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(
                Icons.arrow_back_ios_new_rounded,
                color: theme.text,
                size: 18,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Text(
            'Settings',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: theme.text,
            ),
          ),
        ],
      ),
    );
  }
}
