import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/music_models.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/model_sheet.dart';
import '../../widgets/toast.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// GENRE DETAIL SCREEN — lists all tracks of a given genre
// ═══════════════════════════════════════════════════════════════════════════════

class GenreDetailScreen extends StatelessWidget {
  final Genre genre;
  const GenreDetailScreen({super.key, required this.genre});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();
    final tracks = music.tracksForGenre(genre);

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _DetailHeader(genre: genre),
            Expanded(
              child: tracks.isEmpty
                  ? Center(
                      child: Text(
                        'No tracks in this genre',
                        style: TextStyle(color: theme.muted),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
                      itemCount: tracks.length,
                      itemBuilder: (context, i) {
                        final track = tracks[i];
                        final realIndex =
                            music.tracks.indexWhere((t) => t.id == track.id);
                        return GestureDetector(
                          onTap: () {
                            music.playQueue(tracks, i);
                            Navigator.pushNamed(context, '/now-playing');
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 11),
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(
                              color: theme.surface,
                              border: Border.all(color: theme.border),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 52,
                                  height: 52,
                                  decoration: BoxDecoration(
                                    gradient: theme.gradient(track.grad),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    track.art,
                                    style: const TextStyle(fontSize: 22),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        track.title,
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          color: theme.text,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${track.artist} · ${track.formattedDuration}',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: theme.muted,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () => _showtrackMenu(
                                      context, track, realIndex, music),
                                  child: Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: theme.surface2,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Icon(Icons.more_horiz_rounded,
                                        size: 20, color: theme.muted),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            const AdBannerBar(),
            MiniPlayer(
              onTap: () => Navigator.pushNamed(context, '/now-playing'),
            ),
          ],
        ),
      ),
    );
  }

  void _showtrackMenu(
      BuildContext context, Track track, int realIndex, MusicProvider music) {
    showModalSheet(
      context,
      title: '${track.art} ${track.title}',
      body: '${track.artist} · ${track.formattedDuration}',
      actions: [
        ModalAction(
          label: 'Add to playlist',
          popAfter: false,
          action: () {
            Navigator.pop(context);
            if (music.playlists.isEmpty) {
              VibesToast.show(context, 'Create a playlist first');
              return;
            }
            _showAddToPlaylist(context, music, track);
          },
        ),
        ModalAction(
          label: 'Tag Editor',
          cls: 'primary',
          popAfter: false,
          action: () {
            Navigator.pop(context);
            Navigator.pushNamed(context, '/tag-editor', arguments: track);
          },
        ),
        ModalAction(
          label: track.liked ? 'Unlike ♥' : 'Like ♥',
          cls: 'primary',
          action: () {
            music.toggleLike(track.id);
            VibesToast.show(context, track.liked ? '❤ Liked' : 'Unliked');
            InterstitialAdController.maybeShow(
              InterstitialTrigger.favoriteToggled,
            );
          },
        ),
      ],
    );
  }

  void _showAddToPlaylist(
      BuildContext context, MusicProvider music, Track track) {
    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      final theme = context.read<ThemeProvider>();

      showModalSheet(
        context,
        title: 'Add to Playlist',
        body: 'Select a playlist:',
        actions: [ModalAction(label: 'Cancel', action: () {})],
        extra: Column(
          children: music.playlists.map((pl) {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.pop(context);
                music.addTrackToPlaylist(pl.id, track.id);
                VibesToast.show(context, 'Added to "${pl.name}"');
                InterstitialAdController.maybeShow(
                  InterstitialTrigger.playlistAction,
                );
              },
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: theme.surface2,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Text(pl.art, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(pl.name,
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: theme.text),
                              overflow: TextOverflow.ellipsis),
                          Text('${pl.trackCount} tracks',
                              style:
                                  TextStyle(fontSize: 11, color: theme.muted)),
                        ],
                      ),
                    ),
                    Icon(Icons.add_rounded, size: 18, color: theme.accent),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      );
    });
  }
}

class _DetailHeader extends StatelessWidget {
  final Genre genre;
  const _DetailHeader({required this.genre});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 40, 20, 24),
      decoration: BoxDecoration(
        gradient: theme.gradient(genre.grad),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: Colors.white, size: 18),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  final music = context.read<MusicProvider>();
                  final tracks = music.tracksForGenre(genre);
                  if (tracks.isNotEmpty) {
                    music.playQueue(tracks, 0);
                    Navigator.pushNamed(context, '/now-playing');
                  }
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 20),
                      SizedBox(width: 6),
                      Text(
                        'Play All',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            genre.art,
            style: const TextStyle(fontSize: 56),
          ),
          const SizedBox(height: 12),
          Text(
            genre.name,
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${genre.trackCount} track${genre.trackCount != 1 ? 's' : ''}',
            style: TextStyle(
              fontSize: 13,
              color: Colors.white.withValues(alpha: 0.8),
            ),
          ),
        ],
      ),
    );
  }
}
