import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/music_provider.dart';
import '../../providers/theme_provider.dart';
import '../../models/music_models.dart';
import '../../services/ads/interstitial_ad_controller.dart';
import '../../widgets/ads/ad_banner_bar.dart';
import '../../widgets/track_art_widget.dart';
import '../../widgets/mini_player.dart';
import '../../widgets/model_sheet.dart';
import '../../widgets/toast.dart';
import '../../widgets/info_row.dart';

class FolderDetailScreen extends StatefulWidget {
  final String folderName;
  final List<Track> tracks;

  const FolderDetailScreen({
    super.key,
    required this.folderName,
    required this.tracks,
  });

  @override
  State<FolderDetailScreen> createState() => _FolderDetailScreenState();
}

class _FolderDetailScreenState extends State<FolderDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();
    final tracks = music.tracks
        .where((track) => _folderName(track) == widget.folderName)
        .toList();

    return Scaffold(
      backgroundColor: theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            _Header(folderName: widget.folderName, count: tracks.length),
            Expanded(
                child:
                    _TrackList(tracks: tracks, folderName: widget.folderName)),
            const AdBannerBar(),
            MiniPlayer(
              onTap: () => Navigator.pushNamed(context, '/now-playing'),
            ),
          ],
        ),
      ),
    );
  }

  String _folderName(Track track) {
    final parts = (track.filePath ?? '').split(RegExp(r'[/\\]'));
    return parts.length >= 2 ? parts[parts.length - 2] : 'Unknown';
  }
}

class _Header extends StatelessWidget {
  final String folderName;
  final int count;
  const _Header({required this.folderName, required this.count});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: theme.surface,
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: theme.border),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  color: theme.text, size: 18),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  folderName,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: theme.text,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                ),
                Text(
                  '$count track${count != 1 ? 's' : ''}',
                  style: TextStyle(fontSize: 12, color: theme.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackList extends StatelessWidget {
  final List<Track> tracks;
  final String folderName;
  const _TrackList({required this.tracks, required this.folderName});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
      itemCount: tracks.length,
      itemBuilder: (context, i) {
        final track = tracks[i];
        return GestureDetector(
          // Tapping the track tile plays it in the mini-player (does NOT navigate away)
          onTap: () {
            music.playQueue(tracks, i,
                contextType: ActiveContextType.folder, contextName: folderName);
            Navigator.pushNamed(context, '/now-playing');
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
              color: theme.surface,
              border: Border.all(color: theme.border),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: theme.gradient(track.grad),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: TrackArtWidget(
                      artPath: track.artPath,
                      albumId: track.albumId,
                      mediaStoreId: track.mediaStoreId,
                      volumeName: track.volumeName,
                      stableKey: track.stableKey,
                      trackId: track.id,
                      size: 48,
                      borderRadius: 0,
                      defaultIconColor: theme.accent,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: theme.text,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        '${track.artist} · ${track.formattedDuration}',
                        style: TextStyle(
                          fontSize: 12,
                          color: theme.muted,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                if (track.liked)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Icon(Icons.favorite_rounded,
                        color: theme.danger, size: 16),
                  ),
                // Dots menu — opens track options
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _showtrackMenu(context, music, track),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Icon(Icons.more_vert, size: 20, color: theme.muted),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showtrackMenu(BuildContext context, MusicProvider music, Track track) {
    showSideSheet(
      context,
      title: '${track.art} ${track.title}',
      body: '${track.artist} · ${track.formattedDuration}'
          '${track.albumName != null && track.albumName!.isNotEmpty ? '\nalbum: ${track.albumName}' : ''}'
          '${track.genre.isNotEmpty ? '\nGenre: ${track.genre}' : ''}'
          '${track.formattedSize.isNotEmpty ? '\nSize: ${track.formattedSize}' : ''}',
      verticalActions: true,
      actions: [
        ModalAction(
          label: 'Info',
          cls: 'primary',
          popAfter: false,
          action: () {
            _showInfoDialog(context, track);
          },
        ),
        ModalAction(
          label: 'Add to Playlist',
          popAfter: false,
          action: () => _showAddToPlaylist(context, music, track),
        ),
        ModalAction(
          label: 'Add to Queue',
          action: () {
            music.enqueueTrack(track);
            VibesToast.show(context, 'Added to queue · ${music.queueMode}');
          },
        ),
        ModalAction(
          label: 'Share',
          action: () {
            music.shareTrack(track.id);
            VibesToast.show(context, 'Sharing…');
          },
        ),
        ModalAction(
          label: 'Delete',
          cls: 'danger',
          popAfter: false,
          action: () => _confirmDelete(context, music, track),
        ),
      ],
    );
  }

  void _showInfoDialog(BuildContext context, Track track) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      final theme = context.read<ThemeProvider>();
      showModalSheet(
        context,
        title: 'track Info',
        body: '',
        actions: [ModalAction(label: 'Close', action: () {})],
        extra: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InfoRow(label: 'Title', value: track.title, theme: theme),
            InfoRow(label: 'Artist', value: track.artist, theme: theme),
            InfoRow(
                label: 'album',
                value: track.albumName ?? 'Unknown',
                theme: theme),
            InfoRow(
                label: 'Genre',
                value: track.genre.isNotEmpty ? track.genre : 'Unknown',
                theme: theme),
            InfoRow(
                label: 'Duration',
                value: track.formattedDuration,
                theme: theme),
            if (track.formattedSize.isNotEmpty)
              InfoRow(
                  label: 'File Size', value: track.formattedSize, theme: theme),
            if (track.filePath != null && track.filePath!.isNotEmpty)
              InfoRow(label: 'Path', value: track.filePath!, theme: theme),
          ],
        ),
      );
    });
  }

  void _confirmDelete(BuildContext context, MusicProvider music, Track track) {
    Navigator.pop(context);

    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      showModalSheet(
        context,
        title: 'Delete "${track.title}"?',
        body:
            'This will permanently delete the file from your device. This cannot be undone.',
        actions: [
          ModalAction(label: 'Cancel', action: () {}),
          ModalAction(
            label: 'Delete',
            cls: 'danger',
            action: () async {
              final ok = await music.deleteTrack(track.id);
              if (!context.mounted) return;
              if (ok) {
                VibesToast.show(context, 'Deleted "${track.title}"');
              } else {
                VibesToast.show(context, 'Delete failed');
              }
            },
          ),
        ],
      );
    });
  }

  void _showAddToPlaylist(
      BuildContext context, MusicProvider music, Track track) {
    Navigator.pop(context);

    Future.delayed(const Duration(milliseconds: 350), () {
      if (!context.mounted) return;
      if (music.playlists.isEmpty) {
        VibesToast.show(
            context, 'Create a playlist first in the Playlists tab');
        return;
      }

      final theme = context.read<ThemeProvider>();
      showModalSheet(
        context,
        title: 'Add to Playlist',
        body: 'Select a playlist:',
        actions: [ModalAction(label: 'Cancel', action: () {})],
        extra: Column(
          children: music.playlists.map((pl) {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                Navigator.pop(context);
                music.addTrackToPlaylist(pl.id, track.id);
                VibesToast.show(context, 'Added to "${pl.name}"');
                InterstitialAdController.maybeShow(
                  InterstitialTrigger.playlistAction,
                );
              },
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: theme.surface2,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  children: [
                    Text(pl.art, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            pl.name,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: theme.text,
                            ),
                          ),
                          Text(
                            '${pl.trackCount} tracks',
                            style: TextStyle(fontSize: 11, color: theme.muted),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.add_rounded, size: 18, color: theme.accent),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      );
    });
  }
}
