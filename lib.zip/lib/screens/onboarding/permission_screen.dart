import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../providers/theme_provider.dart';
import '../../services/media_permission_service.dart';

const Color _splashBackground = Color(0xFF071A33);
const Color _splashGold = Color(0xFFF2C22E);
const Color _splashGoldDeep = Color(0xFFD49D17);
const Color _permissionText = Colors.white;
const Color _permissionMutedText = Color(0xFFC8D1DC);

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;

  bool _requesting = false;
  bool _waitingForSettings = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _fadeAnim = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );

    _fadeController.forward();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _fadeController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed || !_waitingForSettings) return;

    _waitingForSettings = false;
    unawaited(_recheckAfterSettings());
  }

  Future<void> _requestPermission() async {
    if (_requesting) return;

    setState(() => _requesting = true);

    final result = await MediaPermissionService.instance.request();

    if (!mounted) return;

    if (result.granted) {
      await _completePermissionFlow();
      return;
    }

    setState(() => _requesting = false);

    _showPermissionDeniedDialog(result);
  }

  Future<void> _completePermissionFlow() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('hasCompletedOnboarding', true);
    await prefs.setBool('audioPermissionGranted', true);

    if (!mounted) return;
    Navigator.of(context).pushReplacementNamed('/home');
  }

  Future<void> _recheckAfterSettings() async {
    if (!mounted) return;

    setState(() => _requesting = true);

    final result = await MediaPermissionService.instance.check();

    if (!mounted) return;

    if (result.granted) {
      await _completePermissionFlow();
      return;
    }

    setState(() => _requesting = false);
  }

  Future<void> _openSettings() async {
    _waitingForSettings = true;
    final opened = await MediaPermissionService.instance.openSettings();

    if (!opened) {
      _waitingForSettings = false;
      if (mounted) {
        setState(() => _requesting = false);
      }
    }
  }

  void _showPermissionDeniedDialog(MediaPermissionResult result) {
    final theme = context.read<ThemeProvider>();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: _splashBackground,
        title: const Text(
          'Music Access Required',
          style: TextStyle(
            color: _permissionText,
            decoration: TextDecoration.none,
          ),
        ),
        content: Text(
          result.shouldOpenSettings
              ? 'Audio access is blocked for Vibes Player. Open Android app '
                  'settings and enable Music and audio permission.\n\n'
                  'Your music stays on your device.'
              : result.state == MediaPermissionState.error
                  ? 'Android could not verify audio access. You can retry or '
                      'open app settings to check Music and audio permission.'
                  : 'Vibes Player needs access to audio files on your device '
                      'to find and play your music.\n\n'
                      'Your music stays on your device. We do not upload or '
                      'share it.',
          style: const TextStyle(
            color: _permissionMutedText,
            height: 1.4,
            decoration: TextDecoration.none,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => SystemNavigator.pop(),
            child: Text(
              'Exit',
              style: TextStyle(
                color: theme.danger,
                decoration: TextDecoration.none,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              if (!mounted) return;
              setState(() => _requesting = false);
              unawaited(_requestPermission());
            },
            child: const Text(
              'Retry',
              style: TextStyle(
                color: _splashGold,
                decoration: TextDecoration.none,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await _openSettings();
            },
            child: const Text(
              'Open Settings',
              style: TextStyle(
                color: _splashGold,
                decoration: TextDecoration.none,
              ),
            ),
          ),
        ],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) SystemNavigator.pop();
      },
      child: Scaffold(
        backgroundColor: _splashBackground,
        body: FadeTransition(
          opacity: _fadeAnim,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Column(
                children: [
                  const Spacer(flex: 3),
                  const Text(
                    'Your Music Lives Here',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w800,
                      color: _permissionText,
                      height: 1.2,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Allow access to your music so Vibes Player can\n'
                    'find and play music on your device.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      color: _permissionMutedText,
                      height: 1.45,
                      decoration: TextDecoration.none,
                    ),
                  ),
                  const Spacer(flex: 4),
                  _AllowButton(
                    loading: _requesting,
                    onTap: _requestPermission,
                  ),
                  const SizedBox(height: 28),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AllowButton extends StatelessWidget {
  final bool loading;
  final VoidCallback onTap;

  const _AllowButton({
    required this.loading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          gradient: loading
              ? null
              : const LinearGradient(
                  colors: [_splashGold, _splashGoldDeep],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
          color: loading ? const Color(0xFF102A4D) : null,
          borderRadius: BorderRadius.circular(50),
          boxShadow: loading
              ? null
              : [
                  BoxShadow(
                    color: _splashGold.withValues(alpha: 0.25),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
        ),
        alignment: Alignment.center,
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(_splashGold),
                ),
              )
            : const Text(
                'Allow Music Access',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                  decoration: TextDecoration.none,
                ),
              ),
      ),
    );
  }
}