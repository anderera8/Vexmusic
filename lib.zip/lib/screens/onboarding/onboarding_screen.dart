import 'package:flutter/material.dart';

import 'permission_screen.dart';

/// Onboarding's entry point. Used to show a brief splash before handing
/// off to [PermissionScreen]; now that the native splash (see
/// android/app/src/main/res/values-v31/styles.xml) covers that moment,
/// this just goes straight there.
class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) => const PermissionScreen();
}
