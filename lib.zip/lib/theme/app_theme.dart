import 'package:flutter/material.dart';

class ThemeColors {
  final Color bg;
  final Color surface;
  final Color surface2;
  final Color border;
  final Color text;
  final Color muted;

  const ThemeColors({
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.border,
    required this.text,
    required this.muted,
  });

  factory ThemeColors.fromScheme(ColorScheme scheme) => ThemeColors(
        bg: scheme.surface,
        surface: scheme.surfaceContainer,
        surface2: scheme.surfaceContainerHigh,
        border: scheme.outlineVariant,
        text: scheme.onSurface,
        muted: scheme.onSurfaceVariant,
      );
}

enum ThemeType { system }

extension ThemeTypeExtension on ThemeType {
  String get label => 'System Default';
  IconData get icon => Icons.settings_suggest;
  String get description => 'Follows device settings';
}

class AppTheme {
  static const Color _brandNavy = Color(0xFF071A33);
  static const Color _brandNavySurface = Color(0xFF0B2446);
  static const Color _brandNavySurfaceHigh = Color(0xFF12325A);
  static const Color _brandNavySurfaceHighest = Color(0xFF183B67);

  static const Color _brandGold = Color(0xFFD8B84A);
  static const Color _brandGoldDeep = Color(0xFFA87918);
  static const Color _brandGoldSoft = Color(0xFFE6C75B);

  static const Color _lightBg = Color(0xFFF6F8FC);
  static const Color _lightSurface = Color(0xFFFFFFFF);
  static const Color _lightSurfaceHigh = Color(0xFFEAF0F8);
  static const Color _lightSurfaceHighest = Color(0xFFDDE7F2);
  static const Color _lightText = Color(0xFF071A33);
  static const Color _lightMuted = Color(0xFF526B86);
  static const Color _lightBorder = Color(0xFFCAD8E7);
  static const Color _lightGold = Color(0xFF9A7413);
  static const Color _lightGoldDeep = Color(0xFF76570B);
  static const Color _lightGoldSoft = Color(0xFFE7C965);

  static ThemeData system({
    required Brightness brightness,
    ColorScheme? dynamicScheme,
    String? systemFontFamily,
  }) {
    final isDark = brightness == Brightness.dark;

    final scheme = dynamicScheme ?? (isDark ? _darkScheme() : _lightScheme());

    var theme = ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      canvasColor: scheme.surface,
      cardColor: scheme.surfaceContainer,
      dividerColor: scheme.outlineVariant,
      splashColor: scheme.primary.withValues(alpha: isDark ? 0.14 : 0.10),
      highlightColor: scheme.primary.withValues(alpha: isDark ? 0.10 : 0.07),
      focusColor: scheme.primary.withValues(alpha: isDark ? 0.18 : 0.12),
      hoverColor: scheme.primary.withValues(alpha: isDark ? 0.10 : 0.08),
      appBarTheme: AppBarTheme(
        backgroundColor: scheme.surface,
        foregroundColor: scheme.onSurface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      iconTheme: IconThemeData(color: scheme.secondary),
      primaryIconTheme: IconThemeData(color: scheme.primary),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: scheme.surfaceContainer,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: CardThemeData(
        color: scheme.surfaceContainer,
        surfaceTintColor: Colors.transparent,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: scheme.surfaceContainer,
        surfaceTintColor: Colors.transparent,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor:
            isDark ? scheme.surfaceContainerHigh : const Color(0xFF102A4A),
        contentTextStyle: const TextStyle(color: Colors.white),
        actionTextColor: scheme.primary,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return scheme.primary;
          return scheme.onSurfaceVariant;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return scheme.primary.withValues(alpha: isDark ? 0.35 : 0.28);
          }
          return scheme.onSurfaceVariant.withValues(alpha: 0.22);
        }),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: scheme.primary,
        inactiveTrackColor: scheme.outlineVariant,
        thumbColor: scheme.primary,
        overlayColor: scheme.primary.withValues(alpha: 0.16),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: scheme.primary,
        linearTrackColor: scheme.outlineVariant,
        circularTrackColor: scheme.outlineVariant,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: scheme.surface,
        indicatorColor: scheme.primary.withValues(alpha: isDark ? 0.18 : 0.14),
        surfaceTintColor: Colors.transparent,
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: scheme.primary);
          }
          return IconThemeData(color: scheme.onSurfaceVariant);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            color: selected ? scheme.primary : scheme.onSurfaceVariant,
            fontSize: 12,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          );
        }),
      ),
      tabBarTheme: TabBarThemeData(
        indicatorColor: scheme.primary,
        labelColor: scheme.primary,
        unselectedLabelColor: scheme.onSurfaceVariant,
        dividerColor: scheme.outlineVariant,
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: scheme.primary,
        foregroundColor: scheme.onPrimary,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: scheme.primary,
          foregroundColor: scheme.onPrimary,
          disabledBackgroundColor:
              scheme.onSurfaceVariant.withValues(alpha: 0.16),
          disabledForegroundColor:
              scheme.onSurfaceVariant.withValues(alpha: 0.55),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: scheme.primary,
          side: BorderSide(color: scheme.outlineVariant),
        ),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        fillColor: scheme.surfaceContainerHigh,
        hintStyle: TextStyle(color: scheme.onSurfaceVariant),
        labelStyle: TextStyle(color: scheme.onSurfaceVariant),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.primary),
        ),
      ),
    );

    if (systemFontFamily != null && systemFontFamily.isNotEmpty) {
      theme = theme.copyWith(
        textTheme: theme.textTheme.apply(fontFamily: systemFontFamily),
        primaryTextTheme:
            theme.primaryTextTheme.apply(fontFamily: systemFontFamily),
      );
    }

    return theme;
  }

  static ColorScheme _darkScheme() {
    final base = ColorScheme.fromSeed(
      seedColor: _brandGold,
      brightness: Brightness.dark,
    );

    return base.copyWith(
      primary: _brandGold,
      onPrimary: _brandNavy,
      primaryContainer: _brandGoldDeep,
      onPrimaryContainer: const Color(0xFFFFF3C2),
      secondary: _brandGoldSoft,
      onSecondary: _brandNavy,
      secondaryContainer: const Color(0xFF6E5516),
      onSecondaryContainer: const Color(0xFFFFF1BF),
      tertiary: const Color(0xFF8FB8D6),
      onTertiary: const Color(0xFF082136),
      tertiaryContainer: const Color(0xFF1C4A74),
      onTertiaryContainer: const Color(0xFFD7ECFF),
      error: const Color(0xFFFF6B6B),
      onError: const Color(0xFF2B0000),
      errorContainer: const Color(0xFF7A1D1D),
      onErrorContainer: const Color(0xFFFFDADA),
      surface: _brandNavy,
      onSurface: const Color(0xFFF4F7FB),
      surfaceContainerLowest: const Color(0xFF051326),
      surfaceContainerLow: const Color(0xFF081D38),
      surfaceContainer: _brandNavySurface,
      surfaceContainerHigh: _brandNavySurfaceHigh,
      surfaceContainerHighest: _brandNavySurfaceHighest,
      onSurfaceVariant: const Color(0xFFAFC0D2),
      outline: const Color(0xFF4E6C8E),
      outlineVariant: const Color(0xFF25496F),
      inverseSurface: const Color(0xFFE8EEF7),
      onInverseSurface: _brandNavy,
      inversePrimary: _lightGold,
      surfaceTint: Colors.transparent,
      shadow: Colors.black,
      scrim: Colors.black,
    );
  }

  static ColorScheme _lightScheme() {
    final base = ColorScheme.fromSeed(
      seedColor: _lightGold,
      brightness: Brightness.light,
    );

    return base.copyWith(
      primary: _lightGold,
      onPrimary: Colors.white,
      primaryContainer: _lightGoldSoft,
      onPrimaryContainer: const Color(0xFF2D2100),
      secondary: _lightGoldDeep,
      onSecondary: Colors.white,
      secondaryContainer: const Color(0xFFF2DF9B),
      onSecondaryContainer: const Color(0xFF2E2200),
      tertiary: const Color(0xFF143C66),
      onTertiary: Colors.white,
      tertiaryContainer: const Color(0xFFDDEAF6),
      onTertiaryContainer: const Color(0xFF071A33),
      error: const Color(0xFFB3261E),
      onError: Colors.white,
      errorContainer: const Color(0xFFFFDAD6),
      onErrorContainer: const Color(0xFF410002),
      surface: _lightBg,
      onSurface: _lightText,
      surfaceContainerLowest: Colors.white,
      surfaceContainerLow: const Color(0xFFFAFCFF),
      surfaceContainer: _lightSurface,
      surfaceContainerHigh: _lightSurfaceHigh,
      surfaceContainerHighest: _lightSurfaceHighest,
      onSurfaceVariant: _lightMuted,
      outline: const Color(0xFF7A8CA2),
      outlineVariant: _lightBorder,
      inverseSurface: _brandNavy,
      onInverseSurface: const Color(0xFFF4F7FB),
      inversePrimary: _brandGold,
      surfaceTint: Colors.transparent,
      shadow: Colors.black,
      scrim: Colors.black,
    );
  }

  static ThemeData custom({
    required Brightness brightness,
    required Color primary,
    required Color background,
    required Color surface,
    required Color accent,
    required Color text,
    String? systemFontFamily,
  }) {
    final base = system(
      brightness: brightness,
      systemFontFamily: systemFontFamily,
    );

    final customMuted = text.withValues(
      alpha: brightness == Brightness.dark ? 0.68 : 0.62,
    );

    final customBorder = accent.withValues(
      alpha: brightness == Brightness.dark ? 0.28 : 0.24,
    );

    final scheme = base.colorScheme.copyWith(
      primary: primary,
      onPrimary: brightness == Brightness.dark ? Colors.black : Colors.white,
      primaryContainer: primary.withValues(alpha: 0.24),
      secondary: accent,
      onSecondary: brightness == Brightness.dark ? Colors.black : Colors.white,
      secondaryContainer: accent.withValues(alpha: 0.20),
      tertiary: accent,
      tertiaryContainer: accent.withValues(alpha: 0.14),
      surface: background,
      surfaceContainerLowest: background,
      surfaceContainerLow: surface,
      surfaceContainer: surface,
      surfaceContainerHigh: surface,
      surfaceContainerHighest: surface,
      outlineVariant: customBorder,
      outline: customBorder,
      onSurface: text,
      onSurfaceVariant: customMuted,
      surfaceTint: Colors.transparent,
    );

    var theme = base.copyWith(
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      canvasColor: background,
      cardColor: surface,
      dividerColor: customBorder,
      appBarTheme: base.appBarTheme.copyWith(
        backgroundColor: background,
        foregroundColor: text,
        surfaceTintColor: Colors.transparent,
      ),
      bottomSheetTheme: base.bottomSheetTheme.copyWith(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: base.cardTheme.copyWith(
        color: surface,
        surfaceTintColor: Colors.transparent,
      ),
      dialogTheme: base.dialogTheme.copyWith(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
      ),
      tabBarTheme: base.tabBarTheme.copyWith(
        indicatorColor: primary,
        labelColor: primary,
        unselectedLabelColor: customMuted,
        dividerColor: customBorder,
      ),
    );

    if (systemFontFamily != null && systemFontFamily.isNotEmpty) {
      theme = theme.copyWith(
        textTheme: theme.textTheme.apply(fontFamily: systemFontFamily),
        primaryTextTheme:
            theme.primaryTextTheme.apply(fontFamily: systemFontFamily),
      );
    }

    return theme;
  }
}
