// lib/providers/radio_provider.dart
// ─────────────────────────────────────────────────────────────────────────────
// UI-facing state for the Radio feature. Ties together the API client, the
// dedicated radio player, and local favorites/history persistence.
//
// This provider is intentionally self-contained: it never imports
// MusicProvider or anything from services/playback/*. The one place it
// touches the rest of the app is [onWillStartPlayback], an optional
// callback main.dart wires up so the two playback surfaces (local music vs
// radio) stay mutually exclusive instead of ever playing over each other.
//
// Registered top-level in main.dart (like MusicProvider) so a station keeps
// playing while the person browses other tabs — which also means this
// constructor runs at app boot, before Radio has ever been opened. It only
// does local, synchronous work (loading cached favorites/recent stations),
// deliberately no network I/O: [loadTrending] is called separately, the
// first time the Radio tab is opened (see home_screen.dart's _onNavTap), so
// a cold launch never makes an unconditional call to a third-party API
// with no uptime SLA.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/radio_models.dart';
import '../services/radio/radio_api_service.dart';
import '../services/radio/radio_connectivity_service.dart';
import '../services/radio/radio_favorites_service.dart';
import '../services/radio/radio_player_service.dart';

class RadioProvider extends ChangeNotifier {
  final RadioApiService _api;
  final RadioFavoritesService _favorites;
  final RadioPlayerService _player;
  final RadioConnectivityService _connectivity;

  /// The country code the Discover screen anchors its featured rail to.
  /// This is the one deliberate, explicit choice in an otherwise fully
  /// data-driven system — Uganda is still ISO code 'UG' regardless of what
  /// happens in the directory. Everything else derived from it (its display
  /// name, its districts, which neighboring countries count as "East
  /// Africa") is looked up live rather than hand-typed, so a change in the
  /// directory (a renamed country entry, a newly-registered district) is
  /// reflected automatically without touching this file.
  static const String featuredCountryCode = 'UG';

  /// ISO codes treated as "East Africa" for the neighboring-countries rail.
  /// This is a codes-only constant — no country names, no station data —
  /// because the Radio Browser directory has no concept of "East Africa"
  /// as a region; everything else about these countries (their live
  /// display name, flag, current station count) still comes from
  /// [allCountries] at request time, never hand-typed here.
  static const List<String> _eastAfricaCodes = [
    'KE', 'TZ', 'RW', 'BI', 'SS', 'ET', 'SO',
  ];

  RadioProvider({
    RadioApiService? api,
    RadioFavoritesService? favoritesService,
    RadioPlayerService? playerService,
    RadioConnectivityService? connectivityService,
  })  : _api = api ?? RadioApiService.instance,
        _favorites = favoritesService ?? RadioFavoritesService.instance,
        _player = playerService ?? RadioPlayerService(),
        _connectivity = connectivityService ?? RadioConnectivityService.instance {
    favorites = _favorites.loadFavorites();
    recentlyPlayed = _favorites.loadRecent();

    _statusSub = _player.statusStream.listen((status) {
      playbackStatus = status;
      notifyListeners();
    });
    _nowPlayingSub = _player.nowPlayingStream.listen((text) {
      nowPlayingText = text;
      notifyListeners();
    });
    _errorSub = _player.errorStream.listen((message) {
      playbackError = message;
      notifyListeners();
    });
    // Keeps `isOffline` current for as long as Radio's provider is alive —
    // e.g. the offline banner on the Discover screen clears itself the
    // moment connectivity returns, with no manual retry needed.
    _offlineSub = _connectivity.offlineChanges.listen((offline) {
      isOffline = offline;
      notifyListeners();
    });
  }

  /// Set by main.dart. Invoked just before radio audio is about to start
  /// (fresh play or resume), so any other active playback can yield first.
  VoidCallback? onWillStartPlayback;

  // ── Discover content ────────────────────────────────────────────────────
  List<RadioStation> trending = [];
  List<RadioStation> ugandaStations = [];
  bool ugandaLoading = false;
  String? ugandaError;
  List<RadioStation> eastAfricaStations = [];
  bool eastAfricaLoading = false;
  String? eastAfricaError;
  bool trendingLoading = false;
  String? trendingError;

  /// Every country the directory currently has stations for, live from
  /// [RadioApiService.allCountries] — nothing here is a fixed list. Ordered
  /// with [featuredCountryCode] and [_eastAfricaCodes] pulled to the front
  /// (still built from live data, just re-sorted) so the "Browse by
  /// Country" rail keeps its featured region without hand-typing it.
  List<RadioCountryDef> allCountries = [];
  bool countriesLoading = false;
  String? countriesError;

  /// The directory's own display name for [featuredCountryCode] (e.g.
  /// "Uganda"), resolved from [allCountries] rather than hand-typed.
  String? get featuredCountryName => allCountries
      .cast<RadioCountryDef?>()
      .firstWhere((c) => c?.code == featuredCountryCode, orElse: () => null)
      ?.name;

  List<RadioStation> favorites = [];
  List<RadioStation> recentlyPlayed = [];

  /// True once connectivity is confirmed fully down (see
  /// [RadioConnectivityService.isOffline] for exactly what that means and
  /// what it deliberately does not cover). Checked proactively before a
  /// play attempt and kept live via [RadioConnectivityService.offlineChanges]
  /// — this is in addition to, not instead of, the reactive
  /// network-failure handling already in [RadioPlayerService].
  bool isOffline = false;

  // ── Now playing ─────────────────────────────────────────────────────────
  RadioStation? currentStation;
  RadioPlaybackStatus playbackStatus = RadioPlaybackStatus.idle;
  String? nowPlayingText;
  String? playbackError;

  late final StreamSubscription<RadioPlaybackStatus> _statusSub;
  late final StreamSubscription<String?> _nowPlayingSub;
  late final StreamSubscription<String> _errorSub;
  late final StreamSubscription<bool> _offlineSub;

  bool get hasActiveStation => currentStation != null;

  bool get isPlaying => playbackStatus == RadioPlaybackStatus.playing;

  bool get isBusy =>
      playbackStatus == RadioPlaybackStatus.loading ||
      playbackStatus == RadioPlaybackStatus.buffering;

  bool isFavorite(RadioStation station) =>
      favorites.any((f) => f.uuid == station.uuid);

  // ── Discover ─────────────────────────────────────────────────────────────

  Future<void> loadDiscover({bool forceRefresh = false}) async {
    // Countries must resolve first: featuredCountryName (used for
    // by-name lookups) is derived from allCountries, so loading it up
    // front means everything downstream already has what it needs
    // instead of racing for it.
    await loadCountries(forceRefresh: forceRefresh);
    await Future.wait([
      loadUganda(forceRefresh: forceRefresh),
      loadEastAfrica(forceRefresh: forceRefresh),
      loadTrending(forceRefresh: forceRefresh),
    ]);
  }

  /// Every country the directory currently has stations for, most-active
  /// first, with [featuredCountryCode] and [_eastAfricaCodes] pulled to the
  /// front — still live data, just re-sorted so the featured region leads
  /// without a fixed country list existing anywhere.
  Future<void> loadCountries({bool forceRefresh = false}) async {
    if (countriesLoading) return;
    if (allCountries.isNotEmpty && !forceRefresh) return;

    countriesLoading = true;
    countriesError = null;
    notifyListeners();

    try {
      final live = await _api.allCountries();
      final featuredSet = {featuredCountryCode, ..._eastAfricaCodes};
      final featured = <RadioCountryDef>[];
      final rest = <RadioCountryDef>[];
      for (final country in live) {
        (featuredSet.contains(country.code) ? featured : rest).add(country);
      }
      // Within the featured group, Uganda itself leads, then the East
      // Africa codes in the order they're declared above — everything
      // else keeps the live station-count ordering from the API.
      featured.sort((a, b) {
        int rank(String code) => code == featuredCountryCode
            ? -1
            : _eastAfricaCodes.indexOf(code);
        return rank(a.code).compareTo(rank(b.code));
      });
      allCountries = [...featured, ...rest];
    } catch (e) {
      countriesError = e.toString();
    } finally {
      countriesLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadUganda({bool forceRefresh = false}) async {
    if (ugandaLoading) return;
    if (ugandaStations.isNotEmpty && !forceRefresh) return;

    ugandaLoading = true;
    ugandaError = null;
    notifyListeners();

    try {
      // Do not hide broken entries for the featured country. Many stations
      // are intermittent online streams; keeping them visible lets the
      // player explain the current failure instead of silently removing
      // the station. Uses the paginated fetch (not the capped preview
      // version) since this is meant to be the full inventory, not a
      // fixed-size sample.
      ugandaStations = await _api.allByCountryCode(
        featuredCountryCode,
        includeBroken: true,
      );
    } catch (e) {
      ugandaError = e.toString();
    } finally {
      ugandaLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadEastAfrica({bool forceRefresh = false}) async {
    if (eastAfricaLoading) return;
    if (eastAfricaStations.isNotEmpty && !forceRefresh) return;

    eastAfricaLoading = true;
    eastAfricaError = null;
    notifyListeners();

    try {
      final batches = await Future.wait(
        _eastAfricaCodes.map(
          (code) => _api.byCountryCode(
            code,
            limit: 12,
            includeBroken: true,
          ),
        ),
      );
      final seen = <String>{};
      eastAfricaStations = [
        for (final station in batches.expand((items) => items))
          if (seen.add(station.uuid.isEmpty
              ? '${station.name}|${station.streamUrl}'
              : station.uuid))
            station,
      ];
    } catch (e) {
      eastAfricaError = e.toString();
    } finally {
      eastAfricaLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadTrending({bool forceRefresh = false}) async {
    if (trendingLoading) return;
    if (trending.isNotEmpty && !forceRefresh) return;

    trendingLoading = true;
    trendingError = null;
    notifyListeners();

    try {
      trending = await _api.topStations(limit: 20);
    } catch (e) {
      trendingError = e.toString();
    } finally {
      trendingLoading = false;
      notifyListeners();
    }
  }

  /// A larger trending list for the "See all" screen — independent of
  /// [trending] (the short hub preview) so opening it always fetches a
  /// fuller, fresh set rather than just re-showing the preview's 20.
  Future<List<RadioStation>> fetchMoreTrending({int limit = 60}) =>
      _api.topStations(limit: limit);

  Future<List<RadioStation>> loadEastAfricaAndReturn() async {
    await loadEastAfrica(forceRefresh: true);
    return eastAfricaStations;
  }

  Future<List<RadioStation>> fetchByGenre(RadioGenreDef genre) =>
      _api.byTag(genre.tag);

  /// For [featuredCountryCode] specifically, this is the full paginated
  /// inventory (see [RadioApiService.allByCountryCode]) — not a capped
  /// preview — since that's the country this feature is built around.
  /// Every other country stays on the capped, single-request fetch: a
  /// full walk for every country in the "Browse by Country" rail would be
  /// a lot of unnecessary calls for countries nobody asked to see all of.
  Future<List<RadioStation>> fetchByCountry(RadioCountryDef country) {
    if (country.code == featuredCountryCode) {
      return _api.allByCountryCode(country.code, includeBroken: true);
    }
    return _api.byCountryCode(country.code, limit: 60);
  }

  Future<List<RadioStation>> searchStations(String query) =>
      _api.searchByName(query);

  // ── Playback ─────────────────────────────────────────────────────────────

  Future<bool> playStation(RadioStation station) async {
    // Proactive check: if there's confirmed no network interface at all,
    // a stream connection attempt is certain to fail — tell the person
    // immediately instead of making them wait out a timeout first. This
    // does not replace RadioPlayerService's own after-the-fact error
    // handling, which is what correctly catches "online but no real
    // internet" (see RadioConnectivityService's doc comment).
    if (await _connectivity.isOffline()) {
      isOffline = true;
      playbackError = "You're offline — can't play right now.";
      notifyListeners();
      return false;
    }

    onWillStartPlayback?.call();

    currentStation = station;
    playbackError = null;
    nowPlayingText = null;
    recentlyPlayed = _favorites.withRecentAdded(station, recentlyPlayed);
    notifyListeners();

    final playFuture = _player.play(
      station.streamUrl,
      fallbackUrl: station.fallbackUrl,
    );

    unawaited(_api.registerClick(station.uuid));
    unawaited(_favorites.saveRecent(recentlyPlayed));

    return await playFuture;
  }

  Future<void> togglePlayPause() async {
    if (currentStation == null) return;

    if (isPlaying || isBusy) {
      await _player.pause();
      return;
    }

    if (await _connectivity.isOffline()) {
      isOffline = true;
      playbackError = "You're offline — can't play right now.";
      notifyListeners();
      return;
    }

    onWillStartPlayback?.call();
    await _player.resume();
  }

  /// Deterministic play for system controls (lock screen / notification).
  /// Unlike [togglePlayPause] this never pauses — a stale system control
  /// tapped a beat after the state actually changed underneath it can't
  /// invert the action by accident.
  Future<void> systemPlay() async {
    if (currentStation == null || isPlaying || isBusy) return;

    if (await _connectivity.isOffline()) {
      isOffline = true;
      playbackError = "You're offline — can't play right now.";
      notifyListeners();
      return;
    }

    onWillStartPlayback?.call();
    await _player.resume();
  }

  /// Deterministic pause for system controls (lock screen / notification).
  /// Unlike [togglePlayPause] this never resumes — see [systemPlay].
  Future<void> systemPause() async {
    if (isPlaying || isBusy) {
      await _player.pause();
    }
  }

  Future<void> retryCurrentStation() async {
    final station = currentStation;
    if (station == null) return;
    await playStation(station);
  }

  Future<void> stopAndClear() async {
    await _player.stop();
    currentStation = null;
    nowPlayingText = null;
    playbackError = null;
    notifyListeners();
  }

  /// Called from main.dart when local music playback starts, so radio
  /// yields instead of playing underneath it. Pauses only — the station
  /// stays loaded so the mini player still shows it, resumable in one tap.
  void pauseForExternalPlayback() {
    if (isPlaying || isBusy) {
      unawaited(_player.pauseForExternalPlayback());
    }
  }

  // ── Favorites ────────────────────────────────────────────────────────────

  Future<void> toggleFavorite(RadioStation station) async {
    final exists = isFavorite(station);
    favorites = exists
        ? favorites.where((f) => f.uuid != station.uuid).toList()
        : [station, ...favorites];
    notifyListeners();
    await _favorites.saveFavorites(favorites);
  }

  @override
  void dispose() {
    _statusSub.cancel();
    _nowPlayingSub.cancel();
    _errorSub.cancel();
    _offlineSub.cancel();
    _player.dispose();
    super.dispose();
  }
}
