
import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/media_models.dart';
import '../services/playback/audio_interruption_policy.dart';
import '../services/playback/media_playback_coordinator.dart';
import '../services/playback/playback_system_service.dart';
import '../services/prefs_service.dart';
import '../services/unified_audio_effects_service.dart';
import 'music_provider.dart' show SortMode;

class SettingsProvider extends ChangeNotifier {
  final MediaPlaybackCoordinator _coordinator = MediaPlaybackCoordinator();

  // ── Persisted settings ──────────────────────────────────────────────────

  SortMode _sortMode = SortMode.titleAZ;
  String sleepTimer = 'Off';
  double playbackSpeed = 1.0;
  int crossfadeSeconds = 0;
  bool normEnabled = false;
  bool bgPlayback = true;
  bool lockScreenControls = true;
  bool allowDuplicates = false;
  String queueMode = 'Add to end';
  String selectedTheme = 'dark';
  String selectedAccent = 'violet';
  bool isShuffle = false;
  int repeatMode = 0; // 0=off, 1=all, 2=one

  // ── Getters ─────────────────────────────────────────────────────────────

  SortMode get sortMode => _sortMode;

  String get sortModeLabel {
    switch (_sortMode) {
      case SortMode.titleAZ:
        return 'Title A–Z';
      case SortMode.titleZA:
        return 'Title Z–A';
      case SortMode.dateNewest:
        return 'Date: Newest';
      case SortMode.dateOldest:
        return 'Date: Oldest';
      case SortMode.sizeBig:
        return 'Size: Largest';
      case SortMode.sizeSmall:
        return 'Size: Smallest';
    }
  }

  bool get sortAZ =>
      _sortMode == SortMode.titleAZ || _sortMode == SortMode.titleZA;

  // ── Deferred player config flags ────────────────────────────────────────

  bool _deferredConfigPending = false;
  bool _deferredNormEnabled = false;
  int _deferredCrossfade = 0;

  bool get deferredConfigPending => _deferredConfigPending;

  // ── Sleep timer ─────────────────────────────────────────────────────────

  Timer? _sleepTimer;
  int _sleepSecondsRemaining = 0;
  final ValueNotifier<int> sleepSecondsNotifier = ValueNotifier(0);

  int get sleepSecondsRemaining => _sleepSecondsRemaining;
  bool get sleepTimerActive => _sleepTimer != null && _sleepTimer!.isActive;

  // ── Construction ────────────────────────────────────────────────────────

  SettingsProvider() {
    _loadSettings();
  }

  // ── Persistence ─────────────────────────────────────────────────────────

  Future<void> _loadSettings() async {
    final prefs = PrefsService.instance;
    sleepTimer = prefs.getString('sleepTimer') ?? 'Off';
    crossfadeSeconds = prefs.getInt('crossfadeSeconds') ?? 0;
    queueMode = prefs.getString('queueMode') ?? 'Add to end';
    playbackSpeed = prefs.getDouble('playbackSpeed') ?? 1.0;
    normEnabled = prefs.getBool('normEnabled') ?? false;
    await UnifiedAudioEffectsService.ensureInitialized();
    await UnifiedAudioEffectsService.setNormalization(normEnabled);
    normEnabled =
        (await UnifiedAudioEffectsService.getState()).normalization;
    bgPlayback = prefs.getBool('bgPlayback') ?? true;
    lockScreenControls = prefs.getBool('lockScreenControls') ?? true;
    allowDuplicates = prefs.getBool('allowDuplicates') ?? false;
    final savedMode = prefs.getString('sortMode');
    if (savedMode != null) {
      _sortMode = SortMode.values.firstWhere(
        (m) => m.name == savedMode,
        orElse: () => SortMode.titleAZ,
      );
    }
    isShuffle = prefs.getBool('isShuffle') ?? false;
    repeatMode = prefs.getInt('repeatMode') ?? 0;
    _deferredConfigPending = true;
    _deferredNormEnabled = normEnabled;
    _deferredCrossfade = crossfadeSeconds;
    notifyListeners();
  }

  // ── Sort ────────────────────────────────────────────────────────────────

  Future<void> setSortMode(SortMode mode) async {
    if (_sortMode == mode) return;
    _sortMode = mode;
    await PrefsService.setString('sortMode', mode.name);
    notifyListeners();
  }

  Future<void> cycleSortMode() async {
    const modes = SortMode.values;
    _sortMode = modes[(_sortMode.index + 1) % modes.length];
    await PrefsService.setString('sortMode', _sortMode.name);
    notifyListeners();
  }

  // ── Audio toggles ───────────────────────────────────────────────────────

  Future<void> toggleNorm() async {
    final next = !normEnabled;
    await UnifiedAudioEffectsService.setNormalization(next);
    normEnabled =
        (await UnifiedAudioEffectsService.getState()).normalization;
    await PrefsService.setBool('normEnabled', normEnabled);
    notifyListeners();
  }

  Future<void> toggleBgPlayback() async {
    bgPlayback = !bgPlayback;
    await PrefsService.setBool('bgPlayback', bgPlayback);
    notifyListeners();
  }

  Future<void> toggleLockScreen() async {
    lockScreenControls = !lockScreenControls;
    await PrefsService.setBool('lockScreenControls', lockScreenControls);
    await PlaybackSystemService.setLockScreenEnabled(lockScreenControls);
    notifyListeners();
  }

  Future<void> toggleDuplicates() async {
    allowDuplicates = !allowDuplicates;
    await PrefsService.setBool('allowDuplicates', allowDuplicates);
    notifyListeners();
  }

  // ── Playback speed ──────────────────────────────────────────────────────

  Future<void> setPlaybackSpeed(double speed,
      {MediaPlaybackCoordinator? coordinator}) async {
    playbackSpeed = speed;
    await (coordinator ?? _coordinator).setSpeed(speed);
    await PrefsService.setDouble('playbackSpeed', speed);
    notifyListeners();
  }

  // ── Crossfade ───────────────────────────────────────────────────────────

  Future<void> setCrossfade(int seconds) async {
    crossfadeSeconds = seconds;
    await PrefsService.setInt('crossfadeSeconds', seconds);
    await _coordinator.setCrossfade(seconds);
    notifyListeners();
  }

  // ── Queue mode ──────────────────────────────────────────────────────────

  Future<void> setQueueMode(String mode) async {
    queueMode = mode;
    await PrefsService.setString('queueMode', mode);
    notifyListeners();
  }

  // ── Sleep timer ─────────────────────────────────────────────────────────

  Future<void> setSleepTimer(String value) async {
    _sleepTimer?.cancel();
    _sleepTimer = null;
    _sleepSecondsRemaining = 0;

    sleepTimer = value;
    await PrefsService.setString('sleepTimer', value);

    final duration = _parseSleepDuration(value);
    if (duration != null) {
      _sleepSecondsRemaining = duration.inSeconds;
      _startSleepCountdown();
    }

    notifyListeners();
  }

  void _startSleepCountdown() {
    _sleepTimer?.cancel();
    final stopwatch = Stopwatch()..start();
    final targetSeconds = _sleepSecondsRemaining;
    _sleepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      final remaining = targetSeconds - stopwatch.elapsed.inSeconds;
      if (remaining <= 0) {
        timer.cancel();
        _sleepTimer = null;
        _sleepSecondsRemaining = 0;
        sleepSecondsNotifier.value = 0;
        sleepTimer = 'Off';
        PrefsService.setString('sleepTimer', 'Off');
        debugPrint('[Playback] pause requested: music sleep timer');
        PlaybackSystemService.registerExplicitPause();
        unawaited(
          PlaybackSystemService.pauseForReason(
            PlaybackPauseReason.sleepTimer,
          ),
        );
        notifyListeners();
      } else {
        _sleepSecondsRemaining = remaining;
        sleepSecondsNotifier.value = remaining;
      }
    });
  }

  Duration? _parseSleepDuration(String value) {
    switch (value) {
      case '5 min':
        return const Duration(minutes: 5);
      case '10 min':
        return const Duration(minutes: 10);
      case '15 min':
        return const Duration(minutes: 15);
      case '30 min':
        return const Duration(minutes: 30);
      case '45 min':
        return const Duration(minutes: 45);
      case '1 hour':
        return const Duration(hours: 1);
      default:
        return null;
    }
  }

  // ── Shuffle / Repeat ────────────────────────────────────────────────────

  Future<void> setShuffle(bool value) async {
    isShuffle = value;
    await PrefsService.setBool('isShuffle', value);
    notifyListeners();
  }

  Future<void> setRepeatMode(int mode) async {
    repeatMode = mode;
    await PrefsService.setInt('repeatMode', mode);
    notifyListeners();
  }

  // ── Deferred config for MusicProvider ───────────────────────────────────
  Future<void> applyDeferredPlayerConfig({
    MediaPlaybackCoordinator? coordinator,
  }) async {
    if (!_deferredConfigPending) return;
    _deferredConfigPending = false;

    final activeCoordinator = coordinator ?? _coordinator;
    if (isShuffle) await activeCoordinator.setShuffle(true);
    final mode = [
      PlaybackRepeatMode.off,
      PlaybackRepeatMode.all,
      PlaybackRepeatMode.one
    ][repeatMode];
    await activeCoordinator.setRepeatMode(mode);
    if (playbackSpeed != 1.0) {
      await activeCoordinator.setSpeed(playbackSpeed);
    }
    await activeCoordinator.setCrossfade(_deferredCrossfade);
    await UnifiedAudioEffectsService.setNormalization(
      _deferredNormEnabled,
    );
    normEnabled =
        (await UnifiedAudioEffectsService.getState()).normalization;
  }

  // ── Cleanup ─────────────────────────────────────────────────────────────

  void cancelSleepTimer() {
    _sleepTimer?.cancel();
    _sleepTimer = null;
  }

  @override
  void dispose() {
    _sleepTimer?.cancel();
    sleepSecondsNotifier.dispose();
    super.dispose();
  }
}
