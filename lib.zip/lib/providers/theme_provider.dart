import 'dart:async';

import 'package:flutter/material.dart';

import '../services/prefs_service.dart';
import '../services/system_font_service.dart';
import '../services/theme_customization_service.dart';
import '../theme/app_theme.dart';

class ThemeProvider extends ChangeNotifier with WidgetsBindingObserver {
  CustomThemeData? _activeCustomTheme;
  String? systemFontFamily;

  ThemeType get themeType => ThemeType.system;
  String get themeLabel => _activeCustomTheme?.name ?? ThemeType.system.label;
  CustomThemeData? get activeCustomTheme => _activeCustomTheme;
  bool get hasCustomTheme => _activeCustomTheme != null;

  void setSystemFontFamily(String? family) {
    if (systemFontFamily == family) return;
    systemFontFamily = family;
    notifyListeners();
  }

  Brightness get _systemBrightness =>
      WidgetsBinding.instance.platformDispatcher.platformBrightness;

  ThemeData _themeFor(Brightness brightness) {
    final custom = _activeCustomTheme;

    if (custom == null) {
      return AppTheme.system(
        brightness: brightness,
        systemFontFamily: systemFontFamily,
      );
    }

    return AppTheme.custom(
      brightness: custom.isDark ? Brightness.dark : Brightness.light,
      primary: custom.primary,
      background: custom.background,
      surface: custom.surface,
      accent: custom.accent,
      text: custom.text,
      systemFontFamily: systemFontFamily,
    );
  }

  ThemeColors get colors =>
      ThemeColors.fromScheme(_themeFor(_systemBrightness).colorScheme);

  Color get bg => colors.bg;
  Color get surface => colors.surface;
  Color get surface2 => colors.surface2;
  Color get border => colors.border;
  Color get text => colors.text;
  Color get muted => colors.muted;

  Color get accent => _themeFor(_systemBrightness).colorScheme.primary;
  Color get accent2 => _themeFor(_systemBrightness).colorScheme.secondary;
  Color get accent3 => _themeFor(_systemBrightness).colorScheme.tertiary;
  Color get danger => _themeFor(_systemBrightness).colorScheme.error;

  LinearGradient gradient(String key) {
    final scheme = _themeFor(_systemBrightness).colorScheme;

    final colors = switch (key) {
      'grad-b' => [scheme.secondary, scheme.secondaryContainer],
      'grad-c' => [scheme.tertiary, scheme.tertiaryContainer],
      'grad-d' => [scheme.error, scheme.errorContainer],
      'grad-e' => [scheme.primaryContainer, scheme.surfaceContainerHighest],
      _ => [scheme.primary, scheme.primaryContainer],
    };

    return LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: colors,
    );
  }

  ThemeData get currentTheme => _themeFor(_systemBrightness);
  ThemeData get themeForLight => _themeFor(Brightness.light);
  ThemeData get themeForDark => _themeFor(Brightness.dark);

  ThemeMode get themeMode => _activeCustomTheme == null
      ? ThemeMode.system
      : (_activeCustomTheme!.isDark ? ThemeMode.dark : ThemeMode.light);

  bool get isDark =>
      _activeCustomTheme?.isDark ?? (_systemBrightness == Brightness.dark);

  ThemeProvider() {
    WidgetsBinding.instance.addObserver(this);
    unawaited(_migrateLegacyThemePreference());
    unawaited(_loadCustomTheme());
    unawaited(refreshSystemFont());
  }

  Future<void> refreshSystemFont() async {
    final family = await SystemFontService.loadCurrentFamily();
    if (family != null) {
      setSystemFontFamily(family);
    }
  }

  Future<void> _migrateLegacyThemePreference() async {
    await PrefsService.instance.setString('selectedTheme', 'system');
  }

  Future<void> _loadCustomTheme() async {
    _activeCustomTheme = await ThemeCustomizationService.getActiveThemeData();
    notifyListeners();
  }

  Future<void> applyCustomTheme(CustomThemeData? theme) async {
    _activeCustomTheme = theme;
    await ThemeCustomizationService.setActiveTheme(theme?.id);
    notifyListeners();
  }

  Future<void> clearCustomTheme() => applyCustomTheme(null);

  Future<void> setTheme(ThemeType _) => clearCustomTheme();

  @override
  void didChangePlatformBrightness() => notifyListeners();

  @override
  void didChangeTextScaleFactor() => notifyListeners();

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(refreshSystemFont());
    }
  }

  @override
  void didChangeLocales(List<Locale>? locales) {}

  @override
  void didChangeAccessibilityFeatures() {}

  @override
  void didHaveMemoryPressure() {}

  @override
  void didChangeMetrics() {}

  @override
  Future<bool> didPopRoute() async => false;

  @override
  Future<bool> didPushRoute(String route) async => false;

  @override
  Future<bool> didPushRouteInformation(
    RouteInformation routeInformation,
  ) async =>
      false;

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}
