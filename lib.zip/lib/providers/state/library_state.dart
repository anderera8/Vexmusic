
import '../../models/music_models.dart';
import '../music_provider.dart' show SortMode;

class LibraryState {
  final List<Track> tracks;
  final List<Album> albums;
  final List<Artist> artists;
  final List<Playlist> playlists;
  final List<Genre> genres;
  final List<PlayHistory> recentHistory;
  final Map<int, Track> trackById;
  final bool libraryLoaded;
  final bool isLoading;
  final String? loadError;
  final bool isFirstLoad;
  final bool isSyncing;

  final Map<SortMode, List<Track>> _sortedTrackCache = {};

  LibraryState({
    required this.tracks,
    required this.albums,
    required this.artists,
    required this.playlists,
    required this.genres,
    required this.recentHistory,
    required this.trackById,
    required this.libraryLoaded,
    required this.isLoading,
    this.loadError,
    required this.isFirstLoad,
    required this.isSyncing,
  });

  factory LibraryState.initial() => LibraryState(
        tracks: [],
        albums: [],
        artists: [],
        playlists: [],
        genres: [],
        recentHistory: [],
        trackById: {},
        libraryLoaded: false,
        isLoading: false,
        loadError: null,
        isFirstLoad: true,
        isSyncing: false,
      );

  // ── Computed properties ────────────────────────────────────────────────

  bool get hasTracks => tracks.isNotEmpty;

  int get genreCount => genres.length;

  List<Track> get likedTracks => tracks.where((t) => t.liked).toList();

  List<Genre> get sortedGenres => List.unmodifiable(genres);

  List<Track> sortedTracks(SortMode mode) {
    final cached = _sortedTrackCache[mode];
    if (cached != null) return cached;

    final sorted = List<Track>.from(tracks);
    switch (mode) {
      case SortMode.titleAZ:
        sorted.sort((a, b) => a.title.compareTo(b.title));
      case SortMode.titleZA:
        sorted.sort((a, b) => b.title.compareTo(a.title));
      case SortMode.dateNewest:
        sorted.sort((a, b) => b.dateAdded.compareTo(a.dateAdded));
      case SortMode.dateOldest:
        sorted.sort((a, b) => a.dateAdded.compareTo(b.dateAdded));
      case SortMode.sizeBig:
        sorted.sort((a, b) => b.size.compareTo(a.size));
      case SortMode.sizeSmall:
        sorted.sort((a, b) => a.size.compareTo(b.size));
    }
    return _sortedTrackCache[mode] = List.unmodifiable(sorted);
  }

  List<Track> tracksForGenre(Genre genre) {
    final result = <Track>[];
    for (final id in genre.trackIds) {
      final match = trackById[id];
      if (match != null) result.add(match);
    }
    return result;
  }

  List<Track> get recentlyPlayed {
    final byStableKey = {
      for (final track in tracks)
        if (track.stableKey.isNotEmpty) track.stableKey: track,
    };

    final result = <Track>[];
    final seenIds = <int>{};
    final seenStableKeys = <String>{};

    for (final entry in recentHistory) {
      final match = trackById[entry.trackId] ??
          (entry.stableKey.isNotEmpty ? byStableKey[entry.stableKey] : null);

      if (match == null) continue;

      if (seenIds.contains(match.id)) continue;
      if (match.stableKey.isNotEmpty &&
          seenStableKeys.contains(match.stableKey)) {
        continue;
      }

      result.add(match);
      seenIds.add(match.id);
      if (match.stableKey.isNotEmpty) {
        seenStableKeys.add(match.stableKey);
      }

      if (result.length >= 10) break;
    }
    return result;
  }

  /// Builds genres by grouping tracks by their actual genre metadata.
  static List<Genre> buildGenres(List<Track> tracks) {
    final map = <String, Set<int>>{};
    for (final t in tracks) {
      final key = (t.genre.isNotEmpty) ? t.genre : _inferGenreFromTrack(t);
      map.putIfAbsent(key, () => {}).add(t.id);
    }
    final result = map.entries
        .map((e) => Genre(
              name: e.key,
              trackIds: e.value.toList(),
              art: Genre.artForGenre(e.key),
              grad: Genre.gradForGenre(e.key),
            ))
        .toList();
    result.sort((a, b) {
      final countCmp = b.trackCount.compareTo(a.trackCount);
      if (countCmp != 0) return countCmp;
      return a.name.compareTo(b.name);
    });
    return result;
  }

  /// Infers a genre name from a track's art emoji and gradient.
  static String _inferGenreFromTrack(Track t) {
    switch (t.art) {
      case '\u{1F3B8}': // 🎸
        if (t.grad == 'grad-c') return 'Rock';
        if (t.grad == 'grad-d') return 'Blues';
        return 'Alternative';
      case '\u{1F3A4}': // 🎤
        return 'Pop';
      case '\u{1F399}\u{FE0F}': // 🎙️
        return 'Hip-Hop/Rap';
      case '\u{1F3B7}': // 🎷
        return 'Jazz';
      case '\u{1F3BB}': // 🎻
        return 'Classical';
      case '\u{1FAA9}': // 🪩
        return 'Electronic';
      case '\u{1F3A7}': // 🎧
        return 'R&B/Soul';
    }
    return 'Other';
  }

  /// Builds a lookup map from track IDs to Track objects.
  static Map<int, Track> buildTrackMap(List<Track> tracks) =>
      {for (final t in tracks) t.id: t};

  // ── copyWith ───────────────────────────────────────────────────────────

  LibraryState copyWith({
    List<Track>? tracks,
    List<Album>? albums,
    List<Artist>? artists,
    List<Playlist>? playlists,
    List<Genre>? genres,
    List<PlayHistory>? recentHistory,
    Map<int, Track>? trackById,
    bool? libraryLoaded,
    bool? isLoading,
    Object? loadError = _noArg, // null is a valid value
    bool? isFirstLoad,
    bool? isSyncing,
  }) {
    return LibraryState(
      tracks: tracks ?? this.tracks,
      albums: albums ?? this.albums,
      artists: artists ?? this.artists,
      playlists: playlists ?? this.playlists,
      genres: genres ?? this.genres,
      recentHistory: recentHistory ?? this.recentHistory,
      trackById: trackById ?? this.trackById,
      libraryLoaded: libraryLoaded ?? this.libraryLoaded,
      isLoading: isLoading ?? this.isLoading,
      loadError: loadError is String? ? loadError : this.loadError,
      isFirstLoad: isFirstLoad ?? this.isFirstLoad,
      isSyncing: isSyncing ?? this.isSyncing,
    );
  }

  static const _noArg = Object();
}
