import '../../models/music_models.dart';

enum QueueItemOrigin {
  active,
  pending,
}

class QueueItemToken {
  static int _counter = 0;

  static String create(String origin) {
    final tick = DateTime.now().microsecondsSinceEpoch;
    return '$origin-$tick-${_counter++}';
  }

  static List<String> createMany(int length, String origin) {
    return List<String>.generate(
      length,
      (_) => create(origin),
      growable: false,
    );
  }

  static List<String> normalize({
    required int length,
    required List<String>? ids,
    required String origin,
  }) {
    if (ids != null && ids.length == length && ids.toSet().length == length) {
      return List<String>.unmodifiable(ids);
    }

    return List<String>.unmodifiable(createMany(length, origin));
  }
}

class QueueItemView {
  final String id;
  final Track track;
  final QueueItemOrigin origin;
  final int sourceIndex;
  final int compositeIndex;

  const QueueItemView({
    required this.id,
    required this.track,
    required this.origin,
    required this.sourceIndex,
    required this.compositeIndex,
  });

  bool get isActive => origin == QueueItemOrigin.active;
  bool get isPending => origin == QueueItemOrigin.pending;

  QueueItemView copyWith({
    String? id,
    Track? track,
    QueueItemOrigin? origin,
    int? sourceIndex,
    int? compositeIndex,
  }) {
    return QueueItemView(
      id: id ?? this.id,
      track: track ?? this.track,
      origin: origin ?? this.origin,
      sourceIndex: sourceIndex ?? this.sourceIndex,
      compositeIndex: compositeIndex ?? this.compositeIndex,
    );
  }
}

class QueueState {
  final List<Track> activeQueue;
  final List<String> activeQueueItemIds;

  QueueState({
    required List<Track> activeQueue,
    List<String>? activeQueueItemIds,
  })  : activeQueue = List<Track>.unmodifiable(activeQueue),
        activeQueueItemIds = QueueItemToken.normalize(
          length: activeQueue.length,
          ids: activeQueueItemIds,
          origin: 'active',
        );

  factory QueueState.initial() => QueueState(activeQueue: const []);

  factory QueueState.fresh(List<Track> activeQueue) {
    return QueueState(activeQueue: activeQueue);
  }

  List<String> _idsForQueue(List<Track> queue) {
    if (activeQueue.isNotEmpty && activeQueueItemIds.length == queue.length) {
      return activeQueueItemIds;
    }

    return List<String>.generate(
      queue.length,
      (index) => 'library-${queue[index].id}-$index',
      growable: false,
    );
  }

  List<int> _normalizedEffectiveOrder(
    int queueLength,
    List<int> effectiveOrder,
  ) {
    final isValid = effectiveOrder.length == queueLength &&
        effectiveOrder.toSet().length == queueLength &&
        effectiveOrder.every((index) => index >= 0 && index < queueLength);

    if (isValid) {
      return List<int>.from(effectiveOrder);
    }

    return List<int>.generate(
      queueLength,
      (index) => index,
      growable: false,
    );
  }

  List<QueueItemView> upNextItems(
    List<Track> tracks,
    int nowIdx,
    List<QueueItemView> pendingItems, {
    List<int> effectiveOrder = const <int>[],
  }) {
    final queue = activeQueue.isNotEmpty ? activeQueue : tracks;

    if (queue.isEmpty || nowIdx < 0 || nowIdx >= queue.length) {
      return List<QueueItemView>.unmodifiable(
        pendingItems.map(
          (item) => item.copyWith(
            compositeIndex: item.compositeIndex,
          ),
        ),
      );
    }

    final ids = _idsForQueue(queue);
    final playbackOrder = _normalizedEffectiveOrder(
      queue.length,
      effectiveOrder,
    );

    final currentPlaybackPosition = playbackOrder.indexOf(nowIdx);

    final upcomingCanonicalIndexes = currentPlaybackPosition >= 0 &&
            currentPlaybackPosition + 1 < playbackOrder.length
        ? playbackOrder.sublist(currentPlaybackPosition + 1)
        : const <int>[];

    final items = <QueueItemView>[];
    var compositeIndex = 0;

    for (final sourceIndex in upcomingCanonicalIndexes) {
      if (sourceIndex < 0 || sourceIndex >= queue.length) {
        continue;
      }

      items.add(
        QueueItemView(
          id: ids[sourceIndex],
          track: queue[sourceIndex],
          origin: QueueItemOrigin.active,
          sourceIndex: sourceIndex,
          compositeIndex: compositeIndex++,
        ),
      );
    }

    for (final pending in pendingItems) {
      items.add(
        pending.copyWith(
          compositeIndex: compositeIndex++,
        ),
      );
    }

    return List<QueueItemView>.unmodifiable(items);
  }

  List<Track> upNextTracks(
    List<Track> tracks,
    int nowIdx,
    List<QueueItemView> pendingItems, {
    List<int> effectiveOrder = const <int>[],
  }) {
    return upNextItems(
      tracks,
      nowIdx,
      pendingItems,
      effectiveOrder: effectiveOrder,
    ).map((item) => item.track).toList(growable: false);
  }

  bool hasUpNext(
    List<Track> tracks,
    int nowIdx,
    List<QueueItemView> pendingItems, {
    List<int> effectiveOrder = const <int>[],
  }) {
    return upNextItems(
      tracks,
      nowIdx,
      pendingItems,
      effectiveOrder: effectiveOrder,
    ).isNotEmpty;
  }

  List<Track> get safeActiveQueue => List<Track>.unmodifiable(activeQueue);

  List<String> get safeActiveQueueItemIds =>
      List<String>.unmodifiable(activeQueueItemIds);

  QueueState copyWith({
    List<Track>? activeQueue,
    List<String>? activeQueueItemIds,
  }) {
    final nextQueue = activeQueue ?? this.activeQueue;
    final nextIds = activeQueueItemIds ??
        (activeQueue == null ? this.activeQueueItemIds : null);

    return QueueState(
      activeQueue: nextQueue,
      activeQueueItemIds: nextIds,
    );
  }
}
