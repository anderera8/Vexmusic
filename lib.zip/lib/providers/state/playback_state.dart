import '../../models/media_models.dart';
import '../../models/music_models.dart';
import '../music_provider.dart' show ActiveContextType;

class PlaybackState {
  final int nowIdx;
  final bool isPlaying;
  final bool hasStartedPlayback;
  final bool isSwitchingTrack;
  final bool audioPlaylistLoaded;
  final Duration position;
  final Duration? totalDuration;
  final ActiveContextType activeContextType;
  final String activeContextName;
  final int activeContextId;
  final PlaybackFailure? failure;
  final bool isRecovering;
  final int consecutiveFailures;

  const PlaybackState({
    required this.nowIdx,
    required this.isPlaying,
    required this.hasStartedPlayback,
    required this.isSwitchingTrack,
    required this.audioPlaylistLoaded,
    required this.position,
    this.totalDuration,
    required this.activeContextType,
    required this.activeContextName,
    required this.activeContextId,
    this.failure,
    this.isRecovering = false,
    this.consecutiveFailures = 0,
  });

  factory PlaybackState.initial() => const PlaybackState(
        nowIdx: 0,
        isPlaying: false,
        hasStartedPlayback: false,
        isSwitchingTrack: false,
        audioPlaylistLoaded: false,
        position: Duration.zero,
        totalDuration: null,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
        failure: null,
        isRecovering: false,
        consecutiveFailures: 0,
      );

  // ── Computed properties ────────────────────────────────────────────────
  Track currentTrack(List<Track> tracks, List<Track> activeQueue) {
    final queue = activeQueue.isNotEmpty ? activeQueue : tracks;
    if (queue.isEmpty) {
      return Track(
        id: 0,
        title: 'No tracks',
        artist: 'Load your library',
        duration: 0,
        art: '??',
        grad: 'grad-a',
        genre: '',
      );
    }
    return queue[nowIdx.clamp(0, queue.length - 1)];
  }

  double get progressPct {
    final dur = totalDuration?.inMilliseconds ?? 0;
    if (dur == 0) return 0;
    return (position.inMilliseconds / dur * 100).clamp(0, 100);
  }

  bool isFav(List<Track> tracks, List<Track> activeQueue) =>
      currentTrack(tracks, activeQueue).liked;

  bool isActiveFolder(String folderName) =>
      activeContextType == ActiveContextType.folder &&
      activeContextName == folderName;

  bool isActivePlaylist(int playlistId) =>
      activeContextType == ActiveContextType.playlist &&
      activeContextId == playlistId;

  bool get hasLoadedAudioPlaylist => audioPlaylistLoaded;

  // ── copyWith ───────────────────────────────────────────────────────────
  PlaybackState copyWith({
    int? nowIdx,
    bool? isPlaying,
    bool? hasStartedPlayback,
    bool? isSwitchingTrack,
    bool? audioPlaylistLoaded,
    Duration? position,
    Object? totalDuration = _noArg, // null is a valid value
    ActiveContextType? activeContextType,
    String? activeContextName,
    int? activeContextId,
    PlaybackFailure? failure,
    bool? isRecovering,
    int? consecutiveFailures,
    bool clearFailure = false,
  }) {
    return PlaybackState(
      nowIdx: nowIdx ?? this.nowIdx,
      isPlaying: isPlaying ?? this.isPlaying,
      hasStartedPlayback: hasStartedPlayback ?? this.hasStartedPlayback,
      isSwitchingTrack: isSwitchingTrack ?? this.isSwitchingTrack,
      audioPlaylistLoaded: audioPlaylistLoaded ?? this.audioPlaylistLoaded,
      position: position ?? this.position,
      totalDuration:
          totalDuration is Duration? ? totalDuration : this.totalDuration,
      activeContextType: activeContextType ?? this.activeContextType,
      activeContextName: activeContextName ?? this.activeContextName,
      activeContextId: activeContextId ?? this.activeContextId,
      failure: clearFailure ? null : failure ?? this.failure,
      isRecovering: isRecovering ?? this.isRecovering,
      consecutiveFailures:
          consecutiveFailures ?? this.consecutiveFailures,
    );
  }

  static const _noArg = Object();
}
