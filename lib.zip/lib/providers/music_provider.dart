import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/media_models.dart';
import '../models/music_models.dart';
import '../services/audio_file_operations_service.dart';
import '../services/audio_library_scanner.dart';
import '../services/artwork_cache_service.dart';
import '../services/database_service.dart';
import '../services/lyrics_service.dart';
import '../services/prefs_service.dart';
import '../services/playback/media_playback_coordinator.dart';
import '../services/playback/playback_system_service.dart';
import '../services/playback/audio_interruption_policy.dart';
import '../services/playback/playback_controller.dart';
import '../services/library/library_service.dart';
import '../services/library/media_store_observer.dart';
import '../services/history/history_service.dart';
import '../services/favorites/like_service.dart';
import '../services/playlist/playlist_manager.dart';
import '../services/playlist/playlist_file_service.dart';
import '../widgets/track_art_widget.dart';
import 'state/library_state.dart';
import 'state/playback_state.dart';
import 'state/queue_state.dart';
import 'settings_provider.dart';
import 'queue_provider.dart';
import 'lyrics_provider.dart';

enum SortMode {
  titleAZ,
  titleZA,
  dateNewest,
  dateOldest,
  sizeBig,
  sizeSmall,
}

enum ActiveContextType {
  none,
  folder,
  playlist,
}

class MusicProvider extends ChangeNotifier with WidgetsBindingObserver {
  // ── Core services ───────────────────────────────────────────────────────
  final MediaPlaybackCoordinator _playbackCoordinator =
      MediaPlaybackCoordinator();
  final DatabaseService _dbService = DatabaseService();
  final AudioFileOperationsService _fileOperations;
  late final LibraryService _libraryService;
  late final PlaybackController _playbackController;
  late final HistoryService _historyService;
  late final LikeService _likeService;
  late final PlaylistManager _playlistManager;
  late final MediaStoreObserver _mediaStoreObserver;

  // ── Delegated providers (facade pattern) ───────────────────────────────
  late final SettingsProvider _settings;
  late final bool _ownsSettings;
  late final QueueProvider _queue;
  late final LyricsProvider _lyrics;

  // ── Immutable state objects ────────────────────────────────────────────
  LibraryState _libraryState = LibraryState.initial();
  PlaybackState _playbackState = PlaybackState.initial();
  QueueState _queueState = QueueState.initial();

  // ── Stream subscriptions ───────────────────────────────────────────────
  final List<StreamSubscription> _subscriptions = [];
  Future<void>? _librarySyncFuture;
  Future<void>? _persistedDataFuture;
  bool _mediaStoreObserverStarted = false;

  // Guards async track-change side effects from older engine events.
  int _trackChangeGeneration = 0;
  PlaybackFailure? _lastPlaybackFailure;

  final ValueNotifier<Duration> positionNotifier = ValueNotifier(Duration.zero);
  final ValueNotifier<Duration?> totalDurationNotifier = ValueNotifier(null);

  // SECTION 1: Public Getters — Library State
  List<Track> get tracks => _libraryState.tracks;
  List<Album> get albums => _libraryState.albums;
  List<Artist> get artists => _libraryState.artists;
  List<Playlist> get playlists => _libraryState.playlists;
  List<Genre> get genres => _libraryState.genres;
  List<PlayHistory> get recentHistory => _libraryState.recentHistory;

  bool get isLoading => _libraryState.isLoading;
  String? get loadError => _libraryState.loadError;
  bool get hasTracks => _libraryState.hasTracks;
  int get genreCount => _libraryState.genreCount;

  List<Track> get sortedTracks =>
      _libraryState.sortedTracks(_settings.sortMode);
  List<Genre> get sortedGenres => _libraryState.sortedGenres;
  List<Track> tracksForGenre(Genre genre) =>
      _libraryState.tracksForGenre(genre);

  List<Track> get recentlyPlayed => _libraryState.recentlyPlayed;
  List<Track> get likedTracks => _libraryState.likedTracks;

  // SECTION 2: Public Getters — Playback State
  int get nowIdx => _playbackState.nowIdx;
  bool get isPlaying => _playbackState.isPlaying;
  bool get hasStartedPlayback => _playbackState.hasStartedPlayback;
  PlaybackFailure? get lastPlaybackFailure => _lastPlaybackFailure;
  bool get isRecoveringPlayback => _playbackState.isRecovering;
  int get consecutivePlaybackFailures =>
      _playbackState.consecutiveFailures;
  String get playbackFailureMessage =>
      _lastPlaybackFailure?.message ?? '';

  Duration get position => positionNotifier.value;
  Duration? get totalDuration => totalDurationNotifier.value;

  ActiveContextType get activeContextType => _playbackState.activeContextType;
  String get activeContextName => _playbackState.activeContextName;
  int get activeContextId => _playbackState.activeContextId;

  bool isActiveFolder(String folderName) =>
      _playbackState.isActiveFolder(folderName);
  bool isActivePlaylist(int playlistId) =>
      _playbackState.isActivePlaylist(playlistId);

  Track get currentTrack =>
      _playbackState.currentTrack(_libraryState.tracks, _queueState.activeQueue);

  bool get isFav =>
      _playbackState.isFav(_libraryState.tracks, _queueState.activeQueue);

  double get progressPct => _playbackState.progressPct;
  List<Track> get activeQueue => _queueState.safeActiveQueue;

  // SECTION 3: Public Getters — Queue State
  List<QueueItemView> get upNextItems => _queueState.upNextItems(
        _libraryState.tracks,
        _playbackState.nowIdx,
        _queue.pendingQueueItems,
        effectiveOrder: _playbackCoordinator.currentQueue.normalizedEffectiveOrder,
      );

  List<Track> get upNextTracks =>
      upNextItems.map((item) => item.track).toList(growable: false);

  List<Track> get pendingQueue => _queue.pendingQueue;

  bool get hasUpNext => upNextItems.isNotEmpty;
  bool get hasPendingQueue => _queue.hasPendingQueue;

  // SECTION 4: Public Getters — Lyrics (delegated to LyricsProvider)
  bool get hasLyrics => _lyrics.hasLyrics;
  LyricsData? get currentLyrics => _lyrics.currentLyrics;
  bool get isLyricsLoading => _lyrics.isLoading;
  String? get lyricsError => _lyrics.error;
  LyricsSource get lyricsSource => _lyrics.source;
  List<LyricsCandidate>? get lyricsCandidates => _lyrics.candidates;
  bool get isSearchingLyricsCandidates => _lyrics.isSearchingCandidates;
  Future<void> retryLyrics() => _lyrics.retry();
  Future<void> searchLyricsCandidates({
    required String artist,
    required String title,
    int durationSeconds = 0,
  }) =>
      _lyrics.searchCandidates(
        artist: artist,
        title: title,
        durationSeconds: durationSeconds,
      );
  void selectLyricsCandidate(LyricsCandidate candidate) =>
      _lyrics.selectCandidate(candidate);
  void clearLyricsCandidates() => _lyrics.clearCandidates();
  void useManualLyrics(LyricsData lyrics) => _lyrics.useManualLyrics(lyrics);
  void dismissLyrics() => _lyrics.dismissCurrent();

  // SECTION 5: Public Getters — Settings (delegated to SettingsProvider)
  bool get isShuffle => _settings.isShuffle;
  int get repeatMode => _settings.repeatMode;
  bool get normEnabled => _settings.normEnabled;
  bool get bgPlayback => _settings.bgPlayback;
  bool get lockScreenControls => _settings.lockScreenControls;
  bool get allowDuplicates => _settings.allowDuplicates;
  String get selectedTheme => _settings.selectedTheme;
  String get selectedAccent => _settings.selectedAccent;
  String get sleepTimer => _settings.sleepTimer;
  double get playbackSpeed => _settings.playbackSpeed;
  int get crossfadeSeconds => _settings.crossfadeSeconds;
  String get queueMode => _settings.queueMode;
  SortMode get sortMode => _settings.sortMode;
  String get sortModeLabel => _settings.sortModeLabel;
  bool get sortAZ => _settings.sortAZ;
  int get sleepSecondsRemaining => _settings.sleepSecondsRemaining;
  bool get sleepTimerActive => _settings.sleepTimerActive;
  ValueNotifier<int> get sleepSecondsNotifier => _settings.sleepSecondsNotifier;

  // SECTION 6: Constructor
  MusicProvider({
    List<Track> initialTracks = const [],
    bool loadPersistedData = true,
    SettingsProvider? settings,
    LyricsProvider? lyricsProvider,
    AudioFileOperationsService? fileOperations,
    AudioLibraryScanner? libraryScanner,
  }) : _fileOperations = fileOperations ?? AudioFileOperationsService() {
    // ── Create delegated providers ─────────────────────────────────────
    _settings = settings ?? SettingsProvider();
    _ownsSettings = settings == null;
    _queue = QueueProvider(_settings);
    _lyrics = lyricsProvider ?? LyricsProvider();

    // ── Create services ────────────────────────────────────────────────
    _historyService = HistoryService(db: _dbService);
    _likeService = LikeService(db: _dbService);
    _playlistManager = PlaylistManager(db: _dbService);
    _libraryService = LibraryService(
      db: _dbService,
      scanner: libraryScanner ?? AudioLibraryScanner(),
      likeService: _likeService,
    );
    _playbackController = PlaybackController(
      coordinator: _playbackCoordinator,
      db: _dbService,
      history: _historyService,
    );
    _mediaStoreObserver = MediaStoreObserver(_onMediaStoreSyncNeeded);

    // ── Initial tracks ─────────────────────────────────────────────────
    if (initialTracks.isNotEmpty) {
      _libraryState = _libraryState.copyWith(
        tracks: List<Track>.from(initialTracks),
        trackById: LibraryState.buildTrackMap(initialTracks),
      );
    }

    _settings.addListener(notifyListeners);
    _queue.addListener(notifyListeners);
    _lyrics.addListener(notifyListeners);

    PlaybackSystemService.setQueueControlCallbacks(
      onPlay: _playFromSystem,
      onPause: _pauseFromSystem,
      onStop: _stopFromSystem,
      onSeek: _seekFromSystem,
      onSkipNext: nexttrack,
      onSkipPrevious: previoustrack,
      onSetShuffle: _setShuffleFromSystem,
      onSetRepeatMode: _setRepeatModeFromSystem,
      onPauseForReason: _pauseForSystemReason,
      onResumeAfterInterruption: _resumeAfterInterruption,
      onSetTransientVolume: _setTransientVolume,
    );

    WidgetsBinding.instance.addObserver(this);
    _initStreams();

    if (loadPersistedData) {
      _persistedDataFuture = _loadPersistedData();
    }
  }

  // SECTION 7: Stream Subscriptions
  void _initStreams() {
    _subscriptions.addAll([
      _playbackCoordinator.playbackState.listen((state) {
        positionNotifier.value = state.position;
        totalDurationNotifier.value =
            state.duration > Duration.zero ? state.duration : null;

        var shouldNotify = false;
        final failure = state.failure;

        if (_playbackState.isRecovering != state.isRecovering ||
            _playbackState.consecutiveFailures !=
                state.consecutiveFailures) {
          _playbackState = _playbackState.copyWith(
            isRecovering: state.isRecovering,
            consecutiveFailures: state.consecutiveFailures,
          );
          shouldNotify = true;
        }

        if (failure != null) {
          shouldNotify = _setPlaybackFailure(
                failure,
                operation: 'runtime playback',
              ) ||
              shouldNotify;

          if (state.processingState == PlaybackProcessingState.error) {
            _playbackState = _playbackState.copyWith(
              isPlaying: false,
              isSwitchingTrack: false,
              failure: failure,
              isRecovering: false,
              consecutiveFailures: state.consecutiveFailures,
            );
            shouldNotify = true;
          }
        }

        // Only notify when isPlaying actually changes
        if (_playbackState.isPlaying != state.playing) {
          _playbackState = _playbackState.copyWith(isPlaying: state.playing);
          final current = currentTrack;
          unawaited(
            PlaybackSystemService.updateWidget(
              title: current.title,
              artist: current.artist,
              isPlaying: state.playing,
            ),
          );
          shouldNotify = true;
        }

        if (shouldNotify) {
          notifyListeners();
        }

        if (state.processingState == PlaybackProcessingState.completed &&
            _queue.hasPendingQueue &&
            !_playbackState.isSwitchingTrack) {
          final activeLen = _queueState.activeQueue.isNotEmpty
              ? _queueState.activeQueue.length
              : _libraryState.tracks.length;
          if (_playbackState.nowIdx >= activeLen - 1) {
            unawaited(_autoDrainPendingQueue());
          }
        }
      }),
      _playbackCoordinator.queueState.listen((queueState) {
        final newIndex = queueState.currentIndex;
        if (newIndex < 0 || newIndex == _playbackState.nowIdx) {
          notifyListeners();
          return;
        }

        final activeLength = _queueState.activeQueue.isNotEmpty
            ? _queueState.activeQueue.length
            : _libraryState.tracks.length;

        if (activeLength <= 0 || newIndex >= activeLength) {
          notifyListeners();
          return;
        }

        final generation = ++_trackChangeGeneration;

        _playbackState = _playbackState.copyWith(
          nowIdx: newIndex,
          isSwitchingTrack: false,
          position: Duration.zero,
          totalDuration: null,
        );

        notifyListeners();

        unawaited(
          _onTrackChangedFromStream(
            generation: generation,
            newIndex: newIndex,
          ),
        );
      }),
    ]);
  }

  Future<void> _autoDrainPendingQueue() {
    return _runEngineBackedPlaybackCommand(
      'promote pending queue',
      () => _playbackController.drainPendingQueue(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        _queue,
      ),
    );
  }

  Future<void> _setShuffleFromSystem(bool enabled) {
    return _runEngineBackedPlaybackCommand(
      'system shuffle',
      () => _playbackController.setShuffleEnabled(
        enabled,
        _playbackState,
        _queueState,
        _settings,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _setRepeatModeFromSystem(PlaybackRepeatMode mode) {
    return _runEngineBackedPlaybackCommand(
      'system repeat mode',
      () => _playbackController.setRepeatModeValue(
        mode,
        _playbackState,
        _queueState,
        _settings,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _playFromSystem() {
    if (_playbackState.isPlaying) return Future<void>.value();

    PlaybackSystemService.registerExplicitPlay();
    return _runEngineBackedPlaybackCommand(
      'system play',
      () => _playbackController.togglePlayPause(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _pauseFromSystem() {
    if (!_playbackState.isPlaying) return Future<void>.value();

    PlaybackSystemService.registerExplicitPause();
    return _runEngineBackedPlaybackCommand(
      'system pause',
      () => _playbackController.togglePlayPause(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _pauseForSystemReason(PlaybackPauseReason reason) {
    if (!_playbackState.isPlaying) return Future<void>.value();

    return _runEngineVoidCommand(
      'pause for ${reason.name}',
      () => _playbackCoordinator.pause(
        releaseAudioSession: reason != PlaybackPauseReason.audioFocus,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _resumeAfterInterruption() {
    if (_playbackState.isPlaying) return Future<void>.value();
    return _playFromSystem();
  }

  Future<void> _setTransientVolume(double volume) {
    return _runEngineVoidCommand(
      'set transient playback volume',
      () => _playbackCoordinator.setVolume(volume),
      rethrowFailure: true,
    );
  }

  Future<void> _stopFromSystem() {
    PlaybackSystemService.registerExplicitStop();
    return _runEngineBackedPlaybackCommand(
      'system stop',
      () => _playbackController.stopAndClear(
        _libraryState,
        _playbackState,
        _queueState,
      ),
      rethrowFailure: true,
    );
  }

  Future<void> _seekFromSystem(Duration position) {
    return _runEngineVoidCommand(
      'system seek',
      () => _playbackController.seekTo(position),
      rethrowFailure: true,
    );
  }

  Future<void> _onTrackChangedFromStream({
    required int generation,
    required int newIndex,
  }) async {
    final updatedLib = await _playbackController.onTrackChanged(
      newIndex,
      _libraryState,
      _queueState.activeQueue,
      _lyrics,
    );

    if (generation != _trackChangeGeneration) return;

    if (updatedLib != null) {
      _libraryState = updatedLib;
      notifyListeners();
    }
  }

  void _startMediaStoreObserverAfterLibraryLoad() {
    if (_mediaStoreObserverStarted) return;
    if (!_libraryState.libraryLoaded || _libraryState.isLoading) return;

    _mediaStoreObserverStarted = true;
    _mediaStoreObserver.start();

    debugPrint('[MediaObserver] Started after library load');
  }

  Future<void> _onMediaStoreSyncNeeded([
    LibrarySyncReason reason = LibrarySyncReason.mediaStoreChanged,
  ]) async {
    if (_libraryState.isLoading || !_libraryState.libraryLoaded) {
      debugPrint('[MediaObserver] Library not loaded yet — skipping sync');
      return;
    }

    Duration? syncCooldown;

    switch (reason) {
      case LibrarySyncReason.resume:
        syncCooldown = const Duration(minutes: 10);
        break;
      case LibrarySyncReason.coldStart:
        syncCooldown = const Duration(seconds: 45);
        break;
      case LibrarySyncReason.mediaStoreChanged:
        syncCooldown = null;
        break;
    }

    if (syncCooldown != null) {
      final lastSync = PrefsService.instance.getInt('lastSyncTimestamp') ?? 0;
      final elapsed = DateTime.now().millisecondsSinceEpoch - lastSync;

      if (elapsed < syncCooldown.inMilliseconds) {
        debugPrint(
          '[MediaObserver] Skipping $reason sync — last sync was ${elapsed}ms ago',
        );
        return;
      }
    }

    if (_librarySyncFuture != null) {
      debugPrint('[MediaObserver] Sync already in progress — skipping');
      return _librarySyncFuture;
    }

    final completer = Completer<void>();
    _librarySyncFuture = completer.future;

    try {
      debugPrint('[MediaObserver] MediaStore sync requested: $reason');

      final oldTracks = _libraryState.tracks;
      final newState = await _libraryService.verifyAndSync(_libraryState);
      final libraryChanged = !_sameTrackLibrary(oldTracks, newState.tracks);
      final deletedTracks = _deletedTracksBetween(
        oldTracks,
        newState.tracks,
      );

      unawaited(
        _invalidateRemappedTrackArtwork(
          oldTracks,
          newState.tracks,
        ),
      );

      if (libraryChanged) {
        final result = await _playbackController.reconcileQueueAfterLibraryChange(
          _libraryState,
          newState,
          _playbackState,
          _queueState,
          _settings,
          _queue,
        );

        _playbackState = result.playbackState;
        _queueState = result.queueState;
        _libraryState = result.libraryState ?? newState;
      } else {
        _libraryState = newState;
      }

      if (deletedTracks.isNotEmpty) {
        _cleanupDeletedTrackRuntimeState(deletedTracks);
      }

      notifyListeners();
    } catch (error, stackTrace) {
      debugPrint('[MediaObserver] Sync failed safely: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      _librarySyncFuture = null;

      if (!completer.isCompleted) {
        completer.complete();
      }
    }
  }

  static Track? _findSurvivingTrack(
    Track previous,
    List<Track> currentTracks,
  ) {
    for (final candidate in currentTracks) {
      if (candidate.id == previous.id ||
          candidate.matchesStableIdentity(previous)) {
        return candidate;
      }
    }

    return null;
  }

  static List<Track> _deletedTracksBetween(
    List<Track> previousTracks,
    List<Track> currentTracks,
  ) {
    final currentIds = <int>{};
    final currentStableKeys = <String>{};
    final currentNormalizedPaths = <String>{};

    for (final track in currentTracks) {
      currentIds.add(track.id);

      final stableKey = track.stableKey.trim();
      if (stableKey.isNotEmpty) {
        currentStableKeys.add(stableKey);
      }

      final normalizedPath = track.normalizedSourcePath;
      if (normalizedPath.isNotEmpty) {
        currentNormalizedPaths.add(normalizedPath);
      }
    }

    bool hasSurvivor(Track previous) {
      if (currentIds.contains(previous.id)) return true;

      final stableKey = previous.stableKey.trim();
      if (stableKey.isNotEmpty && currentStableKeys.contains(stableKey)) {
        return true;
      }

      final normalizedPath = previous.normalizedSourcePath;
      if (normalizedPath.isNotEmpty &&
          currentNormalizedPaths.contains(normalizedPath)) {
        return true;
      }

      return false;
    }

    return previousTracks
        .where((previous) => !hasSurvivor(previous))
        .toList(growable: false);
  }

  static bool _sameTrackLibrary(List<Track> a, List<Track> b) {
    if (a.length != b.length) return false;
    final byId = <int, Track>{};
    final byStableKey = <String, Track>{};
    final byNormalizedPath = <String, Track>{};

    for (final track in b) {
      byId[track.id] = track;

      final stableKey = track.stableKey.trim();
      if (stableKey.isNotEmpty) {
        byStableKey[stableKey] = track;
      }

      final normalizedPath = track.normalizedSourcePath;
      if (normalizedPath.isNotEmpty) {
        byNormalizedPath[normalizedPath] = track;
      }
    }

    final matchedIds = <int>{};

    for (final track in a) {
      Track? other = byId[track.id];

      if (other == null) {
        final stableKey = track.stableKey.trim();
        if (stableKey.isNotEmpty) {
          other = byStableKey[stableKey];
        }
      }

      if (other == null) {
        final normalizedPath = track.normalizedSourcePath;
        if (normalizedPath.isNotEmpty) {
          other = byNormalizedPath[normalizedPath];
        }
      }

      if (other == null || !matchedIds.add(other.id)) {
        return false;
      }

      if (track.title != other.title ||
          track.artist != other.artist ||
          track.albumName != other.albumName ||
          track.albumId != other.albumId ||
          track.filePath != other.filePath ||
          track.playbackUri != other.playbackUri ||
          track.duration != other.duration ||
          track.genre != other.genre ||
          track.size != other.size) {
        return false;
      }
    }

    return true;
  }

  // SECTION 8: Library Loading
  Future<void> loadLibrary({bool forceScan = false}) async {
    if (!forceScan &&
        _libraryState.libraryLoaded &&
        !_libraryState.isFirstLoad) {
      _startMediaStoreObserverAfterLibraryLoad();
      return;
    }

    if (_libraryState.isLoading) return;

    final stateBefore = _libraryState;

    _libraryState = stateBefore.copyWith(
      isLoading: true,
      loadError: null,
    );

    notifyListeners();

    try {
      final newState = await _libraryService.loadLibrary(
        stateBefore,
        forceScan: forceScan,
      );
      final deletedTracks = _deletedTracksBetween(
        stateBefore.tracks,
        newState.tracks,
      );

      unawaited(
        _invalidateRemappedTrackArtwork(
          stateBefore.tracks,
          newState.tracks,
        ),
      );

      final persistedDataFuture = _persistedDataFuture;

      if (persistedDataFuture != null) {
        await persistedDataFuture;
      }

      final playlists = await _playlistManager.loadPlaylists(
        tracks: newState.tracks,
      );
      final recentHistory = await _historyService.loadHistory(
        tracks: newState.tracks,
      );

      _libraryState = newState.copyWith(
        playlists: playlists,
        recentHistory: recentHistory,
        isLoading: false,
        libraryLoaded: true,
        isFirstLoad: false,
        loadError: null,
      );

      if (deletedTracks.isNotEmpty) {
        _cleanupDeletedTrackRuntimeState(deletedTracks);
      }

      _startMediaStoreObserverAfterLibraryLoad();

      notifyListeners();

      debugPrint('Loaded ${_libraryState.tracks.length} tracks');
      unawaited(
        Future<void>.delayed(const Duration(seconds: 2), () async {
          await _onMediaStoreSyncNeeded(LibrarySyncReason.coldStart);
        }),
      );
    } catch (e, stackTrace) {
      debugPrint('Error loading library: $e');
      debugPrint('Stack trace: $stackTrace');

      _libraryState = _libraryState.copyWith(
        isLoading: false,
        isFirstLoad: false,
        loadError: 'Failed to load music: $e',
      );

      notifyListeners();
    }
  }

  Future<void> refreshLibrary() async {
    await loadLibrary(forceScan: true);
  }

  Future<void> _loadPersistedData() async {
    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
      recentHistory: await _historyService.loadHistory(
        tracks: _libraryState.tracks,
      ),
    );
    notifyListeners();
  }

  // SECTION 9: Playback Commands
  Future<void> playtrack(int idx, {bool recordHistory = true}) {
    if (_libraryState.tracks.isEmpty) return Future<void>.value();

    PlaybackSystemService.registerExplicitPlay();
    final targetIndex = idx.clamp(0, _libraryState.tracks.length - 1).toInt();

    return _runEngineBackedPlaybackCommand(
      'play track',
      () => _playbackController.playTrack(
        targetIndex,
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        recordHistory: recordHistory,
      ),
      optimisticUpdate: () {
        ++_trackChangeGeneration;
        _playbackState = _playbackState.copyWith(
          nowIdx: targetIndex,
          hasStartedPlayback: true,
          isSwitchingTrack: true,
          activeContextType: ActiveContextType.none,
          activeContextName: '',
          activeContextId: -1,
        );
        _queueState = QueueState.initial();
      },
    );
  }

  Future<void> resumeTrack(Track track) {
    if (_libraryState.tracks.isEmpty) return Future<void>.value();

    PlaybackSystemService.registerExplicitPlay();

    final idx = _libraryState.tracks.indexWhere((t) => t.id == track.id);
    if (idx == -1) return Future<void>.value();

    return _runEngineBackedPlaybackCommand(
      'resume track',
      () => _playbackController.resumeTrack(
        track,
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
      ),
      optimisticUpdate: () {
        ++_trackChangeGeneration;
        _playbackState = _playbackState.copyWith(
          nowIdx: idx,
          hasStartedPlayback: true,
          isSwitchingTrack: true,
          activeContextType: ActiveContextType.none,
          activeContextName: '',
          activeContextId: -1,
        );
        _queueState = QueueState.initial();
      },
    );
  }

  Future<void> playQueue(
    List<Track> queueTracks,
    int startIndex, {
    ActiveContextType contextType = ActiveContextType.none,
    String contextName = '',
    int contextId = -1,
  }) {
    if (queueTracks.isEmpty) return Future<void>.value();

    PlaybackSystemService.registerExplicitPlay();

    // Show the mini-player instantly — before the engine opens the file.
    final targetIndex = startIndex.clamp(0, queueTracks.length - 1).toInt();

    return _runEngineBackedPlaybackCommand(
      'play queue',
      () => _playbackController.playQueue(
        queueTracks,
        targetIndex,
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        contextType: contextType,
        contextName: contextName,
        contextId: contextId,
      ),
      optimisticUpdate: () {
        ++_trackChangeGeneration;
        _playbackState = _playbackState.copyWith(
          nowIdx: targetIndex,
          hasStartedPlayback: true,
          isSwitchingTrack: true,
          activeContextType: contextType,
          activeContextName: contextName,
          activeContextId: contextId,
        );
        _queueState = QueueState.fresh(List<Track>.from(queueTracks));
      },
    );
  }

  Future<void> togglePlayPause() {
    if (_playbackState.isPlaying) {
      PlaybackSystemService.registerExplicitPause();
    } else {
      PlaybackSystemService.registerExplicitPlay();
    }

    return _runEngineBackedPlaybackCommand(
      'toggle play/pause',
      () => _playbackController.togglePlayPause(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
      ),
    );
  }

  Future<void> stopAndClear() {
    PlaybackSystemService.registerExplicitStop();
    return _runEngineBackedPlaybackCommand(
      'stop playback',
      () => _playbackController.stopAndClear(
        _libraryState,
        _playbackState,
        _queueState,
      ),
    ).then((_) {
      if (!_playbackState.audioPlaylistLoaded) {
        _queue.clearPendingQueue();
      }
    });
  }

  Future<void> dismissPlayer() {
    PlaybackSystemService.registerExplicitStop();
    return _runEngineBackedPlaybackCommand(
      'dismiss player',
      () => _playbackController.dismissPlayer(
        _libraryState,
        _playbackState,
        _queueState,
      ),
    ).then((_) {
      if (!_playbackState.hasStartedPlayback) {
        _queue.clearPendingQueue();
      }
    });
  }

  Future<void> seekTo(Duration pos) {
    return _runEngineVoidCommand(
      'seek playback',
      () => _playbackController.seekTo(pos),
    );
  }

  Future<void> seekRelative(int seconds) {
    return _runEngineVoidCommand(
      'seek playback',
      () => _playbackController.seekRelative(seconds, _playbackState),
    );
  }

  Future<void> nexttrack() {
    PlaybackSystemService.registerExplicitPlay();
    return _runEngineBackedPlaybackCommand(
      'skip to next track',
      () => _playbackController.nextTrack(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        _queue,
      ),
    );
  }

  Future<void> previoustrack() {
    PlaybackSystemService.registerExplicitPlay();
    return _runEngineBackedPlaybackCommand(
      'skip to previous track',
      () => _playbackController.previousTrack(
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
      ),
    );
  }

  void jumpTo(int idx) => unawaited(playtrack(idx));

  Future<void> playFromUpNext(int compositeIndex) {
    PlaybackSystemService.registerExplicitPlay();
    return _runEngineBackedPlaybackCommand(
      'play Up Next item',
      () => _playbackController.playFromUpNext(
        compositeIndex,
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        _queue,
      ),
    );
  }

  Future<void> playFromUpNextItem(String queueItemId) {
    PlaybackSystemService.registerExplicitPlay();
    return _runEngineBackedPlaybackCommand(
      'play Up Next queue item',
      () => _playbackController.playFromUpNextItem(
        queueItemId,
        _libraryState,
        _playbackState,
        _queueState,
        _settings,
        _queue,
      ),
    );
  }

  void removeFromUpNext(int compositeIndex) {
    unawaited(_removeFromUpNext(compositeIndex));
  }

  Future<void> _removeFromUpNext(int compositeIndex) {
    return _runEngineBackedPlaybackCommand(
      'remove Up Next item',
      () => _playbackController.removeFromUpNext(
        compositeIndex,
        _libraryState,
        _playbackState,
        _queueState,
        _queue,
      ),
    );
  }

  void removeFromUpNextItem(String queueItemId) {
    unawaited(_removeFromUpNextItem(queueItemId));
  }

  Future<void> _removeFromUpNextItem(String queueItemId) {
    return _runEngineBackedPlaybackCommand(
      'remove Up Next item',
      () => _playbackController.removeFromUpNextItem(
        queueItemId,
        _libraryState,
        _playbackState,
        _queueState,
        _queue,
      ),
    );
  }

  void clearUpNext() {
    unawaited(_clearUpNext());
  }

  Future<void> _clearUpNext() {
    return _runEngineBackedPlaybackCommand(
      'clear Up Next',
      () => _playbackController.clearUpNext(
        _libraryState,
        _playbackState,
        _queueState,
        _queue,
      ),
    );
  }

  void reorderUpNext(int oldIndex, int newIndex) {
    unawaited(_reorderUpNext(oldIndex, newIndex));
  }

  Future<void> _reorderUpNext(int oldIndex, int newIndex) {
    return _runEngineBackedPlaybackCommand(
      'reorder Up Next',
      () => _playbackController.reorderUpNext(
        oldIndex,
        newIndex,
        _libraryState,
        _playbackState,
        _queueState,
        _queue,
      ),
    );
  }

  void reorderUpNextItems(String movingItemId, String targetItemId) {
    unawaited(_reorderUpNextItems(movingItemId, targetItemId));
  }

  Future<void> _reorderUpNextItems(
    String movingItemId,
    String targetItemId,
  ) {
    return _runEngineBackedPlaybackCommand(
      'reorder Up Next',
      () => _playbackController.reorderUpNextItems(
        movingItemId,
        targetItemId,
        _libraryState,
        _playbackState,
        _queueState,
        _queue,
      ),
    );
  }

  Future<void> toggleShuffle() {
    return _runEngineBackedPlaybackCommand(
      'change shuffle mode',
      () => _playbackController.toggleShuffle(
        _playbackState,
        _queueState,
        _settings,
      ),
    );
  }

  Future<void> cycleRepeat() {
    return _runEngineBackedPlaybackCommand(
      'change repeat mode',
      () => _playbackController.cycleRepeat(
        _playbackState,
        _queueState,
        _settings,
      ),
    );
  }

  Future<void> _runEngineBackedPlaybackCommand(
    String operation,
    Future<PlaybackResult> Function() command, {
    VoidCallback? optimisticUpdate,
    bool rethrowFailure = false,
  }) async {
    final previousPlaybackState = _playbackState;
    final previousQueueState = _queueState;
    final previousLibraryState = _libraryState;
    final previousPosition = positionNotifier.value;
    final previousDuration = totalDurationNotifier.value;

    optimisticUpdate?.call();
    if (optimisticUpdate != null) {
      notifyListeners();
    }

    try {
      final result = await command();
      _applyPlaybackResult(result);
    } on PlaybackCommandException catch (error, stackTrace) {
      _playbackState = previousPlaybackState.copyWith(
        failure: error.failure,
        isRecovering: false,
      );
      _queueState = previousQueueState;
      _libraryState = previousLibraryState;
      positionNotifier.value = previousPosition;
      totalDurationNotifier.value = previousDuration;
      _setPlaybackFailure(
        error.failure,
        operation:
            error.failure.message.isNotEmpty ? operation : 'playback command',
      );
      debugPrint(
        '[MusicProvider] $operation failed: '
        '${error.failure.type.name}: ${error.failure.message}',
      );
      debugPrintStack(stackTrace: stackTrace);
      notifyListeners();

      if (rethrowFailure) {
        Error.throwWithStackTrace(error, stackTrace);
      }
    } catch (error, stackTrace) {
      final typed = PlaybackCommandException(
        PlaybackFailure(
          PlaybackErrorType.engine,
          'An unexpected playback error occurred.',
          cause: error,
        ),
      );

      _playbackState = previousPlaybackState.copyWith(
        failure: typed.failure,
        isRecovering: false,
      );
      _queueState = previousQueueState;
      _libraryState = previousLibraryState;
      positionNotifier.value = previousPosition;
      totalDurationNotifier.value = previousDuration;
      _setPlaybackFailure(typed.failure, operation: operation);
      debugPrint('[MusicProvider] $operation failed unexpectedly: $error');
      debugPrintStack(stackTrace: stackTrace);
      notifyListeners();

      if (rethrowFailure) {
        Error.throwWithStackTrace(typed, stackTrace);
      }
    }
  }

  Future<void> _runEngineVoidCommand(
    String operation,
    Future<void> Function() command, {
    bool rethrowFailure = false,
  }) {
    return _runEngineBackedPlaybackCommand(
      operation,
      () async {
        await command();
        return PlaybackResult(
          playbackState: _playbackState,
          queueState: _queueState,
        );
      },
      rethrowFailure: rethrowFailure,
    );
  }

  void _applyPlaybackResult(PlaybackResult result) {
    final previousPosition = _playbackState.position;
    final previousDuration = _playbackState.totalDuration;

    _playbackState = result.playbackState;
    _queueState = result.queueState;

    if (result.libraryState != null) {
      _libraryState = result.libraryState!;
    }

    if (result.playbackState.position != previousPosition) {
      positionNotifier.value = result.playbackState.position;
    }
    if (result.playbackState.totalDuration != previousDuration) {
      totalDurationNotifier.value = result.playbackState.totalDuration;
    }

    final notice = result.notice;
    if (notice != null) {
      _setPlaybackFailure(
        notice,
        operation: notice.operation.isEmpty
            ? 'automatic playback recovery'
            : notice.operation,
      );
    } else {
      _clearPlaybackFailureWithoutNotify();
      _playbackState = _playbackState.copyWith(clearFailure: true);
    }

    notifyListeners();
  }

  bool _setPlaybackFailure(
    PlaybackFailure failure, {
    required String operation,
  }) {
    final current = _lastPlaybackFailure;
    if (current?.type == failure.type &&
        current?.message == failure.message &&
        current?.cause == failure.cause) {
      return false;
    }

    _lastPlaybackFailure = failure;
    return true;
  }

  void clearPlaybackFailure() {
    if (_lastPlaybackFailure == null) return;

    _lastPlaybackFailure = null;
    _playbackState = _playbackState.copyWith(clearFailure: true);
    notifyListeners();
  }

  void _clearPlaybackFailureWithoutNotify() {
    _lastPlaybackFailure = null;
  }

  // SECTION 10: Likes
  Future<void> toggleLike(int trackId) async {
    final idx = _libraryState.tracks.indexWhere((t) => t.id == trackId);
    if (idx == -1) return;

    final track = _libraryState.tracks[idx];
    final result = await _likeService.toggleLike(track);

    // Update in tracks list
    final newTracks = List<Track>.from(_libraryState.tracks);
    newTracks[idx] = result.track;

    _libraryState = _libraryState.copyWith(
      tracks: newTracks,
      trackById: LibraryState.buildTrackMap(newTracks),
    );

    // Also update in activeQueue if present
    final aqIdx = _queueState.activeQueue.indexWhere((t) => t.id == trackId);
    if (aqIdx != -1) {
      final newAq = List<Track>.from(_queueState.activeQueue);
      newAq[aqIdx] = result.track;
      _queueState = _queueState.copyWith(activeQueue: newAq);
    }

    notifyListeners();
  }

  // SECTION 11: Settings (delegated)
  Future<void> setPlaybackSpeed(double speed) =>
      _settings.setPlaybackSpeed(speed, coordinator: _playbackCoordinator);

  void setSortMode(SortMode mode) => _settings.setSortMode(mode);
  void cycleSortMode() => _settings.cycleSortMode();
  void toggleNorm() => _settings.toggleNorm();
  void toggleBgPlayback() => _settings.toggleBgPlayback();
  void toggleLockScreen() => _settings.toggleLockScreen();
  void toggleDuplicates() => _settings.toggleDuplicates();

  Future<void> setCrossfade(int seconds) => _settings.setCrossfade(seconds);
  Future<void> setQueueMode(String mode) => _settings.setQueueMode(mode);
  Future<void> setSleepTimer(String value) => _settings.setSleepTimer(value);

  // SECTION 12: Playlists
  Future<void> createPlaylist(String name) async {
    await _playlistManager.createPlaylist(name);
    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );
    notifyListeners();
  }

  Future<PlaylistImportResult?> importPlaylistFile() async {
    final imported = await PlaylistFileService.pickAndParse(
      tracks,
      allowDuplicates: allowDuplicates,
    );

    if (imported == null) return null;

    if (imported.trackIds.isEmpty) {
      throw const FormatException(
        'No entries in this playlist matched the current library.',
      );
    }

    final name = imported.name.isEmpty ? 'Imported playlist' : imported.name;

    final importedTracks = imported.trackIds
        .map((id) => _libraryState.trackById[id])
        .whereType<Track>()
        .toList(growable: false);

    await _playlistManager.createPlaylistWithTrackRefs(name, importedTracks);

    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );

    notifyListeners();
    return imported;
  }

  Future<bool> exportPlaylistFile(Playlist playlist) {
    return PlaylistFileService.export(
      playlist: playlist,
      tracks: tracksForPlaylist(playlist),
    );
  }

  Future<void> deletePlaylist(int id) async {
    await _playlistManager.deletePlaylist(id);
    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );
    notifyListeners();
  }

  Future<void> renamePlaylist(int id, String newName) async {
    await _playlistManager.renamePlaylist(id, newName);
    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );
    notifyListeners();
  }

  Future<void> addTrackToPlaylist(int playlistId, int trackId) async {
    final track = _libraryState.trackById[trackId];
    if (track == null) return;

    if (!allowDuplicates) {
      final pl = _libraryState.playlists.firstWhere(
        (p) => p.id == playlistId,
        orElse: () => const Playlist(id: -1, name: '', trackIds: [], art: ''),
      );

      if (pl.id != -1 &&
          _playlistManager.trackExistsInPlaylistRef(pl, track)) {
        return;
      }
    }

    final inserted = await _playlistManager.addTrackToPlaylistRef(
      playlistId,
      track,
      allowDuplicate: allowDuplicates,
    );

    if (!inserted) return;

    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );

    notifyListeners();
  }

  Future<void> removePlaylistEntryAt(
    int playlistId,
    int playlistIndex,
  ) async {
    final removed = await _playlistManager.removeTrackFromPlaylistAt(
      playlistId,
      playlistIndex,
    );

    if (!removed) return;

    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );

    notifyListeners();
  }

  Future<void> removePlaylistEntryById(
    int playlistId,
    String entryId,
  ) async {
    Playlist? playlist;
    for (final candidate in _libraryState.playlists) {
      if (candidate.id == playlistId) {
        playlist = candidate;
        break;
      }
    }

    if (playlist == null || entryId.trim().isEmpty) return;

    final removed = await _playlistManager.removeTrackFromPlaylistEntryId(
      playlist,
      entryId,
    );
    if (!removed) return;

    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );
    notifyListeners();
  }

  Future<void> removeTrackFromPlaylist(int playlistId, int trackId) async {
    final track = _libraryState.trackById[trackId];

    if (track != null) {
      await _playlistManager.removeTrackFromPlaylistRef(playlistId, track);
    } else {
      await _playlistManager.removeTrackFromPlaylist(playlistId, trackId);
    }

    _libraryState = _libraryState.copyWith(
      playlists: await _playlistManager.loadPlaylists(
        tracks: _libraryState.tracks,
      ),
    );

    notifyListeners();
  }

  List<PlaylistTrackEntry> entriesForPlaylist(
    Playlist playlist,
  ) =>
      PlaylistManager.entriesForPlaylist(
        playlist,
        _libraryState.trackById,
        tracks: _libraryState.tracks,
      );

  List<Track> tracksForPlaylist(Playlist playlist) =>
      PlaylistManager.tracksForPlaylist(
        playlist,
        _libraryState.trackById,
        tracks: _libraryState.tracks,
      );

  // SECTION 13: History
  Future<void> clearRecentlyPlayed() async {
    await _historyService.clearHistory();
    _libraryState = _libraryState.copyWith(recentHistory: []);
    notifyListeners();
  }

  // SECTION 14: Queue Management (delegated)
  void enqueueTrack(Track track) {
    unawaited(_enqueueTrack(track));
  }

  Future<void> _enqueueTrack(Track track) async {
    final result = await _playbackController.enqueueTrack(
      track,
      _libraryState,
      _playbackState,
      _queueState,
      _settings,
      _queue,
    );

    _applyPlaybackResult(result);
  }

  void removeFromPendingQueue(int index) => _queue.removeFromPendingQueue(index);

  void reorderPendingQueue(int oldIndex, int newIndex) =>
      _queue.reorderPendingQueue(oldIndex, newIndex);

  void clearPendingQueue() => _queue.clearPendingQueue();

  // SECTION 15: Track Management (delete / share / artwork refresh)
  void _cleanupDeletedTrackRuntimeState(Iterable<Track> deletedTracks) {
    final tracks = deletedTracks.toList(growable: false);
    if (tracks.isEmpty) return;

    _queue.removeTrackRefs(tracks);
    _lyrics.removeTrackRefs(tracks);
    unawaited(_invalidateDeletedTrackArtwork(tracks));
  }

  Future<void> _invalidateDeletedTrackArtwork(List<Track> deletedTracks) async {
    for (final track in deletedTracks) {
      try {
        await ArtworkCacheService.invalidateArtwork(
          albumId: track.albumId,
          mediaStoreId: track.mediaStoreId,
          volumeName: track.volumeName,
          stableKey: track.stableKey,
          trackId: track.id,
        );

        TrackArtWidget.invalidateArtwork(
          albumId: track.albumId,
          mediaStoreId: track.mediaStoreId,
          volumeName: track.volumeName,
          stableKey: track.stableKey,
          trackId: track.id,
        );
      } catch (error) {
        debugPrint(
          '[MusicProvider] Failed to invalidate deleted artwork '
          '${track.id}: $error',
        );
      }
    }
  }

  Future<void> _invalidateRemappedTrackArtwork(
    List<Track> previousTracks,
    List<Track> currentTracks,
  ) async {
    for (final previous in previousTracks) {
      final current = _findSurvivingTrack(
        previous,
        currentTracks,
      );

      if (current == null || previous.id == current.id) {
        continue;
      }

      try {
        await ArtworkCacheService.invalidateArtwork(
          mediaStoreId: previous.mediaStoreId,
          volumeName: previous.volumeName,
          stableKey: previous.stableKey,
          trackId: previous.id,
        );

        await ArtworkCacheService.invalidateArtwork(
          mediaStoreId: current.mediaStoreId,
          volumeName: current.volumeName,
          stableKey: current.stableKey,
          trackId: current.id,
        );

        TrackArtWidget.invalidateArtwork(
          mediaStoreId: previous.mediaStoreId,
          volumeName: previous.volumeName,
          stableKey: previous.stableKey,
          trackId: previous.id,
        );

        TrackArtWidget.invalidateArtwork(
          mediaStoreId: current.mediaStoreId,
          volumeName: current.volumeName,
          stableKey: current.stableKey,
          trackId: current.id,
        );
      } catch (error) {
        debugPrint(
          '[MusicProvider] Failed to invalidate remapped artwork '
          '${previous.id} -> ${current.id}: $error',
        );
      }
    }
  }

  Future<bool> deleteTrack(int trackId) async {
    final track = _libraryState.trackById[trackId];
    if (track == null) return false;

    final currentIdBeforeDelete = currentTrack.id;
    final wasCurrentTrack = currentIdBeforeDelete == trackId;
    final playbackQueueBeforeDelete = _queueState.activeQueue.isNotEmpty
        ? _queueState.activeQueue
        : _libraryState.tracks;
    final wasInPlaybackQueue =
        playbackQueueBeforeDelete.any((item) => item.id == trackId);
    final positionBeforeDelete = position;
    final wasPlayingBeforeDelete = isPlaying;

    if (!await _fileOperations.delete(track)) return false;

    final newTracks = _libraryState.tracks
        .where((item) => item.id != trackId)
        .toList(growable: false);

    var cleanupSucceeded = true;

    try {
      await _dbService.cleanupDeletedAudioTrackReferences(
        [track],
        survivingTracks: newTracks,
      );

      _libraryState = _libraryState.copyWith(
        playlists: await _playlistManager.loadPlaylists(
          tracks: newTracks,
        ),
        recentHistory: await _historyService.loadHistory(
          tracks: newTracks,
        ),
      );
    } catch (error, stackTrace) {
      cleanupSucceeded = false;
      debugPrint('[MusicProvider] Deleted file cleanup failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }

    // Update in-memory state
    final newActiveQueue = <Track>[];
    final newActiveQueueItemIds = <String>[];

    for (var i = 0; i < _queueState.activeQueue.length; i++) {
      final item = _queueState.activeQueue[i];
      if (item.id == trackId) continue;

      newActiveQueue.add(item);
      if (i < _queueState.activeQueueItemIds.length) {
        newActiveQueueItemIds.add(_queueState.activeQueueItemIds[i]);
      }
    }

    _cleanupDeletedTrackRuntimeState([track]);

    _libraryState = _libraryState.copyWith(
      tracks: newTracks,
      trackById: LibraryState.buildTrackMap(newTracks),
      genres: LibraryState.buildGenres(newTracks),
    );
    _queueState = _queueState.copyWith(
      activeQueue: newActiveQueue,
      activeQueueItemIds: newActiveQueueItemIds,
    );

    if (wasCurrentTrack) {
      PlaybackSystemService.registerExplicitStop();
      await _playbackCoordinator.stop();

      _playbackState = _playbackState.copyWith(
        nowIdx: 0,
        audioPlaylistLoaded: false,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
      );
      _queueState = QueueState.initial();
    } else {
      final queue =
          _queueState.activeQueue.isNotEmpty ? _queueState.activeQueue : newTracks;
      final currentIndex =
          queue.indexWhere((item) => item.id == currentIdBeforeDelete);
      final newIdx = queue.isEmpty
          ? 0
          : currentIndex >= 0
              ? currentIndex
              : _playbackState.nowIdx.clamp(0, queue.length - 1);

      _playbackState = _playbackState.copyWith(nowIdx: newIdx);

      if (_playbackController.hasLoadedPlaylist(_playbackState) &&
          wasInPlaybackQueue &&
          queue.isNotEmpty) {
        final (entry, entries) = PlaybackController.toMediaEntries(queue, newIdx);

        await _playbackCoordinator.open(
          entry,
          queue: entries,
          initialIndex: newIdx,
          autoPlay: false,
        );
        await _playbackCoordinator.seek(positionBeforeDelete);

        if (wasPlayingBeforeDelete) {
          await _playbackCoordinator.play();
        }
      }
    }

    notifyListeners();
    return cleanupSucceeded;
  }

  Future<void> refreshTrackArtwork(
    Track track, {
    Uint8List? freshBytes,
  }) async {
    await ArtworkCacheService.invalidateArtwork(
      mediaStoreId: track.mediaStoreId,
      volumeName: track.volumeName,
      stableKey: track.stableKey,
      trackId: track.id,
    );

    TrackArtWidget.invalidateArtwork(
      mediaStoreId: track.mediaStoreId,
      volumeName: track.volumeName,
      stableKey: track.stableKey,
      trackId: track.id,
    );

    if (freshBytes != null && freshBytes.isNotEmpty) {
      await ArtworkCacheService.cacheWrittenArtworkBytes(
        bytes: freshBytes,
        mediaStoreId: track.mediaStoreId,
        volumeName: track.volumeName,
        stableKey: track.stableKey,
        trackId: track.id,
      );

      TrackArtWidget.primeArtwork(
        mediaStoreId: track.mediaStoreId,
        volumeName: track.volumeName,
        stableKey: track.stableKey,
        trackId: track.id,
        bytes: freshBytes,
      );
    } else {
      if (track.albumId != null && track.albumId! > 0) {
        unawaited(
          ArtworkCacheService.cacheArtwork(
            track.albumId!,
            type: ArtworkType.album,
            volumeName: track.volumeName,
            forceRefresh: true,
          ),
        );
      }

      unawaited(
        ArtworkCacheService.cacheTrackArtwork(
          track.mediaStoreId,
          stableKey: track.stableKey,
          volumeName: track.volumeName,
          legacyTrackId: track.id,
          forceRefresh: true,
        ),
      );
    }

    notifyListeners();
  }

  void refreshTrackTags(
    int trackId, {
    required String title,
    required String artist,
    required String album,
  }) {
    final index = _libraryState.tracks.indexWhere((t) => t.id == trackId);
    if (index == -1) return;

    final current = _libraryState.tracks[index];
    final trimmedAlbum = album.trim();
    final updated = trimmedAlbum.isEmpty
        ? Track(
            id: current.id,
            mediaStoreId: current.mediaStoreId,
            stableKey: current.stableKey,
            title: title,
            artist: artist,
            albumName: null,
            albumId: current.albumId,
            filePath: current.filePath,
            playbackUri: current.playbackUri,
            artPath: current.artPath,
            duration: current.duration,
            bitrate: current.bitrate,
            liked: current.liked,
            art: current.art,
            grad: current.grad,
            genre: current.genre,
            dateAdded: current.dateAdded,
            size: current.size,
          )
        : current.copyWith(
            title: title,
            artist: artist,
            albumName: trimmedAlbum,
          );

    final updatedTracks = List<Track>.of(_libraryState.tracks);
    updatedTracks[index] = updated;

    final updatedTrackById = Map<int, Track>.of(_libraryState.trackById);
    updatedTrackById[trackId] = updated;

    _libraryState = _libraryState.copyWith(
      tracks: updatedTracks,
      trackById: updatedTrackById,
    );

    notifyListeners();
  }

  Future<void> shareTrack(int trackId) async {
    final track = _libraryState.trackById[trackId];

    if (track == null || track.filePath == null || track.filePath!.isEmpty) {
      return;
    }

    try {
      await _fileOperations.share(track);
    } catch (e) {
      debugPrint('Failed to share file: $e');
    }
  }

  // SECTION 16: App Lifecycle
  bool _allowNextBackgroundPlayback = false;
  void allowNextBackgroundTransition() {
    _allowNextBackgroundPlayback = true;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (_libraryState.libraryLoaded && !_libraryState.isLoading) {
        _mediaStoreObserver.onLifecycleResumed();
      } else {
        debugPrint('[MediaObserver] Resume ignored — library not loaded yet');
      }
    } else if (state == AppLifecycleState.paused) {
      _mediaStoreObserver.onLifecyclePaused();

      final exempted = _allowNextBackgroundPlayback;
      _allowNextBackgroundPlayback = false;

      if (!exempted &&
          shouldPauseForBackgroundTransition(
            backgroundPlaybackEnabled: bgPlayback,
            isPlaying: isPlaying,
          )) {
        debugPrint(
          '[Playback] pause requested: app lifecycle '
          '(background playback disabled)',
        );
        PlaybackSystemService.registerExplicitPause();
        unawaited(
          _pauseForSystemReason(PlaybackPauseReason.lifecycle),
        );
      } else if (isPlaying) {
        debugPrint(
          '[Playback] app backgrounded: retaining active audio playback',
        );
      }
    }
  }

  // SECTION 17: Dispose
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    PlaybackSystemService.clearQueueControlCallbacks();

    _settings.cancelSleepTimer();
    _mediaStoreObserver.dispose();

    for (final sub in _subscriptions) {
      sub.cancel();
    }

    _subscriptions.clear();
    positionNotifier.dispose();
    totalDurationNotifier.dispose();

    // Clean up delegated providers
    _settings.removeListener(notifyListeners);
    _queue.removeListener(notifyListeners);
    _lyrics.removeListener(notifyListeners);

    if (_ownsSettings) _settings.dispose();

    _queue.dispose();
    _lyrics.dispose();

    super.dispose();
  }
}
