import 'package:flutter/foundation.dart';
import '../models/music_models.dart';
import 'settings_provider.dart';
import 'state/queue_state.dart';

class QueueProvider extends ChangeNotifier {
  final SettingsProvider _settings;

  final List<Track> _pendingQueue = [];
  final List<String> _pendingQueueItemIds = [];

  QueueProvider(this._settings);

  List<Track> get pendingQueue => List<Track>.unmodifiable(_pendingQueue);

  int get pendingCount => _pendingQueue.length;

  bool get hasPendingQueue => _pendingQueue.isNotEmpty;

  List<QueueItemView> get pendingQueueItems {
    return List<QueueItemView>.unmodifiable(
      List<QueueItemView>.generate(
        _pendingQueue.length,
        (index) => QueueItemView(
          id: _pendingQueueItemIds[index],
          track: _pendingQueue[index],
          origin: QueueItemOrigin.pending,
          sourceIndex: index,
          compositeIndex: index,
        ),
        growable: false,
      ),
    );
  }

  List<Track> snapshotPendingQueue() => List<Track>.from(_pendingQueue);

  List<QueueItemView> snapshotPendingQueueItems() {
    return List<QueueItemView>.from(pendingQueueItems);
  }

  void enqueueTrack(Track track) {
    final queueItemId = QueueItemToken.create('pending');

    switch (_settings.queueMode) {
      case 'Play next':
        _pendingQueue.insert(0, track);
        _pendingQueueItemIds.insert(0, queueItemId);
      case 'Shuffle in':
        if (_pendingQueue.isEmpty) {
          _pendingQueue.add(track);
          _pendingQueueItemIds.add(queueItemId);
        } else {
          final rand = DateTime.now().microsecondsSinceEpoch %
              (_pendingQueue.length + 1);
          _pendingQueue.insert(rand, track);
          _pendingQueueItemIds.insert(rand, queueItemId);
        }
      default:
        _pendingQueue.add(track);
        _pendingQueueItemIds.add(queueItemId);
    }

    notifyListeners();
  }

  void removeFromPendingQueue(int index) {
    if (index < 0 || index >= _pendingQueue.length) return;

    _pendingQueue.removeAt(index);
    _pendingQueueItemIds.removeAt(index);

    notifyListeners();
  }

  bool removePendingItemById(String queueItemId) {
    final index = _pendingQueueItemIds.indexOf(queueItemId);
    if (index == -1) return false;

    _pendingQueue.removeAt(index);
    _pendingQueueItemIds.removeAt(index);

    notifyListeners();
    return true;
  }

  void insertPendingQueue(
    int index,
    Track track, {
    String? queueItemId,
  }) {
    final targetIndex = index < 0
        ? 0
        : index > _pendingQueue.length
            ? _pendingQueue.length
            : index;

    _pendingQueue.insert(targetIndex, track);
    _pendingQueueItemIds.insert(
      targetIndex,
      queueItemId ?? QueueItemToken.create('pending'),
    );

    notifyListeners();
  }

  bool removePendingSnapshotItem(Track track, int occurrence) {
    if (occurrence < 0) return false;

    var seen = 0;

    for (var i = 0; i < _pendingQueue.length; i++) {
      if (!identical(_pendingQueue[i], track)) continue;

      if (seen == occurrence) {
        _pendingQueue.removeAt(i);
        _pendingQueueItemIds.removeAt(i);
        notifyListeners();
        return true;
      }

      seen++;
    }

    return false;
  }

  void removeMirroredPendingTracks(Iterable<Track> tracks) {
    var changed = false;

    for (final track in tracks) {
      final index = _pendingQueue.indexWhere((item) => identical(item, track));
      if (index == -1) continue;

      _pendingQueue.removeAt(index);
      _pendingQueueItemIds.removeAt(index);
      changed = true;
    }

    if (changed) notifyListeners();
  }

  int removeMirroredPendingItems(Iterable<QueueItemView> items) {
    final itemIds = items
        .map((item) => item.id)
        .where((id) => id.isNotEmpty)
        .toSet();

    if (itemIds.isEmpty || _pendingQueue.isEmpty) {
      return 0;
    }

    var removedCount = 0;
    
    for (var index = _pendingQueueItemIds.length - 1; index >= 0; index--) {
      if (!itemIds.contains(_pendingQueueItemIds[index])) {
        continue;
      }

      _pendingQueue.removeAt(index);
      _pendingQueueItemIds.removeAt(index);
      removedCount++;
    }

    if (removedCount > 0) {
      notifyListeners();
    }

    return removedCount;
  }

  void removeTrackRefs(Iterable<Track> tracks) {
    final refs = tracks.toList(growable: false);

    final ids = refs
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet();

    final stableKeys = refs
        .map((track) => track.stableKey.trim())
        .where((key) => key.isNotEmpty)
        .toSet();

    final paths = refs
        .map((track) => track.normalizedSourcePath)
        .where((path) => path.isNotEmpty)
        .toSet();

    if (ids.isEmpty && stableKeys.isEmpty && paths.isEmpty) {
      return;
    }

    var changed = false;

    for (var index = _pendingQueue.length - 1; index >= 0; index--) {
      final pendingTrack = _pendingQueue[index];

      final matchesId = ids.contains(pendingTrack.id);

      final stableKey = pendingTrack.stableKey.trim();

      final matchesStableKey =
          stableKey.isNotEmpty && stableKeys.contains(stableKey);

      final path = pendingTrack.normalizedSourcePath;

      final matchesPath = path.isNotEmpty && paths.contains(path);

      if (!matchesId && !matchesStableKey && !matchesPath) {
        continue;
      }

      _pendingQueue.removeAt(index);
      _pendingQueueItemIds.removeAt(index);
      changed = true;
    }

    if (changed) {
      notifyListeners();
    }
  }

  void reorderPendingQueue(int oldIndex, int newIndex) {
    if (oldIndex < 0 || oldIndex >= _pendingQueue.length) return;

    final clampedNew = newIndex.clamp(0, _pendingQueue.length - 1);
    if (oldIndex == clampedNew) return;

    final track = _pendingQueue.removeAt(oldIndex);
    final queueItemId = _pendingQueueItemIds.removeAt(oldIndex);

    _pendingQueue.insert(clampedNew, track);
    _pendingQueueItemIds.insert(clampedNew, queueItemId);

    notifyListeners();
  }

  void clearPendingQueue() {
    if (_pendingQueue.isEmpty) return;

    _pendingQueue.clear();
    _pendingQueueItemIds.clear();

    notifyListeners();
  }

}
