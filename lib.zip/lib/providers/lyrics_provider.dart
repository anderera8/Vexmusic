import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/music_models.dart';
import '../services/lyrics_cache_service.dart';
import '../services/lyrics_service.dart';
import '../services/prefs_service.dart';

enum LyricsSource { none, local, online, manual }

typedef LyricsFetcher = Future<({LyricsData lyrics, bool isOnline})?> Function({
  required String? filePath,
  required String artist,
  required String title,
  required int durationSeconds,
});

typedef LyricsCandidateSearcher = Future<List<LyricsCandidate>> Function(
  String artist,
  String title, {
  int durationSeconds,
  int maxResults,
});

class LyricsProvider extends ChangeNotifier {
  LyricsProvider({
    LyricsFetcher? fetcher,
    LyricsCandidateSearcher? candidateSearcher,
    LyricsCacheService? cacheService,
  })  : _fetcher = fetcher ?? LyricsService.fetchLyrics,
        _candidateSearcher =
            candidateSearcher ?? LyricsService.searchCandidates,
        _cacheService = cacheService ?? LyricsCacheService();

  static const String _onlineLookupPreferenceKey =
      'onlineLyricsLookupEnabled';

  final LyricsFetcher _fetcher;
  final LyricsCandidateSearcher _candidateSearcher;
  final LyricsCacheService _cacheService;
  final Map<String, _LyricsMemoryEntry> _trackCache = {};
  bool _onlineLookupEnabled = true;
  bool _onlinePreferenceLoaded = false;

  LyricsData? _currentLyrics;
  bool _isLoading = false;
  String? _error;
  LyricsSource _source = LyricsSource.none;
  List<LyricsCandidate>? _candidates;
  bool _isSearchingCandidates = false;
  Track? _lastTrack;
  int _requestGeneration = 0;

  bool get hasLyrics => _currentLyrics != null;
  LyricsData? get currentLyrics => _currentLyrics;
  bool get isLoading => _isLoading;
  String? get error => _error;
  LyricsSource get source => _source;
  List<LyricsCandidate>? get candidates => _candidates;
  bool get isSearchingCandidates => _isSearchingCandidates;
  bool get onlineLookupEnabled {
    _loadOnlinePreference();
    return _onlineLookupEnabled;
  }

  void _loadOnlinePreference() {
    if (_onlinePreferenceLoaded) return;
    _onlinePreferenceLoaded = true;
    try {
      _onlineLookupEnabled =
          PrefsService.getBool(_onlineLookupPreferenceKey) ?? true;
    } catch (_) {
      _onlineLookupEnabled = true;
    }
  }

  Future<void> setOnlineLookupEnabled(bool enabled) async {
    _onlinePreferenceLoaded = true;
    if (_onlineLookupEnabled == enabled) return;
    _onlineLookupEnabled = enabled;
    await PrefsService.setBool(_onlineLookupPreferenceKey, enabled);
    notifyListeners();
  }

  ({LyricsData lyrics, LyricsSource source})? _cachedLyricsFor(Track track) {
    final cached = _trackCache[LyricsCacheService.identityFor(track)];
    if (cached == null) return null;
    if (!LyricsCacheService.sameIdentity(cached.track, track)) {
      _trackCache.remove(LyricsCacheService.identityFor(track));
      return null;
    }
    return (lyrics: cached.lyrics, source: cached.source);
  }

  Future<({LyricsData lyrics, LyricsSource source})?> _persistedLyricsFor(
    Track track,
  ) async {
    final cached = await _cacheService.load(track);
    if (cached == null) return null;

    final source = LyricsSource.values.firstWhere(
      (value) => value.name == cached.source,
      orElse: () => LyricsSource.manual,
    );
    _rememberLyrics(track, cached.lyrics, source);
    return (lyrics: cached.lyrics, source: source);
  }

  void _rememberLyrics(
    Track track,
    LyricsData lyrics,
    LyricsSource source,
  ) {
    _trackCache[LyricsCacheService.identityFor(track)] = _LyricsMemoryEntry(
      track: track,
      lyrics: lyrics,
      source: source,
    );
  }

  void _cacheLyricsFor(
    Track track,
    LyricsData lyrics,
    LyricsSource source, {
    bool persist = true,
  }) {
    _rememberLyrics(track, lyrics, source);
    if (persist) {
      unawaited(
        _cacheService
            .save(
              track,
              lyrics,
              source: source.name,
            )
            .catchError((Object error) {
          debugPrint('[LyricsProvider] Cache write failed: $error');
        }),
      );
    }
  }

  Future<void> prepareTrack(Track track) async {
    _loadOnlinePreference();
    final generation = ++_requestGeneration;
    _lastTrack = track;
    _candidates = null;
    _isSearchingCandidates = false;

    final cached = _cachedLyricsFor(track);
    if (cached != null) {
      _currentLyrics = cached.lyrics;
      _source = cached.source;
      _error = null;
      _isLoading = false;
      notifyListeners();
      return;
    }

    final persisted = await _persistedLyricsFor(track);
    if (generation != _requestGeneration) return;
    if (persisted != null) {
      _currentLyrics = persisted.lyrics;
      _source = persisted.source;
      _error = null;
      _isLoading = false;
      notifyListeners();
      return;
    }

    _currentLyrics = null;
    _source = LyricsSource.none;
    _error = null;
    _isLoading = true;
    notifyListeners();
    try {
      final result = await LyricsService.fetchLocalLyrics(
        filePath: track.filePath,
        artist: track.artist,
        title: track.title,
        durationSeconds: track.duration,
      );
      if (generation != _requestGeneration) return;
      if (result != null) {
        _currentLyrics = result.lyrics;
        _source = LyricsSource.local;
        _cacheLyricsFor(
          track,
          result.lyrics,
          LyricsSource.local,
        );
      }
    } finally {
      if (generation == _requestGeneration) {
        _isLoading = false;
        notifyListeners();
      }
    }
  }

  Future<void> loadLyrics(Track track) async {
    _loadOnlinePreference();
    final generation = ++_requestGeneration;
    _lastTrack = track;
    _candidates = null;
    _isSearchingCandidates = false;

    final cached = _cachedLyricsFor(track);
    if (cached != null) {
      _currentLyrics = cached.lyrics;
      _source = cached.source;
      _error = null;
      _isLoading = false;
      notifyListeners();
      return;
    }

    final persisted = await _persistedLyricsFor(track);
    if (generation != _requestGeneration) return;
    if (persisted != null) {
      _currentLyrics = persisted.lyrics;
      _source = persisted.source;
      _error = null;
      _isLoading = false;
      notifyListeners();
      return;
    }

    _currentLyrics = null;
    _error = null;
    _source = LyricsSource.none;
    _isLoading = true;
    notifyListeners();

    try {
      final result = _onlineLookupEnabled
          ? await _fetcher(
              filePath: track.filePath,
              artist: track.artist,
              title: track.title,
              durationSeconds: track.duration,
            )
          : await LyricsService.fetchLocalLyrics(
              filePath: track.filePath,
              artist: track.artist,
              title: track.title,
              durationSeconds: track.duration,
            );
      if (generation != _requestGeneration) return;
      _currentLyrics = result?.lyrics;
      _source = result == null
          ? LyricsSource.none
          : result.isOnline
              ? LyricsSource.online
              : LyricsSource.local;
      if (result != null) {
        _cacheLyricsFor(
          track,
          result.lyrics,
          _source,
        );
      }
      if (result == null && _onlineLookupEnabled) {
        _isLoading = false;
        _isSearchingCandidates = true;
        notifyListeners();
        await _searchCandidates(
          artist: track.artist,
          title: track.title,
          durationSeconds: track.duration,
          generation: generation,
        );
      } else if (result == null) {
        _error = 'Online lyrics lookup is disabled.';
      }
    } on LyricsFetchException catch (error) {
      if (generation != _requestGeneration) return;
      _currentLyrics = null;
      _source = LyricsSource.none;
      _error = error.message;
    } catch (error) {
      if (generation != _requestGeneration) return;
      _currentLyrics = null;
      _source = LyricsSource.none;
      _error = 'Unable to load lyrics.';
    } finally {
      if (generation == _requestGeneration) {
        _isLoading = false;
        _isSearchingCandidates = false;
        notifyListeners();
      }
    }
  }

  Future<void> searchCandidates({
    required String artist,
    required String title,
    int durationSeconds = 0,
  }) async {
    _loadOnlinePreference();
    if (!_onlineLookupEnabled) {
      _error = 'Online lyrics lookup is disabled.';
      _candidates = const <LyricsCandidate>[];
      _isSearchingCandidates = false;
      notifyListeners();
      return;
    }

    final normalizedTitle = title.trim();
    if (normalizedTitle.isEmpty) {
      _error = 'Enter a song title to search for lyrics.';
      _candidates = const [];
      _isSearchingCandidates = false;
      notifyListeners();
      return;
    }

    final generation = ++_requestGeneration;
    _currentLyrics = null;
    _source = LyricsSource.none;
    _candidates = null;
    _error = null;
    _isLoading = false;
    _isSearchingCandidates = true;
    notifyListeners();

    await _searchCandidates(
      artist: artist,
      title: normalizedTitle,
      durationSeconds: durationSeconds,
      generation: generation,
    );
  }

  Future<void> _searchCandidates({
    required String artist,
    required String title,
    required int durationSeconds,
    required int generation,
  }) async {
    try {
      final results = await _candidateSearcher(
        artist,
        title,
        durationSeconds: durationSeconds,
        maxResults: 5,
      );
      if (generation != _requestGeneration) return;
      _candidates = results;
      _error = results.isEmpty
          ? 'No lyrics matches found. Try different search terms or load a file.'
          : null;
    } on LyricsFetchException catch (error) {
      if (generation != _requestGeneration) return;
      _candidates = null;
      _error = error.message;
    } catch (_) {
      if (generation != _requestGeneration) return;
      _candidates = null;
      _error = 'Unable to search for lyrics.';
    } finally {
      if (generation == _requestGeneration) {
        _isSearchingCandidates = false;
        notifyListeners();
      }
    }
  }

  void selectCandidate(LyricsCandidate candidate) {
    _requestGeneration++;
    final lyrics = candidate.toLyricsData();
    _currentLyrics = lyrics;
    _source = LyricsSource.online;
    _candidates = null;
    _error = null;
    _isLoading = false;
    _isSearchingCandidates = false;

    final track = _lastTrack;
    if (track != null) {
      _cacheLyricsFor(
        track,
        lyrics,
        LyricsSource.online,
      );
    }
    notifyListeners();
  }

  void clearCandidates() {
    _requestGeneration++;
    _candidates = null;
    _isSearchingCandidates = false;
    notifyListeners();
  }

  Future<void> retry() async {
    final track = _lastTrack;
    if (track != null) await loadLyrics(track);
  }

  void useManualLyrics(LyricsData lyrics) {
    _requestGeneration++;
    _currentLyrics = lyrics;
    _source = LyricsSource.manual;
    _candidates = null;
    final track = _lastTrack;
    if (track != null) {
      _cacheLyricsFor(
        track,
        lyrics,
        LyricsSource.manual,
      );
    }
    _error = null;
    _isLoading = false;
    notifyListeners();
  }

  void dismissCurrent() {
    _requestGeneration++;
    _currentLyrics = null;
    _source = LyricsSource.none;
    _candidates = null;
    _isSearchingCandidates = false;
    _error = 'Lyrics closed. Retry or pick another lyrics file.';
    _isLoading = false;
    notifyListeners();
  }

  void removeTracks(Iterable<int> trackIds) {
    final ids = trackIds.where((id) => id > 0).toSet();
    if (ids.isEmpty) return;

    var changed = false;
    for (final entry in _trackCache.entries.toList()) {
      final track = entry.value.track;
      final hasPhysicalIdentity = track.stableKey.trim().isNotEmpty ||
          track.normalizedSourcePath.isNotEmpty;
      if (hasPhysicalIdentity || !ids.contains(track.id)) continue;
      _trackCache.remove(entry.key);
      changed = true;
    }

    unawaited(
      _cacheService.removeLegacyTrackIds(ids).catchError((Object error) {
        debugPrint('[LyricsProvider] Legacy cache cleanup failed: $error');
      }),
    );

    final lastTrack = _lastTrack;
    if (lastTrack != null &&
        lastTrack.stableKey.trim().isEmpty &&
        lastTrack.normalizedSourcePath.isEmpty &&
        ids.contains(lastTrack.id)) {
      _clearCurrentTrackState();
      changed = true;
    }

    if (changed) notifyListeners();
  }

  void removeTrackRefs(Iterable<Track> tracks) {
    final refs = tracks.toList(growable: false);
    if (refs.isEmpty) return;

    final identities = refs
        .map(LyricsCacheService.identityFor)
        .toSet();
    var changed = false;

    for (final identity in identities) {
      if (_trackCache.remove(identity) != null) changed = true;
    }
    unawaited(
      _cacheService.removeTracks(refs).catchError((Object error) {
        debugPrint('[LyricsProvider] Cache cleanup failed: $error');
      }),
    );

    final lastTrack = _lastTrack;
    if (lastTrack != null &&
        refs.any((track) => LyricsCacheService.sameIdentity(track, lastTrack))) {
      _clearCurrentTrackState();
      changed = true;
    }

    if (changed) notifyListeners();
  }

  void _clearCurrentTrackState() {
    _requestGeneration++;
    _lastTrack = null;
    _currentLyrics = null;
    _source = LyricsSource.none;
    _candidates = null;
    _error = null;
    _isLoading = false;
    _isSearchingCandidates = false;
  }

  void clear() {
    _currentLyrics = null;
    _source = LyricsSource.none;
    _candidates = null;
    _error = null;
    _isLoading = false;
    _isSearchingCandidates = false;
    _requestGeneration++;
    notifyListeners();
  }
}

class _LyricsMemoryEntry {
  const _LyricsMemoryEntry({
    required this.track,
    required this.lyrics,
    required this.source,
  });

  final Track track;
  final LyricsData lyrics;
  final LyricsSource source;
}

