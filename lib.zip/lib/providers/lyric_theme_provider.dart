import 'package:flutter/foundation.dart';

import '../services/lyric_theme_service.dart';

class LyricThemeProvider extends ChangeNotifier {
  LyricThemeSettings _settings = const LyricThemeSettings();
  bool _isLoading = true;

  LyricThemeSettings get settings => _settings;
  bool get isLoading => _isLoading;

  Future<void> load() async {
    _settings = await LyricThemeService.getSettings();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> update(
    LyricThemeSettings Function(LyricThemeSettings current) transform,
  ) async {
    _settings = transform(_settings);
    notifyListeners();
    await LyricThemeService.saveSettings(_settings);
  }
}
