import 'media_models.dart';
final RegExp _repeatedSlashPattern = RegExp(r'/+');

int _safeInt(dynamic value, int fallback) {
  if (value == null) return fallback;
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim()) ?? fallback;
  return fallback;
}

int? _safeNullableInt(dynamic value) {
  final parsed = _safeInt(value, -1);
  return parsed < 0 ? null : parsed;
}

int? _positiveOrNull(dynamic value) {
  final parsed = _safeNullableInt(value);
  if (parsed == null || parsed <= 0) return null;
  return parsed;
}

String _safeStr(dynamic value, String fallback) {
  final text = value?.toString().trim();
  if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
    return fallback;
  }
  return text;
}

String? _safeNullableStr(dynamic value) {
  final text = value?.toString().trim();
  if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
    return null;
  }
  return text;
}

String? _firstNonEmpty(Iterable<dynamic> values) {
  for (final value in values) {
    final text = _safeNullableStr(value);
    if (text != null) return text;
  }
  return null;
}

int _normalizeEpochMillis(dynamic value) {
  final parsed = _safeInt(value, 0);
  if (parsed <= 0) return 0;
  if (parsed < 1000000000000) return parsed * 1000;
  return parsed;
}

int _durationSecondsFromMap(Map<dynamic, dynamic> map) {
  final explicitSeconds = _safeInt(map['durationSeconds'], -1);
  if (explicitSeconds > 0) return explicitSeconds;

  final raw = _safeInt(map['durationMs'] ?? map['duration'], 0);
  if (raw <= 0) return 0;
  if (raw > 1000) return (raw / 1000).round();
  return raw;
}

String _titleFromDisplayName(dynamic displayName) {
  final text = _safeNullableStr(displayName);
  if (text == null) return 'Unknown Title';
  final dot = text.lastIndexOf('.');
  if (dot <= 0) return text;
  return text.substring(0, dot).trim().isEmpty ? text : text.substring(0, dot);
}

int _stablePositiveHash(String input) {
  var hash = 0x811c9dc5;
  for (final codeUnit in input.codeUnits) {
    hash ^= codeUnit;
    hash = (hash * 0x01000193) & 0x7fffffff;
  }
  return hash == 0 ? 1 : hash;
}

String _normalizeIdentityText(String? value) {
  final text = value?.trim();
  if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
    return '';
  }

  return text
      .replaceAll('\\', '/')
      .replaceAll(_repeatedSlashPattern, '/')
      .toLowerCase();
}

String _normalizeStableKey(String? value) {
  final text = value?.trim();

  if (text == null || text.isEmpty) {
    return '';
  }

  return text.toLowerCase();
}

const gradKeys = ['grad-a', 'grad-b', 'grad-c', 'grad-d', 'grad-e'];

class Track {
  final int id;
  final int mediaStoreId;
  final String stableKey;
  final String title;
  final String artist;
  final String? albumName;
  final int? albumId;
  final String? filePath;
  final String? playbackUri;
  final String? artPath;
  final int duration;
  final int? bitrate;
  final bool liked;
  final String art;
  final String grad;
  final String genre;
  final int dateAdded;
  final int size;

  const Track({
    required this.id,
    this.mediaStoreId = 0,
    this.stableKey = '',
    required this.title,
    required this.artist,
    this.albumName,
    this.albumId,
    this.filePath,
    this.playbackUri,
    this.artPath,
    required this.duration,
    this.bitrate,
    this.liked = false,
    this.art = '🎵',
    this.grad = 'grad-a',
    this.genre = '',
    this.dateAdded = 0,
    this.size = 0,
  })  : assert(id >= 0),
        assert(mediaStoreId >= 0);

  String get formattedDuration {
    final minutes = duration ~/ 60;
    final seconds = duration % 60;

    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  String get volumeName {
    final fromPlaybackUri = _deriveVolumeName(playbackUri);
    if (fromPlaybackUri != null && fromPlaybackUri.isNotEmpty) {
      return fromPlaybackUri;
    }

    final fromFilePath = _deriveVolumeName(filePath);
    if (fromFilePath != null && fromFilePath.isNotEmpty) {
      return fromFilePath;
    }

    return '';
  }

  String get normalizedVolumeName => _normalizeVolumeName(volumeName);

  String get volumeScopedMediaStoreKey =>
      normalizedVolumeName.isEmpty
          ? '$mediaStoreId'
          : '$normalizedVolumeName:$mediaStoreId';
  factory Track.fromMediaStoreMap(
    Map<dynamic, dynamic> media,
  ) {
    final mediaStoreId = _safeInt(
      media['mediaStoreId'] ?? media['id'],
      0,
    );

    final title = _safeStr(
      media['title'],
      _titleFromDisplayName(media['displayName']),
    );

    final artist = _safeStr(
      media['artist'],
      'Unknown Artist',
    );

    final albumName =
        _safeNullableStr(media['album']) ??
            'Unknown album';

    final genre =
        _safeNullableStr(media['genre']) ??
            'Other';

    final playbackUri =
        _safeNullableStr(media['uri']);
    final filePath = _firstNonEmpty([
      media['path'],
      media['data'],
      media['filePath'],
      media['resolvedPath'],
    ]);

    final duration =
        _durationSecondsFromMap(media);

    final size = _safeInt(
      media['size'],
      0,
    );

    final nativeStableKey = _normalizeStableKey(
      _safeNullableStr(media['stableKey']),
    );

    final resolvedStableKey =
        nativeStableKey.isNotEmpty
            ? nativeStableKey
            : _buildFallbackStableKey(
                filePath: filePath,
                title: title,
                artist: artist,
                albumName: albumName,
                duration: duration,
                size: size,
              );

    return Track(
      id: 0,
      mediaStoreId: mediaStoreId,
      stableKey: resolvedStableKey,
      title: title,
      artist: artist,
      albumName: albumName,
      albumId: _positiveOrNull(media['albumId']),
      filePath: filePath,
      playbackUri: playbackUri,
      artPath: null,
      duration: duration,
      liked: false,
      art: _getArtEmoji(genre),
      grad: _getGradientForGenre(genre),
      genre: genre,
      dateAdded: _normalizeEpochMillis(
        media['dateAdded'],
      ),
      size: size,
    );
  }

  factory Track.fromDatabaseMap(
    Map<String, Object?> row,
  ) {
    final title = _safeStr(
      row['title'],
      'Unknown Title',
    );

    final artist = _safeStr(
      row['artist'],
      'Unknown Artist',
    );

    final albumName =
        _safeNullableStr(row['album']) ??
            'Unknown album';

    final filePath =
        _safeNullableStr(row['file_path']);

    final duration = _safeInt(
      row['duration'],
      0,
    );

    final size = _safeInt(
      row['file_size'],
      0,
    );

    final storedStableKey =
        _normalizeStableKey(
      _safeNullableStr(row['stable_key']),
    );

    final resolvedStableKey =
        storedStableKey.isNotEmpty
            ? storedStableKey
            : _buildFallbackStableKey(
                filePath: filePath,
                title: title,
                artist: artist,
                albumName: albumName,
                duration: duration,
                size: size,
              );

    return Track(
      id: _safeInt(row['id'], 0),
      mediaStoreId: _safeInt(
        row['media_store_id'],
        0,
      ),
      stableKey: resolvedStableKey,
      title: title,
      artist: artist,
      albumName: albumName,
      albumId: _positiveOrNull(
        row['album_id'],
      ),
      duration: duration,
      filePath: filePath,
      playbackUri: _safeNullableStr(
        row['playback_uri'],
      ),
      artPath: _safeNullableStr(
        row['art_path'],
      ),
      liked: _safeInt(row['liked'], 0) == 1,
      grad: _safeStr(
        row['grad'],
        'grad-a',
      ),
      genre: _safeNullableStr(
            row['genre'],
          ) ??
          '',
      dateAdded: _safeInt(
        row['date_added'],
        0,
      ),
      size: size,
    );
  }

  factory Track.fromSongModel(dynamic song) {
    final map = <String, Object?>{
      'id': _safeInt(
        _readDynamic(song, 'id'),
        0,
      ),
      'mediaStoreId': _safeInt(
        _readDynamic(song, 'id'),
        0,
      ),
      'stableKey': '',
      'uri': _readDynamic(song, 'uri'),
      'title': _readDynamic(song, 'title'),
      'artist': _readDynamic(song, 'artist'),
      'album': _readDynamic(song, 'album'),
      'albumId': _readDynamic(song, 'albumId'),
      'duration': _readDynamic(song, 'duration'),
      'data': _readDynamic(song, 'data'),
      'path': _readDynamic(song, 'data'),
      'genre': _readDynamic(song, 'genre'),
      'dateAdded': _readDynamic(
        song,
        'dateAdded',
      ),
      'size': _readDynamic(song, 'size'),
    };

    return Track.fromMediaStoreMap(map);
  }

  static String? _deriveVolumeName(String? value) {
    final text = value?.trim();
    if (text == null || text.isEmpty) return null;

    final uri = Uri.tryParse(text);
    if (uri != null && uri.scheme == 'content') {
      final segments = uri.pathSegments;
      if (segments.isEmpty) return null;

      final candidate = segments.first;
      if (candidate.isEmpty) return null;

      return segments.length > 1 && candidate.toLowerCase() == 'media'
          ? segments[1]
          : candidate;
    }

    return null;
  }

  static String _normalizeVolumeName(String? value) {
    final text = value?.trim();
    if (text == null || text.isEmpty) return '';
    return text.toLowerCase();
  }

  static dynamic _readDynamic(
    dynamic object,
    String fieldName,
  ) {
    try {
      switch (fieldName) {
        case 'id':
          return object.id;
        case 'uri':
          return object.uri;
        case 'title':
          return object.title;
        case 'artist':
          return object.artist;
        case 'album':
          return object.album;
        case 'albumId':
          return object.albumId;
        case 'duration':
          return object.duration;
        case 'data':
          return object.data;
        case 'genre':
          return object.genre;
        case 'dateAdded':
          return object.dateAdded;
        case 'size':
          return object.size;
      }
    } catch (_) {
      return null;
    }

    return null;
  }

  static String _buildFallbackStableKey({
    required String? filePath,
    required String title,
    required String artist,
    required String? albumName,
    required int duration,
    required int size,
  }) {
    final normalizedPath =
        _normalizeRealFilePath(filePath);

    if (normalizedPath.isNotEmpty) {
      return 'audio:path:'
          '${_stablePositiveHash(normalizedPath).toRadixString(16)}';
    }

    final fingerprint = [
      _normalizeIdentityText(title),
      _normalizeIdentityText(artist),
      _normalizeIdentityText(albumName),
      duration,
      size,
    ].join('|');

    return 'audio:content:'
        '${_stablePositiveHash(fingerprint).toRadixString(16)}';
  }

  static String _normalizeRealFilePath(
    String? value,
  ) {
    final normalized =
        _normalizeIdentityText(value);

    if (normalized.isEmpty ||
        normalized.startsWith('content://')) {
      return '';
    }

    return normalized;
  }

  static String _getArtEmoji(String? genre) {
    if (genre == null || genre.isEmpty) {
      return '♪';
    }

    final normalized = genre.toLowerCase();

    if (normalized.contains('rock')) {
      return '🎸';
    }

    if (normalized.contains('pop')) {
      return '🎤';
    }

    if (normalized.contains('hip hop') ||
        normalized.contains('rap')) {
      return '🎙️';
    }

    if (normalized.contains('jazz')) {
      return '🎷';
    }

    if (normalized.contains('classical')) {
      return '🎻';
    }

    if (normalized.contains('electronic')) {
      return '🪩';
    }

    if (normalized.contains('rnb') ||
        normalized.contains('soul')) {
      return '🎧';
    }

    return '♪';
  }

  static String _getGradientForGenre(
    String? genre,
  ) {
    if (genre == null || genre.isEmpty) {
      return 'grad-a';
    }

    final normalized = genre.toLowerCase();

    if (normalized.contains('rock')) {
      return 'grad-c';
    }

    if (normalized.contains('pop')) {
      return 'grad-a';
    }

    if (normalized.contains('hip hop')) {
      return 'grad-b';
    }

    if (normalized.contains('jazz')) {
      return 'grad-d';
    }

    if (normalized.contains('electronic')) {
      return 'grad-e';
    }

    return 'grad-a';
  }

  String get formattedSize {
    if (size <= 0) return '';

    if (size < 1024) {
      return '$size B';
    }

    if (size < 1024 * 1024) {
      return '${(size / 1024).toStringAsFixed(1)} KB';
    }

    return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  bool get hasAppIdentity => id > 0;

  bool get hasMediaStoreIdentity =>
      mediaStoreId > 0;

  bool get hasStableIdentity =>
      stableKey.trim().isNotEmpty;

  String get normalizedSourcePath {
    return _normalizeRealFilePath(filePath);
  }

  String get contentFingerprint {
    final raw = [
      _normalizeIdentityText(title),
      _normalizeIdentityText(artist),
      _normalizeIdentityText(albumName),
      duration,
      size,
    ].join('|');

    return 'audio:content:'
        '${_stablePositiveHash(raw).toRadixString(16)}';
  }

  bool get hasUsableContentFingerprint {
    return duration > 0 &&
        size > 0 &&
        _normalizeIdentityText(title).isNotEmpty;
  }

  bool matchesStableIdentity(Track other) {
    final firstStableKey =
        stableKey.trim();

    final secondStableKey =
        other.stableKey.trim();

    if (firstStableKey.isNotEmpty &&
        secondStableKey.isNotEmpty &&
        firstStableKey == secondStableKey) {
      return true;
    }

    final firstPath = normalizedSourcePath;
    final secondPath =
        other.normalizedSourcePath;

    return firstPath.isNotEmpty &&
        secondPath.isNotEmpty &&
        firstPath == secondPath;
  }

  Track copyWith({
    int? id,
    int? mediaStoreId,
    String? stableKey,
    String? title,
    String? artist,
    String? albumName,
    int? albumId,
    String? filePath,
    String? playbackUri,
    String? artPath,
    int? duration,
    int? bitrate,
    bool? liked,
    String? art,
    String? grad,
    String? genre,
    int? dateAdded,
    int? size,
  }) {
    return Track(
      id: id ?? this.id,
      mediaStoreId:
          mediaStoreId ?? this.mediaStoreId,
      stableKey:
          stableKey ?? this.stableKey,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      albumName:
          albumName ?? this.albumName,
      albumId: albumId ?? this.albumId,
      filePath: filePath ?? this.filePath,
      playbackUri:
          playbackUri ?? this.playbackUri,
      artPath: artPath ?? this.artPath,
      duration: duration ?? this.duration,
      bitrate: bitrate ?? this.bitrate,
      liked: liked ?? this.liked,
      art: art ?? this.art,
      grad: grad ?? this.grad,
      genre: genre ?? this.genre,
      dateAdded:
          dateAdded ?? this.dateAdded,
      size: size ?? this.size,
    );
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        other is Track && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;

  MediaEntry toMediaEntry() {
    final uri = playbackUri?.trim() ?? '';
    final path = filePath?.trim() ?? '';

    return MediaEntry(
      id: id.toString(),
      kind: MediaKind.audio,
      title: title,
      artist: artist,
      album: albumName ?? '',
      duration: Duration(seconds: duration),
      size: size,
      source: MediaSourceRef(
        type: uri.isNotEmpty
            ? MediaSourceType.contentUri
            : MediaSourceType.filePath,
        value: uri.isNotEmpty ? uri : path,
      ),
      artworkPath: artPath ?? '',
      dateAdded: dateAdded,
      extras: {
        'appTrackId': id,
        'mediaStoreId': mediaStoreId,
        'stableKey': stableKey,
      },
    );
  }
}

class Album {
  final int id;
  final String name;
  final String artist;
  final int trackCount;
  final String? artPath;
  final String art;
  final String grad;

  const Album({
    required this.id,
    required this.name,
    required this.artist,
    required this.trackCount,
    this.artPath,
    this.art = '💿',
    this.grad = 'grad-a',
  });

  factory Album.fromAlbumModel(dynamic album) {
    return Album(
      id: _safeInt(_readAlbumDynamic(album, 'id'), 0),
      name: _safeStr(_readAlbumDynamic(album, 'album'), 'Unknown album'),
      artist: _safeStr(_readAlbumDynamic(album, 'artist'), 'Unknown Artist'),
      trackCount: _safeInt(_readAlbumDynamic(album, 'numOfSongs'), 0),
    );
  }

  static List<Album> buildFromTracks(List<Track> tracks) {
    final groups = <String, List<Track>>{};

    for (final track in tracks) {
      final albumName = _safeStr(track.albumName, 'Unknown album');
      final artistName = _safeStr(track.artist, 'Unknown Artist');
      final key = '${track.albumId ?? 0}|$albumName|$artistName';
      groups.putIfAbsent(key, () => <Track>[]).add(track);
    }

    final result = groups.values.map((albumTracks) {
      final first = albumTracks.first;
      final name = _safeStr(first.albumName, 'Unknown album');
      final artist = _safeStr(first.artist, 'Unknown Artist');
      final id = first.albumId ?? _stablePositiveHash('album:$name|$artist');

      return Album(
        id: id,
        name: name,
        artist: artist,
        trackCount: albumTracks.length,
        artPath: first.artPath,
      );
    }).toList();

    result.sort((a, b) {
      final nameCompare = a.name.toLowerCase().compareTo(b.name.toLowerCase());
      if (nameCompare != 0) return nameCompare;
      return a.artist.toLowerCase().compareTo(b.artist.toLowerCase());
    });

    return List<Album>.unmodifiable(result);
  }

  static dynamic _readAlbumDynamic(dynamic object, String fieldName) {
    try {
      switch (fieldName) {
        case 'id':
          return object.id;
        case 'album':
          return object.album;
        case 'artist':
          return object.artist;
        case 'numOfSongs':
          return object.numOfSongs;
      }
    } catch (_) {
      return null;
    }
    return null;
  }
}

class Artist {
  final int id;
  final String name;
  final int trackCount;
  final int albumCount;
  final String art;

  const Artist({
    required this.id,
    required this.name,
    required this.trackCount,
    this.albumCount = 0,
    this.art = '🎤',
  });

  factory Artist.fromArtistModel(dynamic artist) {
    return Artist(
      id: _safeInt(_readArtistDynamic(artist, 'id'), 0),
      name: _safeStr(_readArtistDynamic(artist, 'artist'), 'Unknown Artist'),
      trackCount: _safeInt(_readArtistDynamic(artist, 'numberOfTracks'), 0),
      albumCount: _safeInt(_readArtistDynamic(artist, 'numberOfalbums'), 0),
    );
  }

  static List<Artist> buildFromTracks(List<Track> tracks) {
    final groups = <String, List<Track>>{};

    for (final track in tracks) {
      final artistName = _safeStr(track.artist, 'Unknown Artist');
      groups.putIfAbsent(artistName, () => <Track>[]).add(track);
    }

    final result = groups.entries.map((entry) {
      final albumNames = entry.value
          .map((track) => _safeStr(track.albumName, 'Unknown album'))
          .toSet();

      return Artist(
        id: _stablePositiveHash('artist:${entry.key}'),
        name: entry.key,
        trackCount: entry.value.length,
        albumCount: albumNames.length,
      );
    }).toList();

    result.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

    return List<Artist>.unmodifiable(result);
  }

  static dynamic _readArtistDynamic(dynamic object, String fieldName) {
    try {
      switch (fieldName) {
        case 'id':
          return object.id;
        case 'artist':
          return object.artist;
        case 'numberOfTracks':
          return object.numberOfTracks;
        case 'numberOfalbums':
          return object.numberOfalbums;
      }
    } catch (_) {
      return null;
    }
    return null;
  }
}

class Playlist {
  final int id;
  final String name;
  final List<int> trackIds;
  final List<String> trackStableKeys;
  final List<String> trackEntryIds;
  final String art;

  const Playlist({
    required this.id,
    required this.name,
    required this.trackIds,
    this.trackStableKeys = const [],
    this.trackEntryIds = const [],
    this.art = '🎵',
  });

  int get trackCount {
    var count = trackIds.length;
    if (trackStableKeys.length > count) count = trackStableKeys.length;
    if (trackEntryIds.length > count) count = trackEntryIds.length;
    return count;
  }

  Playlist copyWith({
    String? name,
    List<int>? trackIds,
    List<String>? trackStableKeys,
    List<String>? trackEntryIds,
    String? art,
  }) =>
      Playlist(
        id: id,
        name: name ?? this.name,
        trackIds: trackIds ?? this.trackIds,
        trackStableKeys: trackStableKeys ?? this.trackStableKeys,
        trackEntryIds: trackEntryIds ?? this.trackEntryIds,
        art: art ?? this.art,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'track_ids': trackIds.join(','),
        'track_stable_keys': trackStableKeys.join(','),
        'track_entry_ids': trackEntryIds.join(','),
        'art': art,
      };

  factory Playlist.fromMap(Map<String, dynamic> map) {
    final trackIdsStr = map['track_ids'] as String? ?? '';
    final stableKeysStr = map['track_stable_keys'] as String? ?? '';
    final entryIdsStr = map['track_entry_ids'] as String? ?? '';

    final ids = trackIdsStr.isEmpty
        ? <int>[]
        : trackIdsStr
            .split(',')
            .where((s) => s.isNotEmpty)
            .map((s) => int.tryParse(s) ?? 0)
            .where((id) => id > 0)
            .toList();

    final stableKeys = stableKeysStr.isEmpty
        ? <String>[]
        : stableKeysStr
            .split(',')
            .map((s) => s.trim())
            .toList();

    final playlistId = map['id'] as int;
    final rawEntryIds = entryIdsStr.isEmpty
        ? <String>[]
        : entryIdsStr
            .split(',')
            .map((s) => s.trim())
            .toList();

    final length = ids.length > stableKeys.length ? ids.length : stableKeys.length;
    final entryIds = List<String>.generate(
      length,
      (index) {
        final persisted = index < rawEntryIds.length
            ? rawEntryIds[index].trim()
            : '';
        if (persisted.isNotEmpty) return persisted;

        final trackId = index < ids.length ? ids[index] : 0;
        final stableKey = index < stableKeys.length ? stableKeys[index] : '';
        return _legacyPlaylistEntryId(
          playlistId: playlistId,
          index: index,
          trackId: trackId,
          stableKey: stableKey,
        );
      },
      growable: false,
    );

    return Playlist(
      id: playlistId,
      name: map['name'] as String,
      trackIds: ids,
      trackStableKeys: stableKeys,
      trackEntryIds: entryIds,
      art: map['art'] as String? ?? '🎵',
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is Playlist && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

String _legacyPlaylistEntryId({
  required int playlistId,
  required int index,
  required int trackId,
  required String stableKey,
}) {
  final seed = '$playlistId|$index|$trackId|${stableKey.trim().toLowerCase()}';
  var hash = 0x811c9dc5;
  for (final codeUnit in seed.codeUnits) {
    hash ^= codeUnit;
    hash = (hash * 0x01000193) & 0x7fffffff;
  }
  return 'legacy-$playlistId-$index-${hash.toRadixString(36)}';
}

class PlaylistTrackEntry {
  const PlaylistTrackEntry({
    required this.entryId,
    required this.playlistIndex,
    required this.track,
  });

  final String entryId;
  final int playlistIndex;
  final Track track;
}

class PlayHistory {
  final int trackId;
  final String stableKey;
  final String title;
  final String artist;
  final DateTime playedAt;
  final int lastPositionMs;

  const PlayHistory({
    required this.trackId,
    this.stableKey = '',
    required this.title,
    required this.artist,
    required this.playedAt,
    this.lastPositionMs = 0,
  });

  Map<String, dynamic> toMap() => {
        'track_id': trackId,
        'stable_key': stableKey,
        'title': title,
        'artist': artist,
        'played_at': playedAt.toIso8601String(),
        'last_position_ms': lastPositionMs,
      };

  factory PlayHistory.fromMap(Map<String, dynamic> map) => PlayHistory(
        trackId: map['track_id'] as int,
        stableKey: _safeNullableStr(map['stable_key']) ?? '',
        title: map['title'] as String,
        artist: map['artist'] as String,
        playedAt: DateTime.parse(map['played_at'] as String),
        lastPositionMs: (map['last_position_ms'] as int?) ?? 0,
      );
}

// GENRE
class Genre {
  final String name;
  final List<int> trackIds;
  final String art;
  final String grad;

  const Genre({
    required this.name,
    required this.trackIds,
    this.art = '🎵',
    this.grad = 'grad-a',
  });

  int get trackCount => trackIds.length;

  static String artForGenre(String name) {
    final g = name.toLowerCase();
    if (g.contains('rock')) return '🎸';
    if (g.contains('pop')) return '🎤';
    if (g.contains('hip hop') || g.contains('rap')) return '🎙️';
    if (g.contains('jazz')) return '🎷';
    if (g.contains('classical')) return '🎻';
    if (g.contains('electronic') || g.contains('edm') || g.contains('dance')) {
      return '🪩';
    }
    if (g.contains('rnb') || g.contains('r&b') || g.contains('soul')) {
      return '🎧';
    }
    if (g.contains('country')) return '🪕';
    if (g.contains('metal')) return '🤘';
    if (g.contains('blues')) return '🎸';
    if (g.contains('folk')) return '🪈';
    if (g.contains('reggae')) return '🥁';
    if (g.contains('latin')) return '💃';
    if (g.contains('gospel') || g.contains('christian')) return '✝️';
    if (g.contains('punk')) return '🎸';
    if (g.contains('alternative')) return '🎸';
    if (g.contains('indie')) return '🎸';
    return '♪';
  }

  static String gradForGenre(String name) {
    final g = name.toLowerCase();
    if (g.contains('rock')) return 'grad-c';
    if (g.contains('pop')) return 'grad-a';
    if (g.contains('hip hop') || g.contains('rap')) return 'grad-b';
    if (g.contains('jazz')) return 'grad-d';
    if (g.contains('electronic') || g.contains('edm') || g.contains('dance')) {
      return 'grad-e';
    }
    if (g.contains('metal')) return 'grad-c';
    if (g.contains('classical')) return 'grad-d';
    if (g.contains('country')) return 'grad-a';
    if (g.contains('blues')) return 'grad-d';
    if (g.contains('reggae')) return 'grad-b';
    return 'grad-a';
  }
}
