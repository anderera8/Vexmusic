// lib/models/radio_models.dart
// ─────────────────────────────────────────────────────────────────────────────
// Data models for the Radio feature.
//
// RadioStation mirrors the JSON shape returned by the Radio Browser API
// (https://api.radio-browser.info) — a free, open, no-key-required directory
// of internet radio stations. Every field is parsed defensively since the
// directory is community-maintained and individual entries are sometimes
// missing fields or contain unexpected types.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:convert';

class RadioStation {
  final String uuid;
  final String name;
  final String streamUrl; // url_resolved when available, else url
  /// The other of the two URLs the directory reports for this station —
  /// i.e. `url` when [streamUrl] is `url_resolved`, or empty when there
  /// was nothing to fall back to (no `url_resolved`, or both fields were
  /// identical so there's nothing meaningfully different to retry with).
  /// [RadioProvider.playStation] tries this only after [streamUrl] fails,
  /// since a resolved URL (redirects/playlists already decoded server-side)
  /// is normally the better bet and should be tried first.
  final String fallbackUrl;
  final String favicon;
  final String homepage;
  final List<String> tags;
  final String country;
  final String countryCode;
  final String language;
  final String codec;
  final int bitrate;
  final int votes;
  final int clickCount;
  final bool lastCheckOk;

  const RadioStation({
    required this.uuid,
    required this.name,
    required this.streamUrl,
    this.fallbackUrl = '',
    required this.favicon,
    required this.homepage,
    required this.tags,
    required this.country,
    required this.countryCode,
    required this.language,
    required this.codec,
    required this.bitrate,
    required this.votes,
    required this.clickCount,
    required this.lastCheckOk,
  });

  /// Parses one station entry from the Radio Browser API. Never throws —
  /// falls back to safe defaults for anything malformed or missing so a
  /// single bad entry in a 1000-station response can't take the whole
  /// batch down.
  factory RadioStation.fromJson(Map<String, dynamic> json) {
    final resolved = _str(json['url_resolved']);
    final raw = _str(json['url']);
    final primary = resolved.isNotEmpty ? resolved : raw;
    // Only keep a fallback when it's a real, different URL — never the
    // same string as primary (nothing to gain retrying an identical URL)
    // and never empty (nothing to try at all).
    final fallback = (resolved.isNotEmpty && raw.isNotEmpty && raw != resolved)
        ? raw
        : '';

    return RadioStation(
      uuid: _str(json['stationuuid']),
      name: _cleanName(_str(json['name'])),
      streamUrl: primary,
      fallbackUrl: fallback,
      favicon: _str(json['favicon']),
      homepage: _str(json['homepage']),
      tags: _tagList(json['tags']),
      country: _str(json['country']),
      countryCode: _str(json['countrycode']).toUpperCase(),
      language: _cleanName(_str(json['language'])),
      codec: _str(json['codec']).toUpperCase(),
      bitrate: _int(json['bitrate']),
      votes: _int(json['votes']),
      clickCount: _int(json['clickcount']),
      lastCheckOk: _bool(json['lastcheckok']),
    );
  }

  /// Round-trips through JSON for local persistence (favorites / recently
  /// played caches), independent of the live API response shape.
  factory RadioStation.fromCache(Map<String, dynamic> json) => RadioStation(
        uuid: _str(json['uuid']),
        name: _str(json['name']),
        streamUrl: _str(json['streamUrl']),
        // Defaults to '' via the constructor for caches written before this
        // field existed — same "nothing to fall back to" behavior as a
        // station that never had one.
        fallbackUrl: _str(json['fallbackUrl']),
        favicon: _str(json['favicon']),
        homepage: _str(json['homepage']),
        tags: (json['tags'] as List?)?.map((e) => e.toString()).toList() ??
            const [],
        country: _str(json['country']),
        countryCode: _str(json['countryCode']),
        language: _str(json['language']),
        codec: _str(json['codec']),
        bitrate: _int(json['bitrate']),
        votes: _int(json['votes']),
        clickCount: _int(json['clickCount']),
        lastCheckOk: json['lastCheckOk'] != false,
      );

  Map<String, dynamic> toCache() => {
        'uuid': uuid,
        'name': name,
        'streamUrl': streamUrl,
        'fallbackUrl': fallbackUrl,
        'favicon': favicon,
        'homepage': homepage,
        'tags': tags,
        'country': country,
        'countryCode': countryCode,
        'language': language,
        'codec': codec,
        'bitrate': bitrate,
        'votes': votes,
        'clickCount': clickCount,
        'lastCheckOk': lastCheckOk,
      };

  static String encodeList(List<RadioStation> stations) =>
      jsonEncode(stations.map((s) => s.toCache()).toList());

  static List<RadioStation> decodeList(String? raw) {
    if (raw == null || raw.isEmpty) return const [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      return decoded
          .whereType<Map>()
          .map((e) => RadioStation.fromCache(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  /// First tag, title-cased, for compact subtitle display. Empty when the
  /// station has no tags at all.
  String get primaryTag => tags.isEmpty ? '' : _titleCase(tags.first);

  /// A short "Genre · Country" style subtitle, skipping empty parts.
  String get subtitle {
    final parts = <String>[
      if (primaryTag.isNotEmpty) primaryTag,
      if (country.isNotEmpty) country,
    ];
    return parts.join(' · ');
  }

  /// Compact listener/popularity label, e.g. "12.4K" or "830". Based on
  /// click count (recent plays tracked by the directory), which is a much
  /// better "trending" signal than raw vote count.
  String get popularityLabel {
    if (clickCount >= 1000000) {
      return '${(clickCount / 1000000).toStringAsFixed(1)}M';
    }
    if (clickCount >= 1000) {
      return '${(clickCount / 1000).toStringAsFixed(1)}K';
    }
    return '$clickCount';
  }

  /// Two-letter country code turned into a flag emoji via regional
  /// indicator symbols — no image asset or package needed.
  String get flagEmoji {
    if (countryCode.length != 2) return '📻';
    final code = countryCode.toUpperCase();
    final first = code.codeUnitAt(0);
    final second = code.codeUnitAt(1);
    if (first < 65 || first > 90 || second < 65 || second > 90) return '📻';
    const base = 0x1F1E6;
    return String.fromCharCodes([
      base + (first - 65),
      base + (second - 65),
    ]);
  }

  bool get hasStream => streamUrl.trim().isNotEmpty;

  @override
  bool operator ==(Object other) =>
      other is RadioStation && other.uuid == uuid && uuid.isNotEmpty;

  @override
  int get hashCode => uuid.hashCode;

  static String _str(dynamic v) => v == null ? '' : v.toString().trim();

  static int _int(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  static bool _bool(dynamic v) {
    if (v is bool) return v;
    if (v is num) return v != 0;
    if (v is String) return v == '1' || v.toLowerCase() == 'true';
    return false;
  }

  static List<String> _tagList(dynamic v) {
    final raw = _str(v);
    if (raw.isEmpty) return const [];
    final seen = <String>{};
    final out = <String>[];
    for (final part in raw.split(',')) {
      final t = part.trim().toLowerCase();
      // The directory occasionally has junk "tags" that are really whole
      // sentences from a bad import — skip anything implausibly long.
      if (t.isEmpty || t.length > 24) continue;
      if (seen.add(t)) out.add(t);
    }
    return out;
  }

  static String _cleanName(String s) => s.replaceAll(RegExp(r'\s+'), ' ').trim();

  static String _titleCase(String s) {
    if (s.isEmpty) return s;
    return s
        .split(' ')
        .map((w) => w.isEmpty ? w : '${w[0].toUpperCase()}${w.substring(1)}')
        .join(' ');
  }
}

/// A curated, browsable genre — maps to a `tag` query against the API.
/// The directory's raw tag list is extremely noisy (tens of thousands of
/// free-text entries), so the Discover grid instead offers this fixed,
/// reliable set that's known to return good results.
class RadioGenreDef {
  final String label;
  final String tag;
  final String emoji;

  const RadioGenreDef(this.label, this.tag, this.emoji);
}

const List<RadioGenreDef> kRadioGenres = [
  RadioGenreDef('Pop', 'pop', '🎤'),
  RadioGenreDef('Hip-Hop', 'hip hop', '🎧'),
  RadioGenreDef('Rock', 'rock', '🎸'),
  RadioGenreDef('Dance', 'dance', '💃'),
  RadioGenreDef('Electronic', 'electronic', '🎛️'),
  RadioGenreDef('Chill / Lofi', 'chillout', '🌙'),
  RadioGenreDef('Jazz', 'jazz', '🎷'),
  RadioGenreDef('Classical', 'classical', '🎻'),
  RadioGenreDef('Country', 'country', '🤠'),
  RadioGenreDef('Latin', 'latin', '💃'),
  RadioGenreDef('Reggae', 'reggae', '🌴'),
  RadioGenreDef('Metal', 'metal', '🤘'),
  RadioGenreDef('R&B / Soul', 'rnb', '💜'),
  RadioGenreDef('K-Pop', 'kpop', '⭐'),
  RadioGenreDef('News / Talk', 'news', '🎙️'),
  RadioGenreDef('Sports', 'sports', '🏆'),
  RadioGenreDef('Oldies', 'oldies', '📻'),
  RadioGenreDef('80s', '80s', '✨'),
  RadioGenreDef('90s', '90s', '💿'),
  RadioGenreDef('Indie', 'indie', '🌈'),
];

/// A country as reported live by the directory's `/json/countries`
/// aggregate — name, ISO code, and how many stations it currently has.
/// Nothing here is a fixed list: [RadioApiService.allCountries] returns
/// every country the directory currently has stations for, so a country
/// only appears (or disappears) because of what's actually live right now.
class RadioCountryDef {
  final String name;
  final String code; // ISO 3166-1 alpha-2
  final int stationCount;

  const RadioCountryDef(this.name, this.code, {this.stationCount = 0});

  /// Parses one entry of `/json/countries`, which reports both the display
  /// name and the ISO code in the same `name`/`iso_3166_1` shape used by
  /// the countrycodes aggregate — falls back to countrycodes' plain `name`
  /// (the 2-letter code itself) when the alpha-2 field isn't present, so
  /// this also works against `/json/countrycodes` if that's ever needed.
  factory RadioCountryDef.fromJson(Map<String, dynamic> json) {
    final iso = (json['iso_3166_1'] ?? json['name'] ?? '').toString().trim();
    final name = (json['name'] ?? iso).toString().trim();
    return RadioCountryDef(
      name,
      iso.toUpperCase(),
      stationCount: int.tryParse((json['stationcount'] ?? '0').toString()) ?? 0,
    );
  }

  String get flagEmoji {
    final c = code.toUpperCase();
    if (c.length != 2) return '🌍';
    final first = c.codeUnitAt(0);
    final second = c.codeUnitAt(1);
    if (first < 65 || first > 90 || second < 65 || second > 90) return '🌍';
    const base = 0x1F1E6;
    return String.fromCharCodes([
      base + (first - 65),
      base + (second - 65),
    ]);
  }

  @override
  bool operator ==(Object other) =>
      other is RadioCountryDef && other.code == code && code.isNotEmpty;

  @override
  int get hashCode => code.hashCode;
}
