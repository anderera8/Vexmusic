enum MediaKind { audio }
enum MediaSourceType { filePath, contentUri, documentUri }
enum MediaAccessMode { full, limited, denied }
enum MediaSyncReason { startup, manual, observer, resume, operation }
enum PlaybackProcessingState {
  idle,
  loading,
  buffering,
  ready,
  completed,
  error,
}

enum PlaybackRepeatMode { off, all, one }
enum PlaybackErrorType {
  invalidSource,
  sourceUnavailable,
  accessDenied,
  unsupportedFormat,
  decoder,
  interrupted,
  cancelled,
  timeout,
  invalidOperation,
  engine,
}

class MediaSyncResult {
  final int added;
  final int updated;
  final int removed;
  final int unchanged;
  final List<String> successfulVolumes;
  final List<String> failedVolumes;

  const MediaSyncResult({
    this.added = 0,
    this.updated = 0,
    this.removed = 0,
    this.unchanged = 0,
    this.successfulVolumes = const [],
    this.failedVolumes = const [],
  });

  int get totalChanged => added + updated + removed;

  factory MediaSyncResult.empty() => const MediaSyncResult();

  @override
  String toString() =>
      'MediaSyncResult(+$added ~$updated -$removed =$unchanged, '
      'ok: ${successfulVolumes.length}, fail: ${failedVolumes.length})';
}

class MediaSourceRef {
  final MediaSourceType type;
  final String value;
  final String mimeType;

  const MediaSourceRef({
    required this.type,
    required this.value,
    this.mimeType = '',
  });

  bool get isEmpty => value.isEmpty;
}

class MediaEntry {
  final String id;
  final MediaKind kind;
  final String title;
  final String artist;
  final String album;
  final Duration duration;
  final int size;
  final MediaSourceRef source;
  final String artworkPath;
  final String volumeName;
  final String relativePath;
  final String folder;
  final int dateAdded;
  final bool isAvailable;
  final String lastSeenScan;
  final Map<String, Object?> extras;

  const MediaEntry({
    required this.id,
    required this.kind,
    required this.title,
    required this.source,
    this.artist = '',
    this.album = '',
    this.duration = Duration.zero,
    this.size = 0,
    this.artworkPath = '',
    this.volumeName = '',
    this.relativePath = '',
    this.folder = '',
    this.dateAdded = 0,
    this.isAvailable = true,
    this.lastSeenScan = '',
    this.extras = const {},
  });

  static String buildId({
    required MediaKind kind,
    required String volumeName,
    required int mediaStoreId,
    String filePath = '',
  }) {
    if (mediaStoreId > 0) {
      return '$volumeName:${kind.name}:$mediaStoreId';
    }
    return 'local:${kind.name}:${filePath.hashCode.abs()}';
  }

  MediaEntry copyWith({
    String? id,
    MediaKind? kind,
    String? title,
    String? artist,
    String? album,
    Duration? duration,
    int? size,
    MediaSourceRef? source,
    String? artworkPath,
    String? volumeName,
    String? relativePath,
    String? folder,
    int? dateAdded,
    bool? isAvailable,
    String? lastSeenScan,
    Map<String, Object?>? extras,
  }) {
    return MediaEntry(
      id: id ?? this.id,
      kind: kind ?? this.kind,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      duration: duration ?? this.duration,
      size: size ?? this.size,
      source: source ?? this.source,
      artworkPath: artworkPath ?? this.artworkPath,
      volumeName: volumeName ?? this.volumeName,
      relativePath: relativePath ?? this.relativePath,
      folder: folder ?? this.folder,
      dateAdded: dateAdded ?? this.dateAdded,
      isAvailable: isAvailable ?? this.isAvailable,
      lastSeenScan: lastSeenScan ?? this.lastSeenScan,
      extras: extras ?? this.extras,
    );
  }

  // ── Database serialization ─────────────────────────────────────────

  Map<String, dynamic> toMap() => {
        'id': id,
        'kind': kind.name,
        'title': title,
        'artist': artist,
        'album': album,
        'duration': duration.inMilliseconds,
        'size': size,
        'source_type': source.type.name,
        'source_value': source.value,
        'mime_type': source.mimeType,
        'artwork_path': artworkPath,
        'volume_name': volumeName,
        'relative_path': relativePath,
        'folder': folder,
        'date_added': dateAdded,
        'is_available': isAvailable ? 1 : 0,
        'last_seen_scan': lastSeenScan,
      };

  factory MediaEntry.fromMap(Map<String, dynamic> map) {
    final sourceType = MediaSourceType.values.firstWhere(
      (t) => t.name == map['source_type'],
      orElse: () => MediaSourceType.filePath,
    );
    final kind = MediaKind.values.firstWhere(
      (k) => k.name == map['kind'],
      orElse: () => MediaKind.audio,
    );
    return MediaEntry(
      id: map['id'] as String,
      kind: kind,
      title: map['title'] as String,
      artist: (map['artist'] as String?) ?? '',
      album: (map['album'] as String?) ?? '',
      duration: Duration(milliseconds: (map['duration'] as int?) ?? 0),
      size: (map['size'] as int?) ?? 0,
      source: MediaSourceRef(
        type: sourceType,
        value: (map['source_value'] as String?) ?? '',
        mimeType: (map['mime_type'] as String?) ?? '',
      ),
      artworkPath: (map['artwork_path'] as String?) ?? '',
      volumeName: (map['volume_name'] as String?) ?? '',
      relativePath: (map['relative_path'] as String?) ?? '',
      folder: (map['folder'] as String?) ?? '',
      dateAdded: (map['date_added'] as int?) ?? 0,
      isAvailable: (map['is_available'] as int?) != 0,
      lastSeenScan: (map['last_seen_scan'] as String?) ?? '',
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MediaEntry && other.id == id && other.kind == kind;

  @override
  int get hashCode => Object.hash(id, kind);
}

class PlaybackQueue {
  const PlaybackQueue({
    this.entries = const [],
    this.currentIndex = -1,
    this.shuffleEnabled = false,
    this.repeatMode = PlaybackRepeatMode.off,
    this.effectiveOrder = const [],
  });

  final List<MediaEntry> entries;
  final int currentIndex;

  final bool shuffleEnabled;
  final PlaybackRepeatMode repeatMode;
  final List<int> effectiveOrder;

  MediaEntry? get current {
    if (currentIndex < 0 || currentIndex >= entries.length) {
      return null;
    }

    return entries[currentIndex];
  }

  List<int> get normalizedEffectiveOrder {
    final isValid = effectiveOrder.length == entries.length &&
        effectiveOrder.toSet().length == entries.length &&
        effectiveOrder.every((index) => index >= 0 && index < entries.length);

    if (isValid) {
      return List<int>.unmodifiable(effectiveOrder);
    }

    return List<int>.generate(
      entries.length,
      (index) => index,
      growable: false,
    );
  }

  List<int> get upcomingCanonicalIndices {
    if (entries.isEmpty || currentIndex < 0 || currentIndex >= entries.length) {
      return const <int>[];
    }

    final order = normalizedEffectiveOrder;
    final currentPosition = order.indexOf(currentIndex);

    if (currentPosition == -1 || currentPosition + 1 >= order.length) {
      return const <int>[];
    }

    return List<int>.unmodifiable(order.sublist(currentPosition + 1));
  }

  PlaybackQueue copyWith({
    List<MediaEntry>? entries,
    int? currentIndex,
    bool? shuffleEnabled,
    PlaybackRepeatMode? repeatMode,
    List<int>? effectiveOrder,
  }) {
    return PlaybackQueue(
      entries: entries ?? this.entries,
      currentIndex: currentIndex ?? this.currentIndex,
      shuffleEnabled: shuffleEnabled ?? this.shuffleEnabled,
      repeatMode: repeatMode ?? this.repeatMode,
      effectiveOrder: effectiveOrder ?? this.effectiveOrder,
    );
  }
}

class PlaybackFailure {
  final PlaybackErrorType type;
  final String message;
  final Object? cause;
  final String operation;
  final String entryId;
  final int queueIndex;
  final int attempt;
  final int maxAttempts;

  const PlaybackFailure(
    this.type,
    this.message, {
    this.cause,
    this.operation = '',
    this.entryId = '',
    this.queueIndex = -1,
    this.attempt = 0,
    this.maxAttempts = 0,
  });

  bool get canSkipTrack =>
      type == PlaybackErrorType.invalidSource ||
      type == PlaybackErrorType.sourceUnavailable ||
      type == PlaybackErrorType.unsupportedFormat ||
      type == PlaybackErrorType.decoder;

  bool get requiresUserAction =>
      type == PlaybackErrorType.accessDenied ||
      type == PlaybackErrorType.interrupted;

  PlaybackFailure copyWith({
    PlaybackErrorType? type,
    String? message,
    Object? cause,
    String? operation,
    String? entryId,
    int? queueIndex,
    int? attempt,
    int? maxAttempts,
  }) {
    return PlaybackFailure(
      type ?? this.type,
      message ?? this.message,
      cause: cause ?? this.cause,
      operation: operation ?? this.operation,
      entryId: entryId ?? this.entryId,
      queueIndex: queueIndex ?? this.queueIndex,
      attempt: attempt ?? this.attempt,
      maxAttempts: maxAttempts ?? this.maxAttempts,
    );
  }
}

class PlaybackCommandResult {
  const PlaybackCommandResult._({
    required this.succeeded,
    required this.changed,
    this.failure,
  });

  const PlaybackCommandResult.success({
    bool changed = true,
  }) : this._(
          succeeded: true,
          changed: changed,
        );

  const PlaybackCommandResult.noChange()
      : this._(
          succeeded: true,
          changed: false,
        );

  const PlaybackCommandResult.failure(
    PlaybackFailure failure,
  ) : this._(
          succeeded: false,
          changed: false,
          failure: failure,
        );

  final bool succeeded;
  final bool changed;
  final PlaybackFailure? failure;
  bool get failed => !succeeded;
}

class PlaybackCommandException implements Exception {
  const PlaybackCommandException(this.failure);

  final PlaybackFailure failure;

  @override
  String toString() {
    return 'PlaybackCommandException('
        '${failure.type.name}: ${failure.message})';
  }
}

class PlaybackSnapshot {
  final PlaybackProcessingState processingState;
  final bool playing;
  final Duration position;
  final Duration duration;
  final Duration bufferedPosition;
  final double volume;
  final double speed;
  final PlaybackFailure? failure;
  final bool isRecovering;
  final int consecutiveFailures;
  final String failedEntryId;

  const PlaybackSnapshot({
    this.processingState = PlaybackProcessingState.idle,
    this.playing = false,
    this.position = Duration.zero,
    this.duration = Duration.zero,
    this.bufferedPosition = Duration.zero,
    this.volume = 1,
    this.speed = 1,
    this.failure,
    this.isRecovering = false,
    this.consecutiveFailures = 0,
    this.failedEntryId = '',
  });

  PlaybackSnapshot copyWith({
    PlaybackProcessingState? processingState,
    bool? playing,
    Duration? position,
    Duration? duration,
    Duration? bufferedPosition,
    double? volume,
    double? speed,
    PlaybackFailure? failure,
    bool? isRecovering,
    int? consecutiveFailures,
    String? failedEntryId,
    bool clearFailure = false,
    bool clearRecovery = false,
  }) {
    return PlaybackSnapshot(
      processingState: processingState ?? this.processingState,
      playing: playing ?? this.playing,
      position: position ?? this.position,
      duration: duration ?? this.duration,
      bufferedPosition: bufferedPosition ?? this.bufferedPosition,
      volume: volume ?? this.volume,
      speed: speed ?? this.speed,
      failure: clearFailure ? null : failure ?? this.failure,
      isRecovering:
          clearRecovery ? false : isRecovering ?? this.isRecovering,
      consecutiveFailures:
          clearRecovery ? 0 : consecutiveFailures ?? this.consecutiveFailures,
      failedEntryId:
          clearRecovery ? '' : failedEntryId ?? this.failedEntryId,
    );
  }
}
