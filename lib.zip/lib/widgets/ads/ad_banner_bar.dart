import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';

import '../../providers/theme_provider.dart';
import '../../services/ads/unity_ads_service.dart';

/// A slim, fixed-height Unity banner ad.
///
/// The banner waits for Unity Ads initialization before creating the native ad
/// view. If initialization fails, it retries instead of permanently collapsing
/// the banner after one transient failure.
class AdBannerBar extends StatefulWidget {
  const AdBannerBar({super.key, this.inline = false});

  final bool inline;

  static const double height = 50;

  /// Master on/off switch for every banner slot in the app (radio, audio,
  /// library, settings — everywhere this widget is used), independent of
  /// platform or Unity init state. Set to `false` for now because of a
  /// problem with the ads provider. Flip back to `true` to bring banners
  /// back — no call site anywhere else needs to change.
  static const bool adsEnabled = false;

  @override
  State<AdBannerBar> createState() => _AdBannerBarState();
}

class _AdBannerBarState extends State<AdBannerBar> {
  bool _ready = false;
  Timer? _retryTimer;

  @override
  void initState() {
    super.initState();
    if (AdBannerBar.adsEnabled && Platform.isAndroid) {
      _ensureUnityReady();
    }
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    super.dispose();
  }

  Future<void> _ensureUnityReady() async {
    if (!Platform.isAndroid) return;

    await UnityAdsService.instance.init();
    if (!mounted) return;

    if (UnityAdsService.instance.isInitialized) {
      setState(() => _ready = true);
      return;
    }

    // Unity init can fail transiently (network/service startup). Do not hide
    // the banner forever; retry until the SDK is ready or the widget leaves
    // the tree.
    _retryTimer?.cancel();
    _retryTimer = Timer(const Duration(seconds: 2), _ensureUnityReady);
  }

  void _handleBannerFailure(String error, String message) {
    debugPrint('[AdBannerBar] failed to load: $error $message');
    if (!mounted) return;

    // Recreate the native banner after a short delay instead of permanently
    // setting a failed state. This also handles temporary Unity fill errors.
    setState(() => _ready = false);
    _retryTimer?.cancel();
    _retryTimer = Timer(const Duration(seconds: 2), _ensureUnityReady);
  }

  @override
  Widget build(BuildContext context) {
    if (!AdBannerBar.adsEnabled || !Platform.isAndroid || !_ready) {
      return const SizedBox.shrink();
    }

    final theme = context.watch<ThemeProvider>();
    final banner = UnityBannerAd(
      key: UniqueKey(),
      placementId: UnityAdsService.bannerPlacementId,
      onFailed: (placementId, error, message) {
        _handleBannerFailure('$error', message);
      },
    );

    if (widget.inline) {
      return Container(
        width: double.infinity,
        height: AdBannerBar.height,
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: theme.border),
        ),
        clipBehavior: Clip.antiAlias,
        child: banner,
      );
    }

    return Container(
      width: double.infinity,
      height: AdBannerBar.height,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: theme.surface,
        border: Border(top: BorderSide(color: theme.border)),
      ),
      child: banner,
    );
  }
}
