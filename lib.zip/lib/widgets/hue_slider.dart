import 'package:flutter/material.dart';

class HueSlider extends StatefulWidget {
  final double hue;
  final ValueChanged<double> onChanged;
  final double trackHeight;
  final double thumbDiameter;

  const HueSlider({
    super.key,
    required this.hue,
    required this.onChanged,
    this.trackHeight = 28,
    this.thumbDiameter = 30,
  });

  @override
  State<HueSlider> createState() => _HueSliderState();
}

class _HueSliderState extends State<HueSlider> {
  final GlobalKey _trackKey = GlobalKey();

  void _handleUpdate(Offset globalPosition) {
    final box = _trackKey.currentContext?.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;

    final local = box.globalToLocal(globalPosition);
    final fraction = (local.dx / box.size.width).clamp(0.0, 1.0);
    final hue = (fraction * 360).clamp(0.0, 359.999);
    widget.onChanged(hue);
  }

  @override
  Widget build(BuildContext context) {
    final thumbColor = HSVColor.fromAHSV(1, widget.hue, 1, 1).toColor();

    return SizedBox(
      height: widget.thumbDiameter,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final usableWidth =
              (constraints.maxWidth - widget.thumbDiameter).clamp(0.0, double.infinity);
          final thumbLeft = (widget.hue / 360).clamp(0.0, 1.0) * usableWidth;

          return Listener(
            onPointerDown: (event) => _handleUpdate(event.position),
            onPointerMove: (event) => _handleUpdate(event.position),
            behavior: HitTestBehavior.opaque,
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                // The color-wheel track itself.
                Positioned(
                  left: widget.thumbDiameter / 2,
                  right: widget.thumbDiameter / 2,
                  child: Container(
                    key: _trackKey,
                    height: widget.trackHeight,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.circular(widget.trackHeight / 2),
                      gradient: const LinearGradient(
                        colors: [
                          Color(0xFFFF0000), // 0°
                          Color(0xFFFFFF00), // 60°
                          Color(0xFF00FF00), // 120°
                          Color(0xFF00FFFF), // 180°
                          Color(0xFF0000FF), // 240°
                          Color(0xFFFF00FF), // 300°
                          Color(0xFFFF0000), // 360°
                        ],
                      ),
                    ),
                  ),
                ),
                // The thumb, positioned along the track by hue.
                Positioned(
                  left: thumbLeft,
                  child: IgnorePointer(
                    child: Container(
                      width: widget.thumbDiameter,
                      height: widget.thumbDiameter,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: thumbColor,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.35),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
