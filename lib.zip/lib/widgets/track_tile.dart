import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../models/music_models.dart';
import 'track_art_widget.dart';

class TrackTile extends StatelessWidget {
  final Track track;
  final VoidCallback onTap;
  final VoidCallback? onMenuTap;
  final bool showLike;

  const TrackTile({
    super.key,
    required this.track,
    required this.onTap,
    this.onMenuTap,
    this.showLike = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: theme.surface,
          border: Border.all(color: theme.border),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            // Art thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: TrackArtWidget(
                artPath: track.artPath,
                albumId: track.albumId,
                mediaStoreId: track.mediaStoreId,
                volumeName: track.volumeName,
                stableKey: track.stableKey,
                trackId: track.id,
                size: 48,
                borderRadius: 0,
                defaultIconColor: theme.accent,
              ),
            ),
            const SizedBox(width: 12),
            // Title + artist
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    track.title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: theme.text,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${track.artist}   ${track.formattedDuration}',
                          style: TextStyle(
                            fontSize: 12,
                            color: theme.muted,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (showLike && track.liked)
                        Padding(
                          padding: const EdgeInsets.only(left: 6),
                          child: Icon(Icons.favorite_rounded,
                              size: 13, color: theme.danger),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            // Menu or play icon
            if (onMenuTap != null)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onMenuTap,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Icon(Icons.more_vert, size: 20, color: theme.muted),
                ),
              )
            else
              Icon(Icons.play_arrow_rounded, size: 22, color: theme.muted),
          ],
        ),
      ),
    );
  }
}
