import 'dart:math' as math;
import 'package:flutter/material.dart';

class SoundWaveIndicator extends StatefulWidget {
  final Color color;
  final double size;

  const SoundWaveIndicator({
    super.key,
    required this.color,
    this.size = 20,
  });

  @override
  State<SoundWaveIndicator> createState() => _SoundWaveIndicatorState();
}

class _SoundWaveIndicatorState extends State<SoundWaveIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _SoundWavePainter(
            color: widget.color,
            animationValue: _controller.value,
          ),
        );
      },
    );
  }
}

class _SoundWavePainter extends CustomPainter {
  final Color color;
  final double animationValue;

  _SoundWavePainter({required this.color, required this.animationValue});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withValues(alpha: 0.6)
      ..style = PaintingStyle.fill
      ..strokeCap = StrokeCap.round;

    final barCount = 4;
    final barWidth = size.width / (barCount * 2 - 1);
    final gap = barWidth;

    for (int i = 0; i < barCount; i++) {
      final phase = (i / barCount);
      final t = (animationValue + phase) % 1.0;
      final heightFactor =
          0.3 + 0.7 * (0.5 - 0.5 * math.cos(t * 2 * math.pi)).abs();
      final eased = _easeInOut(heightFactor);
      final barHeight = size.height * (0.3 + eased * 0.7);

      final x = i * (barWidth + gap);
      final y = (size.height - barHeight) / 2;

      final rrect = RRect.fromRectAndRadius(
        Rect.fromLTWH(x, y, barWidth, barHeight),
        const Radius.circular(2),
      );
      canvas.drawRRect(rrect, paint);
    }
  }

  double _easeInOut(double t) {
    return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  }

  @override
  bool shouldRepaint(covariant _SoundWavePainter oldDelegate) {
    return oldDelegate.animationValue != animationValue ||
        oldDelegate.color != color;
  }
}
