import 'package:flutter/material.dart';
import '../providers/theme_provider.dart';

class InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final ThemeProvider theme;

  const InfoRow({
    super.key,
    required this.label,
    required this.value,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: theme.muted,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(fontSize: 13, color: theme.text),
            ),
          ),
        ],
      ),
    );
  }
}
