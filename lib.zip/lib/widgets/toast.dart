import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/media_models.dart';
import '../providers/theme_provider.dart';

class VibesToast {
  static OverlayEntry? _overlayEntry;
  static int _currentToken = 0;
  static void showPlaybackFailure(
    BuildContext context,
    PlaybackFailure failure, {
    Duration duration = const Duration(seconds: 4),
  }) {
    final prefix = failure.canSkipTrack
        ? 'Playback source problem'
        : 'Playback error';
    show(
      context,
      '$prefix: ${failure.message}',
      duration: duration,
    );
  }

  static void show(
    BuildContext context,
    String message, {
    Duration duration = const Duration(seconds: 2),
  }) {

    _overlayEntry?.remove();
    _overlayEntry = null;

    final token = ++_currentToken;
    final theme = context.read<ThemeProvider>();

    _overlayEntry = OverlayEntry(
      builder: (ctx) {
        final screenHeight = MediaQuery.of(ctx).size.height;
        final bottomOffset = screenHeight * 0.15;
        return Positioned(
          bottom: bottomOffset,
          left: 20,
          right: 20,
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
              decoration: BoxDecoration(
                color: theme.surface2,
                border: Border.all(color: theme.accent.withValues(alpha: 0.25)),
                borderRadius: BorderRadius.circular(50),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.18),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: theme.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        );
      },
    );

    Overlay.of(context).insert(_overlayEntry!);

    Future.delayed(duration, () {
      if (_currentToken == token) {
        _overlayEntry?.remove();
        _overlayEntry = null;
      }
    });
  }
}
