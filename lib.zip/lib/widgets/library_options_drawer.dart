import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/theme_provider.dart';

class LibraryOption {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const LibraryOption({
    required this.label,
    required this.icon,
    required this.onTap,
    this.selected = false,
  });
}

class LibraryOptionSection {
  final String title;
  final List<LibraryOption> options;

  const LibraryOptionSection({required this.title, required this.options});
}

class LibraryOptionsButton extends StatelessWidget {
  final String title;
  final List<LibraryOptionSection> sections;

  const LibraryOptionsButton({
    super.key,
    required this.title,
    required this.sections,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return IconButton(
      tooltip: 'Sort and display',
      icon: Icon(Icons.more_vert_rounded, color: theme.muted),
      onPressed: () => _open(context),
    );
  }

  void _open(BuildContext context) {
    final theme = context.read<ThemeProvider>();
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Close options',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (dialogContext, _, __) => Align(
        alignment: Alignment.centerLeft,
        child: Material(
          color: theme.surface,
          child: SafeArea(
            child: SizedBox(
              width: MediaQuery.sizeOf(context).width * 0.78,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 8, 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: TextStyle(
                              color: theme.text,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(dialogContext),
                          icon: Icon(Icons.close_rounded, color: theme.muted),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.only(bottom: 24),
                      children: [
                        for (final section in sections) ...[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
                            child: Text(
                              section.title.toUpperCase(),
                              style: TextStyle(
                                color: theme.muted,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.1,
                              ),
                            ),
                          ),
                          for (final option in section.options)
                            ListTile(
                              leading: Icon(
                                option.icon,
                                color: option.selected
                                    ? theme.accent
                                    : theme.muted,
                              ),
                              title: Text(
                                option.label,
                                style: TextStyle(
                                  color: option.selected
                                      ? theme.accent
                                      : theme.text,
                                  fontWeight: option.selected
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                ),
                              ),
                              trailing: option.selected
                                  ? Icon(Icons.check_rounded,
                                      color: theme.accent, size: 20)
                                  : null,
                              onTap: () {
                                Navigator.pop(dialogContext);
                                option.onTap();
                              },
                            ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      transitionBuilder: (_, animation, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(-1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: animation, curve: Curves.easeOut)),
        child: child,
      ),
    );
  }
}
