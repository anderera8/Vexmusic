import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../services/platform/audio_spectrum_service.dart';

enum SpectrumVisualizerMode {
  bars,
  wave,
  mirror;

  static SpectrumVisualizerMode fromName(String? value) {
    return switch (value) {
      'wave' => SpectrumVisualizerMode.wave,
      'mirror' => SpectrumVisualizerMode.mirror,
      _ => SpectrumVisualizerMode.bars,
    };
  }
}

class SpectrumVisualizer extends StatefulWidget {
  final double? height;
  final double gapFraction;
  final double barRadius;
  final Gradient? barGradient;
  final Duration animationDuration;
  final SpectrumVisualizerMode mode;
  final Color? color;
  final bool showLabels;

  const SpectrumVisualizer({
    super.key,
    this.height,
    this.gapFraction = 0.35,
    this.barRadius = 3,
    this.barGradient,
    this.animationDuration = const Duration(milliseconds: 120),
    this.mode = SpectrumVisualizerMode.bars,
    this.color,
    this.showLabels = true,
  });

  @override
  State<SpectrumVisualizer> createState() => _SpectrumVisualizerState();
}

class _SpectrumVisualizerState extends State<SpectrumVisualizer>
    with SingleTickerProviderStateMixin {
  static const _bandCount = 10;
  static const _bandLabels = [
    '31',
    '62',
    '125',
    '250',
    '500',
    '1K',
    '2K',
    '4K',
    '8K',
    '16K',
  ];

  late final AnimationController _animation;
  final List<double> _start = List<double>.filled(_bandCount, 0.02);
  final List<double> _targets = List<double>.filled(_bandCount, 0.02);
  final List<double> _current = List<double>.filled(_bandCount, 0.02);
  StreamSubscription<List<double>>? _subscription;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(
      vsync: this,
      duration: widget.animationDuration,
    )..addListener(_tick);

    if (AudioSpectrumService.isSupported) {
      _subscription =
          AudioSpectrumService.instance.magnitudeStream.listen(_onData);
    }
  }

  @override
  void didUpdateWidget(covariant SpectrumVisualizer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animationDuration != widget.animationDuration) {
      _animation.duration = widget.animationDuration;
    }
  }

  void _onData(List<double> magnitudes) {
    for (var index = 0; index < _bandCount; index++) {
      _start[index] = _current[index];
      final raw = index < magnitudes.length ? magnitudes[index] : 0.0;
      _targets[index] = _curveMagnitude(raw);
    }
    _animation.forward(from: 0);
  }

  void _tick() {
    final progress = Curves.easeOutCubic.transform(_animation.value);
    for (var index = 0; index < _bandCount; index++) {
      _current[index] =
          _start[index] + (_targets[index] - _start[index]) * progress;
    }
    if (mounted) setState(() {});
  }

  static double _curveMagnitude(double magnitude) {
    final safe = magnitude.clamp(0.0, 1.0).toDouble();
    return math.sqrt(safe).clamp(0.025, 1.0).toDouble();
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _animation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = widget.color ?? theme.colorScheme.primary;
    final gradient = widget.barGradient ??
        LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            color.withValues(alpha: 0.35),
            color.withValues(alpha: 0.78),
            Color.lerp(color, Colors.white, 0.24)!,
          ],
        );

    final content = switch (widget.mode) {
      SpectrumVisualizerMode.bars => _buildBars(
          context,
          gradient,
          mirrored: false,
        ),
      SpectrumVisualizerMode.mirror => _buildBars(
          context,
          gradient,
          mirrored: true,
        ),
      SpectrumVisualizerMode.wave => SizedBox.expand(
          child: CustomPaint(
            painter: _SpectrumWavePainter(
              values: List<double>.unmodifiable(_current),
              color: color,
            ),
          ),
        ),
    };
    return widget.height != null
        ? SizedBox(height: widget.height, child: content)
        : SizedBox.expand(child: content);
  }

  Widget _buildBars(
    BuildContext context,
    Gradient gradient, {
    required bool mirrored,
  }) {
    return Column(
      children: [
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final barWidth = constraints.maxWidth /
                  (_bandCount + (_bandCount - 1) * widget.gapFraction);
              final gap = barWidth * widget.gapFraction;
              final maxHeight = constraints.maxHeight;

              return Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: List<Widget>.generate(_bandCount, (index) {
                  final magnitude = _current[index];
                  final height = mirrored
                      ? (magnitude * maxHeight).clamp(4.0, maxHeight)
                      : (magnitude * maxHeight).clamp(2.0, maxHeight);

                  return Padding(
                    padding: EdgeInsets.only(
                      left: index == 0 ? 0 : gap / 2,
                      right: index == _bandCount - 1 ? 0 : gap / 2,
                    ),
                    child: SizedBox(
                      width: barWidth,
                      child: Align(
                        alignment: mirrored
                            ? Alignment.center
                            : Alignment.bottomCenter,
                        child: Container(
                          height: height,
                          decoration: BoxDecoration(
                            gradient: gradient,
                            borderRadius: BorderRadius.circular(
                              widget.barRadius,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              );
            },
          ),
        ),
        if (widget.showLabels) ...[
          const SizedBox(height: 6),
          Row(
            children: List<Widget>.generate(
              _bandCount,
              (index) => Expanded(
                child: Text(
                  _bandLabels[index],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withValues(alpha: 0.4),
                  ),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}

class _SpectrumWavePainter extends CustomPainter {
  const _SpectrumWavePainter({
    required this.values,
    required this.color,
  });

  final List<double> values;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty || size.isEmpty) return;

    final centerY = size.height * 0.55;
    final amplitude = size.height * 0.32;
    final path = Path()..moveTo(0, centerY);
    final points = math.max(48, size.width ~/ 8);

    for (var index = 0; index <= points; index++) {
      final x = size.width * index / points;
      final normalized = index / points;
      final scaled = normalized * (values.length - 1);
      final left = scaled.floor().clamp(0, values.length - 1).toInt();
      final right = math.min(left + 1, values.length - 1);
      final blend = scaled - left;
      final magnitude =
          values[left] + (values[right] - values[left]) * blend;
      final wave = math.sin(normalized * math.pi * 6.0);
      final envelope = math.sin(normalized * math.pi).abs();
      final y = centerY - wave * magnitude * amplitude * envelope;
      path.lineTo(x, y);
    }

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round
      ..color = color.withValues(alpha: 0.12)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..color = color.withValues(alpha: 0.72);

    canvas.drawPath(path, glow);
    canvas.drawPath(path, line);
  }

  @override
  bool shouldRepaint(covariant _SpectrumWavePainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.values != values;
}
