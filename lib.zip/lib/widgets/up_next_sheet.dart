import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/music_provider.dart';
import '../providers/state/queue_state.dart';
import '../providers/theme_provider.dart';
import 'track_art_widget.dart';

class UpNextSheet extends StatelessWidget {
  const UpNextSheet({super.key});
  static void show(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const UpNextSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Consumer<MusicProvider>(
      builder: (context, music, _) {
        final upNextItems = music.upNextItems;

        return DraggableScrollableSheet(
          initialChildSize: 0.55,
          minChildSize: 0.3,
          maxChildSize: 0.9,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: theme.bg,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(28)),
              ),
              child: Column(
                children: [
                  // ── Drag handle ────────────────────────────────────
                  const SizedBox(height: 12),
                  Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: theme.muted.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 12),
                  // ── Header ─────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(Icons.queue_music_rounded,
                            size: 20, color: theme.accent),
                        const SizedBox(width: 8),
                        Text(
                          'Up Next',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: theme.text,
                          ),
                        ),
                        const Spacer(),
                        if (upNextItems.isNotEmpty) ...[
                          GestureDetector(
                            onTap: music.clearUpNext,
                            child: Text(
                              'Clear',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: theme.danger,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ── Queue mode indicator ───────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Icon(Icons.add_rounded, size: 12, color: theme.muted),
                        const SizedBox(width: 4),
                        Text(
                          'New tracks: ${music.queueMode.toLowerCase()}',
                          style: TextStyle(fontSize: 11, color: theme.muted),
                        ),
                        if (music.isShuffle) ...[
                          const SizedBox(width: 10),
                          Icon(
                            Icons.shuffle_rounded,
                            size: 12,
                            color: theme.accent,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Active order locked',
                            style: TextStyle(
                              fontSize: 11,
                              color: theme.accent,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ── List ───────────────────────────────────────────
                  Expanded(
                    child: upNextItems.isEmpty
                        ? _EmptyState()
                        : ReorderableListView.builder(
                            scrollController: scrollController,
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                            buildDefaultDragHandles: false,
                            itemCount: upNextItems.length,
                            onReorderItem: (oldIndex, targetIndex) {
                              if (oldIndex < 0 ||
                                  oldIndex >= upNextItems.length ||
                                  targetIndex < 0 ||
                                  targetIndex >= upNextItems.length ||
                                  oldIndex == targetIndex) {
                                return;
                              }

                              final movingItem = upNextItems[oldIndex];
                              final targetItem = upNextItems[targetIndex];
                              if (music.isShuffle &&
                                  (movingItem.isActive || targetItem.isActive)) {
                                return;
                              }

                              music.reorderUpNextItems(
                                movingItem.id,
                                targetItem.id,
                              );
                            },
                            itemBuilder: (context, index) {
                              final item = upNextItems[index];
                              return _TrackRow(
                                key: ValueKey('upnext-${item.id}'),
                                item: item,
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.queue_music_rounded, size: 48, color: theme.muted),
          const SizedBox(height: 12),
          Text(
            'No upcoming tracks',
            style: TextStyle(fontSize: 15, color: theme.muted),
          ),
          const SizedBox(height: 4),
          Text(
            'Add tracks from your library',
            style: TextStyle(fontSize: 12, color: theme.muted),
          ),
        ],
      ),
    );
  }
}

class _TrackRow extends StatelessWidget {
  final QueueItemView item;

  const _TrackRow({
    super.key,
    required this.item,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.read<MusicProvider>();
    final track = item.track;
    final index = item.compositeIndex;
    final isPending = item.isPending;
    final canReorder = !music.isShuffle || isPending;

    return Dismissible(
      key: ValueKey('dismiss-upnext-${item.id}'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 6),
        decoration: BoxDecoration(
          color: theme.danger.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(Icons.delete_outline, color: theme.danger, size: 22),
      ),
      confirmDismiss: (_) async {
        music.removeFromUpNextItem(item.id);
        return false;
      },
      child: GestureDetector(
        onTap: () => music.playFromUpNextItem(item.id),
        behavior: HitTestBehavior.opaque,
        child: Container(
          margin: const EdgeInsets.only(bottom: 6),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: theme.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.border),
          ),
          child: Row(
            children: [
              // Track number / pending badge
              Container(
                width: 28,
                alignment: Alignment.center,
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isPending ? theme.accent : theme.muted,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // Artwork
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: TrackArtWidget(
                  artPath: track.artPath,
                  albumId: track.albumId,
                  mediaStoreId: track.mediaStoreId,
                  volumeName: track.volumeName,
                  stableKey: track.stableKey,
                  trackId: track.id,
                  size: 42,
                  borderRadius: 0,
                  defaultIconColor: theme.accent,
                ),
              ),
              const SizedBox(width: 10),
              // Title + artist
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: theme.text,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${track.artist} · ${track.formattedDuration}',
                      style: TextStyle(fontSize: 11, color: theme.muted),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              if (canReorder)
                ReorderableDragStartListener(
                  index: index,
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Icon(
                      Icons.drag_handle_rounded,
                      size: 18,
                      color: theme.muted,
                    ),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.shuffle_rounded,
                    size: 18,
                    color: theme.muted,
                  ),
                ),
              GestureDetector(
                onTap: () => music.removeFromUpNextItem(item.id),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.close_rounded,
                    size: 18,
                    color: theme.muted,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
