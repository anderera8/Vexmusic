import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../providers/music_provider.dart';
import '../screens/settings/settings_dialogs.dart';
import 'settings_tiles.dart';
import 'toast.dart';

class SideDrawer extends StatelessWidget {
  const SideDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final music = context.watch<MusicProvider>();

    return Drawer(
      backgroundColor: theme.bg,
      width: MediaQuery.of(context).size.width * 0.85,
      child: SafeArea(
        child: Column(
          children: [
            // Top Banner
            Container(
              key: const ValueKey('side-drawer-banner'),
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    theme.surface,
                    theme.surface2,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border(
                  bottom: BorderSide(color: theme.border),
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: theme.accent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: theme.accent.withValues(alpha: 0.24),
                      ),
                    ),
                    child: Icon(
                      Icons.music_note_rounded,
                      size: 30,
                      color: theme.accent,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Vibes Player',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: theme.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Stylish Music Player',
                    style: TextStyle(
                      fontSize: 12,
                      color: theme.muted,
                    ),
                  ),
                ],
              ),
            ),

            //Scrollable settings content
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                children: [
                  // Static "Settings" header
                  Padding(
                    padding: const EdgeInsets.only(top: 4, bottom: 4, left: 4),
                    child: Row(
                      children: [
                        Icon(
                          Icons.settings_rounded,
                          size: 20,
                          color: theme.muted,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'SETTINGS',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: theme.muted,
                            letterSpacing: 1.8,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // APPEARANCE
                  const SettingsSectionHeader('Appearance'),
                  SettingsSection(
                    children: [
                      SettingsActionTile(
                        icon: Icons.palette_outlined,
                        label: 'Theme',
                        subtitle: theme.themeLabel,
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/theme-selection');
                        },
                      ),
                      SettingsActionTile(
                        icon: Icons.brush_rounded,
                        label: 'Custom Theme',
                        subtitle: 'Create your own colour scheme',
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/custom-themes');
                        },
                      ),
                    ],
                  ),

                  // PLAYBACK
                  const SettingsSectionHeader('Playback'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.equalizer_rounded,
                        label: 'Volume normalisation',
                        subtitle: 'Keep all tracks at consistent loudness',
                        value: music.normEnabled,
                        onChanged: (_) => music.toggleNorm(),
                      ),
                      SettingsSliderTile(
                        icon: Icons.speed_rounded,
                        label: 'Playback speed',
                        value: music.playbackSpeed,
                        min: 0.5,
                        max: 2.0,
                        divisions: 6,
                        format: (v) => '${v.toStringAsFixed(1)}×',
                        onChanged: (v) => music.setPlaybackSpeed(v),
                      ),
                      SettingsSliderTile(
                        icon: Icons.blur_on_rounded,
                        label: 'Crossfade',
                        value: music.crossfadeSeconds.toDouble(),
                        min: 0,
                        max: 12,
                        divisions: 6,
                        format: (v) => v == 0 ? 'Off' : '${v.toInt()} sec',
                        onChanged: (v) => music.setCrossfade(v.toInt()),
                      ),
                      SettingsPickerTile(
                        icon: Icons.timer_outlined,
                        label: 'Sleep timer',
                        current: music.sleepTimer,
                        options: const [
                          'Off',
                          '5 min',
                          '10 min',
                          '15 min',
                          '30 min',
                          '45 min',
                          '1 hour',
                        ],
                        onPick: (v) {
                          music.setSleepTimer(v);
                          VibesToast.show(
                            context,
                            v == 'Off' ? 'Sleep timer off' : 'Sleep timer: $v',
                          );
                        },
                      ),
                    ],
                  ),

                  // LIBRARY
                  const SettingsSectionHeader('Library'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.copy_all_rounded,
                        label: 'Allow duplicates',
                        subtitle: 'Show multiple copies of the same track',
                        value: music.allowDuplicates,
                        onChanged: (_) => music.toggleDuplicates(),
                      ),
                      SettingsPickerTile(
                        icon: Icons.queue_music_rounded,
                        label: 'Queue mode',
                        current: music.queueMode,
                        options: const [
                          'Add to end',
                          'Play next',
                          'Shuffle in',
                        ],
                        onPick: (v) => music.setQueueMode(v),
                      ),
                    ],
                  ),

                  // TOOLS
                  const SettingsSectionHeader('Tools'),
                  SettingsSection(
                    children: [
                      SettingsActionTile(
                        icon: Icons.image_rounded,
                        label: 'Artwork Manager',
                        subtitle: 'See tracks missing album art',
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(
                            context,
                            '/artwork-manager',
                            arguments: {'tracks': music.tracks},
                          );
                        },
                      ),
                      SettingsActionTile(
                        icon: Icons.lyrics_rounded,
                        label: 'Lyric Themes',
                        subtitle: 'Customize lyrics appearance',
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.pushNamed(context, '/lyric-themes');
                        },
                      ),
                      SettingsActionTile(
                        icon: Icons.delete_sweep_rounded,
                        label: 'Clear Play History',
                        subtitle: 'Remove all recently played tracks',
                        onTap: () => _confirmClearHistory(context),
                      ),
                    ],
                  ),

                  // SYSTEM
                  const SettingsSectionHeader('System'),
                  SettingsSection(
                    children: [
                      SettingsToggleTile(
                        icon: Icons.play_circle_outline_rounded,
                        label: 'Background playback',
                        subtitle: 'Keep playing when app is backgrounded',
                        value: music.bgPlayback,
                        onChanged: (_) => music.toggleBgPlayback(),
                      ),
                      SettingsToggleTile(
                        icon: Icons.lock_outline_rounded,
                        label: 'Lock screen controls',
                        subtitle: 'Show controls on device lock screen',
                        value: music.lockScreenControls,
                        onChanged: (_) => music.toggleLockScreen(),
                      ),
                      SettingsActionTile(
                        icon: Icons.info_outline_rounded,
                        label: 'About',
                        subtitle: 'Version 2.2.1+11',
                        onTap: () => showVibesAboutDialog(context),
                      ),
                      SettingsActionTile(
                        icon: Icons.privacy_tip_rounded,
                        label: 'Privacy Policy',
                        subtitle: 'View our privacy policy',
                        onTap: () => showVibesPrivacyDialog(context),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),
                  Center(
                    child: Text(
                      'Vibes Player 2.2.1+11',
                      style: TextStyle(fontSize: 12, color: theme.muted),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmClearHistory(BuildContext context) {
    final theme = context.read<ThemeProvider>();

    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: theme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.delete_sweep_rounded,
                size: 48,
                color: theme.danger,
              ),
              const SizedBox(height: 16),
              Text(
                'Clear Play History',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: theme.text,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'This will remove all recently played tracks. Cannot be undone.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: theme.muted),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: theme.muted,
                        side: BorderSide(color: theme.border),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        context.read<MusicProvider>().clearRecentlyPlayed();
                        Navigator.pop(ctx);
                        VibesToast.show(context, 'History cleared');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: theme.danger,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text('Clear'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
