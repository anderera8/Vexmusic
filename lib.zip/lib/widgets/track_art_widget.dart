import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../services/artwork_cache_service.dart';

class TrackArtWidget extends StatefulWidget {
  const TrackArtWidget({
    super.key,
    this.artPath,
    this.albumId,
    this.mediaStoreId,
    this.volumeName,
    this.stableKey = '',
    @Deprecated(
      'Pass mediaStoreId and stableKey. trackId is retained only while '
      'legacy call sites are migrated.',
    )
    this.trackId,
    this.size = 48,
    this.borderRadius = 12,
    this.fit = BoxFit.cover,
    this.defaultIconColor,
    this.gaplessPlayback = true,
    this.cacheToken,
  });

  final String? artPath;
  final int? albumId;
  final int? mediaStoreId;
  final String? volumeName;
  final String stableKey;

  @Deprecated(
    'Pass mediaStoreId and stableKey. trackId is retained only while '
    'legacy call sites are migrated.',
  )
  final int? trackId;

  final double size;
  final double borderRadius;
  final BoxFit fit;
  final Color? defaultIconColor;
  final bool gaplessPlayback;
  final Object? cacheToken;

  static void invalidateArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    @Deprecated(
      'Pass mediaStoreId and stableKey. trackId is retained only while '
      'legacy call sites are migrated.',
    )
    int? trackId,
  }) {
    _TrackArtWidgetState.invalidateArtwork(
      albumId: albumId,
      mediaStoreId: mediaStoreId,
      volumeName: volumeName,
      stableKey: stableKey,
      trackId: trackId,
    );
  }


  static void primeArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    @Deprecated(
      'Pass mediaStoreId and stableKey. trackId is retained only while '
      'legacy call sites are migrated.',
    )
    int? trackId,
    required Uint8List bytes,
  }) {
    _TrackArtWidgetState.primeArtwork(
      albumId: albumId,
      mediaStoreId: mediaStoreId,
      volumeName: volumeName,
      stableKey: stableKey,
      trackId: trackId,
      bytes: bytes,
    );
  }

  @override
  State<TrackArtWidget> createState() => _TrackArtWidgetState();
}

class _TrackArtWidgetState extends State<TrackArtWidget> {
  static final Map<String, Uint8List?> _artCache = <String, Uint8List?>{};
  static final List<String> _cacheOrder = <String>[];

  static const int _maxCacheBytes = 12 * 1024 * 1024;
  static int _cacheBytes = 0;

  String? _cacheKey;
  Uint8List? _cachedData;
  Future<Uint8List?>? _loadFuture;
  Timer? _deferredLoadTimer;

  int? get _nativeTrackId {
    final mediaStoreId = widget.mediaStoreId;

    if (mediaStoreId != null && mediaStoreId > 0) {
      return mediaStoreId;
    }

    final legacyTrackId = widget.trackId;

    if (legacyTrackId != null && legacyTrackId > 0) {
      return legacyTrackId;
    }

    return null;
  }

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(
    covariant TrackArtWidget oldWidget,
  ) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.artPath != widget.artPath ||
        oldWidget.albumId != widget.albumId ||
        oldWidget.mediaStoreId != widget.mediaStoreId ||
        oldWidget.volumeName != widget.volumeName ||
        oldWidget.stableKey != widget.stableKey ||
        oldWidget.trackId != widget.trackId ||
        oldWidget.size != widget.size ||
        oldWidget.cacheToken != widget.cacheToken) {
      _deferredLoadTimer?.cancel();
      _resolve();
      _scheduleLoad(notify: mounted);
    }
  }

  static String _normalizeVolumeName(String? value) {
    final normalized = value?.trim().toLowerCase() ?? '';
    return normalized == 'external' ? 'external_primary' : normalized;
  }

  static String _albumCacheKey(
    int albumId,
    String? volumeName,
  ) {
    final volume = _normalizeVolumeName(volumeName);
    return volume.isEmpty
        ? 'album:$albumId'
        : 'album-source:$volume:$albumId';
  }

  static String? _audioCacheKey({
    required int? mediaStoreId,
    required String? volumeName,
    required String stableKey,
    int? legacyTrackId,
  }) {
    final normalizedStableKey = stableKey.trim().toLowerCase();

    if (normalizedStableKey.isNotEmpty) {
      return 'audio-stable:$normalizedStableKey';
    }

    final nativeId = mediaStoreId != null && mediaStoreId > 0
        ? mediaStoreId
        : legacyTrackId;

    if (nativeId != null && nativeId > 0) {
      final volume = _normalizeVolumeName(volumeName);
      return volume.isEmpty
          ? 'audio-media:$nativeId'
          : 'audio-source:$volume:$nativeId';
    }

    return null;
  }

  void _resolve() {
    final albumId = widget.albumId;

    if (_nativeTrackId != null) {
      _cacheKey = _audioCacheKey(
        mediaStoreId: widget.mediaStoreId,
        volumeName: widget.volumeName,
        stableKey: widget.stableKey,
        legacyTrackId: widget.trackId,
      );
    } else if (albumId != null && albumId > 0) {
      _cacheKey = _albumCacheKey(
        albumId,
        widget.volumeName,
      );
    } else {
      _cacheKey = null;
    }

    final key = _cacheKey;

    if (key == null || widget.artPath?.trim().isNotEmpty == true) {
      _cachedData = null;
      _loadFuture = null;
      return;
    }

    if (_artCache.containsKey(key)) {
      _cachedData = _artCache[key];
      _touch(key);
      _loadFuture = null;
      return;
    }

    _cachedData = null;
    _loadFuture = null;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _scheduleLoad();
  }

  void _scheduleLoad({
    bool notify = false,
  }) {
    final key = _cacheKey;

    if (key == null ||
        _cachedData != null ||
        _loadFuture != null ||
        widget.artPath?.trim().isNotEmpty == true) {
      return;
    }

    _deferredLoadTimer?.cancel();

    if (Scrollable.recommendDeferredLoadingForContext(context)) {
      _deferredLoadTimer = Timer(
        const Duration(milliseconds: 80),
        () {
          if (!mounted) return;
          _scheduleLoad(notify: true);
        },
      );

      return;
    }

    final rawSize = widget.size.isFinite ? widget.size : 200.0;
    final pixelSize = (rawSize * 3)
        .round()
        .clamp(100, 600)
        .toInt();

    late final Future<Uint8List?> future;

    final albumId = widget.albumId;
    final nativeTrackId = _nativeTrackId;

    if (nativeTrackId != null) {
      future = ArtworkCacheService.loadTrackArtwork(
        nativeTrackId,
        stableKey: widget.stableKey,
        volumeName: widget.volumeName,
        legacyTrackId: widget.mediaStoreId == null ? null : widget.trackId,
        size: pixelSize,
        quality: 80,
      ).then((data) async {
        if (data != null && data.isNotEmpty) {
          return data;
        }

        if (albumId != null && albumId > 0) {
          return ArtworkCacheService.loadArtwork(
            albumId,
            type: ArtworkType.album,
            volumeName: widget.volumeName,
            size: pixelSize,
            quality: 80,
          );
        }

        return null;
      });
    } else if (albumId != null && albumId > 0) {
      future = ArtworkCacheService.loadArtwork(
        albumId,
        type: ArtworkType.album,
        volumeName: widget.volumeName,
        size: pixelSize,
        quality: 80,
      );
    } else {
      return;
    }

    final cachedFuture = future.then((data) {
      _cachePut(key, data);
      return data;
    });

    if (notify && mounted) {
      setState(() {
        _loadFuture = cachedFuture;
      });
    } else {
      _loadFuture = cachedFuture;
    }
  }

  @override
  void dispose() {
    _deferredLoadTimer?.cancel();
    super.dispose();
  }

  static void _touch(String key) {
    _cacheOrder.remove(key);
    _cacheOrder.add(key);
  }

  static void _cachePut(
    String key,
    Uint8List? data,
  ) {
    final previous = _artCache[key];

    if (previous != null) {
      _cacheBytes -= previous.lengthInBytes;
    }

    _artCache[key] = data;

    if (data != null) {
      _cacheBytes += data.lengthInBytes;
    }

    _touch(key);

    while (_cacheBytes > _maxCacheBytes && _cacheOrder.length > 1) {
      final oldest = _cacheOrder.removeAt(0);
      final removed = _artCache.remove(oldest);

      if (removed != null) {
        _cacheBytes -= removed.lengthInBytes;
      }
    }
  }

  static void _cacheRemove(String key) {
    final removed = _artCache.remove(key);

    if (removed != null) {
      _cacheBytes -= removed.lengthInBytes;
    }

    _cacheOrder.remove(key);
  }

  static void invalidateArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    int? trackId,
  }) {
    if (albumId != null && albumId > 0) {
      _cacheRemove(
        _albumCacheKey(albumId, volumeName),
      );
      _cacheRemove('album:$albumId');
    }

    final normalizedStableKey = stableKey.trim().toLowerCase();

    if (normalizedStableKey.isNotEmpty) {
      _cacheRemove('audio-stable:$normalizedStableKey');
    }

    if (mediaStoreId != null && mediaStoreId > 0) {
      final volume = _normalizeVolumeName(volumeName);
      if (volume.isNotEmpty) {
        _cacheRemove('audio-source:$volume:$mediaStoreId');
      }
      _cacheRemove('audio-media:$mediaStoreId');
    }

    if (trackId != null && trackId > 0) {
      _cacheRemove('audio-media:$trackId');
    }
  }

  static void primeArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    int? trackId,
    required Uint8List bytes,
  }) {
    if (bytes.isEmpty) return;

    if (albumId != null && albumId > 0) {
      _cachePut(
        _albumCacheKey(albumId, volumeName),
        bytes,
      );
    }

    final audioKey = _audioCacheKey(
      mediaStoreId: mediaStoreId,
      volumeName: volumeName,
      stableKey: stableKey,
      legacyTrackId: trackId,
    );

    if (audioKey != null) {
      _cachePut(audioKey, bytes);
    }
  }

  @override
  Widget build(BuildContext context) {
    final artPath = widget.artPath?.trim();

    if (artPath != null && artPath.isNotEmpty) {
      return _buildFileImage(
        artPath,
        context,
      );
    }

    if (_cachedData != null && _cachedData!.isNotEmpty) {
      return _buildMemoryImage(
        _cachedData!,
        context,
      );
    }

    if (_loadFuture != null) {
      return FutureBuilder<Uint8List?>(
        future: _loadFuture,
        builder: (
          context,
          snapshot,
        ) {
          final data = snapshot.data;

          if (data != null && data.isNotEmpty) {
            return _buildMemoryImage(
              data,
              context,
            );
          }

          return _defaultIcon(context);
        },
      );
    }

    return _defaultIcon(context);
  }

  Widget _buildFileImage(
    String path,
    BuildContext context,
  ) {
    final finite = widget.size.isFinite;
    final cacheSize = finite
        ? (widget.size * MediaQuery.devicePixelRatioOf(context)).round()
        : null;

    return ClipRRect(
      borderRadius: BorderRadius.circular(
        widget.borderRadius,
      ),
      child: Image.file(
        File(path),
        width: finite ? widget.size : null,
        height: finite ? widget.size : null,
        fit: widget.fit,
        cacheWidth: cacheSize,
        cacheHeight: cacheSize,
        gaplessPlayback: widget.gaplessPlayback,
        errorBuilder: (
          _,
          __,
          ___,
        ) =>
            _defaultIcon(context),
      ),
    );
  }

  Widget _buildMemoryImage(
    Uint8List data,
    BuildContext context,
  ) {
    final finite = widget.size.isFinite;
    final cacheSize = finite
        ? (widget.size * MediaQuery.devicePixelRatioOf(context)).round()
        : null;

    return ClipRRect(
      borderRadius: BorderRadius.circular(
        widget.borderRadius,
      ),
      child: Image.memory(
        data,
        width: finite ? widget.size : null,
        height: finite ? widget.size : null,
        fit: widget.fit,
        cacheWidth: cacheSize,
        cacheHeight: cacheSize,
        gaplessPlayback: widget.gaplessPlayback,
        errorBuilder: (
          _,
          __,
          ___,
        ) =>
            _defaultIcon(context),
      ),
    );
  }

  Widget _defaultIcon(
    BuildContext context,
  ) {
    final color = widget.defaultIconColor ??
        Theme.of(context).colorScheme.primary.withValues(alpha: 0.5);

    return Icon(
      Icons.music_note_rounded,
      size: widget.size.isFinite ? widget.size * 0.6 : 28.8,
      color: color,
    );
  }
}
