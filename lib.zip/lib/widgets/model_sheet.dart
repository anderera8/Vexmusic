import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class ModalAction {
  final String label;
  final String cls; // 'primary', 'secondary', 'danger'
  final VoidCallback action;
  final bool popAfter;

  ModalAction({
    required this.label,
    this.cls = 'secondary',
    required this.action,
    this.popAfter = true,
  });
}

void showModalSheet(
  BuildContext context, {
  required String title,
  required String body,
  required List<ModalAction> actions,
  Widget? extra,
}) {
  final theme = context.read<ThemeProvider>();

  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (ctx) {

      final bottomInset = MediaQuery.of(ctx).viewInsets.bottom;

      return Container(
        decoration: BoxDecoration(
          color: theme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border(
            top: BorderSide(color: theme.border),
          ),
        ),
        padding: EdgeInsets.fromLTRB(22, 20, 22, 32 + bottomInset),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Drag handle
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: theme.surface2,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: theme.text,
                ),
              ),
              // Only render body text when it is non-empty
              if (body.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  body,
                  style: TextStyle(
                    fontSize: 14,
                    color: theme.muted,
                    height: 1.6,
                  ),
                ),
              ],
              if (extra != null) ...[
                const SizedBox(height: 16),
                extra,
              ],
              const SizedBox(height: 20),
              Row(
                children: actions.map((action) {
                  return Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: action == actions.first ? 0 : 5,
                        right: action == actions.last ? 0 : 5,
                      ),
                      child: _ModalButton(
                        label: action.label,
                        type: action.cls,
                        onPressed: () {
                          action.action();
                          if (action.popAfter) {
                            Navigator.pop(ctx);
                          }
                        },
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      );
    },
  );
}

void showSideSheet(
  BuildContext context, {
  required String title,
  required String body,
  required List<ModalAction> actions,
  Widget? extra,
  bool verticalActions = false,
}) {
  final theme = context.read<ThemeProvider>();

  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Dismiss',
    barrierColor: Colors.black54,
    transitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (ctx, anim1, anim2) => Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // Tapping the left side dismisses
          GestureDetector(
            onTap: () => Navigator.pop(ctx),
            child: Container(color: Colors.transparent),
          ),
          // The side panel
          Align(
            alignment: Alignment.centerRight,
            child: GestureDetector(
              onTap: () {},
              child: Container(
                width: MediaQuery.of(ctx).size.width * 0.85,
                constraints: const BoxConstraints(maxWidth: 400),
                decoration: BoxDecoration(
                  color: theme.bg,
                  borderRadius:
                      const BorderRadius.horizontal(left: Radius.circular(28)),
                  border: Border(
                    left: BorderSide(color: theme.border),
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Drag handle
                          Center(
                            child: Container(
                              width: 36,
                              height: 4,
                              decoration: BoxDecoration(
                                color: theme.surface2,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            title,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: theme.text,
                            ),
                          ),
                          if (body.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              body,
                              style: TextStyle(
                                fontSize: 14,
                                color: theme.muted,
                                height: 1.6,
                              ),
                            ),
                          ],
                          if (extra != null) ...[
                            const SizedBox(height: 16),
                            extra,
                          ],
                          const SizedBox(height: 20),
                          if (verticalActions)
                            _VerticalActions(
                              actions: actions,
                              onAction: (action) {
                                action.action();
                                if (action.popAfter) {
                                  Navigator.pop(ctx);
                                }
                              },
                            )
                          else
                            Row(
                              children: actions.map((action) {
                                return Expanded(
                                  child: Padding(
                                    padding: EdgeInsets.only(
                                      left: action == actions.first ? 0 : 5,
                                      right: action == actions.last ? 0 : 5,
                                    ),
                                    child: _ModalButton(
                                      label: action.label,
                                      type: action.cls,
                                      onPressed: () {
                                        action.action();
                                        if (action.popAfter) {
                                          Navigator.pop(ctx);
                                        }
                                      },
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
    transitionBuilder: (ctx, anim, secondaryAnim, child) {
      return SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1.0, 0.0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutCubic,
        )),
        child: child,
      );
    },
  );
}

class _ModalButton extends StatelessWidget {
  final String label;
  final String type;
  final VoidCallback onPressed;

  const _ModalButton({
    required this.label,
    required this.type,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    Decoration decoration;
    Color textColor;

    switch (type) {
      case 'primary':
        decoration = BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [theme.accent, theme.accent2],
          ),
          borderRadius: const BorderRadius.all(Radius.circular(50)),
        );
        textColor = Theme.of(context).colorScheme.onPrimary;
        break;
      case 'danger':
        decoration = BoxDecoration(
          color: theme.danger.withValues(alpha: 0.15),
          borderRadius: const BorderRadius.all(Radius.circular(50)),
        );
        textColor = theme.danger;
        break;
      default:
        decoration = BoxDecoration(
          color: theme.surface2,
          borderRadius: const BorderRadius.all(Radius.circular(50)),
        );
        textColor = theme.text;
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onPressed,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: decoration,
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: textColor,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// ── Vertical action list ─────────────────────────────────────────────────────
class _VerticalActions extends StatelessWidget {
  final List<ModalAction> actions;
  final void Function(ModalAction action) onAction;

  const _VerticalActions({
    required this.actions,
    required this.onAction,
  });

  IconData _iconForAction(ModalAction action) {
    final label = action.label.toLowerCase();
    if (label.contains('info')) return Icons.info_outline_rounded;
    if (label.contains('playlist')) return Icons.playlist_add_rounded;
    if (label.contains('queue')) return Icons.queue_music_rounded;
    if (label.contains('like') || label.contains('unlike')) {
      return action.label.contains('Unlike')
          ? Icons.favorite_border_rounded
          : Icons.favorite_rounded;
    }
    if (label.contains('share')) return Icons.share_rounded;
    if (label.contains('rename')) return Icons.edit_rounded;
    if (label.contains('delete')) return Icons.delete_outline_rounded;
    if (label.contains('cancel')) return Icons.close_rounded;
    return Icons.chevron_right_rounded;
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: actions.asMap().entries.map((e) {
        final idx = e.key;
        final action = e.value;
        final color = action.cls == 'danger'
            ? theme.danger
            : action.cls == 'primary'
                ? theme.accent
                : theme.text;

        return Column(
          children: [
            if (idx > 0)
              Divider(
                  color: theme.border, height: 1, indent: 16, endIndent: 16),
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => onAction(action),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
                child: Row(
                  children: [
                    Icon(_iconForAction(action), size: 22, color: color),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        action.label,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: color,
                        ),
                      ),
                    ),
                    Icon(Icons.chevron_right_rounded,
                        size: 18, color: theme.muted),
                  ],
                ),
              ),
            ),
          ],
        );
      }).toList(),
    );
  }
}
