import 'dart:math' as math;
import 'package:flutter/material.dart';

class RadioVisualizer extends StatefulWidget {
  final List<Color> colors;
  final double height;
  final bool active;
  final int barCount;

  const RadioVisualizer({
    super.key,
    required this.colors,
    this.height = 64,
    this.active = true,
    this.barCount = 9,
  });

  @override
  State<RadioVisualizer> createState() => _RadioVisualizerState();
}

class _RadioVisualizerState extends State<RadioVisualizer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        return SizedBox(
          width: double.infinity,
          height: widget.height,
          child: CustomPaint(
            painter: _VisualizerPainter(
              t: _ctrl.value,
              colors: widget.colors,
              active: widget.active,
              barCount: widget.barCount,
            ),
          ),
        );
      },
    );
  }
}

class _VisualizerPainter extends CustomPainter {
  final double t;
  final List<Color> colors;
  final bool active;
  final int barCount;

  _VisualizerPainter({
    required this.t,
    required this.colors,
    required this.active,
    required this.barCount,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final barWidth = size.width / (barCount * 1.8);
    final gap = barWidth * 0.8;
    final totalWidth = barCount * barWidth + (barCount - 1) * gap;
    final startX = (size.width - totalWidth) / 2;

    final paint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: colors,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.fill;

    for (int i = 0; i < barCount; i++) {
      final phase = i / barCount;
      final freq = 0.8 + (i % 3) * 0.35;
      final wave =
          (0.5 - 0.5 * math.cos((t * freq + phase) * 2 * math.pi)).abs();

      final minHeightFactor = active ? 0.14 : 0.10;
      final maxHeightFactor = active ? 1.0 : 0.16;
      final heightFactor =
          minHeightFactor + (maxHeightFactor - minHeightFactor) * wave;
      final barHeight = size.height * heightFactor;

      final x = startX + i * (barWidth + gap);
      final y = size.height - barHeight;

      final rrect = RRect.fromRectAndRadius(
        Rect.fromLTWH(x, y, barWidth, barHeight),
        Radius.circular(barWidth / 2),
      );
      canvas.drawRRect(rrect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _VisualizerPainter oldDelegate) {
    return oldDelegate.t != t ||
        oldDelegate.active != active ||
        oldDelegate.colors != colors;
  }
}
