import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/radio_provider.dart';
import '../../providers/theme_provider.dart';
import '../../services/radio/radio_player_service.dart';
import '../toast.dart';
import 'radio_art.dart';

class RadioMiniPlayer extends StatelessWidget {
  final VoidCallback onTap;

  const RadioMiniPlayer({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final radio = context.watch<RadioProvider>();
    final screenWidth = MediaQuery.of(context).size.width;

    final station = radio.currentStation;
    if (station == null) return const SizedBox.shrink();

    final isBusy = radio.isBusy;
    final hasError = radio.playbackStatus == RadioPlaybackStatus.error;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Semantics(
        label: 'Now playing ${station.name} on radio. Double tap to open player.',
        button: true,
        child: Container(
          decoration: BoxDecoration(
            color: theme.surface,
            border: Border(top: BorderSide(color: theme.border)),
          ),
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
          child: Stack(
            children: [
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 1,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        theme.accent,
                        theme.accent2,
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  RadioArt(
                    favicon: station.favicon,
                    stationName: station.name,
                    size: 48,
                    borderRadius: 12,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            if (!hasError)
                              Container(
                                width: 6,
                                height: 6,
                                margin: const EdgeInsets.only(right: 5),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: radio.isPlaying
                                      ? theme.danger
                                      : theme.muted,
                                ),
                              ),
                            Expanded(
                              child: Text(
                                station.name,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: theme.text,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 1),
                        Text(
                          hasError
                              ? (radio.playbackError ?? 'Playback error')
                              : (radio.nowPlayingText?.isNotEmpty == true
                                  ? radio.nowPlayingText!
                                  : (station.subtitle.isEmpty
                                      ? 'Live radio'
                                      : station.subtitle)),
                          style: TextStyle(fontSize: 11, color: theme.muted),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  if (isBusy)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: theme.accent,
                        ),
                      ),
                    )
                  else if (hasError)
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        radio.retryCurrentStation();
                        VibesToast.show(context, 'Reconnecting…');
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Icon(Icons.refresh_rounded,
                            size: 20, color: theme.accent),
                      ),
                    )
                  else
                    GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => radio.togglePlayPause(),
                      child: Semantics(
                        label: radio.isPlaying ? 'Pause' : 'Play',
                        button: true,
                        child: Padding(
                          padding: const EdgeInsets.all(4),
                          child: Icon(
                            radio.isPlaying
                                ? Icons.pause_circle
                                : Icons.play_circle,
                            size: screenWidth < 360 ? 26 : 30,
                            color: theme.text,
                          ),
                        ),
                      ),
                    ),
                  SizedBox(width: screenWidth < 360 ? 2 : 6),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => radio.stopAndClear(),
                    child: Semantics(
                      label: 'Stop radio',
                      button: true,
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(
                          Icons.close_rounded,
                          size: screenWidth < 360 ? 26 : 30,
                          color: theme.muted,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
