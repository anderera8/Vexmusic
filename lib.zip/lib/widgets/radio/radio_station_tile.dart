import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/radio_models.dart';
import '../../providers/theme_provider.dart';
import '../sound_wave_indicator.dart';
import 'radio_art.dart';

class RadioStationTile extends StatelessWidget {
  final RadioStation station;
  final VoidCallback onTap;
  final bool isActive;
  final bool isPlaying;
  final bool isFavorite;
  final VoidCallback? onFavoriteTap;

  const RadioStationTile({
    super.key,
    required this.station,
    required this.onTap,
    this.isActive = false,
    this.isPlaying = false,
    this.isFavorite = false,
    this.onFavoriteTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Semantics(
        label: '${station.name}, ${station.subtitle}'
            '${isActive ? ', currently playing' : ''}',
        button: true,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isActive
                ? theme.accent.withValues(alpha: 0.10)
                : theme.surface,
            border: Border.all(
              color: isActive
                  ? theme.accent.withValues(alpha: 0.45)
                  : theme.border,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              RadioArt(
                favicon: station.favicon,
                stationName: station.name,
                size: 48,
                borderRadius: 12,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      station.name,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: isActive ? theme.accent : theme.text,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            station.subtitle.isEmpty
                                ? 'Internet radio'
                                : station.subtitle,
                            style: TextStyle(fontSize: 12, color: theme.muted),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (station.clickCount > 0) ...[
                          Icon(Icons.headphones_rounded,
                              size: 11, color: theme.muted),
                          const SizedBox(width: 2),
                          Text(
                            station.popularityLabel,
                            style: TextStyle(fontSize: 11, color: theme.muted),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 4),
              if (isActive && isPlaying)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: SoundWaveIndicator(color: theme.accent, size: 18),
                ),
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onFavoriteTap,
                child: Semantics(
                  label: isFavorite ? 'Remove from favorites' : 'Add to favorites',
                  button: true,
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      size: 20,
                      color: isFavorite ? theme.danger : theme.muted,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
