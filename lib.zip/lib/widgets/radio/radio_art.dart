import 'package:flutter/material.dart';

const List<List<Color>> _kFallbackGradients = [
  [Color(0xFFFFC542), Color(0xFFFF7A45)], // gold → amber
  [Color(0xFF7F5AF0), Color(0xFF2B2450)], // violet → deep indigo
  [Color(0xFF00C2A8), Color(0xFF00707A)], // teal → deep teal
  [Color(0xFFFF5E7E), Color(0xFF7A1E45)], // rose → deep wine
  [Color(0xFF3E8EF7), Color(0xFF1B2A6B)], // sky → deep blue
  [Color(0xFF35D07F), Color(0xFF0E6B4F)], // emerald → forest
];

class RadioArt extends StatelessWidget {
  final String favicon;
  final String stationName;
  final double size;
  final double borderRadius;

  const RadioArt({
    super.key,
    required this.favicon,
    required this.stationName,
    this.size = 56,
    this.borderRadius = 14,
  });

  List<Color> get _gradient {
    final index = stationName.isEmpty
        ? 0
        : stationName.codeUnits.fold<int>(0, (a, b) => a + b) %
            _kFallbackGradients.length;
    return _kFallbackGradients[index];
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius),
      child: SizedBox(
        width: size,
        height: size,
        child: favicon.trim().isEmpty
            ? _fallback()
            : Image.network(
                favicon,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _fallback(),
                loadingBuilder: (context, child, progress) {
                  if (progress == null) return child;
                  return _fallback(loading: true);
                },
              ),
      ),
    );
  }

  Widget _fallback({bool loading = false}) {
    final colors = _gradient;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: colors,
        ),
      ),
      alignment: Alignment.center,
      child: loading
          ? SizedBox(
              width: size * 0.28,
              height: size * 0.28,
              child: const CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white70,
              ),
            )
          : Icon(
              Icons.radio_rounded,
              color: Colors.white.withValues(alpha: 0.92),
              size: size * 0.44,
            ),
    );
  }
}
