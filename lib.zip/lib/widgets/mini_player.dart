import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../providers/music_provider.dart';
import 'toast.dart';
import 'track_art_widget.dart';

class MiniPlayer extends StatelessWidget {
  final VoidCallback onTap;

  const MiniPlayer({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final screenWidth = MediaQuery.of(context).size.width;

    return Consumer<MusicProvider>(
      builder: (context, music, _) {
        if (!music.hasTracks || !music.hasStartedPlayback) {
          return const SizedBox.shrink();
        }

        final track = music.currentTrack;

        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onTap,
          child: Semantics(
            label:
                'Now playing ${track.title} by ${track.artist}. Double tap to open player.',
            button: true,
            child: Container(
              decoration: BoxDecoration(
                color: theme.surface,
                border: Border(
                  top: BorderSide(color: theme.border),
                ),
              ),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Stack(
                children: [
                  // Progress accent line at top
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            theme.accent,
                            theme.accent2,
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Progress bar at bottom
                  Positioned(
                    bottom: 0,
                    left: 0,
                    child: Container(
                      height: 2,
                      width: music.totalDuration == null
                          ? 0
                          : screenWidth *
                              (music.progressPct / 100).clamp(0.0, 1.0),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [theme.accent, theme.accent2],
                        ),
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(2),
                          bottomRight: Radius.circular(2),
                        ),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      // track art
                      TrackArtWidget(
                        key: ValueKey(
                          'mini-player-art-'
                          '${track.id}-'
                          '${track.mediaStoreId}-'
                          '${track.volumeName}-'
                          '${track.stableKey}-'
                          '${track.albumId ?? 0}-'
                          '${track.artPath ?? ''}',
                        ),
                        artPath: track.artPath,
                        albumId: track.albumId,
                        mediaStoreId: track.mediaStoreId,
                        volumeName: track.volumeName,
                        stableKey: track.stableKey,
                        trackId: track.id,
                        size: 48,
                        borderRadius: 12,
                        defaultIconColor: theme.accent,
                        gaplessPlayback: false,
                      ),
                      const SizedBox(width: 12),
                      // Title + artist
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              track.title,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: theme.text,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 1),
                            Text(
                              track.artist,
                              style: TextStyle(
                                fontSize: 11,
                                color: theme.muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (music.isRecoveringPlayback)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: theme.accent,
                            ),
                          ),
                        )
                      else if (music.lastPlaybackFailure != null)
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () => VibesToast.showPlaybackFailure(
                            context,
                            music.lastPlaybackFailure!,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(6),
                            child: Icon(
                              Icons.error_outline_rounded,
                              size: 20,
                              color: theme.accent,
                            ),
                          ),
                        ),

                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => music.togglePlayPause(),
                        child: Semantics(
                          label: music.isPlaying ? 'Pause' : 'Play',
                          button: true,
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: Icon(
                              music.isPlaying
                                  ? Icons.pause_circle
                                  : Icons.play_circle,
                              size: screenWidth < 360 ? 26 : 30,
                              color: theme.text,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: screenWidth < 360 ? 2 : 6),
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => music.nexttrack(),
                        child: Semantics(
                          label: 'Skip to next track',
                          button: true,
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: Icon(
                              Icons.skip_next,
                              size: screenWidth < 360 ? 26 : 30,
                              color: theme.text,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: screenWidth < 360 ? 0 : 2),
                      GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => music.dismissPlayer(),
                        child: Semantics(
                          label: 'Dismiss mini player',
                          button: true,
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: Icon(
                              Icons.close_rounded,
                              size: screenWidth < 360 ? 26 : 30,
                              color: theme.muted,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
