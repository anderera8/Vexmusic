import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'providers/theme_provider.dart';
import 'screens/onboarding/permission_screen.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/now_playing/now_playing_screen.dart';
import 'screens/library/library_screen.dart';
import 'screens/albums/albums_detail_screen.dart';
import 'screens/playlists/playlists_detail_screen.dart';
import 'screens/settings/settings_screen.dart';
import 'screens/settings/theme_selection_screen.dart';
import 'screens/folders/folder_detail_screen.dart';
import 'screens/genres/genres_screen.dart';
import 'screens/equalizer/equalizer_screen.dart';
import 'screens/editor/tag_editor_screen.dart';
import 'screens/editor/artwork_manager_screen.dart';
import 'screens/theme/custom_theme_screen.dart';
import 'screens/theme/player_skin_screen.dart';
import 'screens/theme/lyric_theme_screen.dart';
import 'models/music_models.dart';
import 'services/media_permission_service.dart';

class VibesPlayerApp extends StatelessWidget {
  final bool skipOnboarding;

  const VibesPlayerApp({
    super.key,
    required this.skipOnboarding,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return MaterialApp(
          title: 'Vibes Player',
          debugShowCheckedModeBanner: false,
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('en'),
            Locale('es'),
            Locale('fr'),
            Locale('de'),
            Locale('pt'),
            Locale('ar'),
            Locale('hi'),
            Locale('zh'),
            Locale('ja'),
            Locale('ko'),
            Locale('ru'),
          ],
          theme: themeProvider.themeForLight,
          darkTheme: themeProvider.themeForDark,
          themeMode: themeProvider.themeMode,

          home: _StartupGate(skipOnboarding: skipOnboarding),

          onGenerateRoute: (settings) {
            switch (settings.name) {
              case '/permission':
                return _fade(const PermissionScreen());

              case '/onboarding':
                return _fade(const OnboardingScreen());

              case '/home':
                return _fade(const HomeScreen());

              case '/now-playing':
                return _slide(const NowPlayingScreen());

              case '/library':
                return _fade(const LibraryScreen());

              case '/album-detail':
                final album = settings.arguments as Album;
                return _fade(AlbumDetailScreen(album: album));

              case '/playlist-detail':
                final playlist = settings.arguments as Playlist;
                return _fade(PlaylistDetailScreen(playlist: playlist));

              case '/settings':
                return _fade(const SettingsScreen());

              case '/theme-selection':
                return _fade(const ThemeSelectionScreen());

              case '/folder-detail':
                final args = settings.arguments as Map<String, dynamic>;
                return _fade(
                  FolderDetailScreen(
                    folderName: args['name'] as String,
                    tracks: (args['tracks'] as List).cast<Track>(),
                  ),
                );

              case '/genre-detail':
                final genre = settings.arguments as Genre;
                return _fade(GenreDetailScreen(genre: genre));

              case '/equalizer':
                return _fade(const EqualizerScreen());

              case '/tag-editor':
                final track = settings.arguments as Track;
                return _fade(TagEditorScreen(track: track));

              case '/artwork-manager':
                final args = settings.arguments as Map<String, dynamic>;
                return _fade(
                  ArtworkManagerScreen(
                    tracks: (args['tracks'] as List).cast<Track>(),
                  ),
                );

              case '/custom-themes':
                return _fade(const CustomThemeScreen());

              case '/player-skins':
                return _fade(const PlayerSkinScreen());

              case '/lyric-themes':
                return _fade(const LyricThemeScreen());

              default:
                return _fade(const HomeScreen());
            }
          },
        );
      },
    );
  }

  static PageRoute _fade(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 220),
      );

  static PageRoute _slide(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, animation, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 1),
            end: Offset.zero,
          ).animate(
            CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
            ),
          ),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 320),
      );
}

class _StartupGate extends StatefulWidget {
  final bool skipOnboarding;

  const _StartupGate({
    required this.skipOnboarding,
  });

  @override
  State<_StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<_StartupGate> {
  bool? _hasAudioPermission;

  @override
  void initState() {
    super.initState();

    // No artificial delay here: the native splash (see
    // android/app/src/main/res/values-v31/styles.xml) stays on screen
    // until this widget's first frame is actually drawn, so there's
    // nothing left to pace against — resolving as soon as possible is
    // what keeps that handoff feeling instant rather than padded.
    WidgetsBinding.instance.addPostFrameCallback((_) => _resolveStartup());
  }

  Future<void> _resolveStartup() async {
    if (!mounted) return;

    if (!widget.skipOnboarding) {
      setState(() {
        _hasAudioPermission = false;
      });
      return;
    }

    final hasAudioPermission = await _hasRequiredAudioPermission();

    if (!mounted) return;

    setState(() {
      _hasAudioPermission = hasAudioPermission;
    });
  }

  Future<bool> _hasRequiredAudioPermission() async {
    final result = await MediaPermissionService.instance.check();

    if (!result.granted && result.error != null) {
      debugPrint(
        '[StartupGate] Audio permission could not be verified: '
        '${result.error}',
      );
    }

    return result.granted;
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.skipOnboarding) {
      return const PermissionScreen();
    }

    if (_hasAudioPermission == true) {
      return const HomeScreen();
    }

    if (_hasAudioPermission == null) {
      // Audio-permission check is still resolving. This paints for at
      // most one frame — same navy as the native splash it's continuing
      // from, so there's nothing to see here rather than a flash of an
      // unrelated screen.
      return const ColoredBox(color: Color(0xFF071A33));
    }

    return const PermissionScreen();
  }
}
