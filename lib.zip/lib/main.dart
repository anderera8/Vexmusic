import 'dart:async' show unawaited, TimeoutException;
import 'dart:io' show HttpException, Platform, SocketException, TlsException;
import 'dart:ui' show PlatformDispatcher;

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:firebase_performance/firebase_performance.dart';
import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'firebase_options.dart';
import 'providers/music_provider.dart';
import 'providers/radio_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/theme_provider.dart';
import 'providers/lyric_theme_provider.dart';
import 'services/ads/unity_ads_service.dart';
import 'services/audio/radio_system_playback_bridge.dart';
import 'services/database_service.dart';
import 'services/legacy_cleanup_service.dart';
import 'services/playback/media_playback_coordinator.dart';
import 'services/playback/performance_metrics.dart';
import 'services/playback/playback_system_service.dart';
import 'services/prefs_service.dart';
import 'services/startup/startup_work_scheduler.dart';

Future<void> main() async {
  final startupClock = Stopwatch()..start();

  WidgetsFlutterBinding.ensureInitialized();
  unawaited(UnityAdsService.instance.init());
  FlutterError.onError = FlutterError.presentError;

  PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('Unhandled startup error: $error');
    return true;
  };

  await PrefsService.init();

  PerformanceMetrics().recordInitStart();

  final playbackCoordinator = MediaPlaybackCoordinator();
  PlaybackSystemService.bindCoordinator(playbackCoordinator);

  final hasCompletedOnboarding =
      PrefsService.getBool('hasCompletedOnboarding') ?? false;

  final settingsProvider = SettingsProvider();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
    ),
  );

  final themeProvider = ThemeProvider()
    ..setSystemFontFamily(Platform.isAndroid ? 'sans-serif' : null);

  final musicProvider = MusicProvider(settings: settingsProvider);
  final radioProvider = RadioProvider()
    ..onWillStartPlayback = () {
      if (musicProvider.isPlaying) unawaited(musicProvider.togglePlayPause());
    };
  musicProvider.addListener(() {
    if (musicProvider.isPlaying) radioProvider.pauseForExternalPlayback();
  });

  RadioSystemPlaybackBridge(radioProvider);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: themeProvider),
        ChangeNotifierProvider(
          create: (_) => LyricThemeProvider()..load(),
        ),
        ChangeNotifierProvider.value(value: musicProvider),
        ChangeNotifierProvider.value(value: radioProvider),
        ChangeNotifierProvider.value(value: settingsProvider),
      ],
      child: VibesPlayerApp(skipOnboarding: hasCompletedOnboarding),
    ),
  );

  WidgetsBinding.instance.addPostFrameCallback((_) {
    startupClock.stop();
    PerformanceMetrics().recordInitEnd();

    debugPrint(
      '[Startup] first Flutter frame in ${startupClock.elapsedMilliseconds} ms',
    );

    unawaited(_initializeDeferredServices());

    unawaited(
      PlaybackSystemService.initialize(playbackCoordinator),
    );
  });
}

Future<void> _initializeDeferredServices() {
  return StartupWorkScheduler.run([
    StartupTask(
      name: 'orientation setup',
      work: () => SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]),
    ),
    StartupTask(
      name: 'legacy cleanup',
      delay: const Duration(milliseconds: 120),
      work: LegacyCleanupService.runOnce,
    ),
    StartupTask(
      name: 'media-library migration',
      delay: const Duration(milliseconds: 180),
      work: () async {
        if (PrefsService.getBool('mediaLibraryMigrated') == true) return;
        await DatabaseService().migrateToMediaLibrary();
        await PrefsService.setBool('mediaLibraryMigrated', true);
      },
    ),
    StartupTask(
      name: 'Firebase initialization',
      delay: const Duration(milliseconds: 500),
      work: _initializeFirebase,
    ),
  ]);
}

bool _isRecoverableNetworkError(Object error) {
  return error is SocketException ||
      error is TimeoutException ||
      error is HttpException ||
      error is TlsException ||
      error is NetworkImageLoadException;
}
bool _isReportableFlutterError(FlutterErrorDetails details) {
  final message = details.exception.toString();
  if (message.contains('overflowed by')) {
    return false;
  }
  if (_isRecoverableNetworkError(details.exception)) {
    return false;
  }
  return true;
}

bool _isFatalError(Object error) {
  if (_isRecoverableNetworkError(error)) {
    return false;
  }
  return true;
}

Future<void> _initializeFirebase() async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    FlutterError.onError = (details) {
      FlutterError.presentError(details);
      if (_isReportableFlutterError(details)) {
        FirebaseCrashlytics.instance.recordFlutterError(details);
      }
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(
        error,
        stack,
        fatal: _isFatalError(error),
      );
      return true;
    };

    for (final entry in PerformanceMetrics().summary.entries) {
      await FirebaseCrashlytics.instance.setCustomKey(entry.key, entry.value);
    }

    if (!kDebugMode) {
      await FirebasePerformance.instance.setPerformanceCollectionEnabled(true);
    }
  } catch (error) {
    debugPrint('Firebase initialization failed: $error');
  }
}
