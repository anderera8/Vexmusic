import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;
    
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAvJkGYGCZVQPMmNyWMpkcrNhYHAbXZEQk',
    appId: '1:286349525894:web:960f87b5cad64b56292207',
    messagingSenderId: '286349525894',
    projectId: 'vexmusic-36fc6',
    authDomain: 'vexmusic-36fc6.firebaseapp.com',
    storageBucket: 'vexmusic-36fc6.firebasestorage.app',
    measurementId: 'G-GBPS35ZFVW',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAHqL9O_OEpUFc2cntK8PZYLNPHrz3hII8',
    appId: '1:286349525894:android:11a93bdde051cd95292207',
    messagingSenderId: '286349525894',
    projectId: 'vexmusic-36fc6',
    storageBucket: 'vexmusic-36fc6.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCEK0ocrq0T3G58C_s7DzAfP3HNGuLnv34',
    appId: '1:286349525894:ios:3e0c8e73275ab689292207',
    messagingSenderId: '286349525894',
    projectId: 'vexmusic-36fc6',
    storageBucket: 'vexmusic-36fc6.firebasestorage.app',
    iosBundleId: 'com.vextech.vexmusic',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCEK0ocrq0T3G58C_s7DzAfP3HNGuLnv34',
    appId: '1:286349525894:ios:3e0c8e73275ab689292207',
    messagingSenderId: '286349525894',
    projectId: 'vexmusic-36fc6',
    storageBucket: 'vexmusic-36fc6.firebasestorage.app',
    iosBundleId: 'com.vextech.vexmusic',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAvJkGYGCZVQPMmNyWMpkcrNhYHAbXZEQk',
    appId: '1:286349525894:web:ecd4d8ab53ef4718292207',
    messagingSenderId: '286349525894',
    projectId: 'vexmusic-36fc6',
    authDomain: 'vexmusic-36fc6.firebaseapp.com',
    storageBucket: 'vexmusic-36fc6.firebasestorage.app',
    measurementId: 'G-KMQTTFLB51',
  );
}
