import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';

import '../models/music_models.dart';
import 'lyrics_service.dart';

class CachedLyricsRecord {
  const CachedLyricsRecord({
    required this.lyrics,
    required this.source,
  });

  final LyricsData lyrics;
  final String source;
}

/// Disk-backed lyrics cache owned by stable physical-track identity.
class LyricsCacheService {
  static const int _schemaVersion = 2;
  static const String _directoryName = 'lyrics-cache-v2';

  Directory? _directory;

  static String identityFor(Track track) {
    final stableKey = _normalize(track.stableKey);
    if (stableKey.isNotEmpty) {
      return 'stable-${_digest(stableKey)}';
    }

    final path = _normalize(track.normalizedSourcePath);
    if (path.isNotEmpty) {
      return 'path-${_digest(path)}';
    }

    return 'content-${_digest(_fingerprint(track))}';
  }

  static bool sameIdentity(Track first, Track second) {
    final firstStable = _normalize(first.stableKey);
    final secondStable = _normalize(second.stableKey);
    if (firstStable.isNotEmpty || secondStable.isNotEmpty) {
      return firstStable.isNotEmpty && firstStable == secondStable;
    }

    final firstPath = _normalize(first.normalizedSourcePath);
    final secondPath = _normalize(second.normalizedSourcePath);
    if (firstPath.isNotEmpty || secondPath.isNotEmpty) {
      return firstPath.isNotEmpty && firstPath == secondPath;
    }

    return _fingerprint(first) == _fingerprint(second);
  }

  Future<CachedLyricsRecord?> load(Track track) async {
    final directory = await _cacheDirectory();
    final primary = File('${directory.path}/${identityFor(track)}.json');

    final current = await _readValidated(primary, track);
    if (current != null) return current;
    if (track.id <= 0) return null;
    final legacy = File('${directory.path}/track-${track.id}.json');
    final migrated = await _readValidated(legacy, track);
    if (migrated == null) return null;

    await save(track, migrated.lyrics, source: migrated.source);
    try {
      if (await legacy.exists()) await legacy.delete();
    } catch (_) {}
    return migrated;
  }

  Future<void> save(
    Track track,
    LyricsData lyrics, {
    required String source,
  }) async {
    final directory = await _cacheDirectory();
    final target = File('${directory.path}/${identityFor(track)}.json');
    final temporary = File('${target.path}.tmp');

    final payload = <String, Object?>{
      'schemaVersion': _schemaVersion,
      'trackId': track.id,
      'stableKey': _normalize(track.stableKey),
      'sourcePath': _normalize(track.normalizedSourcePath),
      'fingerprint': _fingerprint(track),
      'source': source,
      'updatedAt': DateTime.now().toUtc().toIso8601String(),
      'lyrics': lyrics.toJson(),
    };

    await temporary.writeAsString(
      jsonEncode(payload),
      flush: true,
    );
    if (await target.exists()) await target.delete();
    await temporary.rename(target.path);
  }

  Future<void> removeTracks(Iterable<Track> tracks) async {
    final directory = await _cacheDirectory();
    for (final track in tracks) {
      final files = <File>[
        File('${directory.path}/${identityFor(track)}.json'),
        if (track.id > 0) File('${directory.path}/track-${track.id}.json'),
      ];
      for (final file in files) {
        try {
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
    }
  }

  Future<void> removeLegacyTrackIds(Iterable<int> trackIds) async {
    final directory = await _cacheDirectory();
    for (final id in trackIds.where((value) => value > 0).toSet()) {
      final file = File('${directory.path}/track-$id.json');
      try {
        if (await file.exists()) await file.delete();
      } catch (_) {}
    }
  }

  Future<CachedLyricsRecord?> _readValidated(
    File file,
    Track track,
  ) async {
    try {
      if (!await file.exists()) return null;
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return null;
      final payload = Map<String, dynamic>.from(decoded);
      if (!_matchesStoredIdentity(payload, track)) return null;

      final rawLyrics = payload['lyrics'];
      if (rawLyrics is! Map) return null;
      final lyrics = LyricsData.fromJson(
        Map<String, dynamic>.from(rawLyrics),
      );
      if (lyrics.lines.isEmpty) return null;

      return CachedLyricsRecord(
        lyrics: lyrics,
        source: payload['source']?.toString() ?? 'manual',
      );
    } catch (_) {
      return null;
    }
  }

  bool _matchesStoredIdentity(
    Map<String, dynamic> payload,
    Track track,
  ) {
    final storedStable = _normalize(payload['stableKey']?.toString());
    final currentStable = _normalize(track.stableKey);
    if (currentStable.isNotEmpty || storedStable.isNotEmpty) {
      return currentStable.isNotEmpty && currentStable == storedStable;
    }

    final storedPath = _normalize(payload['sourcePath']?.toString());
    final currentPath = _normalize(track.normalizedSourcePath);
    if (currentPath.isNotEmpty || storedPath.isNotEmpty) {
      return currentPath.isNotEmpty && currentPath == storedPath;
    }

    return payload['fingerprint']?.toString() == _fingerprint(track);
  }

  Future<Directory> _cacheDirectory() async {
    final existing = _directory;
    if (existing != null) return existing;

    final support = await getApplicationSupportDirectory();
    final directory = Directory('${support.path}/$_directoryName');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    _directory = directory;
    return directory;
  }

  static String _fingerprint(Track track) => <Object>[
        _normalize(track.title),
        _normalize(track.artist),
        _normalize(track.albumName),
        track.duration,
        track.size,
      ].join('|');

  static String _normalize(String? value) => value
          ?.trim()
          .replaceAll('\\', '/')
          .replaceAll(RegExp(r'/+'), '/')
          .toLowerCase() ??
      '';

  static String _digest(String value) => sha256.convert(utf8.encode(value)).toString();
}
