// lib/services/radio/radio_connectivity_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Proactive "you're offline" detection for Radio, backed by connectivity_plus
// (device-level network-interface state — Wi-Fi/cellular/ethernet/none).
//
// This is deliberately narrow: it only ever answers "does the device have
// any network interface up at all". connectivity_plus is explicit that
// interface-up is not the same thing as "the internet actually works" (a
// phone can be joined to a Wi-Fi network with no upstream, e.g. a hotel
// captive portal) — see the package's own README. So this service is only
// the fast, proactive half of offline handling:
//   • RadioConnectivityService (this file) → "no interface at all" → warn
//     before the person even taps play, since a stream attempt is certain
//     to fail.
//   • RadioPlayerService._friendlyMessage (unchanged) → the real backstop.
//     A failed stream connection is always checked for what actually
//     happened (SocketException / failed host lookup / HTTP status), which
//     correctly covers "interface up but no real internet" too. This
//     service does not replace that; it only adds an earlier, cheaper
//     warning for the common case.
//
// Self-contained: only providers/radio_provider.dart depends on this.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

class RadioConnectivityService {
  RadioConnectivityService._();
  static final RadioConnectivityService instance = RadioConnectivityService._();

  final Connectivity _connectivity = Connectivity();

  /// True as soon as any network interface is confirmed down — i.e. every
  /// entry in the platform's result is [ConnectivityResult.none]. False
  /// includes "unknown" (a check that itself failed, or returned an empty
  /// result list): playback's own after-the-fact error handling is the
  /// correct place to react to an actual failed connection, so this
  /// proactive check only ever blocks on a *confirmed* absence of any
  /// interface, never on ambiguity.
  Future<bool> isOffline() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return _isConfirmedOffline(result);
    } catch (_) {
      return false;
    }
  }

  /// Emits `true`/`false` (offline/online) whenever the device's network
  /// interface state changes. Radio uses this to clear a stale "offline"
  /// state the moment connectivity returns, without the person needing to
  /// retry manually.
  Stream<bool> get offlineChanges =>
      _connectivity.onConnectivityChanged.map(_isConfirmedOffline);

  /// `List.every` is vacuously `true` on an empty list, so an empty result
  /// (seen in practice on some platforms/edge cases rather than the
  /// documented `[ConnectivityResult.none]`) would otherwise be
  /// misread as "every entry is none" — i.e. confirmed offline, when it's
  /// really just an inconclusive result. This treats "no entries reported"
  /// the same as "unknown": not confirmed offline.
  bool _isConfirmedOffline(List<ConnectivityResult> result) {
    if (result.isEmpty) return false;
    return result.every((r) => r == ConnectivityResult.none);
  }
}
