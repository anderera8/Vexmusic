// lib/services/radio/radio_api_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Client for the Radio Browser API (https://api.radio-browser.info).
//
// This is a free, open-source, community-run directory of internet radio
// stations. No API key, no auth, no cost — verified before use:
//   • Docs:     https://api.radio-browser.info  /  https://docs.radio-browser.info
//   • Coverage: tens of thousands of live stations worldwide, with tags,
//               country, language, codec, bitrate, favicon, vote and click
//               (recent-plays) counts.
//   • Access:   plain JSON over HTTPS, no key required.
//
// The service is community-run across a handful of named mirror servers
// with no formal uptime SLA, so this client fails over across several
// known-stable mirrors rather than hammering a single host. Only the
// standard library (`dart:io`, `dart:convert`) is used — no new pubspec
// dependency was needed for this.
//
// This file is self-contained: nothing outside `services/radio` and
// `providers/radio_provider.dart` needs to know it exists.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' show compute;

import '../../models/radio_models.dart';

class RadioApiException implements Exception {
  final String message;
  const RadioApiException(this.message);
  @override
  String toString() => message;
}

class RadioApiService {
  RadioApiService._();
  static final RadioApiService instance = RadioApiService._();

  // Known-stable mirror hosts (see the server list linked from
  // https://api.radio-browser.info). Order is shuffled per app run so load
  // spreads across mirrors instead of every install hammering the first one.
  static final List<String> _mirrors = [
    'de1.api.radio-browser.info',
    'de2.api.radio-browser.info',
    'at1.api.radio-browser.info',
    'nl1.api.radio-browser.info',
  ]..shuffle();

  static const Duration _timeout = Duration(seconds: 8);
  static const String _userAgent = 'VibesPlayer/2.2 (Flutter radio feature)';

  String? _lastGoodMirror;
  HttpClient? _client;

  HttpClient get _http => _client ??= HttpClient()
    ..connectionTimeout = _timeout
    ..idleTimeout = const Duration(seconds: 15);

  Future<List<RadioStation>> topStations({int limit = 24}) => _stationList(
        '/json/stations/search',
        {
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          'hidebroken': 'true',
        },
      );

  Future<List<RadioStation>> byTag(String tag, {int limit = 40}) =>
      _stationList(
        '/json/stations/search',
        {
          'tag': tag,
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          'hidebroken': 'true',
        },
      );

  Future<List<RadioStation>> byCountryCode(
    String code, {
    int limit = 60,
    bool includeBroken = false,
  }) =>
      _stationList(
        '/json/stations/search',
        {
          'countrycode': code,
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          // Uganda deliberately includes stations that the directory has
          // recently marked broken. A station can be temporarily offline
          // and still be worth showing; the player explains failures.
          'hidebroken': includeBroken ? 'false' : 'true',
        },
      );

  /// Every station the directory has for [code] — not a preview capped at
  /// some fixed count. Walks `/json/stations/search` page by page using
  /// `offset`/`limit` until a page comes back shorter than [pageSize],
  /// which is the correct end-of-data signal (only the genuinely last page
  /// can be short). This is the paginated counterpart to [byCountryCode]:
  /// that one stays as a capped, single-request preview for callers that
  /// want a small fast fetch; this one is for "the full inventory".
  ///
  /// The directory sorts by `clickcount` live, and click counts can shift
  /// between page requests — with no stable cursor offered by the API,
  /// that means offset-based paging against a live-sorted view can in
  /// theory skip or duplicate an entry right at a page boundary if its
  /// rank crosses the boundary mid-walk. Deduping by UUID across pages
  /// closes the duplicate case; a skipped entry would only recur on a
  /// subsequent full refresh, which is an acceptable trade-off against
  /// paying for a stable-but-far-slower sort like `random` or `name`.
  Future<List<RadioStation>> allByCountryCode(
    String code, {
    bool includeBroken = true,
    int pageSize = 200,
    int maxPages = 50,
  }) async {
    final seen = <String>{};
    final all = <RadioStation>[];

    for (var page = 0; page < maxPages; page++) {
      final batch = await _stationList(
        '/json/stations/search',
        {
          'countrycode': code,
          'order': 'clickcount',
          'reverse': 'true',
          'offset': '${page * pageSize}',
          'limit': '$pageSize',
          'hidebroken': includeBroken ? 'false' : 'true',
        },
      );

      for (final station in batch) {
        final key = station.uuid.isEmpty
            ? '${station.name}|${station.streamUrl}'
            : station.uuid;
        if (seen.add(key)) all.add(station);
      }

      // Short page (fewer than requested) is the correct signal that
      // there's nothing left — not an arbitrary cap. An empty page (e.g.
      // every station on it was broken and includeBroken is true so they
      // were already dropped by _stationList's own filtering) also ends
      // the walk rather than looping on empty pages until maxPages.
      if (batch.length < pageSize) break;
    }

    return all;
  }

  /// Every country the directory currently has at least one station for,
  /// most-populated first. This is the live replacement for what used to
  /// be a fixed, hand-typed country list — a country appears here (and
  /// only here) because it genuinely has stations right now.
  Future<List<RadioCountryDef>> allCountries({bool includeBroken = false}) async {
    final body = await _getRaw(
      '/json/countries',
      query: {
        'order': 'stationcount',
        'reverse': 'true',
        'hidebroken': includeBroken ? 'false' : 'true',
      },
    );
    final data = jsonDecode(body);
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => RadioCountryDef.fromJson(Map<String, dynamic>.from(e)))
        .where((c) => c.code.length == 2 && c.name.isNotEmpty)
        .toList();
  }

  /// Searches by station name, the free-text `state` field, and `tag`, then
  /// merges all three result sets. Name covers "type the station's actual
  /// name". State covers a town or district — "Bushenyi", "Arua",
  /// "Mbarara" — surfacing a station even when that place doesn't appear
  /// in its own name (the `state` search is a substring match server-side,
  /// so "Mbarara" matches a station whose state is recorded as e.g.
  /// "Mbarara District"). Tag covers genre/format words — "jazz", "news"
  /// — the same substring-match query [byTag] uses for the genre grid,
  /// merged in here too so the same word typed into search finds it.
  Future<List<RadioStation>> searchByName(
    String query, {
    int limit = 40,
  }) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    final results = await Future.wait([
      _stationList(
        '/json/stations/search',
        {
          'name': trimmed,
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          'hidebroken': 'true',
        },
      ),
      _stationList(
        '/json/stations/search',
        {
          'state': trimmed,
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          // A district/town search deliberately includes stations the
          // directory has recently marked broken: a small local station
          // going briefly offline shouldn't make it unfindable by name.
          'hidebroken': 'false',
        },
      ),
      _stationList(
        '/json/stations/search',
        {
          'tag': trimmed,
          'order': 'clickcount',
          'reverse': 'true',
          'limit': '$limit',
          'hidebroken': 'true',
        },
      ),
    ]);

    final seen = <String>{};
    final merged = <RadioStation>[];
    // Name matches first, then state, then tag: if someone typed a
    // station's actual name, that's almost always what they meant even
    // when the same word also happens to match a district or a genre tag.
    for (final list in results) {
      for (final station in list) {
        final key = station.uuid.isEmpty
            ? '${station.name}|${station.streamUrl}'
            : station.uuid;
        if (seen.add(key)) merged.add(station);
      }
    }
    return merged;
  }

  /// Tells the directory a station was played. This is the same click a
  /// browser makes when the user hits play — it's how the community
  /// popularity ranking (used for "Trending") stays meaningful, and it's
  /// good etiquette on a free shared service. Best-effort only: failures
  /// are swallowed since this must never block or interrupt playback.
  Future<void> registerClick(String stationUuid) async {
    if (stationUuid.isEmpty) return;
    try {
      await _getRaw('/json/url/$stationUuid');
    } catch (_) {
      // Non-critical — playback already started from the resolved URL we
      // already had, this is purely a popularity-tracking courtesy call.
    }
  }

  /// [allByCountryCode] alone can mean parsing up to 50 pages of 200
  /// stations apiece (10,000 station objects) for a large country's full
  /// inventory. Decoding and mapping that much JSON is real, synchronous
  /// CPU work; done inline it's the kind of thing that's easy to not
  /// notice on a fast dev phone and then see as an ANR in the field on a
  /// slower one, especially stacked page after page in
  /// [allByCountryCode]'s loop. compute() runs it on a background isolate
  /// instead, so the size of a country's station list can never cost the
  /// UI thread anything. (allCountries doesn't get the same treatment —
  /// geography bounds it to at most a few hundred small entries, so the
  /// isolate round-trip would cost more than it saves.)
  Future<List<RadioStation>> _stationList(
    String path,
    Map<String, String> query,
  ) async {
    final body = await _getRaw(path, query: query);
    return compute(_decodeStationListJson, body);
  }

  /// Top-level so it's eligible for [compute] — must not close over any
  /// instance state, since it runs on a different isolate that only ever
  /// receives [body].
  static List<RadioStation> _decodeStationListJson(String body) {
    final data = jsonDecode(body);
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => RadioStation.fromJson(Map<String, dynamic>.from(e)))
        .where((s) => s.hasStream && s.name.isNotEmpty)
        .toList();
  }

  /// Issues a GET against the current mirror, falling back through the
  /// remaining mirrors on connection failure, timeout, or a non-200
  /// response. Throws [RadioApiException] only once every mirror has been
  /// tried and failed.
  ///
  /// Returns the raw response body rather than pre-decoded JSON — callers
  /// decode it themselves, which lets [_stationList] hand the body to
  /// [compute] instead of decoding it inline. See [_decodeStationListJson].
  Future<String> _getRaw(String path, {Map<String, String>? query}) async {
    final ordered = <String>[
      if (_lastGoodMirror != null) _lastGoodMirror!,
      ..._mirrors.where((m) => m != _lastGoodMirror),
    ];

    Object? lastError;

    for (final mirror in ordered) {
      try {
        final uri = Uri.https(mirror, path, query);
        final request = await _http.getUrl(uri).timeout(_timeout);
        request.headers.set(HttpHeaders.userAgentHeader, _userAgent);
        request.headers.set(HttpHeaders.acceptHeader, 'application/json');

        final response = await request.close().timeout(_timeout);

        if (response.statusCode != 200) {
          await response.drain<void>();
          lastError = 'HTTP ${response.statusCode} from $mirror';
          continue;
        }

        final body = await response
            .transform(utf8.decoder)
            .join()
            .timeout(_timeout);

        _lastGoodMirror = mirror;
        return body;
      } catch (e) {
        lastError = e;
        continue;
      }
    }

    throw RadioApiException(
      'Could not reach the radio directory. $lastError',
    );
  }

  void dispose() {
    _client?.close(force: true);
    _client = null;
  }
}
