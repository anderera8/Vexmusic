// lib/services/radio/radio_favorites_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Local persistence for favorite stations and recently-played history.
//
// Uses the app's existing PrefsService (SharedPreferences) — no new
// dependency and no database schema changes. Stations are cached as JSON
// snapshots (name, art, tags, stream url…) rather than just UUIDs, so the
// Favorites / Recently Played screens render instantly offline instead of
// waiting on a network round trip.
// ─────────────────────────────────────────────────────────────────────────────

import '../../models/radio_models.dart';
import '../prefs_service.dart';

class RadioFavoritesService {
  RadioFavoritesService._();
  static final RadioFavoritesService instance = RadioFavoritesService._();

  static const _favoritesKey = 'radio_favorites_v1';
  static const _recentKey = 'radio_recent_v1';
  static const _maxRecent = 25;

  // Two of PrefsService's underlying writes (SharedPreferences, via a
  // platform channel) aren't guaranteed to land in the order they were
  // *started* if they're in flight at the same time — only in the order
  // they're *awaited* here. Two toggleFavorite calls in quick succession
  // (a rapid double-tap) each start a write before the first has
  // finished; without this, whichever write's platform-channel round
  // trip happens to complete last wins, which isn't necessarily the more
  // recent toggle. Chaining each write onto the previous one for the
  // same key forces disk-write order to match call order, so the last
  // toggle is always the one that actually sticks. One chain per key —
  // favorites and recent history don't contend with each other.
  Future<void> _favoritesWriteChain = Future<void>.value();
  Future<void> _recentWriteChain = Future<void>.value();

  List<RadioStation> loadFavorites() =>
      RadioStation.decodeList(PrefsService.getString(_favoritesKey));

  Future<void> saveFavorites(List<RadioStation> stations) {
    final chained = _favoritesWriteChain.then<void>((_) async {
      await PrefsService.setString(
        _favoritesKey,
        RadioStation.encodeList(stations),
      );
    });
    _favoritesWriteChain = chained;
    return chained;
  }

  List<RadioStation> loadRecent() =>
      RadioStation.decodeList(PrefsService.getString(_recentKey));

  /// Pure computation of [current] with [station] moved to the front,
  /// de-duplicated by UUID and capped to [_maxRecent] — no I/O. Callers
  /// apply this synchronously to their own in-memory list (the same
  /// pattern RadioProvider.toggleFavorite already uses for favorites)
  /// before persisting with [saveRecent], rather than awaiting a
  /// round-trip to learn the updated list — otherwise a second station
  /// change arriving before the first's write completes would compute
  /// its own update from a stale base list and silently drop the first
  /// change once both writes land.
  List<RadioStation> withRecentAdded(
    RadioStation station,
    List<RadioStation> current,
  ) {
    return [
      station,
      ...current.where((s) => s.uuid != station.uuid),
    ].take(_maxRecent).toList();
  }

  Future<void> saveRecent(List<RadioStation> stations) {
    final chained = _recentWriteChain.then<void>((_) async {
      await PrefsService.setString(
        _recentKey,
        RadioStation.encodeList(stations),
      );
    });
    _recentWriteChain = chained;
    return chained;
  }

  Future<void> clearRecent() => saveRecent(const []);
}
