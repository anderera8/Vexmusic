// lib/services/radio/radio_player_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// A small, self-contained just_audio wrapper dedicated to live radio
// streaming.
//
// Deliberately independent from services/playback/* (the local-library
// engine): a live stream has no queue, no duration, no seeking, and
// different reconnect behavior than a track queue, so bolting it onto the
// existing engine would add risk for no real benefit. This owns its own
// `AudioPlayer` instance and exposes a simple status stream the provider
// layer can react to.
//
// It does NOT own its own audio focus policy from scratch, though. Android
// and iOS only have one real audio-focus session per app — the app's single
// `AudioSession.instance` from package:audio_session — and
// PlaybackSystemService already owns configuring and activating that
// session for local playback. just_audio's own built-in interruption
// handling defaults to reacting to that same shared session independently
// of PlaybackSystemService, which would mean two uncoordinated listeners
// both deciding what to do about the same phone call or headphone unplug.
// So this disables just_audio's built-in handling
// (handleAudioSessionActivation / handleInterruptions / 
// androidApplyAudioAttributes all false — see _createPlayer) and instead
// reuses AudioInterruptionPolicy, the same decision logic
// PlaybackSystemService uses for music, with its own instance and its own
// `isPlaying` — so both playback surfaces make the same *kind* of decision
// about a given interruption, without literally sharing mutable state
// (which they shouldn't: only one of the two is ever meant to be active at
// a time, per RadioProvider.onWillStartPlayback / pauseForExternalPlayback).
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';

import '../playback/audio_interruption_policy.dart';

enum RadioPlaybackStatus { idle, loading, buffering, playing, paused, error }

class RadioPlayerService {
  AudioPlayer? _player;
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<dynamic>? _icySub;
  StreamSubscription<AudioInterruptionEvent>? _interruptionSub;
  StreamSubscription<dynamic>? _becomingNoisySub;

  final _statusController =
      StreamController<RadioPlaybackStatus>.broadcast();
  final _nowPlayingController = StreamController<String?>.broadcast();
  final _errorController = StreamController<String>.broadcast();

  final _interruptionPolicy = AudioInterruptionPolicy();
  AudioSession? _session;

  RadioPlaybackStatus _status = RadioPlaybackStatus.idle;
  String? _currentUrl;
  /// The other URL to try if [_currentUrl] fails — see [RadioStation]'s own
  /// fallbackUrl doc for what this is and isn't. Cleared once a fallback
  /// attempt has been made so a single station never retries back and
  /// forth between the two URLs indefinitely.
  String? _fallbackUrl;
  int _retryCount = 0;

  RadioPlaybackStatus get status => _status;
  String? get currentUrl => _currentUrl;
  bool get isActive => _currentUrl != null;
  bool get _isPlaying => _status == RadioPlaybackStatus.playing;

  /// Emits whenever playback status changes.
  Stream<RadioPlaybackStatus> get statusStream => _statusController.stream;

  /// Emits the station's live "now playing" text (ICY metadata) when the
  /// stream broadcasts it, or `null` when unavailable/cleared. Purely
  /// decorative — most stations don't send this, and that's fine.
  Stream<String?> get nowPlayingStream => _nowPlayingController.stream;

  /// Emits a user-friendly message whenever playback fails.
  Stream<String> get errorStream => _errorController.stream;

  AudioPlayer get _p => _player ??= _createPlayer();

  AudioPlayer _createPlayer() {
    final player = AudioPlayer(
      userAgent: 'VibesPlayer/2.2 (Flutter radio feature)',
      // All three of these default to `true` in just_audio, and all three
      // touch the app's single shared AudioSession.instance independently
      // of PlaybackSystemService. Disabled here so PlaybackSystemService's
      // stream subscriptions and this class's own _handleInterruption below
      // are the only things ever reacting to focus/route events — never
      // both at once for the same event.
      handleAudioSessionActivation: false,
      handleInterruptions: false,
      androidApplyAudioAttributes: false,
    );

    _stateSub = player.playerStateStream.listen(
      _onStateChanged,
      onError: (e, st) => _fail(e),
    );

    // ICY metadata (live "now playing" text) isn't guaranteed to be
    // supported for every stream/platform combination — keep this
    // best-effort and never let it affect core playback.
    try {
      _icySub = player.icyMetadataStream.listen(
        (meta) {
          final title = meta?.info?.title;
          _nowPlayingController.add(
            (title == null || title.trim().isEmpty) ? null : title.trim(),
          );
        },
        onError: (_) {},
      );
    } catch (_) {
      // Not supported here — the now-playing ticker just stays hidden.
    }

    unawaited(_listenForInterruptions());

    return player;
  }

  Future<void> _listenForInterruptions() async {
    try {
      final session = await _resolveSession();
      _interruptionSub = session.interruptionEventStream.listen(
        _handleInterruption,
        onError: (_, __) {},
      );
      _becomingNoisySub = session.becomingNoisyEventStream.listen(
        (_) => _handleBecomingNoisy(),
        onError: (_) {},
      );
    } catch (_) {
      // If the session can't be reached, radio simply gets no interruption
      // handling rather than crashing playback setup over it.
    }
  }

  void _handleInterruption(AudioInterruptionEvent event) {
    final command = _interruptionPolicy.handle(event, isPlaying: _isPlaying);
    switch (command) {
      case AudioInterruptionCommand.none:
        return;
      case AudioInterruptionCommand.duck:
      case AudioInterruptionCommand.restoreVolume:
        // A live stream's own volume control isn't exposed at this layer
        // today (see just_audio's setVolume if that's ever added here) —
        // ducking is a no-op for radio for now rather than guessing at a
        // volume API that isn't wired up.
        return;
      case AudioInterruptionCommand.pause:
        _pauseForInterruption();
        return;
      case AudioInterruptionCommand.resume:
        unawaited(resume());
        return;
    }
  }

  void _handleBecomingNoisy() {
    if (!_isPlaying) return;
    _interruptionPolicy.registerNoisyRoutePause();
    _pauseForInterruption();
  }

  /// Pauses for a non-user reason (audio focus loss, headphone unplug).
  /// Unlike [pause], this deliberately does NOT release the audio session —
  /// doing so mid-interruption could let some other app claim focus
  /// permanently instead of it being handed back when the interruption
  /// ends, mirroring how PlaybackSystemService treats an audioFocus pause
  /// for local playback.
  void _pauseForInterruption() {
    unawaited(_p.pause().catchError((Object _) {}));
  }

  /// Loads and starts playing a stream URL from scratch. [fallbackUrl], if
  /// given, is tried once — automatically, with no separate user action —
  /// if [streamUrl] fails outright (setUrl/play throwing, e.g. a bad
  /// redirect or a refused connection on the resolved URL). This is
  /// distinct from the same-URL retry in [_onStateChanged]'s
  /// `ProcessingState.completed` handling, which is for a stream that
  /// connected fine and then dropped mid-play — a different failure mode
  /// that a different URL wouldn't fix, so that path is untouched.
  Future<bool> play(String streamUrl, {String? fallbackUrl}) async {
    _retryCount = 0;
    _fallbackUrl = (fallbackUrl != null && fallbackUrl.trim().isNotEmpty)
        ? fallbackUrl.trim()
        : null;
    _interruptionPolicy.registerExplicitPlay();
    return _playInternal(streamUrl);
  }

  Future<bool> _playInternal(String streamUrl) async {
    _currentUrl = streamUrl;
    _nowPlayingController.add(null);
    _setStatus(RadioPlaybackStatus.loading);

    try {
      if (!await _activateSession()) {
        _fail(StateError('audio focus not granted'));
        return false;
      }
      await _p.setUrl(streamUrl);
      await _p.play();
      return true;
    } catch (e) {
      return _handleFailure(e);
    }
  }

  /// Tries [_fallbackUrl] once, if one is set, before surfacing [error] as
  /// a real failure. Consumes the fallback either way it's used — if the
  /// fallback attempt itself also throws, [_playInternal]'s own catch
  /// calls this again, sees `_fallbackUrl` already cleared, and falls
  /// through to [_fail] — so this can never loop between the two URLs.
  Future<bool> _handleFailure(Object error) async {
    final fallback = _fallbackUrl;
    if (fallback != null) {
      _fallbackUrl = null;
      return _playInternal(fallback);
    }
    _fail(error);
    return false;
  }

  Future<void> pause() async {
    _interruptionPolicy.registerExplicitPause();
    try {
      await _p.pause();
    } catch (_) {
      // Pausing a stream that already dropped is harmless to ignore.
    } finally {
      await _deactivateSession();
    }
  }

  /// Resumes the currently loaded station. No-op if nothing has ever been
  /// loaded (use [play] first).
  Future<void> resume() async {
    if (_currentUrl == null) return;
    try {
      if (!await _activateSession()) {
        _fail(StateError('audio focus not granted'));
        return;
      }
      _setStatus(RadioPlaybackStatus.loading);
      await _p.play();
    } catch (e) {
      _fail(e);
    }
  }

  /// Fully stops and releases the current stream (used when switching
  /// stations or leaving radio entirely). The player instance itself is
  /// kept warm for the next station.
  Future<void> stop() async {
    _currentUrl = null;
    _interruptionPolicy.registerExplicitStop();
    try {
      await _p.stop();
    } catch (_) {
      // Already stopped/errored — nothing further to clean up.
    } finally {
      await _deactivateSession();
    }
    _nowPlayingController.add(null);
    _setStatus(RadioPlaybackStatus.idle);
  }

  /// Pauses without touching explicit-pause bookkeeping — used when
  /// RadioProvider pauses radio because local music started instead (see
  /// pauseForExternalPlayback in radio_provider.dart). Deliberately reuses
  /// the *interruption* pause path, not [pause]: this isn't the user
  /// choosing to pause, and unlike stop() the station should stay loaded
  /// and resumable, matching pauseForExternalPlayback's own contract.
  Future<void> pauseForExternalPlayback() async {
    if (!_isPlaying) return;
    _pauseForInterruption();
  }

  Future<AudioSession> _resolveSession() async {
    return _session ??= await AudioSession.instance;
  }

  Future<bool> _activateSession() async {
    try {
      final session = await _resolveSession();
      return await session.setActive(true);
    } catch (_) {
      return false;
    }
  }

  Future<void> _deactivateSession() async {
    try {
      final session = await _resolveSession();
      await session.setActive(false);
    } catch (_) {
      // Best-effort — a failed release here doesn't affect radio's own
      // playback state, only whether focus is promptly given back up.
    }
  }

  void _onStateChanged(PlayerState state) {
    switch (state.processingState) {
      case ProcessingState.idle:
        _setStatus(RadioPlaybackStatus.idle);
        break;

      case ProcessingState.loading:
        _setStatus(RadioPlaybackStatus.loading);
        break;

      case ProcessingState.buffering:
        _setStatus(RadioPlaybackStatus.buffering);
        break;

      case ProcessingState.ready:
        _retryCount = 0;
        _setStatus(
          state.playing ? RadioPlaybackStatus.playing : RadioPlaybackStatus.paused,
        );
        break;

      case ProcessingState.completed:
        // A *live* stream reporting "completed" almost always means the
        // connection was dropped rather than content genuinely ending.
        // Retry once automatically (brief drops are common on mobile
        // networks) before surfacing it as a real error.
        final url = _currentUrl;
        if (url != null && _retryCount < 1) {
          _retryCount++;
          unawaited(_playInternal(url));
        } else {
          _errorController.add('The station stopped unexpectedly.');
          _setStatus(RadioPlaybackStatus.error);
        }
        break;
    }
  }

  void _fail(Object error) {
    _setStatus(RadioPlaybackStatus.error);
    _errorController.add(_friendlyMessage(error));
  }

  String _friendlyMessage(Object error) {
    final msg = error.toString().toLowerCase();
    if (msg.contains('socketexception') ||
        msg.contains('failed host lookup') ||
        msg.contains('network')) {
      return 'No internet connection.';
    }
    if (msg.contains('404') || msg.contains('403')) {
      return 'This station is currently offline.';
    }
    return "Couldn't play this station right now.";
  }

  void _setStatus(RadioPlaybackStatus status) {
    _status = status;
    if (!_statusController.isClosed) _statusController.add(status);
  }

  Future<void> dispose() async {
    await _stateSub?.cancel();
    await _icySub?.cancel();
    await _interruptionSub?.cancel();
    await _becomingNoisySub?.cancel();
    await _statusController.close();
    await _nowPlayingController.close();
    await _errorController.close();
    await _player?.dispose();
    _player = null;
  }
}
