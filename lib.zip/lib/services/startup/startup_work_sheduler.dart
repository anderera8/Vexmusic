import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/scheduler.dart';

typedef StartupWork = FutureOr<void> Function();

class StartupTask {
  const StartupTask({
    required this.name,
    required this.work,
    this.delay = Duration.zero,
  });

  final String name;
  final StartupWork work;
  final Duration delay;
}

/// Runs noncritical startup jobs serially after the first frame.
///
/// Serial execution avoids Firebase, migration, cleanup, and platform setup
/// competing for the UI thread and database connection at the same instant.
class StartupWorkScheduler {
  const StartupWorkScheduler._();

  static Future<void> run(List<StartupTask> tasks) async {
    await SchedulerBinding.instance.endOfFrame;

    for (final task in tasks) {
      if (task.delay > Duration.zero) {
        await Future<void>.delayed(task.delay);
      }

      final stopwatch = Stopwatch()..start();
      try {
        await task.work();
      } catch (error, stackTrace) {
        debugPrint('[Startup] ${task.name} failed: $error');
        debugPrintStack(stackTrace: stackTrace);
      } finally {
        stopwatch.stop();
        debugPrint(
          '[Startup] ${task.name} completed in '
          '${stopwatch.elapsedMilliseconds} ms',
        );
      }

      await SchedulerBinding.instance.endOfFrame;
    }
  }
}
