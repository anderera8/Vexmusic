// lib/services/platform/audio_spectrum_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Dart-side bridge to the Android Goertzel spectrum analyser.
//
// The Android SoftwareEqProcessor runs a 10-band Goertzel FFT on the
// live audio stream.  This service listens via EventChannel and provides
// a broadcast Stream<List<double>> of normalised magnitudes (0.0–1.0).
//
// Channel: "vexmusic/audio_spectrum"
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Streaming spectrum data from the native Goertzel FFT analyser.
///
/// Usage:
/// ```dart
/// final spectrum = AudioSpectrumService.instance;
/// spectrum.magnitudeStream.listen((magnitudes) {
///   // magnitudes[0] = 31 Hz, magnitudes[9] = 16 kHz (0.0–1.0)
/// });
/// ```
class AudioSpectrumService {
  static const _channelName = 'vexmusic/audio_spectrum';

  static AudioSpectrumService? _instance;

  /// The shared singleton.
  static AudioSpectrumService get instance =>
      _instance ??= AudioSpectrumService._();

  AudioSpectrumService._();

  /// Whether the current platform is supported (Android only).
  static bool get isSupported => !kIsWeb && Platform.isAndroid;

  EventChannel? _eventChannel;
  StreamSubscription? _subscription;
  StreamController<List<double>>? _magnitudeController;

  bool _isListening = false;

  /// Broadcast stream of normalised magnitudes (0.0–1.0) for all 10 EQ bands.
  ///
  /// Index → frequency: 0=31, 1=62, 2=125, 3=250, 4=500,
  ///                    5=1k, 6=2k, 7=4k, 8=8k, 9=16k Hz.
  Stream<List<double>> get magnitudeStream {
    _ensureController();
    return _magnitudeController!.stream;
  }

  /// Whether the spectrum stream is active.
  bool get isListening => _isListening;

  /// Start listening to the spectrum EventChannel.
  void _ensureController() {
    if (!isSupported) return;
    if (_magnitudeController != null) return;

    _magnitudeController = StreamController<List<double>>.broadcast(
      onListen: _startListening,
      onCancel: stop,
    );
  }

  void _startListening() {
    if (!isSupported || _isListening) return;
    _eventChannel = const EventChannel(_channelName);
    _subscription = _eventChannel!.receiveBroadcastStream().listen(
      (dynamic data) {
        if (data is List<dynamic>) {
          try {
            final magnitudes =
                data.map((e) => (e as num).toDouble().clamp(0.0, 1.0)).toList();
            if (magnitudes.length >= 10) {
              _magnitudeController?.add(magnitudes.sublist(0, 10));
            }
          } catch (_) {
            // Malformed data — skip this frame
          }
        }
      },
      onError: (dynamic error) {
        debugPrint('[AudioSpectrum] EventChannel error: $error');
      },
    );

    _isListening = true;
    debugPrint('[AudioSpectrum] Listening to native spectrum stream');
  }

  /// Stop listening and release resources.
  void stop() {
    if (!_isListening) return;
    _subscription?.cancel();
    _subscription = null;
    _isListening = false;
  }
}
