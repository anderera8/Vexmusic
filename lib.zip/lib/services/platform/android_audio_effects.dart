import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Flutter bridge for the process-scoped software DSP chain injected into
/// just_audio's ExoPlayer renderer.
class AndroidAudioEffects {
  static const MethodChannel _channel = MethodChannel('vexmusic/audio_effects');

  static AndroidAudioEffects? _instance;

  static AndroidAudioEffects get instance =>
      _instance ??= AndroidAudioEffects._();

  AndroidAudioEffects._();

  bool _initialized = false;
  bool _available = false;
  String? _lastError;
  int _requestRevision = 0;
  Future<void> _applyTail = Future<void>.value();

  List<EqualizerBandInfo> _equalizerBands = <EqualizerBandInfo>[];

  static bool get isSupported => !kIsWeb && Platform.isAndroid;

  bool get isInitialized => _initialized;
  bool get isAvailable => _available;
  String? get lastError => _lastError;

  bool get loudnessEnhancerAvailable => _available;
  bool get virtualizerAvailable => _available;
  bool get equalizerAvailable => _available;

  List<EqualizerBandInfo> get equalizerBands =>
      List<EqualizerBandInfo>.unmodifiable(_equalizerBands);

  /// Confirms that the custom renderer factory has attached the processor.
  /// Initialization is intentionally retryable because the Flutter channel may
  /// be ready before just_audio has built its AudioSink.
  Future<bool> initialize([int sessionId = 0]) async {
    if (!isSupported) {
      _initialized = true;
      _available = false;
      _lastError = 'Software audio effects are available on Android only.';
      return false;
    }

    try {
      final result = await _channel.invokeMapMethod<String, dynamic>(
        'initializeEffects',
        <String, dynamic>{'sessionId': sessionId},
      );

      if (result == null) {
        _initialized = false;
        _available = false;
        _lastError = 'The native audio-effects bridge returned no status.';
        return false;
      }

      final rawBands = result['bands'];
      _equalizerBands = rawBands is List
          ? rawBands
              .whereType<Map>()
              .map(
                (raw) => EqualizerBandInfo(
                  band: (raw['band'] as num?)?.toInt() ?? 0,
                  centerFrequencyHz:
                      (raw['centerFreqHz'] as num?)?.toDouble() ?? 0,
                  minDb: (raw['minDb'] as num?)?.toDouble() ?? -12,
                  maxDb: (raw['maxDb'] as num?)?.toDouble() ?? 12,
                ),
              )
              .toList(growable: false)
          : <EqualizerBandInfo>[];

      _available = result['softwareEqAvailable'] == true &&
          result['rendererAttached'] == true &&
          _equalizerBands.length == 10;
      _initialized = _available;
      _lastError = _available
          ? null
          : (result['message'] as String? ??
              'The software DSP renderer is not attached.');

      debugPrint(
        '[SoftwareEQ] availability=$_available, '
        'rendererAttached=${result['rendererAttached']}, '
        'processorConfigured=${result['processorConfigured']}',
      );
      return _available;
    } on PlatformException catch (error, stackTrace) {
      _initialized = false;
      _available = false;
      _lastError = error.message ?? error.code;
      debugPrint('[SoftwareEQ] initialize failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      return false;
    } catch (error, stackTrace) {
      _initialized = false;
      _available = false;
      _lastError = error.toString();
      debugPrint('[SoftwareEQ] initialize failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      return false;
    }
  }

  /// Atomically applies the complete DSP configuration. Rapid UI updates are
  /// coalesced so only the newest state crosses the method channel.
  Future<bool> applyConfiguration({
    required bool enabled,
    required List<double> bandGainsDb,
    required double bassBoost,
    required double volumeBoost,
    required double stereoWidth,
    required bool normalization,
  }) async {
    if (bandGainsDb.length != 10) {
      throw ArgumentError.value(
        bandGainsDb.length,
        'bandGainsDb.length',
        'Expected exactly 10 equalizer bands.',
      );
    }

    if (!isSupported) return false;
    if (!_initialized && !await initialize()) return false;

    final revision = ++_requestRevision;
    final completer = Completer<bool>();
    final payload = <String, dynamic>{
      'enabled': enabled,
      'gains': bandGainsDb
          .map((value) => value.clamp(-12.0, 12.0).toDouble())
          .toList(growable: false),
      'bassBoost': bassBoost.clamp(0.0, 1.0),
      'volumeBoost': volumeBoost.clamp(0.0, 1.0),
      'stereoWidth': stereoWidth.clamp(1.0, 1.5),
      'normalization': normalization,
      'revision': revision,
    };

    _applyTail = _applyTail.then((_) async {
      if (revision != _requestRevision) {
        completer.complete(true);
        return;
      }

      try {
        final result = await _channel.invokeMapMethod<String, dynamic>(
          'applyConfiguration',
          payload,
        );
        final applied = result?['applied'] == true;
        if (!applied) {
          _lastError = result?['message'] as String? ??
              'The native processor rejected the DSP configuration.';
        } else {
          _lastError = null;
        }
        completer.complete(applied);
      } on PlatformException catch (error, stackTrace) {
        _lastError = error.message ?? error.code;
        debugPrint('[SoftwareEQ] applyConfiguration failed: $error');
        debugPrintStack(stackTrace: stackTrace);
        completer.completeError(
          AudioEffectsException(
            code: error.code,
            message: _lastError!,
            cause: error,
          ),
          stackTrace,
        );
      } catch (error, stackTrace) {
        _lastError = error.toString();
        debugPrint('[SoftwareEQ] applyConfiguration failed: $error');
        debugPrintStack(stackTrace: stackTrace);
        completer.completeError(
          AudioEffectsException(
            code: 'APPLY_FAILED',
            message: _lastError!,
            cause: error,
          ),
          stackTrace,
        );
      }
    });

    return completer.future;
  }

  Future<bool> setBandGains(List<double> gains) => _invokeBoolean(
        'setBandGains',
        <String, dynamic>{'gains': gains},
      );

  Future<bool> setBandGain(int band, double gainDb) => _invokeBoolean(
        'setBandGain',
        <String, dynamic>{'band': band, 'gainDb': gainDb},
      );

  Future<bool> setEnabled(bool enabled) => _invokeBoolean(
        'setEnabled',
        <String, dynamic>{'enabled': enabled},
      );

  Future<bool> setLoudnessEnhancer(int gainMb) => _invokeBoolean(
        'setLoudnessEnhancer',
        <String, dynamic>{'gainMb': gainMb},
      );

  Future<bool> setVirtualizer(int strength) => _invokeBoolean(
        'setVirtualizer',
        <String, dynamic>{'strength': strength},
      );

  Future<bool> setVolumeGain(double gain) => _invokeBoolean(
        'setVolumeGain',
        <String, dynamic>{'gain': gain.clamp(1.0, 1.5)},
      );

  Future<bool> setStereoWidth(double width) => _invokeBoolean(
        'setStereoWidth',
        <String, dynamic>{'width': width.clamp(1.0, 1.5)},
      );

  Future<bool> setEqualizer(List<EqualizerBand> bands) {
    final gains = List<double>.filled(10, 0);
    for (final band in bands) {
      if (band.band >= 0 && band.band < gains.length) {
        gains[band.band] = band.gainMb / 100.0;
      }
    }
    return setBandGains(gains);
  }

  Future<bool> resetAll() => _invokeBoolean('resetAll');

  Future<bool> _invokeBoolean(
    String method, [
    Map<String, dynamic>? arguments,
  ]) async {
    if (!isSupported) return false;
    if (!_initialized && !await initialize()) return false;

    try {
      final value = await _channel.invokeMethod<bool>(method, arguments);
      if (value != true) {
        _lastError = 'Native method $method did not confirm success.';
        return false;
      }
      _lastError = null;
      return true;
    } on PlatformException catch (error, stackTrace) {
      _lastError = error.message ?? error.code;
      debugPrint('[SoftwareEQ] $method failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      throw AudioEffectsException(
        code: error.code,
        message: _lastError!,
        cause: error,
      );
    }
  }

  Future<void> release() async {
    _requestRevision++;
    _initialized = false;
    _available = false;
    _equalizerBands = <EqualizerBandInfo>[];
  }
}

class AudioEffectsException implements Exception {
  const AudioEffectsException({
    required this.code,
    required this.message,
    this.cause,
  });

  final String code;
  final String message;
  final Object? cause;

  @override
  String toString() => 'AudioEffectsException($code): $message';
}

class EqualizerBandInfo {
  const EqualizerBandInfo({
    required this.band,
    required this.centerFrequencyHz,
    required this.minDb,
    required this.maxDb,
  });

  final int band;
  final double centerFrequencyHz;
  final double minDb;
  final double maxDb;
}

class EqualizerBand {
  const EqualizerBand({
    required this.band,
    required this.gainMb,
  });

  final int band;
  final int gainMb;
}
