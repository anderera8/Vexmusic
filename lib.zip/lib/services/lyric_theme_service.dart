import 'dart:convert';
import 'prefs_service.dart';

/// Manages lyric theme preferences (fonts, colors, background).
class LyricThemeService {
  static const _key = 'lyric_theme_settings';

  static Future<LyricThemeSettings> getSettings() async {
    final prefs = PrefsService.instance;
    final raw = prefs.getString(_key);
    if (raw == null) return const LyricThemeSettings();
    try {
      return LyricThemeSettings.fromJson(jsonDecode(raw));
    } catch (_) {
      return const LyricThemeSettings();
    }
  }

  static Future<void> saveSettings(LyricThemeSettings settings) async {
    final prefs = PrefsService.instance;
    await prefs.setString(_key, jsonEncode(settings.toJson()));
  }
}

class LyricThemeSettings {
  /// Font family for lyrics
  final String fontFamily;

  /// Font size for active line
  final double activeFontSize;

  /// Font size for inactive lines
  final double inactiveFontSize;

  /// Active line color (0xAARRGGBB)
  final int activeColor;

  /// Inactive line color
  final int inactiveColor;

  /// Background color for lyrics screen
  final int backgroundColor;

  /// Whether to show a gradient behind lyrics
  final bool showGradient;

  /// Text alignment
  final String textAlign;

  /// Whether the active line highlights word-by-word as it plays, instead
  /// of the whole line lighting up at once.
  final bool karaokeMode;

  const LyricThemeSettings({
    this.fontFamily = 'Default',
    this.activeFontSize = 22,
    this.inactiveFontSize = 17,
    this.activeColor = 0xFFFFFFFF,
    this.inactiveColor = 0x80FFFFFF,
    this.backgroundColor = 0xFF0A0A14,
    this.showGradient = false,
    this.textAlign = 'center',
    this.karaokeMode = false,
  });

  LyricThemeSettings copyWith({
    String? fontFamily,
    double? activeFontSize,
    double? inactiveFontSize,
    int? activeColor,
    int? inactiveColor,
    int? backgroundColor,
    bool? showGradient,
    String? textAlign,
    bool? karaokeMode,
  }) =>
      LyricThemeSettings(
        fontFamily: fontFamily ?? this.fontFamily,
        activeFontSize: activeFontSize ?? this.activeFontSize,
        inactiveFontSize: inactiveFontSize ?? this.inactiveFontSize,
        activeColor: activeColor ?? this.activeColor,
        inactiveColor: inactiveColor ?? this.inactiveColor,
        backgroundColor: backgroundColor ?? this.backgroundColor,
        showGradient: showGradient ?? this.showGradient,
        textAlign: textAlign ?? this.textAlign,
        karaokeMode: karaokeMode ?? this.karaokeMode,
      );

  Map<String, dynamic> toJson() => {
        'fontFamily': fontFamily,
        'activeFontSize': activeFontSize,
        'inactiveFontSize': inactiveFontSize,
        'activeColor': activeColor,
        'inactiveColor': inactiveColor,
        'backgroundColor': backgroundColor,
        'showGradient': showGradient,
        'textAlign': textAlign,
        'karaokeMode': karaokeMode,
      };

  factory LyricThemeSettings.fromJson(Map<String, dynamic> json) =>
      LyricThemeSettings(
        fontFamily: json['fontFamily'] as String? ?? 'Default',
        activeFontSize: (json['activeFontSize'] as num?)?.toDouble() ?? 22,
        inactiveFontSize: (json['inactiveFontSize'] as num?)?.toDouble() ?? 17,
        activeColor: json['activeColor'] as int? ?? 0xFFFFFFFF,
        inactiveColor: json['inactiveColor'] as int? ?? 0x80FFFFFF,
        backgroundColor: json['backgroundColor'] as int? ?? 0xFF0A0A14,
        showGradient: json['showGradient'] as bool? ?? false,
        textAlign: json['textAlign'] as String? ?? 'center',
        karaokeMode: json['karaokeMode'] as bool? ?? false,
      );

  String? get resolvedFontFamily => switch (fontFamily) {
        'Serif' => 'serif',
        'Monospace' => 'monospace',
        'Cursive' => 'cursive',
        'Fantasy' => 'sans-serif-black',
        _ => null,
      };
}
