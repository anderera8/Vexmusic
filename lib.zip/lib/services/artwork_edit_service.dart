import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';

import '../models/music_models.dart';
import 'artwork_cache_service.dart';
import 'audio_file_operations_service.dart';

@immutable
class ArtworkEditResult {
  const ArtworkEditResult._({
    required this.success,
    required this.cancelled,
    required this.message,
    this.imageBytes,
    this.mimeType,
  });

  const ArtworkEditResult.success({
    required Uint8List imageBytes,
    required String mimeType,
  }) : this._(
          success: true,
          cancelled: false,
          message: 'Artwork updated',
          imageBytes: imageBytes,
          mimeType: mimeType,
        );

  const ArtworkEditResult.cancelled([
    String message = 'Artwork selection cancelled',
  ]) : this._(
          success: false,
          cancelled: true,
          message: message,
        );

  const ArtworkEditResult.failure(
    String message,
  ) : this._(
          success: false,
          cancelled: false,
          message: message,
        );

  final bool success;
  final bool cancelled;
  final String message;
  final Uint8List? imageBytes;
  final String? mimeType;
}

class ArtworkEditService {
  ArtworkEditService._();

  static const int _maxImageBytes =
      8 * 1024 * 1024;

  static Future<ArtworkEditResult>
      pickAndSetArtwork({
    required Track track,
    AudioFileOperationsService?
        fileOperations,
  }) async {
    final validationFailure =
        _validateTrack(track);

    if (validationFailure != null) {
      return ArtworkEditResult.failure(
        validationFailure,
      );
    }

    final PlatformFile? selectedFile;

    try {
      selectedFile =
          await FilePicker.pickFile(
        type: FileType.image,
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkEditService] Artwork '
        'picker failed: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      return const ArtworkEditResult.failure(
        'Could not open the image picker.',
      );
    }

    if (selectedFile == null) {
      return const ArtworkEditResult
          .cancelled();
    }

    final Uint8List imageBytes;

    try {
      imageBytes =
          await _readPickedImageBytes(
        selectedFile,
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkEditService] Failed to '
        'read selected artwork: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      return const ArtworkEditResult.failure(
        'Could not read the selected image.',
      );
    }

    if (imageBytes.isEmpty) {
      return const ArtworkEditResult.failure(
        'Could not read the selected image.',
      );
    }

    if (imageBytes.lengthInBytes >
        _maxImageBytes) {
      return const ArtworkEditResult.failure(
        'Selected image is too large. '
        'Choose an image smaller than 8 MB.',
      );
    }

    final mimeType = _detectMimeType(
      selectedFile.name,
      imageBytes,
    );

    if (mimeType == null) {
      return const ArtworkEditResult.failure(
        'Unsupported image type. Choose a '
        'JPEG, PNG, or WebP image.',
      );
    }

    try {
      final operations =
          fileOperations ??
              AudioFileOperationsService();

      final updated =
          await operations.writeArtwork(
        track: track,
        imageBytes: imageBytes,
        mimeType: mimeType,
      );

      if (!updated) {
        return const ArtworkEditResult.failure(
          'Artwork update failed.',
        );
      }
    } on AudioFileEditException catch (
      error,
      stackTrace
    ) {
      debugPrint(
        '[ArtworkEditService] Native '
        'artwork update failed: '
        '${error.code} ${error.message}',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      if (error.code == 'WRITE_CANCELLED') {
        return ArtworkEditResult.cancelled(
          error.message,
        );
      }

      return ArtworkEditResult.failure(
        error.message,
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkEditService] Artwork '
        'update failed: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      return const ArtworkEditResult.failure(
        'Artwork update failed.',
      );
    }

    try {
      await ArtworkCacheService
          .invalidateArtwork(
        mediaStoreId:
            track.mediaStoreId,
        volumeName: track.volumeName,
        stableKey: track.stableKey,
        trackId: track.id,
      );

      await ArtworkCacheService
          .cacheWrittenArtworkBytes(
        bytes: imageBytes,
        mediaStoreId:
            track.mediaStoreId,
        volumeName: track.volumeName,
        stableKey: track.stableKey,
        trackId: track.id,
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkEditService] Artwork '
        'was written, but cache refresh '
        'failed: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );
    }

    return ArtworkEditResult.success(
      imageBytes: imageBytes,
      mimeType: mimeType,
    );
  }

  static String? _validateTrack(
    Track track,
  ) {
    if (!Platform.isAndroid) {
      return 'Writing embedded audio '
          'artwork is currently supported '
          'on Android only.';
    }

    if (track.mediaStoreId <= 0) {
      return 'This track has no valid '
          'MediaStore identity.';
    }

    final hasPath =
        track.filePath
                ?.trim()
                .isNotEmpty ==
            true;

    final hasUri =
        track.playbackUri
                ?.trim()
                .isNotEmpty ==
            true;

    final hasVolume =
        track.volumeName.trim().isNotEmpty;

    if (!hasPath && !hasUri && !hasVolume) {
      return 'This track has no editable '
          'MediaStore source.';
    }

    final format =
        AudioFileOperationsService
            .formatInfoForTrack(track);

    if (!format.supportsArtwork) {
      return '${format.label} artwork '
          'editing is not supported. '
          'Supported formats are MP3, '
          'M4A, MP4, FLAC, OGG, and WAV.';
    }

    return null;
  }

  static Future<Uint8List>
      _readPickedImageBytes(
    PlatformFile file,
  ) async {
    final bytes = await file.readAsBytes();

    if (bytes.isEmpty) {
      return Uint8List(0);
    }

    if (bytes.lengthInBytes > _maxImageBytes) {
      throw const FileSystemException(
        'Selected artwork exceeds the '
        'maximum supported size.',
      );
    }

    return bytes;
  }

  static String? _detectMimeType(
    String fileName,
    Uint8List bytes,
  ) {
    if (_isPng(bytes)) {
      return 'image/png';
    }

    if (_isJpeg(bytes)) {
      return 'image/jpeg';
    }

    if (_isWebP(bytes)) {
      return 'image/webp';
    }

    final lower =
        fileName.trim().toLowerCase();

    if (lower.endsWith('.png')) {
      return 'image/png';
    }

    if (lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg')) {
      return 'image/jpeg';
    }

    if (lower.endsWith('.webp')) {
      return 'image/webp';
    }

    return null;
  }

  static bool _isPng(
    Uint8List bytes,
  ) {
    return bytes.length >= 8 &&
        bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4e &&
        bytes[3] == 0x47 &&
        bytes[4] == 0x0d &&
        bytes[5] == 0x0a &&
        bytes[6] == 0x1a &&
        bytes[7] == 0x0a;
  }

  static bool _isJpeg(
    Uint8List bytes,
  ) {
    return bytes.length >= 3 &&
        bytes[0] == 0xff &&
        bytes[1] == 0xd8 &&
        bytes[2] == 0xff;
  }

  static bool _isWebP(
    Uint8List bytes,
  ) {
    return bytes.length >= 12 &&
        bytes[0] == 0x52 &&
        bytes[1] == 0x49 &&
        bytes[2] == 0x46 &&
        bytes[3] == 0x46 &&
        bytes[8] == 0x57 &&
        bytes[9] == 0x45 &&
        bytes[10] == 0x42 &&
        bytes[11] == 0x50;
  }
}
