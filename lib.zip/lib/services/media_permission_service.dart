import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

import 'native_media_library_service.dart';

enum MediaPermissionState {
  granted,
  notRequired,
  denied,
  permanentlyDenied,
  restricted,
  error,
}

@immutable
class MediaPermissionResult {
  const MediaPermissionResult({
    required this.state,
    required this.nativeGranted,
    this.audioStatus,
    this.storageStatus,
    this.error,
    this.stackTrace,
  });

  final MediaPermissionState state;
  final bool nativeGranted;
  final PermissionStatus? audioStatus;
  final PermissionStatus? storageStatus;
  final Object? error;
  final StackTrace? stackTrace;

  bool get granted =>
      state == MediaPermissionState.granted ||
      state == MediaPermissionState.notRequired;

  bool get canRequest => state == MediaPermissionState.denied;

  bool get shouldOpenSettings =>
      state == MediaPermissionState.permanentlyDenied ||
      state == MediaPermissionState.restricted;

  String get message {
    switch (state) {
      case MediaPermissionState.granted:
        return 'Audio media access is granted.';
      case MediaPermissionState.notRequired:
        return 'Audio media permission is not required on this platform.';
      case MediaPermissionState.denied:
        return 'Audio media permission has not been granted.';
      case MediaPermissionState.permanentlyDenied:
        return 'Audio media permission is blocked. Enable it in app settings.';
      case MediaPermissionState.restricted:
        return 'Audio media access is restricted by the operating system.';
      case MediaPermissionState.error:
        return 'Audio permission status could not be verified.';
    }
  }
}

class MediaPermissionService {
  MediaPermissionService({
    NativeMediaLibraryService? mediaLibrary,
  }) : _mediaLibrary = mediaLibrary ?? NativeMediaLibraryService.instance;

  static MediaPermissionService? _instance;

  static MediaPermissionService get instance =>
      _instance ??= MediaPermissionService();

  final NativeMediaLibraryService _mediaLibrary;

  Future<MediaPermissionResult>? _activeRequest;

  Future<MediaPermissionResult> check() async {
    if (kIsWeb || !Platform.isAndroid) {
      return const MediaPermissionResult(
        state: MediaPermissionState.notRequired,
        nativeGranted: false,
      );
    }

    bool nativeGranted;

    try {
      nativeGranted = await _mediaLibrary.hasPermission();
    } catch (error, stackTrace) {
      return MediaPermissionResult(
        state: MediaPermissionState.error,
        nativeGranted: false,
        error: error,
        stackTrace: stackTrace,
      );
    }

    final statuses = await Future.wait<PermissionStatus?>([
      _readStatus(Permission.audio),
      _readStatus(Permission.storage),
    ]);

    final audioStatus = statuses[0];
    final storageStatus = statuses[1];

    if (nativeGranted) {
      return MediaPermissionResult(
        state: MediaPermissionState.granted,
        nativeGranted: true,
        audioStatus: audioStatus,
        storageStatus: storageStatus,
      );
    }

    final knownStatuses = <PermissionStatus>[
      if (audioStatus != null) audioStatus,
      if (storageStatus != null) storageStatus,
    ];

    if (knownStatuses.isEmpty) {
      return const MediaPermissionResult(
        state: MediaPermissionState.error,
        nativeGranted: false,
      );
    }

    if (knownStatuses.any((status) => status.isDenied)) {
      return MediaPermissionResult(
        state: MediaPermissionState.denied,
        nativeGranted: false,
        audioStatus: audioStatus,
        storageStatus: storageStatus,
      );
    }

    if (knownStatuses.any((status) => status.isRestricted)) {
      return MediaPermissionResult(
        state: MediaPermissionState.restricted,
        nativeGranted: false,
        audioStatus: audioStatus,
        storageStatus: storageStatus,
      );
    }

    if (knownStatuses.any((status) => status.isPermanentlyDenied)) {
      return MediaPermissionResult(
        state: MediaPermissionState.permanentlyDenied,
        nativeGranted: false,
        audioStatus: audioStatus,
        storageStatus: storageStatus,
      );
    }

    if (knownStatuses.any(_isUsable)) {
      return MediaPermissionResult(
        state: MediaPermissionState.error,
        nativeGranted: false,
        audioStatus: audioStatus,
        storageStatus: storageStatus,
        error: StateError(
          'Android reports permission as granted, but native MediaStore '
          'access is unavailable.',
        ),
      );
    }

    return MediaPermissionResult(
      state: MediaPermissionState.error,
      nativeGranted: false,
      audioStatus: audioStatus,
      storageStatus: storageStatus,
    );
  }

  Future<MediaPermissionResult> request({int attempts = 1}) {
    final active = _activeRequest;
    if (active != null) return active;

    final future = _request(attempts: attempts < 1 ? 1 : attempts);
    _activeRequest = future;

    return future.whenComplete(() {
      if (identical(_activeRequest, future)) {
        _activeRequest = null;
      }
    });
  }

  Future<MediaPermissionResult> _request({required int attempts}) async {
    var current = await check();
    if (current.granted || !Platform.isAndroid) return current;

    try {
      for (var attempt = 0; attempt < attempts; attempt++) {
        if (_canRequestStatus(current.audioStatus)) {
          await Permission.audio.request();
          current = await check();
          if (current.granted) return current;
        }

        if (_canRequestStatus(current.storageStatus)) {
          await Permission.storage.request();
          current = await check();
          if (current.granted) return current;
        }

        if (!current.canRequest) return current;

        if (attempt + 1 < attempts) {
          await Future<void>.delayed(
            Duration(milliseconds: 350 + (attempt * 300)),
          );
          current = await check();
          if (current.granted) return current;
        }
      }

      return check();
    } catch (error, stackTrace) {
      debugPrint('[MediaPermission] Permission request failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return MediaPermissionResult(
        state: MediaPermissionState.error,
        nativeGranted: false,
        audioStatus: current.audioStatus,
        storageStatus: current.storageStatus,
        error: error,
        stackTrace: stackTrace,
      );
    }
  }

  Future<bool> openSettings() => openAppSettings();

  Future<MediaPermissionResult> openSettingsAndRecheck({
    Duration settleDelay = const Duration(milliseconds: 500),
  }) async {
    await openSettings();
    await Future<void>.delayed(settleDelay);
    return check();
  }

  Future<PermissionStatus?> _readStatus(Permission permission) async {
    try {
      return await permission.status;
    } catch (error) {
      debugPrint('[MediaPermission] Could not read permission status: $error');
      return null;
    }
  }

  bool _canRequestStatus(PermissionStatus? status) {
    return status == null || status.isDenied;
  }

  static bool _isUsable(PermissionStatus status) {
    return status.isGranted || status.isLimited;
  }

  @visibleForTesting
  static void resetForTesting() {
    _instance = null;
  }
}
