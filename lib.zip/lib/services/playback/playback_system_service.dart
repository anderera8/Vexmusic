import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../audio/coordinator_audio_handler.dart';
import 'audio_interruption_policy.dart';
import 'media_playback_coordinator.dart';

typedef SystemPauseReasonCommand = Future<void> Function(
  PlaybackPauseReason reason,
);
typedef SystemVolumeCommand = Future<void> Function(double volume);

/// Single application owner of AudioSession configuration, activation, focus
/// events, route-loss events, and audio_service integration.
class PlaybackSystemService {
  static CoordinatorAudioHandler? _handler;
  static MediaPlaybackCoordinator? _coordinator;
  static AudioSession? _session;
  static Future<void>? _sessionInitialization;
  static bool _audioServiceInitializing = false;
  static bool _sessionConfigured = false;

  static final AudioInterruptionPolicy _interruptionPolicy =
      AudioInterruptionPolicy();
  static final List<StreamSubscription<dynamic>> _sessionSubscriptions = [];
  static Future<void> _sessionCommandTail = Future<void>.value();

  static SystemPlaybackCommand? _onPlay;
  static SystemPlaybackCommand? _onPause;
  static SystemPlaybackCommand? _onStop;
  static SystemSeekCommand? _onSeek;
  static SystemPlaybackCommand? _onSkipNext;
  static SystemPlaybackCommand? _onSkipPrevious;
  static SystemShuffleCommand? _onSetShuffle;
  static SystemRepeatCommand? _onSetRepeatMode;
  static SystemPauseReasonCommand? _onPauseForReason;
  static SystemPlaybackCommand? _onResumeAfterInterruption;
  static SystemVolumeCommand? _onSetTransientVolume;

  /// Snapshot of the callback set that was active immediately before a
  /// [pushTemporaryQueueControlCallbacks] call, so it can be restored by a
  /// matching [popTemporaryQueueControlCallbacks]. Only one saved set is
  /// ever needed in practice (Radio is the only temporary borrower of
  /// system controls today), so this is a single slot rather than a true
  /// stack — a second push while one is already pending overwrites it,
  /// which would drop the ability to restore the first caller's callbacks.
  static _SavedQueueControlCallbacks? _savedCallbacks;

  static double? _duckRestoreVolume;
  static DateTime? _lastRouteLossAt;

  static bool get audioServiceRunning => _handler != null;
  static bool get audioSessionConfigured => _sessionConfigured;

  static void bindCoordinator(MediaPlaybackCoordinator coordinator) {
    _coordinator = coordinator;
    coordinator.setAudioSessionDelegates(
      activate: activateAudioSession,
      deactivate: deactivateAudioSession,
    );
  }

  static Future<void> initialize(
    MediaPlaybackCoordinator coordinator,
  ) async {
    bindCoordinator(coordinator);
    try {
      await configureAudioSession();
    } catch (error, stackTrace) {
      debugPrint(
        '[PlaybackSystemService] Audio session configuration failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);
    }
    await initializeAudioService(coordinator);
  }

  static Future<void> configureAudioSession() {
    if (_sessionConfigured) return Future<void>.value();
    return _sessionInitialization ??= _configureAudioSessionInternal();
  }

  static Future<void> _configureAudioSessionInternal() async {
    try {
      final session = await AudioSession.instance;
      _session = session;

      await session.configure(const AudioSessionConfiguration(
        avAudioSessionCategory: AVAudioSessionCategory.playback,
        avAudioSessionCategoryOptions:
            AVAudioSessionCategoryOptions.allowBluetooth,
        avAudioSessionMode: AVAudioSessionMode.defaultMode,
        avAudioSessionRouteSharingPolicy:
            AVAudioSessionRouteSharingPolicy.defaultPolicy,
        avAudioSessionSetActiveOptions: AVAudioSessionSetActiveOptions.none,
        androidAudioAttributes: AndroidAudioAttributes(
          contentType: AndroidAudioContentType.music,
          usage: AndroidAudioUsage.media,
        ),
        androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
        androidWillPauseWhenDucked: false,
      ));

      await _cancelSessionSubscriptions();
      _sessionSubscriptions.addAll([
        session.interruptionEventStream.listen(
          _handleInterruption,
          onError: _logSessionStreamError,
        ),
        session.becomingNoisyEventStream.listen(
          (_) => _handleRouteLoss('becoming noisy'),
          onError: _logSessionStreamError,
        ),
        session.devicesChangedEventStream.listen(
          (event) {
            final removedOutput =
                event.devicesRemoved.any((device) => device.isOutput);
            if (removedOutput) {
              _handleRouteLoss('audio output disconnected');
            }
          },
          onError: _logSessionStreamError,
        ),
      ]);

      _sessionConfigured = true;
    } finally {
      _sessionInitialization = null;
    }
  }

  static Future<bool> activateAudioSession() async {
    await configureAudioSession();
    final session = _session;
    if (session == null) return false;

    try {
      return await session.setActive(true);
    } catch (error, stackTrace) {
      debugPrint('[PlaybackSystemService] Audio focus activation failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      return false;
    }
  }

  static Future<void> deactivateAudioSession() async {
    final session = _session;
    if (session == null) return;

    try {
      await session.setActive(false);
    } catch (error, stackTrace) {
      debugPrint('[PlaybackSystemService] Audio focus release failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  static Future<void> initializeAudioService(
    MediaPlaybackCoordinator coordinator,
  ) async {
    if (_handler != null || _audioServiceInitializing) return;
    _audioServiceInitializing = true;
    try {
      final handler = await AudioService.init(
        builder: () => CoordinatorAudioHandler(
          coordinator,
          onPlay: _onPlay,
          onPause: _onPause,
          onStop: _onStop,
          onSeek: _onSeek,
          onSkipNext: _onSkipNext,
          onSkipPrevious: _onSkipPrevious,
          onSetShuffle: _onSetShuffle,
          onSetRepeatMode: _onSetRepeatMode,
        ),
        config: const AudioServiceConfig(
          androidNotificationChannelId: 'com.vextech.vexmusic.audio',
          androidNotificationChannelName: 'Vibes Player Playback',
          androidNotificationChannelDescription: 'Music playback controls',
          androidNotificationIcon: 'mipmap/ic_launcher',
          androidNotificationOngoing: false,
          androidStopForegroundOnPause: false,
          artDownscaleWidth: 512,
          artDownscaleHeight: 512,
        ),
      );
      _handler = handler;
    } catch (error, stackTrace) {
      debugPrint('[PlaybackSystemService] Audio service failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      _audioServiceInitializing = false;
    }
  }

  static Future<void> setLockScreenEnabled(bool enabled) async {
    _handler?.setControlsEnabled(enabled);
  }

  static void setQueueControlCallbacks({
    SystemPlaybackCommand? onPlay,
    SystemPlaybackCommand? onPause,
    SystemPlaybackCommand? onStop,
    SystemSeekCommand? onSeek,
    SystemPlaybackCommand? onSkipNext,
    SystemPlaybackCommand? onSkipPrevious,
    SystemShuffleCommand? onSetShuffle,
    SystemRepeatCommand? onSetRepeatMode,
    SystemPauseReasonCommand? onPauseForReason,
    SystemPlaybackCommand? onResumeAfterInterruption,
    SystemVolumeCommand? onSetTransientVolume,
  }) {
    _onPlay = onPlay;
    _onPause = onPause;
    _onStop = onStop;
    _onSeek = onSeek;
    _onSkipNext = onSkipNext;
    _onSkipPrevious = onSkipPrevious;
    _onSetShuffle = onSetShuffle;
    _onSetRepeatMode = onSetRepeatMode;
    _onPauseForReason = onPauseForReason;
    _onResumeAfterInterruption = onResumeAfterInterruption;
    _onSetTransientVolume = onSetTransientVolume;

    _handler?.setQueueControlCallbacks(
      onPlay: onPlay,
      onPause: onPause,
      onStop: onStop,
      onSeek: onSeek,
      onSkipNext: onSkipNext,
      onSkipPrevious: onSkipPrevious,
      onSetShuffle: onSetShuffle,
      onSetRepeatMode: onSetRepeatMode,
    );
  }

  /// Temporarily redirects lock-screen/notification play, pause, and stop
  /// to a different source (Radio), saving whatever callback set is
  /// currently registered (MusicProvider's, in practice) so a matching
  /// [popTemporaryQueueControlCallbacks] can hand it back untouched.
  /// Deliberately narrower than [setQueueControlCallbacks]: seek, skip, and
  /// shuffle/repeat aren't meaningful for a live stream, so those simply
  /// aren't offered while a temporary set is active (see
  /// [CoordinatorAudioHandler.publishExternalNowPlaying], which is what
  /// actually controls which controls the notification shows).
  static void pushTemporaryQueueControlCallbacks({
    SystemPlaybackCommand? onPlay,
    SystemPlaybackCommand? onPause,
    SystemPlaybackCommand? onStop,
  }) {
    _savedCallbacks ??= _SavedQueueControlCallbacks(
      onPlay: _onPlay,
      onPause: _onPause,
      onStop: _onStop,
      onSeek: _onSeek,
      onSkipNext: _onSkipNext,
      onSkipPrevious: _onSkipPrevious,
      onSetShuffle: _onSetShuffle,
      onSetRepeatMode: _onSetRepeatMode,
      onPauseForReason: _onPauseForReason,
      onResumeAfterInterruption: _onResumeAfterInterruption,
      onSetTransientVolume: _onSetTransientVolume,
    );

    setQueueControlCallbacks(onPlay: onPlay, onPause: onPause, onStop: onStop);
  }

  /// Restores whatever callback set was active before the matching
  /// [pushTemporaryQueueControlCallbacks] call. A no-op if nothing is
  /// currently saved (e.g. called twice by mistake), so it's always safe
  /// to call defensively.
  static void popTemporaryQueueControlCallbacks() {
    final saved = _savedCallbacks;
    if (saved == null) return;
    _savedCallbacks = null;

    setQueueControlCallbacks(
      onPlay: saved.onPlay,
      onPause: saved.onPause,
      onStop: saved.onStop,
      onSeek: saved.onSeek,
      onSkipNext: saved.onSkipNext,
      onSkipPrevious: saved.onSkipPrevious,
      onSetShuffle: saved.onSetShuffle,
      onSetRepeatMode: saved.onSetRepeatMode,
      onPauseForReason: saved.onPauseForReason,
      onResumeAfterInterruption: saved.onResumeAfterInterruption,
      onSetTransientVolume: saved.onSetTransientVolume,
    );
  }

  /// Suspends publishing local-playback state to the lock screen/
  /// notification so an external source (Radio) can drive it instead via
  /// [publishExternalNowPlaying] without local-queue updates racing in and
  /// overwriting it. Pair with [exitExternalPlaybackMode].
  static void enterExternalPlaybackMode() {
    _handler?.enterExternalPlaybackMode();
  }

  /// Resumes publishing local-playback state to the lock screen/
  /// notification, immediately refreshing it from the current local queue
  /// so it doesn't keep showing whatever Radio last published.
  static void exitExternalPlaybackMode() {
    _handler?.exitExternalPlaybackMode();
  }

  /// Publishes now-playing info for an external (non-local-queue) source —
  /// currently just Radio — to the lock screen/notification. Only takes
  /// effect between [enterExternalPlaybackMode] and [exitExternalPlaybackMode];
  /// see [CoordinatorAudioHandler.publishExternalNowPlaying] for the actual
  /// mapping to audio_service's MediaItem/PlaybackState.
  ///
  /// Returns whether a handler actually received this. False only in the
  /// narrow startup window before [initialize] has finished (unreachable
  /// in practice, since that completes well before a human could open the
  /// Radio tab and start a station) — but a caller tracking "have I
  /// already published this state" (see RadioSystemPlaybackBridge) should
  /// still key off this rather than assume, so a call that lands in that
  /// window doesn't get silently treated as delivered when it wasn't.
  static bool publishExternalNowPlaying({
    required String id,
    required String title,
    String? subtitle,
    Uri? artUri,
    required bool playing,
    required AudioProcessingState processingState,
  }) {
    final handler = _handler;
    if (handler == null) return false;
    handler.publishExternalNowPlaying(
      id: id,
      title: title,
      subtitle: subtitle,
      artUri: artUri,
      playing: playing,
      processingState: processingState,
    );
    return true;
  }

  static void registerExplicitPlay() {
    final restoreDuck = _interruptionPolicy.registerExplicitPlay();
    if (restoreDuck) {
      unawaited(
        _enqueueSessionCommand(
          'restore volume before explicit play',
          _restoreDuckedVolume,
        ),
      );
    }
  }

  static void registerExplicitPause() {
    final restoreDuck = _interruptionPolicy.registerExplicitPause();
    if (restoreDuck) {
      unawaited(
        _enqueueSessionCommand(
          'restore volume after explicit pause',
          _restoreDuckedVolume,
        ),
      );
    }
  }

  static void registerExplicitStop() {
    final restoreDuck = _interruptionPolicy.registerExplicitStop();
    if (restoreDuck) {
      unawaited(
        _enqueueSessionCommand(
          'restore volume after explicit stop',
          _restoreDuckedVolume,
        ),
      );
    }
  }

  /// Routes non-user pause causes through the same provider/controller callback
  /// path used by focus and route-loss events.
  static Future<void> pauseForReason(PlaybackPauseReason reason) {
    return _enqueueSessionCommand(
      'pause for ${reason.name}',
      () => _pauseForReason(reason),
    );
  }

  static void _handleInterruption(AudioInterruptionEvent event) {
    final coordinator = _coordinator;
    if (coordinator == null) return;

    final command = _interruptionPolicy.handle(
      event,
      isPlaying: coordinator.currentState.playing,
    );

    unawaited(_enqueueSessionCommand('audio interruption', () async {
      switch (command) {
        case AudioInterruptionCommand.none:
          return;
        case AudioInterruptionCommand.duck:
          _duckRestoreVolume ??= coordinator.currentState.volume;
          final duckVolume =
              (_duckRestoreVolume! * 0.20).clamp(0.05, 1.0).toDouble();
          await _setTransientVolume(duckVolume);
          return;
        case AudioInterruptionCommand.restoreVolume:
          await _restoreDuckedVolume();
          return;
        case AudioInterruptionCommand.pause:
          await _restoreDuckedVolume();
          await _pauseForReason(PlaybackPauseReason.audioFocus);
          return;
        case AudioInterruptionCommand.resume:
          await _restoreDuckedVolume();
          final callback = _onResumeAfterInterruption;
          if (callback != null) {
            await callback();
          } else {
            await coordinator.play();
          }
          return;
      }
    }));
  }

  static void _handleRouteLoss(String source) {
    final coordinator = _coordinator;
    if (coordinator == null || !coordinator.currentState.playing) return;

    final now = DateTime.now();
    final previous = _lastRouteLossAt;
    if (previous != null &&
        now.difference(previous) < const Duration(milliseconds: 750)) {
      return;
    }
    _lastRouteLossAt = now;

    final restoreDuck = _interruptionPolicy.registerNoisyRoutePause();
    unawaited(_enqueueSessionCommand(source, () async {
      if (restoreDuck) await _restoreDuckedVolume();
      await _pauseForReason(PlaybackPauseReason.noisyRoute);
    }));
  }

  static Future<void> _pauseForReason(PlaybackPauseReason reason) async {
    final callback = _onPauseForReason;
    if (callback != null) {
      await callback(reason);
    } else {
      final coordinator = _coordinator;
      if (coordinator != null) {
        await coordinator.pause(
          releaseAudioSession: reason != PlaybackPauseReason.audioFocus,
        );
      }
    }
  }

  static Future<void> _setTransientVolume(double volume) async {
    final callback = _onSetTransientVolume;
    if (callback != null) {
      await callback(volume);
    } else {
      final coordinator = _coordinator;
      if (coordinator != null) {
        await coordinator.setVolume(volume);
      }
    }
  }

  static Future<void> _restoreDuckedVolume() async {
    final restore = _duckRestoreVolume;
    _duckRestoreVolume = null;
    if (restore != null) {
      await _setTransientVolume(restore);
    }
  }

  static Future<void> _enqueueSessionCommand(
    String label,
    Future<void> Function() command,
  ) {
    final operation = _sessionCommandTail.then((_) => command());
    _sessionCommandTail = operation.catchError(
      (Object error, StackTrace stackTrace) {
        debugPrint('[PlaybackSystemService] $label failed: $error');
        debugPrintStack(stackTrace: stackTrace);
      },
    );
    return operation;
  }

  static void _logSessionStreamError(
    Object error,
    StackTrace stackTrace,
  ) {
    debugPrint('[PlaybackSystemService] Audio session stream failed: $error');
    debugPrintStack(stackTrace: stackTrace);
  }

  static void clearQueueControlCallbacks() {
    _onPlay = null;
    _onPause = null;
    _onStop = null;
    _onSeek = null;
    _onSkipNext = null;
    _onSkipPrevious = null;
    _onSetShuffle = null;
    _onSetRepeatMode = null;
    _onPauseForReason = null;
    _onResumeAfterInterruption = null;
    _onSetTransientVolume = null;
    _handler?.setQueueControlCallbacks();
  }

  static Future<void> _cancelSessionSubscriptions() async {
    for (final subscription in _sessionSubscriptions) {
      await subscription.cancel();
    }
    _sessionSubscriptions.clear();
  }

  static Future<void> shutdown() async {
    final handler = _handler;
    _handler = null;
    clearQueueControlCallbacks();
    _savedCallbacks = null;
    await handler?.disposeSubscriptions();
    await _cancelSessionSubscriptions();
    await deactivateAudioSession();
    _interruptionPolicy.reset();
    _duckRestoreVolume = null;
    _session = null;
    _sessionConfigured = false;
    _sessionInitialization = null;
    _coordinator?.clearAudioSessionDelegates();
    _coordinator = null;
  }

  static const _widgetChannel = MethodChannel('com.vextech.vexmusic/widget');

  static Future<void> updateWidget({
    String? title,
    String? artist,
    String? artworkPath,
    bool isPlaying = false,
  }) async {
    try {
      await _widgetChannel.invokeMethod('updateWidget', {
        'title': title,
        'artist': artist,
        'artworkPath': artworkPath,
        'isPlaying': isPlaying,
      });
    } catch (_) {
      // The widget channel is optional outside Android.
    }
  }
}

/// Immutable snapshot of every callback [PlaybackSystemService] can route
/// system playback commands through, captured by
/// [PlaybackSystemService.pushTemporaryQueueControlCallbacks] so it can be
/// restored verbatim by [PlaybackSystemService.popTemporaryQueueControlCallbacks].
class _SavedQueueControlCallbacks {
  final SystemPlaybackCommand? onPlay;
  final SystemPlaybackCommand? onPause;
  final SystemPlaybackCommand? onStop;
  final SystemSeekCommand? onSeek;
  final SystemPlaybackCommand? onSkipNext;
  final SystemPlaybackCommand? onSkipPrevious;
  final SystemShuffleCommand? onSetShuffle;
  final SystemRepeatCommand? onSetRepeatMode;
  final SystemPauseReasonCommand? onPauseForReason;
  final SystemPlaybackCommand? onResumeAfterInterruption;
  final SystemVolumeCommand? onSetTransientVolume;

  const _SavedQueueControlCallbacks({
    this.onPlay,
    this.onPause,
    this.onStop,
    this.onSeek,
    this.onSkipNext,
    this.onSkipPrevious,
    this.onSetShuffle,
    this.onSetRepeatMode,
    this.onPauseForReason,
    this.onResumeAfterInterruption,
    this.onSetTransientVolume,
  });
}
