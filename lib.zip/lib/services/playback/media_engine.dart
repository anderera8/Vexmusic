import '../../models/media_models.dart';

/// Typed playback boundary. Every mutating command must return a result;
/// implementations must never convert engine failures into silent success.
abstract interface class MediaEngine {
  MediaKind get kind;

  Stream<PlaybackSnapshot> get playbackState;

  Stream<PlaybackQueue> get queueState;

  PlaybackSnapshot get currentState;

  PlaybackQueue get currentQueue;

  Future<PlaybackCommandResult> open(
    MediaEntry entry, {
    List<MediaEntry> queue = const [],
    int initialIndex = 0,
  });

  Future<PlaybackCommandResult> play();

  Future<PlaybackCommandResult> pause();

  Future<PlaybackCommandResult> stop();

  Future<PlaybackCommandResult> seek(Duration position);

  Future<PlaybackCommandResult> skipNext();

  Future<PlaybackCommandResult> skipPrevious();

  Future<PlaybackCommandResult> jumpTo(int index);

  Future<PlaybackCommandResult> insertQueueEntry(
    int index,
    MediaEntry entry,
  );

  Future<PlaybackCommandResult> removeQueueEntry(int index);

  Future<PlaybackCommandResult> clearQueueAfter(int index);

  Future<PlaybackCommandResult> moveQueueEntry(
    int oldIndex,
    int newIndex,
  );

  Future<PlaybackCommandResult> setVolume(double volume);

  Future<PlaybackCommandResult> setSpeed(double speed);

  Future<PlaybackCommandResult> setShuffle(bool enabled);

  Future<PlaybackCommandResult> setRepeatMode(
    PlaybackRepeatMode mode,
  );

  Future<PlaybackCommandResult> setCrossfade(int seconds);

  Future<void> dispose();
}
