// lib/services/playback/just_audio_engine.dart
// ─────────────────────────────────────────────────────────────────────────────
// Audio-only just_audio engine — implements MediaEngine using ExoPlayer/AVPlayer.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:collection';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../../models/media_models.dart';
import '../../services/unified_audio_effects_service.dart';
import '../platform/android_audio_effects.dart';
import 'media_engine.dart';
import 'performance_metrics.dart';

class JustAudioEngine implements MediaEngine {
  static const Duration _openTimeout = Duration(seconds: 30);
  static const Duration _queueMutationTimeout = Duration(seconds: 10);
  static const Duration _navigationTimeout = Duration(seconds: 10);
  static const Duration _playStartTimeout = Duration(seconds: 8);
  static const Duration _configurationTimeout = Duration(seconds: 8);
  static const int _maxConsecutiveRuntimeFailures = 3;
  static const Duration _runtimeFailureWindow = Duration(seconds: 30);
  static const Duration _stablePlaybackThreshold = Duration(seconds: 3);
  // Matches the max exposed by every crossfade control in the app
  // (settings_screen.dart and side_drawer.dart both use min: 0, max: 12).
  // Both setCrossfade's clamp and the fade-duration clamp below derive
  // from this single constant so they can't silently drift apart again.
  static const int _maxCrossfadeSeconds = 12;

  final AudioPlayer _player = AudioPlayer(
    handleInterruptions: false,
    handleAudioSessionActivation: false,
    androidApplyAudioAttributes: false,
  );

  final StreamController<PlaybackSnapshot> _stateController =
      StreamController<PlaybackSnapshot>.broadcast();
  final StreamController<PlaybackQueue> _queueController =
      StreamController<PlaybackQueue>.broadcast();

  final List<StreamSubscription<dynamic>> _subscriptions = [];
  StreamSubscription<EqState>? _effectsSubscription;
  EqState? _effectsState;

  bool _disposed = false;
  bool _androidEffectsInitialized = false;
  bool _openingSource = false;
  bool _runtimeRecoveryInProgress = false;
  int _consecutiveRuntimeFailures = 0;
  DateTime? _lastRuntimeFailureAt;
  final PerformanceMetrics _metrics = PerformanceMetrics();

  int _crossfadeSeconds = 0;
  bool _crossfadeTriggered = false;
  bool _crossfadeInProgress = false;
  int _transitionToken = 0;

  // The real user/player volume. During crossfade the engine temporarily
  // changes the just_audio volume, then restores this value.
  double _targetVolume = 1.0;

  PlaybackSnapshot _state = const PlaybackSnapshot();
  PlaybackQueue _queue = const PlaybackQueue();

  JustAudioEngine() {
    // ── Processing state ──────────────────────────────────────────
    _subscriptions.add(_player.playerStateStream.listen((playerState) {
      final processing = switch (playerState.processingState) {
        ProcessingState.idle => PlaybackProcessingState.idle,
        ProcessingState.loading => PlaybackProcessingState.loading,
        ProcessingState.buffering => PlaybackProcessingState.buffering,
        ProcessingState.ready => PlaybackProcessingState.ready,
        ProcessingState.completed => PlaybackProcessingState.completed,
      };

      _emitState(_state.copyWith(
        processingState: processing,
        playing: playerState.playing,
      ));
    }));

    // Runtime decoder/source failures can arrive after open() has returned.
    _subscriptions.add(
      _player.playbackEventStream.listen(
        (_) {},
        onError: (Object error, StackTrace stackTrace) {
          if (!_openingSource) {
            unawaited(_recoverFromRuntimeFailure(error, stackTrace));
          }
        },
      ),
    );

    // ── Position + smooth crossfade ───────────────────────────────
    _subscriptions.add(_player.positionStream.listen((position) {
      var nextState = _state.copyWith(position: position);

      if (position >= _stablePlaybackThreshold &&
          _state.playing &&
          _consecutiveRuntimeFailures > 0) {
        _consecutiveRuntimeFailures = 0;
        _lastRuntimeFailureAt = null;
        nextState = nextState.copyWith(
          clearFailure: true,
          clearRecovery: true,
        );
      }

      _emitState(nextState);
      _checkCrossfade(position);
    }));

    // ── Duration ─────────────────────────────────────────────────
    _subscriptions.add(_player.durationStream.listen((duration) {
      _emitState(_state.copyWith(duration: duration ?? Duration.zero));
    }));

    // ── Buffered position ────────────────────────────────────────
    _subscriptions.add(_player.bufferedPositionStream.listen((buffered) {
      _emitState(_state.copyWith(bufferedPosition: buffered));
    }));

    // ── Volume ───────────────────────────────────────────────────
    _subscriptions.add(_player.volumeStream.listen((volume) {
      _emitState(_state.copyWith(volume: volume));
    }));

    // ── Speed ────────────────────────────────────────────────────
    _subscriptions.add(_player.speedStream.listen((speed) {
      _emitState(_state.copyWith(speed: speed));
    }));

        // ── Sequence (queue) changes ─────────────────────────────────
    _subscriptions.add(_player.sequenceStateStream.listen((sequenceState) {
      final canonicalSources = sequenceState.sequence;

      final entries = canonicalSources
          .where((source) => source.tag is MediaEntry)
          .map((source) => source.tag as MediaEntry)
          .toList(growable: false);

      final canonicalIndexBySource = HashMap<Object, int>.identity();

      for (var index = 0; index < canonicalSources.length; index++) {
        canonicalIndexBySource[canonicalSources[index]] = index;
      }

      final effectiveOrder = <int>[];

      for (final source in sequenceState.effectiveSequence) {
        final canonicalIndex = canonicalIndexBySource[source];

        if (canonicalIndex != null) {
          effectiveOrder.add(canonicalIndex);
        }
      }

      final validEffectiveOrder = effectiveOrder.length == entries.length &&
          effectiveOrder.toSet().length == entries.length;

      final currentIndex = sequenceState.currentIndex;

      if (!_crossfadeInProgress) {
        _crossfadeTriggered = false;
      }

      _queue = _queue.copyWith(
        entries: List<MediaEntry>.unmodifiable(entries),
        currentIndex:
            currentIndex != null && currentIndex >= 0 && currentIndex < entries.length
                ? currentIndex
                : -1,
        effectiveOrder: validEffectiveOrder
            ? List<int>.unmodifiable(effectiveOrder)
            : List<int>.generate(
                entries.length,
                (index) => index,
                growable: false,
              ),
      );

      _queueController.add(_queue);
    }));

    // Seed initial state.
    _emitState(const PlaybackSnapshot(
      processingState: PlaybackProcessingState.idle,
    ));

    // ── Equalizer ────────────────────────────────────────────────
    _effectsSubscription = UnifiedAudioEffectsService.changes.listen(
      (state) => unawaited(_applyAudioEffects(state)),
    );

    unawaited(UnifiedAudioEffectsService.ensureInitialized().then((_) async {
      await _applyAudioEffects(await UnifiedAudioEffectsService.getState());
    }));

  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MediaEngine implementation
  // ═══════════════════════════════════════════════════════════════════════════

  @override
  MediaKind get kind => MediaKind.audio;

  @override
  Stream<PlaybackSnapshot> get playbackState => _stateController.stream;

  @override
  Stream<PlaybackQueue> get queueState => _queueController.stream;

  @override
  PlaybackSnapshot get currentState => _state;

  @override
  PlaybackQueue get currentQueue => _queue;

  @override
  Future<PlaybackCommandResult> open(
    MediaEntry entry, {
    List<MediaEntry> queue = const [],
    int initialIndex = 0,
  }) async {
    _cancelCrossfadeState();

    final entries = queue.isEmpty
        ? <MediaEntry>[entry]
        : List<MediaEntry>.from(queue);

    if (entries.isEmpty) {
      return _reportCommandFailure(
        const PlaybackFailure(
          PlaybackErrorType.invalidSource,
          'The playback queue is empty.',
        ),
        fatal: true,
      );
    }

    final index = initialIndex.clamp(0, entries.length - 1);

    if (entries[index].source.isEmpty) {
      return _reportCommandFailure(
        PlaybackFailure(
          PlaybackErrorType.invalidSource,
          'The selected track has no playable file or MediaStore URI.',
          entryId: entries[index].id,
          queueIndex: index,
          operation: 'open audio source',
        ),
        fatal: true,
      );
    }
    final previousQueue = _queue;

    _emitState(_state.copyWith(
      processingState: PlaybackProcessingState.loading,
      playing: false,
      position: Duration.zero,
      duration: Duration.zero,
      bufferedPosition: Duration.zero,
      clearFailure: true,
    ));

    _openingSource = true;
    _metrics.recordAudioOpenStart();

    try {
      final audioSources = entries.map(_toAudioSource).toList(growable: false);

      await _player
          .setAudioSources(audioSources, initialIndex: index)
          .timeout(_openTimeout);
      await _player.setVolume(_targetVolume).timeout(_configurationTimeout);

      try {
        await _initializeAndroidEffects();

        final effectsState = _effectsState;
        if (effectsState != null) {
          await _applyAudioEffects(effectsState);
        }
      } catch (error, stackTrace) {
        debugPrint(
          '[JustAudioEngine] Optional audio-effect setup failed: $error',
        );
        debugPrintStack(stackTrace: stackTrace);
      }

      _queue = PlaybackQueue(
        entries: List<MediaEntry>.unmodifiable(entries),
        currentIndex: index,
        shuffleEnabled: previousQueue.shuffleEnabled,
        repeatMode: previousQueue.repeatMode,
        effectiveOrder: List<int>.generate(
          entries.length,
          (queueIndex) => queueIndex,
          growable: false,
        ),
      );
      _queueController.add(_queue);

      _consecutiveRuntimeFailures = 0;
      _lastRuntimeFailureAt = null;
      _metrics.recordAudioReady();
      _emitState(_state.copyWith(
        processingState: PlaybackProcessingState.ready,
        clearFailure: true,
        clearRecovery: true,
      ));

      return const PlaybackCommandResult.success();
    } on PlayerException catch (error) {
      final failure = _classifyPlayerException(error);
      debugPrint('[JustAudioEngine] open() failed: $error');

      return _reportCommandFailure(
        failure,
        fatal: true,
        restoreQueue: previousQueue,
      );
    } on TimeoutException catch (error) {
      debugPrint('[JustAudioEngine] open() timed out: $error');

      return _reportCommandFailure(
        PlaybackFailure(
          PlaybackErrorType.timeout,
          'Opening the audio source timed out.',
          cause: error,
        ),
        fatal: true,
        restoreQueue: previousQueue,
      );
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] open() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(
          error,
          operation: 'open audio source',
        ),
        fatal: true,
        restoreQueue: previousQueue,
      );
    } finally {
      _openingSource = false;
    }
  }

  @override
  Future<PlaybackCommandResult> insertQueueEntry(
    int index,
    MediaEntry entry,
  ) async {
    if (entry.source.isEmpty) {
      return const PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidSource,
          'The queued track has no playable source.',
        ),
      );
    }

    final length = _player.audioSources.length;

    if (index < 0 || index > length) {
      return PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'Cannot insert a queue item at index $index. '
          'Valid range: 0 to $length.',
        ),
      );
    }

    try {
      await _player
          .insertAudioSource(index, _toAudioSource(entry))
          .timeout(_queueMutationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint(
        '[JustAudioEngine] insertQueueEntry($index) failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'insert queue item'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> removeQueueEntry(int index) async {
    final length = _player.audioSources.length;

    if (index < 0 || index >= length) {
      return PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'Cannot remove queue index $index from a queue of length $length.',
        ),
      );
    }

    try {
      await _player
          .removeAudioSourceAt(index)
          .timeout(_queueMutationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint(
        '[JustAudioEngine] removeQueueEntry($index) failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'remove queue item'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> clearQueueAfter(int index) async {
    final length = _player.audioSources.length;

    if (index < 0 || index >= length) {
      return PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'Cannot clear a queue of length $length after index $index.',
        ),
      );
    }

    if (index == length - 1) {
      return const PlaybackCommandResult.noChange();
    }

    try {
      for (var queueIndex = length - 1; queueIndex > index; queueIndex--) {
        await _player
            .removeAudioSourceAt(queueIndex)
            .timeout(_queueMutationTimeout);
      }

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint(
        '[JustAudioEngine] clearQueueAfter($index) failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'clear upcoming queue'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> moveQueueEntry(
    int oldIndex,
    int newIndex,
  ) async {
    final length = _player.audioSources.length;

    if (oldIndex < 0 ||
        oldIndex >= length ||
        newIndex < 0 ||
        newIndex >= length) {
      return PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'Cannot move queue index $oldIndex to $newIndex '
          'in a queue of length $length.',
        ),
      );
    }

    if (oldIndex == newIndex) {
      return const PlaybackCommandResult.noChange();
    }

    try {
      await _player
          .moveAudioSource(oldIndex, newIndex)
          .timeout(_queueMutationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint(
        '[JustAudioEngine] moveQueueEntry($oldIndex, $newIndex) failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'move queue item'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> play() async {
    try {
      final startedFuture = _player.playingStream
          .firstWhere((playing) => playing)
          .then<PlaybackFailure?>((_) => null);

      final playbackFuture = _player.play().then<PlaybackFailure?>(
        (_) {
          if (_player.playing) return null;

          return const PlaybackFailure(
            PlaybackErrorType.cancelled,
            'Playback ended or was cancelled before it started.',
          );
        },
        onError: (Object error, StackTrace stackTrace) {
          debugPrint(
            '[JustAudioEngine] asynchronous play() failure: $error',
          );
          debugPrintStack(stackTrace: stackTrace);

          return _classifyCommandError(error, operation: 'start playback');
        },
      );

      final failure = await Future.any<PlaybackFailure?>([
        startedFuture,
        playbackFuture,
      ]).timeout(_playStartTimeout);

      if (failure != null) {
        return _reportCommandFailure(failure, fatal: true);
      }

      return const PlaybackCommandResult.success();
    } on TimeoutException catch (error) {
      return _reportCommandFailure(
        PlaybackFailure(
          PlaybackErrorType.timeout,
          'Playback did not start within '
          '${_playStartTimeout.inSeconds} seconds.',
          cause: error,
        ),
        fatal: true,
      );
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] play() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'start playback'),
        fatal: true,
      );
    }
  }

  @override
  Future<PlaybackCommandResult> pause() async {
    try {
      await _cancelCrossfadeAndRestoreVolume();
      await _player.pause().timeout(_configurationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] pause() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'pause playback'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> stop() async {
    try {
      await _cancelCrossfadeAndRestoreVolume();
      await _player.stop().timeout(_configurationTimeout);

      // Release Android audio effects on stop.
      if (_androidEffectsInitialized) {
        await AndroidAudioEffects.instance.release();
        _androidEffectsInitialized = false;
      }

      _consecutiveRuntimeFailures = 0;
      _lastRuntimeFailureAt = null;
      _emitState(_state.copyWith(
        processingState: PlaybackProcessingState.idle,
        playing: false,
        position: Duration.zero,
        clearFailure: true,
        clearRecovery: true,
      ));

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] stop() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'stop playback'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> seek(Duration position) async {
    try {
      await _cancelCrossfadeAndRestoreVolume();
      await _player.seek(position).timeout(_navigationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] seek() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'seek playback'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> skipNext() async {
    if (!_player.hasNext) {
      await _cancelCrossfadeAndRestoreVolume();
      return const PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'There is no next queue item.',
        ),
      );
    }

    try {
      if (_crossfadeSeconds > 0) {
        await _performSmoothTransition(() => _player.seekToNext());
      } else {
        await _cancelCrossfadeAndRestoreVolume();
        await _player.seekToNext().timeout(_navigationTimeout);
      }

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] skipNext() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'skip to next track'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> skipPrevious() async {
    try {
      if (_player.hasPrevious) {
        if (_crossfadeSeconds > 0) {
          await _performSmoothTransition(() => _player.seekToPrevious());
        } else {
          await _cancelCrossfadeAndRestoreVolume();
          await _player.seekToPrevious().timeout(_navigationTimeout);
        }
      } else {
        await _cancelCrossfadeAndRestoreVolume();
        await _player.seek(Duration.zero).timeout(_navigationTimeout);
      }

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] skipPrevious() failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'skip to previous track'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> jumpTo(int index) async {
    await _cancelCrossfadeAndRestoreVolume();

    final length = _player.audioSources.length;

    if (index < 0 || index >= length) {
      return PlaybackCommandResult.failure(
        PlaybackFailure(
          PlaybackErrorType.invalidOperation,
          'Cannot jump to index $index in a queue of length $length.',
        ),
      );
    }

    try {
      await _player
          .seek(Duration.zero, index: index)
          .timeout(_navigationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] jumpTo($index) failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'jump to queue item'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> setVolume(double volume) async {
    final previousVolume = _targetVolume;
    final nextVolume = volume.clamp(0.0, 1.0).toDouble();

    try {
      // Do not fight the fade while crossfade is actively controlling volume.
      // The final fade-in will restore the newest _targetVolume.
      if (!_crossfadeInProgress) {
        await _player.setVolume(nextVolume).timeout(_configurationTimeout);
      }

      _targetVolume = nextVolume;

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      _targetVolume = previousVolume;
      debugPrint('[JustAudioEngine] setVolume($volume) failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'change volume'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> setSpeed(double speed) async {
    final clamped = speed.clamp(0.25, 4.0).toDouble();

    try {
      await _player.setSpeed(clamped).timeout(_configurationTimeout);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] setSpeed($speed) failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'change speed'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> setShuffle(bool enabled) async {
    if (_queue.shuffleEnabled == enabled) {
      return const PlaybackCommandResult.noChange();
    }

    try {
      await _player
          .setShuffleModeEnabled(enabled)
          .timeout(_configurationTimeout);

      _queue = _queue.copyWith(shuffleEnabled: enabled);
      _queueController.add(_queue);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] setShuffle($enabled) failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'change shuffle mode'),
      );
    }
  }

  @override
  Future<PlaybackCommandResult> setRepeatMode(PlaybackRepeatMode mode) async {
    if (_queue.repeatMode == mode) {
      return const PlaybackCommandResult.noChange();
    }

    final loopMode = switch (mode) {
      PlaybackRepeatMode.off => LoopMode.off,
      PlaybackRepeatMode.all => LoopMode.all,
      PlaybackRepeatMode.one => LoopMode.one,
    };

    try {
      await _player.setLoopMode(loopMode).timeout(_configurationTimeout);

      _queue = _queue.copyWith(repeatMode: mode);
      _queueController.add(_queue);

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      debugPrint(
        '[JustAudioEngine] setRepeatMode(${mode.name}) failed: $error',
      );
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'change repeat mode'),
      );
    }
  }
  @override
  Future<PlaybackCommandResult> setCrossfade(int seconds) async {
    final previousSeconds = _crossfadeSeconds;
    final previousTriggered = _crossfadeTriggered;

    try {
      // Clamped to _maxCrossfadeSeconds, matching the actual range exposed
      // by every crossfade control in the app. Nothing in the UI can ever
      // send a value above this, so accepting a wider range here only
      // implied capacity that didn't exist three layers away in the
      // fade-duration math.
      final clamped = seconds.clamp(0, _maxCrossfadeSeconds).toInt();

      if (clamped == 0) {
        await _cancelCrossfadeAndRestoreVolume();
      }

      _crossfadeSeconds = clamped;
      _crossfadeTriggered = false;

      return const PlaybackCommandResult.success();
    } catch (error, stackTrace) {
      _crossfadeSeconds = previousSeconds;
      _crossfadeTriggered = previousTriggered;
      debugPrint('[JustAudioEngine] setCrossfade($seconds) failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return _reportCommandFailure(
        _classifyCommandError(error, operation: 'change crossfade'),
      );
    }
  }

  /// Starts a safe single-player smooth transition when the current track is
  /// within [_crossfadeSeconds] of its end.
  ///
  /// This is intentionally not a two-player overlapping DJ crossfade. It is a
  /// safer release-ready transition:
  /// current track fades down → player jumps to next track → next track fades up.
  void _checkCrossfade(Duration position) {
    if (_crossfadeSeconds <= 0) return;
    if (_crossfadeTriggered || _crossfadeInProgress) return;
    if (_disposed) return;
    if (!_state.playing) return;
    if (_state.processingState != PlaybackProcessingState.ready) return;
    if (!_player.hasNext) return;

    final duration = _state.duration;
    if (duration <= Duration.zero) return;

    final threshold = Duration(seconds: _crossfadeSeconds);

    // Avoid instantly crossfading very short clips where the selected
    // crossfade duration is longer than the usable track duration.
    if (duration <= threshold + const Duration(seconds: 1)) return;

    final remaining = duration - position;
    if (remaining <= Duration.zero) return;

    if (remaining <= threshold) {
      _crossfadeTriggered = true;
      unawaited(_performSmoothCrossfadeToNext());
    }
  }

  /// Starts a safe single-player smooth transition when the current track is
  /// within [_crossfadeSeconds] of its end. Delegates the actual fade to
  /// [_performSmoothTransition], which is also used by [skipNext] and
  /// [skipPrevious] so manual skips feel consistent with natural transitions
  /// whenever crossfade is enabled.
  Future<void> _performSmoothCrossfadeToNext() async {
    if (_disposed || _crossfadeInProgress || !_player.hasNext) return;
    await _performSmoothTransition(() => _player.seekToNext());
  }

  /// Runs [seek] as a smooth, faded transition instead of an instant cut:
  /// current volume fades to silence, [seek] executes, then volume fades
  /// back up to the real target volume.
  ///
  /// This is intentionally not a two-player overlapping DJ crossfade. It is a
  /// safer single-player transition:
  /// current track fades down → [seek] runs → next track fades up.
  Future<void> _performSmoothTransition(Future<void> Function() seek) async {
    if (_disposed || _crossfadeInProgress) return;

    _crossfadeInProgress = true;
    _crossfadeTriggered = true;

    final token = ++_transitionToken;

    // Split the selected crossfade duration into fade-out + fade-in.
    // Example: 6 sec setting = 3 sec fade down + 3 sec fade up.
    // The ceiling here is derived from _maxCrossfadeSeconds (not a separate
    // literal), so it always lands exactly on the real max setting's fade
    // duration and can't drift out of sync with setCrossfade's own clamp.
    final fadeMs = (_crossfadeSeconds * 500)
        .clamp(350, _maxCrossfadeSeconds * 500)
        .toInt();
    final fadeDuration = Duration(milliseconds: fadeMs);

    final startVolume = _state.volume.clamp(0.0, 1.0).toDouble();
    final restoreVolume = _targetVolume.clamp(0.0, 1.0).toDouble();

    debugPrint(
      '[JustAudioEngine] smooth transition: fade out ${fadeDuration.inMilliseconds}ms, '
      'seek, fade in ${fadeDuration.inMilliseconds}ms',
    );

    try {
      await _fadePlayerVolume(
        from: startVolume,
        to: 0.0,
        duration: fadeDuration,
        token: token,
      );

      if (_disposed || token != _transitionToken) return;

      await seek();

      if (_disposed || token != _transitionToken) return;

      // Ensure the new track starts silent before fade-in.
      await _player.setVolume(0.0);

      await _fadePlayerVolume(
        from: 0.0,
        to: restoreVolume,
        duration: fadeDuration,
        token: token,
      );
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] smooth transition failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      if (!_disposed && token == _transitionToken) {
        _crossfadeInProgress = false;
        _crossfadeTriggered = false;

        try {
          await _player.setVolume(_targetVolume);
        } catch (_) {
          // Ignore restore errors if the player is changing state/disposed.
        }
      }
    }
  }

  Future<void> _fadePlayerVolume({
    required double from,
    required double to,
    required Duration duration,
    required int token,
  }) async {
    if (_disposed) return;
    if (token != _transitionToken) return;

    final totalMs = duration.inMilliseconds;
    if (totalMs <= 0) {
      await _player.setVolume(to.clamp(0.0, 1.0).toDouble());
      return;
    }

    final steps = (totalMs ~/ 50).clamp(6, 80).toInt();
    final stepDelay = Duration(milliseconds: (totalMs ~/ steps).clamp(10, 120));

    for (var i = 1; i <= steps; i++) {
      if (_disposed || token != _transitionToken) return;

      final t = i / steps;
      final value = from + ((to - from) * t);
      await _player.setVolume(value.clamp(0.0, 1.0).toDouble());
      await Future<void>.delayed(stepDelay);
    }
  }

  void _cancelCrossfadeState() {
    _transitionToken++;
    _crossfadeTriggered = false;
    _crossfadeInProgress = false;
  }

  Future<void> _cancelCrossfadeAndRestoreVolume() async {
    _cancelCrossfadeState();

    if (_disposed) return;

    try {
      await _player.setVolume(_targetVolume);
    } catch (_) {
      // Ignore restore errors if the player is not ready.
    }
  }

  @override
  Future<void> dispose() async {
    if (_disposed) return;

    _disposed = true;
    _transitionToken++;

    await _effectsSubscription?.cancel();

    for (final sub in _subscriptions) {
      await sub.cancel();
    }

    await _stateController.close();
    await _queueController.close();

    // Release Android audio effects.
    if (_androidEffectsInitialized) {
      await AndroidAudioEffects.instance.release();
      _androidEffectsInitialized = false;
    }

    await _player.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Audio source conversion
  // ═══════════════════════════════════════════════════════════════════════════

  /// Converts a [MediaEntry] into a just_audio [AudioSource].
  ///
  /// Tags each source with the original [MediaEntry] so the queue can be
  /// reconstructed from the sequence state stream.
  AudioSource _toAudioSource(MediaEntry entry) {
    if (entry.source.isEmpty) {
      // Keep invalid future queue entries representable so a valid current
      // source can start. ExoPlayer will report this placeholder as missing
      // only if playback reaches it, allowing bounded runtime recovery.
      final safeId = Uri.encodeComponent(entry.id);
      return AudioSource.uri(
        Uri.file('/__vibes_missing_source__/$safeId'),
        tag: entry,
      );
    }

    final uri = _toPlaybackUri(entry.source);
    return AudioSource.uri(Uri.parse(uri), tag: entry);
  }

  /// Converts a [MediaSourceRef] value into a URI string.
  static String _toPlaybackUri(MediaSourceRef source) {
    final value = source.value;

    switch (source.type) {
      case MediaSourceType.contentUri:
        return value;
      case MediaSourceType.documentUri:
        return value;
      case MediaSourceType.filePath:
        if (value.startsWith('file://')) return value;
        if (value.startsWith('content://')) return value;
        return 'file://$value';
    }
  }

  PlaybackCommandResult _reportCommandFailure(
    PlaybackFailure failure, {
    bool fatal = false,
    PlaybackQueue? restoreQueue,
  }) {
    final currentIndex = _queue.currentIndex;
    final currentEntry = _queue.current;
    final enriched = failure.copyWith(
      entryId: failure.entryId.isNotEmpty
          ? failure.entryId
          : currentEntry?.id ?? '',
      queueIndex:
          failure.queueIndex >= 0 ? failure.queueIndex : currentIndex,
    );

    _metrics.recordFailure(
      enriched.type,
      operation: enriched.operation,
    );

    if (restoreQueue != null) {
      _queue = restoreQueue;
      _queueController.add(_queue);
    }

    if (fatal) {
      _emitState(
        _state.copyWith(
          processingState: PlaybackProcessingState.error,
          playing: false,
          failure: enriched,
          isRecovering: false,
          consecutiveFailures: _consecutiveRuntimeFailures,
          failedEntryId: enriched.entryId,
        ),
      );
    }

    return PlaybackCommandResult.failure(enriched);
  }

  static PlaybackFailure _classifyCommandError(
    Object error, {
    required String operation,
  }) {
    if (error is PlayerException) {
      return _classifyPlayerException(error).copyWith(
        operation: operation,
      );
    }

    if (error is TimeoutException) {
      return PlaybackFailure(
        PlaybackErrorType.timeout,
        'The engine timed out while trying to $operation.',
        cause: error,
      );
    }

    final text = '${error.runtimeType} $error'.toLowerCase();

    if (error is FormatException ||
        error is ArgumentError ||
        text.contains('invalid uri') ||
        text.contains('invalid source') ||
        text.contains('malformed')) {
      return PlaybackFailure(
        PlaybackErrorType.invalidSource,
        'The audio source is invalid and could not be used.',
        cause: error,
      );
    }

    if (text.contains('cancel') ||
        text.contains('canceled') ||
        text.contains('cancelled') ||
        text.contains('abort')) {
      return PlaybackFailure(
        PlaybackErrorType.cancelled,
        'The engine cancelled the request to $operation.',
        cause: error,
      );
    }

    if (text.contains('interrupt') ||
        text.contains('audio focus') ||
        text.contains('focus loss') ||
        text.contains('session inactive')) {
      return PlaybackFailure(
        PlaybackErrorType.interrupted,
        'Playback was interrupted while trying to $operation.',
        cause: error,
      );
    }

    if (text.contains('permission') ||
        text.contains('denied') ||
        text.contains('securityexception')) {
      return PlaybackFailure(
        PlaybackErrorType.accessDenied,
        'Audio access was denied while trying to $operation.',
        cause: error,
      );
    }

    if (text.contains('not found') ||
        text.contains('no such file') ||
        text.contains('file_not_found') ||
        text.contains('enoent') ||
        text.contains('source unavailable')) {
      return PlaybackFailure(
        PlaybackErrorType.sourceUnavailable,
        'The requested audio file is missing or unavailable.',
        cause: error,
      );
    }

    if (text.contains('unsupported') ||
        text.contains('unrecognized') ||
        text.contains('unsupported format') ||
        text.contains('unsupported codec')) {
      return PlaybackFailure(
        PlaybackErrorType.unsupportedFormat,
        'The audio format or codec is not supported.',
        cause: error,
      );
    }

    if (text.contains('decoder') ||
        text.contains('decode') ||
        text.contains('codec')) {
      return PlaybackFailure(
        PlaybackErrorType.decoder,
        'The audio source could not be decoded.',
        cause: error,
      );
    }

    return PlaybackFailure(
      PlaybackErrorType.engine,
      'The playback engine failed to $operation.',
      cause: error,
    );
  }

  static PlaybackFailure _classifyPlayerException(PlayerException error) {
    final message = '${error.code} ${error.message}'.toLowerCase();

    if (message.contains('permission') ||
        message.contains('denied') ||
        message.contains('security')) {
      return PlaybackFailure(
        PlaybackErrorType.accessDenied,
        'Audio access was denied for this track.',
        cause: error,
      );
    }

    if (message.contains('not found') ||
        message.contains('no such file') ||
        message.contains('file_not_found') ||
        message.contains('source error')) {
      return PlaybackFailure(
        PlaybackErrorType.sourceUnavailable,
        'The audio file was moved, deleted, or is unavailable.',
        cause: error,
      );
    }

    if (message.contains('unsupported') ||
        message.contains('unrecognized') ||
        message.contains('format')) {
      return PlaybackFailure(
        PlaybackErrorType.unsupportedFormat,
        'The audio format or codec is not supported.',
        cause: error,
      );
    }

    return PlaybackFailure(
      PlaybackErrorType.decoder,
      'The audio file could not be decoded.',
      cause: error,
    );
  }

  Future<void> _recoverFromRuntimeFailure(
    Object error,
    StackTrace stackTrace,
  ) async {
    if (_disposed || _openingSource || _runtimeRecoveryInProgress) {
      return;
    }

    _runtimeRecoveryInProgress = true;

    try {
      var failure = _classifyCommandError(
        error,
        operation: 'continue runtime playback',
      );
      final now = DateTime.now();

      if (_lastRuntimeFailureAt == null ||
          now.difference(_lastRuntimeFailureAt!) > _runtimeFailureWindow) {
        _consecutiveRuntimeFailures = 0;
      }

      _lastRuntimeFailureAt = now;
      _consecutiveRuntimeFailures++;

      failure = failure.copyWith(
        entryId: _queue.current?.id ?? '',
        queueIndex: _queue.currentIndex,
        attempt: _consecutiveRuntimeFailures,
        maxAttempts: _maxConsecutiveRuntimeFailures,
      );

      debugPrint(
        '[JustAudioEngine] Runtime playback failure '
        '${failure.type.name}: ${failure.message}',
      );
      debugPrintStack(stackTrace: stackTrace);
      _metrics.recordFailure(
        failure.type,
        operation: failure.operation,
      );

      if (!failure.canSkipTrack) {
        _reportCommandFailure(failure, fatal: true);
        return;
      }

      var latestFailure = failure;

      while (_consecutiveRuntimeFailures <=
              _maxConsecutiveRuntimeFailures &&
          _player.hasNext) {
        _metrics.recordRecoveryAttempt();

        _emitState(
          _state.copyWith(
            processingState: PlaybackProcessingState.buffering,
            playing: false,
            failure: latestFailure,
            isRecovering: true,
            consecutiveFailures: _consecutiveRuntimeFailures,
            failedEntryId: latestFailure.entryId,
          ),
        );

        final previousIndex = _player.currentIndex;

        try {
          await _player.seekToNext().timeout(_navigationTimeout);

          if (!_player.playing) {
            unawaited(
              _player.play().catchError(
                (Object playError, StackTrace playStackTrace) {
                  debugPrint(
                    '[JustAudioEngine] Recovery play request failed: '
                    '$playError',
                  );
                  debugPrintStack(stackTrace: playStackTrace);
                },
              ),
            );
          }

          await _player.playerStateStream
              .firstWhere(
                (state) =>
                    _player.currentIndex != previousIndex &&
                    state.processingState == ProcessingState.ready &&
                    state.playing,
              )
              .timeout(_playStartTimeout);

          _metrics.recordRecoverySuccess();
          _emitState(
            _state.copyWith(
              processingState: PlaybackProcessingState.ready,
              playing: true,
              position: Duration.zero,
              clearFailure: true,
              clearRecovery: true,
            ),
          );
          return;
        } catch (recoveryError, recoveryStackTrace) {
          _consecutiveRuntimeFailures++;
          latestFailure = _classifyCommandError(
            recoveryError,
            operation: 'recover runtime playback',
          ).copyWith(
            entryId: _queue.current?.id ?? '',
            queueIndex: _queue.currentIndex,
            attempt: _consecutiveRuntimeFailures,
            maxAttempts: _maxConsecutiveRuntimeFailures,
          );

          _metrics.recordFailure(
            latestFailure.type,
            operation: latestFailure.operation,
          );
          debugPrint(
            '[JustAudioEngine] Recovery attempt failed: '
            '${latestFailure.message}',
          );
          debugPrintStack(stackTrace: recoveryStackTrace);
        }
      }

      _metrics.recordRecoveryExhausted();
      _reportCommandFailure(
        latestFailure.copyWith(
          message:
              'Playback stopped after repeated unavailable or unplayable tracks.',
          operation: 'automatic runtime recovery',
        ),
        fatal: true,
      );
    } finally {
      _runtimeRecoveryInProgress = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Audio effects (equalizer)
  // ═══════════════════════════════════════════════════════════════════════════

  /// Applies one atomic DSP snapshot. Gain staging, bass layering,
  /// normalization, stereo width, and limiting are resolved by the native
  /// processor so rapid state changes cannot be applied out of order.
  Future<void> _applyAudioEffects(EqState state) async {
    _effectsState = state;

    if (!AndroidAudioEffects.isSupported || _disposed) {
      return;
    }

    if (!_androidEffectsInitialized) {
      await _initializeAndroidEffects();
    }

    if (!_androidEffectsInitialized) {
      return;
    }

    try {
      final applied = await AndroidAudioEffects.instance.applyConfiguration(
        enabled: state.enabled,
        bandGainsDb: state.bands
            .map((band) => band.gainDb)
            .toList(growable: false),
        bassBoost: state.bassBoost / 100.0,
        volumeBoost: state.volumeBoost / 100.0,
        stereoWidth: 1.0 + (state.virtualizer / 100.0 * 0.5),
        normalization: state.normalization,
      );

      if (!applied) {
        debugPrint(
          '[JustAudioEngine] Audio effects were not applied: '
          '${AndroidAudioEffects.instance.lastError ?? 'unknown reason'}',
        );
      }
    } on AudioEffectsException catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] Audio effects failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    } catch (error, stackTrace) {
      debugPrint('[JustAudioEngine] Audio effects failed: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Android audio effects initialization
  // ═══════════════════════════════════════════════════════════════════════════

  /// Initialize Android native audio effects.
  ///
  /// Uses the global audio session (0), which affects this app's audio output
  /// through the platform effects implementation.
  Future<void> _initializeAndroidEffects() async {
    if (!AndroidAudioEffects.isSupported ||
        _androidEffectsInitialized ||
        _disposed) {
      return;
    }

    try {
      _androidEffectsInitialized =
          await AndroidAudioEffects.instance.initialize();

      if (!_androidEffectsInitialized) {
        debugPrint(
          '[JustAudioEngine] Software DSP unavailable: '
          '${AndroidAudioEffects.instance.lastError ?? 'renderer not attached'}',
        );
        return;
      }

      debugPrint(
        '[JustAudioEngine] Software DSP initialized with '
        '${AndroidAudioEffects.instance.equalizerBands.length} bands.',
      );
    } catch (error, stackTrace) {
      _androidEffectsInitialized = false;
      debugPrint(
        '[JustAudioEngine] Failed to initialize Android effects: $error',
      );
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // Internal helpers
  // ═══════════════════════════════════════════════════════════════════════════

  void _emitState(PlaybackSnapshot state) {
    if (!_disposed && !_stateController.isClosed) {
      _state = state;
      _stateController.add(state);
    }
  }
}
