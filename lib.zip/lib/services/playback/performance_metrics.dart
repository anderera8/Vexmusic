// lib/services/playback/performance_metrics.dart
// ─────────────────────────────────────────────────────────────────────────────
// Performance measurement for Phase 8 production rollout.
//
// Tracks:
//   - Player initialization time
//   - Time to first audio frame
//   - Playback failure count by error type
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/foundation.dart';
import '../../models/media_models.dart';

class PerformanceMetrics {
  static final PerformanceMetrics _instance = PerformanceMetrics._();
  factory PerformanceMetrics() => _instance;
  PerformanceMetrics._();

  // ── Timing ────────────────────────────────────────────────────────

  DateTime? _initStart;
  DateTime? _initEnd;
  DateTime? _firstAudioOpenStart;

  /// Whether metrics have been recorded (prevents double-counting).
  bool _audioMeasured = false;

  /// Player initialization duration in milliseconds, or -1.
  int get initDurationMs {
    if (_initStart == null || _initEnd == null) return -1;
    return _initEnd!.difference(_initStart!).inMilliseconds;
  }

  /// Time to first audio frame in milliseconds, or -1.
  int _firstAudioFrameMs = -1;

  // ── Failure counts ────────────────────────────────────────────────

  final Map<PlaybackErrorType, int> _failures = {};
  final Map<String, int> _operationFailures = {};
  int _recoveryAttempts = 0;
  int _successfulRecoveries = 0;
  int _exhaustedRecoveries = 0;

  int failureCount(PlaybackErrorType type) => _failures[type] ?? 0;
  int operationFailureCount(String operation) =>
      _operationFailures[operation] ?? 0;
  int get recoveryAttempts => _recoveryAttempts;
  int get successfulRecoveries => _successfulRecoveries;
  int get exhaustedRecoveries => _exhaustedRecoveries;
  int get totalFailures =>
      _failures.values.fold(0, (sum, count) => sum + count);

  // ── Record methods ────────────────────────────────────────────────

  void recordInitStart() {
    _initStart = DateTime.now();
  }

  void recordInitEnd() {
    _initEnd = DateTime.now();
  }

  void recordAudioOpenStart() {
    if (!_audioMeasured) _firstAudioOpenStart = DateTime.now();
  }

  void recordAudioReady() {
    if (!_audioMeasured && _firstAudioOpenStart != null) {
      _firstAudioFrameMs =
          DateTime.now().difference(_firstAudioOpenStart!).inMilliseconds;
      _audioMeasured = true;
    }
  }

  void recordFailure(
    PlaybackErrorType type, {
    String operation = '',
  }) {
    _failures[type] = (_failures[type] ?? 0) + 1;

    if (operation.isNotEmpty) {
      _operationFailures[operation] =
          (_operationFailures[operation] ?? 0) + 1;
    }
  }

  void recordRecoveryAttempt() {
    _recoveryAttempts++;
  }

  void recordRecoverySuccess() {
    _successfulRecoveries++;
  }

  void recordRecoveryExhausted() {
    _exhaustedRecoveries++;
  }

  // ── Summary ───────────────────────────────────────────────────────

  /// Returns a map suitable for logging to Firebase or debug output.
  Map<String, dynamic> get summary => {
        'initDurationMs': initDurationMs,
        'firstAudioFrameMs': _firstAudioFrameMs,
        'totalFailures': totalFailures,
        'recoveryAttempts': recoveryAttempts,
        'successfulRecoveries': successfulRecoveries,
        'exhaustedRecoveries': exhaustedRecoveries,
        for (final entry in _operationFailures.entries)
          'operationFailures_${entry.key}': entry.value,
        for (final type in PlaybackErrorType.values)
          'failures_${type.name}': _failures[type] ?? 0,
      };

  @visibleForTesting
  static void resetInstance() {
    // No-op for now — tests use their own snapshot fields.
  }
}
