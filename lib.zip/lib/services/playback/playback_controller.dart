// lib/services/playback/playback_controller.dart
// ─────────────────────────────────────────────────────────────────────────────
// Playback command handler — extracted from MusicProvider.
// Handles all play, pause, seek, skip, shuffle, repeat, and queue-drain
// operations.  Pure service — takes state in, returns PlaybackResult out.
// MusicProvider is responsible for calling notifyListeners() afterward.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../../models/music_models.dart';
import '../../models/media_models.dart';
import '../../providers/state/library_state.dart';
import '../../providers/state/playback_state.dart';
import '../../providers/state/queue_state.dart';
import '../../providers/settings_provider.dart';
import '../../providers/queue_provider.dart';
import '../../providers/lyrics_provider.dart';
import '../database_service.dart';
import '../artwork_cache_service.dart';
import '../history/history_service.dart';
import 'media_playback_coordinator.dart';
import 'playback_system_service.dart';
import '../../providers/music_provider.dart' show ActiveContextType;

/// Bundled result of a playback operation.
class PlaybackResult {
  final PlaybackState playbackState;
  final QueueState queueState;
  final LibraryState? libraryState; // non-null when history changes

  /// Non-fatal source failure that was recovered by advancing in the queue.
  final PlaybackFailure? notice;

  const PlaybackResult({
    required this.playbackState,
    required this.queueState,
    this.libraryState,
    this.notice,
  });
}

class _PlaybackSelection {
  const _PlaybackSelection({
    required this.index,
    this.notice,
  });

  final int index;
  final PlaybackFailure? notice;
}

class PlaybackController {
  final MediaPlaybackCoordinator _coordinator;
  final DatabaseService _db;
  final HistoryService _history;

  bool _pendingDrainInProgress = false;

  PlaybackController({
    MediaPlaybackCoordinator? coordinator,
    DatabaseService? db,
    HistoryService? history,
  })  : _coordinator = coordinator ?? MediaPlaybackCoordinator(),
        _db = db ?? DatabaseService(),
        _history = history ?? HistoryService();

  // ── Helpers ─────────────────────────────────────────────────────────────

  /// Converts a list of Tracks into engine-neutral MediaEntry objects.
  static (MediaEntry, List<MediaEntry>) toMediaEntries(
      List<Track> tracks, int initialIndex) {
    final entries = tracks.map((t) => t.toMediaEntry()).toList();
    final idx = initialIndex.clamp(0, entries.length - 1);
    return (entries[idx], entries);
  }

  static LibraryState _withRecentPlay(
    LibraryState state,
    Track track, {
    int lastPositionMs = 0,
  }) {
    final entry = PlayHistory(
      trackId: track.id,
      stableKey: track.stableKey,
      title: track.title,
      artist: track.artist,
      playedAt: DateTime.now(),
      lastPositionMs: lastPositionMs,
    );

    final history = <PlayHistory>[
      entry,
      ...state.recentHistory.where(
        (item) =>
            item.trackId != track.id &&
            (item.stableKey.isEmpty || item.stableKey != track.stableKey),
      ),
    ];
    return state.copyWith(
      recentHistory: history.take(30).toList(growable: false),
    );
  }

  /// Whether the coordinator currently has a loaded playlist.
  bool hasLoadedPlaylist(PlaybackState pb) {
    if (!pb.audioPlaylistLoaded) return false;
    return _coordinator.currentQueue.entries.isNotEmpty;
  }

  Future<void> _insertQueueEntry(int index, Track track) {
    return _coordinator.insertQueueEntry(index, track.toMediaEntry());
  }

  Track? _findRefreshedTrack(
    Track oldTrack,
    LibraryState newLib,
  ) {
    final byId = newLib.trackById[oldTrack.id];
    if (byId != null) return byId;

    for (final candidate in newLib.tracks) {
      if (candidate.matchesStableIdentity(oldTrack)) {
        return candidate;
      }
    }

    return null;
  }

  bool _isSameQueueTrack(Track a, Track b) {
    return a.id == b.id || a.matchesStableIdentity(b);
  }

  List<String> _libraryQueueIds(List<Track> queue) {
    return List<String>.generate(
      queue.length,
      (index) => 'library-${queue[index].id}-$index',
      growable: false,
    );
  }

  List<String> _activeQueueIdsFor(QueueState q, List<Track> queue) {
    if (q.activeQueue.isNotEmpty && q.activeQueueItemIds.length == queue.length) {
      return List<String>.from(q.activeQueueItemIds);
    }

    return _libraryQueueIds(queue);
  }

  List<QueueItemView> _visibleUpNextItems(
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    QueueProvider queueProvider,
  ) {
    return queueState.upNextItems(
      library.tracks,
      playback.nowIdx,
      queueProvider.pendingQueueItems,
      effectiveOrder: _coordinator.currentQueue.normalizedEffectiveOrder,
    );
  }

  int _resolveUpNextIndexById(
    String queueItemId,
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    QueueProvider queueProvider,
  ) {
    final items = _visibleUpNextItems(
      library,
      playback,
      queueState,
      queueProvider,
    );

    return items.indexWhere((item) => item.id == queueItemId);
  }

  bool _isExpectedQueueLoaded(
    List<MediaEntry> expectedEntries,
    int expectedIndex,
  ) {
    final playbackState = _coordinator.currentState;

    // JustAudioEngine currently reports failures through its state instead of
    // always throwing them. A successful open must therefore reach ready.
    if (playbackState.processingState != PlaybackProcessingState.ready) {
      return false;
    }

    final actualQueue = _coordinator.currentQueue;

    if (actualQueue.currentIndex != expectedIndex ||
        actualQueue.entries.length != expectedEntries.length) {
      return false;
    }

    for (var index = 0; index < expectedEntries.length; index++) {
      final expected = expectedEntries[index];
      final actual = actualQueue.entries[index];

      if (actual.id != expected.id ||
          actual.source.type != expected.source.type ||
          actual.source.value != expected.source.value) {
        return false;
      }
    }

    return true;
  }

  static const int _maxSourceRecoveryAttempts = 3;

  bool _canAdvancePastFailure(PlaybackFailure failure) =>
      failure.canSkipTrack;

  Future<_PlaybackSelection> _openAndStartWithRecovery({
    required List<Track> tracks,
    required int initialIndex,
    required SettingsProvider settings,
    int direction = 1,
    Duration resumePosition = Duration.zero,
  }) async {
    if (tracks.isEmpty) {
      throw const PlaybackCommandException(
        PlaybackFailure(
          PlaybackErrorType.invalidSource,
          'The playback queue is empty.',
          operation: 'open queue',
        ),
      );
    }

    final entries = tracks.map((track) => track.toMediaEntry()).toList(
          growable: false,
        );
    final safeInitial = initialIndex.clamp(0, tracks.length - 1).toInt();
    final maximumAttempts = math.min(
      _maxSourceRecoveryAttempts,
      direction >= 0 ? tracks.length - safeInitial : safeInitial + 1,
    );

    PlaybackCommandException? lastFailure;
    var skipped = 0;

    for (var attempt = 0; attempt < maximumAttempts; attempt++) {
      final candidateIndex = safeInitial + (attempt * direction);
      final candidate = entries[candidateIndex];

      try {
        await _coordinator.open(
          candidate,
          queue: entries,
          initialIndex: candidateIndex,
          autoPlay: false,
        );

        await applyDeferredConfig(settings);

        if (attempt == 0 && resumePosition > Duration.zero) {
          await _coordinator.seek(resumePosition);
        }

        await _coordinator.play();

        PlaybackFailure? notice;
        if (skipped > 0 && lastFailure != null) {
          notice = lastFailure.failure.copyWith(
            message: skipped == 1
                ? 'Skipped one unavailable or unplayable track.'
                : 'Skipped $skipped unavailable or unplayable tracks.',
            operation: 'automatic source recovery',
            attempt: skipped,
            maxAttempts: maximumAttempts,
          );
        }

        return _PlaybackSelection(
          index: candidateIndex,
          notice: notice,
        );
      } on PlaybackCommandException catch (error) {
        final failure = error.failure.copyWith(
          entryId: candidate.id,
          queueIndex: candidateIndex,
          attempt: attempt + 1,
          maxAttempts: maximumAttempts,
        );
        lastFailure = PlaybackCommandException(failure);

        final hasAnotherCandidate = attempt + 1 < maximumAttempts;
        if (!_canAdvancePastFailure(failure) || !hasAnotherCandidate) {
          throw lastFailure;
        }

        skipped++;
        debugPrint(
          '[PlaybackController] Skipping failed queue item '
          '$candidateIndex (${failure.type.name}).',
        );
      }
    }

    throw lastFailure ??
        const PlaybackCommandException(
          PlaybackFailure(
            PlaybackErrorType.engine,
            'Playback recovery ended without selecting a source.',
          ),
        );
  }

  Future<void> _restoreAfterFailedPendingDrain({
    required PlaybackQueue previousQueue,
    required PlaybackSnapshot previousState,
  }) async {
    try {
      if (previousQueue.entries.isEmpty) {
        await _coordinator.stop();
        return;
      }

      final previousIndex = previousQueue.currentIndex < 0
          ? 0
          : previousQueue.currentIndex.clamp(
              0,
              previousQueue.entries.length - 1,
            ).toInt();

      await _coordinator.open(
        previousQueue.entries[previousIndex],
        queue: previousQueue.entries,
        initialIndex: previousIndex,
        autoPlay: false,
      );

      if (_coordinator.currentState.processingState ==
          PlaybackProcessingState.error) {
        debugPrint(
          '[PlaybackController] Could not restore the previous queue after '
          'a failed pending drain.',
        );
        return;
      }

      await _coordinator.setShuffle(previousQueue.shuffleEnabled);
      await _coordinator.setRepeatMode(previousQueue.repeatMode);
      await _coordinator.setVolume(previousState.volume);
      await _coordinator.setSpeed(previousState.speed);

      if (previousState.position > Duration.zero) {
        await _coordinator.seek(previousState.position);
      }

      if (previousState.playing) {
        unawaited(
          _coordinator.play().catchError(
            (Object error, StackTrace stackTrace) {
              debugPrint(
                '[PlaybackController] Failed to resume restored playback: '
                '$error\n$stackTrace',
              );
            },
          ),
        );
      } else {
        await _coordinator.pause();
      }
    } catch (error, stackTrace) {
      // Restoration is best-effort. The original pending queue remains intact
      // even when the underlying engine cannot restore its old source.
      debugPrint(
        '[PlaybackController] Pending-drain rollback failed: '
        '$error\n$stackTrace',
      );
    }
  }

  /// Persists the current playback position so it can be resumed later.
  Future<void> saveCurrentPosition(
    PlaybackState pb,
    LibraryState lib,
    QueueState q,
  ) async {
    if (!hasLoadedPlaylist(pb) || lib.tracks.isEmpty) return;
    final queue = q.activeQueue.isNotEmpty ? q.activeQueue : lib.tracks;
    if (pb.nowIdx < 0 || pb.nowIdx >= queue.length) return;
    final posMs = pb.position.inMilliseconds;
    if (posMs > 2000) {
      await _db.recordPlay(queue[pb.nowIdx], lastPositionMs: posMs);
    }
  }

  /// Applies deferred player config (shuffle, repeat, speed) via settings.
  Future<void> applyDeferredConfig(SettingsProvider settings) =>
      settings.applyDeferredPlayerConfig(coordinator: _coordinator);

  // ── Playback commands ───────────────────────────────────────────────────

  /// Play a single track from the full library queue.
  Future<PlaybackResult> playTrack(
    int idx,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings, {
    bool recordHistory = true,
  }) async {
    if (lib.tracks.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    await saveCurrentPosition(pb, lib, q);
    final requestedIndex = idx.clamp(0, lib.tracks.length - 1).toInt();
    final selection = await _openAndStartWithRecovery(
      tracks: lib.tracks,
      initialIndex: requestedIndex,
      settings: settings,
    );
    final selectedTrack = lib.tracks[selection.index];

    LibraryState? updatedLib;
    if (recordHistory) {
      await _history.recordPlay(selectedTrack);
      updatedLib = _withRecentPlay(lib, selectedTrack);
    }

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: selection.index,
        isSwitchingTrack: false,
        hasStartedPlayback: true,
        isPlaying: true,
        audioPlaylistLoaded: true,
        position: Duration.zero,
        totalDuration: null,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
        failure: selection.notice,
        isRecovering: false,
        consecutiveFailures: selection.notice?.attempt ?? 0,
        clearFailure: selection.notice == null,
      ),
      queueState: QueueState.initial(),
      libraryState: updatedLib,
      notice: selection.notice,
    );
  }

  /// Play a context-specific queue (folder / artist / playlist).
  Future<PlaybackResult> playQueue(
    List<Track> queueTracks,
    int startIndex,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings, {
    ActiveContextType contextType = ActiveContextType.none,
    String contextName = '',
    int contextId = -1,
  }) async {
    if (queueTracks.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    await saveCurrentPosition(pb, lib, q);
    final activeQueue = List<Track>.unmodifiable(queueTracks);
    final requestedIndex = startIndex.clamp(0, activeQueue.length - 1).toInt();
    final selection = await _openAndStartWithRecovery(
      tracks: activeQueue,
      initialIndex: requestedIndex,
      settings: settings,
    );
    final selectedTrack = activeQueue[selection.index];

    await _history.recordPlay(selectedTrack);
    final updatedLib = _withRecentPlay(lib, selectedTrack);

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: selection.index,
        isSwitchingTrack: false,
        hasStartedPlayback: true,
        isPlaying: true,
        audioPlaylistLoaded: true,
        position: Duration.zero,
        totalDuration: null,
        activeContextType: contextType,
        activeContextName: contextName,
        activeContextId: contextId,
        failure: selection.notice,
        isRecovering: false,
        consecutiveFailures: selection.notice?.attempt ?? 0,
        clearFailure: selection.notice == null,
      ),
      queueState: QueueState.fresh(activeQueue),
      libraryState: updatedLib,
      notice: selection.notice,
    );
  }

  /// Resume a track from its last known playback position.
  Future<PlaybackResult> resumeTrack(
    Track track,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    if (lib.tracks.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    final requestedIndex = lib.tracks.indexWhere((item) => item.id == track.id);
    if (requestedIndex == -1) {
      throw const PlaybackCommandException(
        PlaybackFailure(
          PlaybackErrorType.sourceUnavailable,
          'The selected track is no longer in the library.',
          operation: 'resume track',
        ),
      );
    }

    final lastPlay = await _history.getLastResumePointForTrack(track);
    final resumePosMs = lastPlay?.lastPositionMs ?? 0;
    final durationMs = track.duration * 1000;
    final ninetyFivePercentMs =
        durationMs > 0 ? (durationMs * 0.95).round() : 0;
    final tenSecondsBeforeEndMs = durationMs > 10000 ? durationMs - 10000 : 0;
    final shouldResume = resumePosMs > 0 &&
        durationMs > 0 &&
        resumePosMs < ninetyFivePercentMs &&
        resumePosMs < tenSecondsBeforeEndMs;
    final targetMs = shouldResume
        ? resumePosMs.clamp(0, durationMs).toInt()
        : 0;

    await saveCurrentPosition(pb, lib, q);

    final selection = await _openAndStartWithRecovery(
      tracks: lib.tracks,
      initialIndex: requestedIndex,
      settings: settings,
      resumePosition: Duration(milliseconds: targetMs),
    );
    final selectedTrack = lib.tracks[selection.index];
    final appliedResumeMs = selection.index == requestedIndex ? targetMs : 0;

    await _history.recordPlay(
      selectedTrack,
      lastPositionMs: appliedResumeMs,
    );
    final updatedLib = _withRecentPlay(
      lib,
      selectedTrack,
      lastPositionMs: appliedResumeMs,
    );

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: selection.index,
        isSwitchingTrack: false,
        hasStartedPlayback: true,
        isPlaying: true,
        audioPlaylistLoaded: true,
        position: Duration(milliseconds: appliedResumeMs),
        totalDuration: null,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
        failure: selection.notice,
        isRecovering: false,
        consecutiveFailures: selection.notice?.attempt ?? 0,
        clearFailure: selection.notice == null,
      ),
      queueState: QueueState.initial(),
      libraryState: updatedLib,
      notice: selection.notice,
    );
  }

  /// Toggle between play and pause.
  Future<PlaybackResult> togglePlayPause(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    if (lib.tracks.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    if (pb.isPlaying) {
      await saveCurrentPosition(pb, lib, q);
      await _coordinator.pause();
      return PlaybackResult(
        playbackState: pb.copyWith(
          isPlaying: false,
          isRecovering: false,
          clearFailure: true,
        ),
        queueState: q,
      );
    }

    if (!hasLoadedPlaylist(pb)) {
      final queue = q.activeQueue.isNotEmpty ? q.activeQueue : lib.tracks;
      final selection = await _openAndStartWithRecovery(
        tracks: queue,
        initialIndex: pb.nowIdx,
        settings: settings,
      );

      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: selection.index,
          hasStartedPlayback: true,
          audioPlaylistLoaded: true,
          isPlaying: true,
          isSwitchingTrack: false,
          failure: selection.notice,
          isRecovering: false,
          consecutiveFailures: selection.notice?.attempt ?? 0,
          clearFailure: selection.notice == null,
        ),
        queueState: q,
        notice: selection.notice,
      );
    }

    await _coordinator.play();
    return PlaybackResult(
      playbackState: pb.copyWith(
        hasStartedPlayback: true,
        isPlaying: true,
        isRecovering: false,
        clearFailure: true,
      ),
      queueState: q,
    );
  }

  /// Stop playback, keep mini player visible.
  Future<PlaybackResult> stopAndClear(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
  ) async {
    await saveCurrentPosition(pb, lib, q);
    await _coordinator.stop();
    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: 0,
        audioPlaylistLoaded: false,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
      ),
      queueState: QueueState.initial(),
    );
  }

  /// Stop playback and dismiss mini player.
  Future<PlaybackResult> dismissPlayer(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
  ) async {
    await saveCurrentPosition(pb, lib, q);
    await _coordinator.stop();
    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: 0,
        hasStartedPlayback: false,
        audioPlaylistLoaded: false,
        activeContextType: ActiveContextType.none,
        activeContextName: '',
        activeContextId: -1,
      ),
      queueState: QueueState.initial(),
    );
  }

   /// Skip to next track.
  Future<PlaybackResult> nextTrack(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    await saveCurrentPosition(pb, lib, q);

    final queue = q.activeQueue.isNotEmpty ? q.activeQueue : lib.tracks;
    if (queue.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    final activeLen = queue.length;

    // If at last track with pending queue, drain before normal next logic.
    if (pb.nowIdx >= activeLen - 1 && queueProvider.hasPendingQueue) {
      return drainPendingQueue(
        lib,
        pb,
        q,
        settings,
        queueProvider,
      );
    }

    final fallbackNextIdx = pb.nowIdx + 1 < activeLen ? pb.nowIdx + 1 : pb.nowIdx;

    if (!hasLoadedPlaylist(pb)) {
      final selection = await _openAndStartWithRecovery(
        tracks: queue,
        initialIndex: fallbackNextIdx,
        settings: settings,
      );

      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: selection.index,
          audioPlaylistLoaded: true,
          hasStartedPlayback: true,
          isPlaying: true,
          isSwitchingTrack: false,
          position: Duration.zero,
          totalDuration: null,
          failure: selection.notice,
          isRecovering: false,
          consecutiveFailures: selection.notice?.attempt ?? 0,
          clearFailure: selection.notice == null,
        ),
        queueState: q,
        notice: selection.notice,
      );
    }

    await _coordinator.skipNext();

    final engineIndex = _coordinator.currentQueue.currentIndex;
    final resolvedIndex = engineIndex >= 0 && engineIndex < activeLen
        ? engineIndex
        : fallbackNextIdx;

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: resolvedIndex,
        hasStartedPlayback: true,
        isPlaying: true,
        isSwitchingTrack: false,
        position: Duration.zero,
        totalDuration: null,
      ),
      queueState: q,
    );
  }

    /// Skip to previous track.
  Future<PlaybackResult> previousTrack(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    await saveCurrentPosition(pb, lib, q);

    final queue = q.activeQueue.isNotEmpty ? q.activeQueue : lib.tracks;
    if (queue.isEmpty) {
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    final activeLen = queue.length;
    final fallbackPreviousIdx = pb.nowIdx > 0 ? pb.nowIdx - 1 : 0;

    if (!hasLoadedPlaylist(pb)) {
      final selection = await _openAndStartWithRecovery(
        tracks: queue,
        initialIndex: fallbackPreviousIdx,
        settings: settings,
        direction: -1,
      );

      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: selection.index,
          audioPlaylistLoaded: true,
          hasStartedPlayback: true,
          isPlaying: true,
          isSwitchingTrack: false,
          position: Duration.zero,
          totalDuration: null,
          failure: selection.notice,
          isRecovering: false,
          consecutiveFailures: selection.notice?.attempt ?? 0,
          clearFailure: selection.notice == null,
        ),
        queueState: q,
        notice: selection.notice,
      );
    }

    await _coordinator.skipPrevious();

    final engineIndex = _coordinator.currentQueue.currentIndex;
    final resolvedIndex = engineIndex >= 0 && engineIndex < activeLen
        ? engineIndex
        : fallbackPreviousIdx;

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: resolvedIndex,
        hasStartedPlayback: true,
        isPlaying: true,
        isSwitchingTrack: false,
        position: Duration.zero,
        totalDuration: null,
      ),
      queueState: q,
    );
  }

  /// Seek to a specific position.
  Future<void> seekTo(Duration pos) => _coordinator.seek(pos);

  /// Seek relative by seconds (+ forward, - backward).
  Future<void> seekRelative(int seconds, PlaybackState pb) async {
    final dur = pb.totalDuration ?? Duration.zero;
    if (dur == Duration.zero) return;
    final newPosMs = (pb.position.inMilliseconds + seconds * 1000)
        .clamp(0, dur.inMilliseconds);
    await _coordinator.seek(Duration(milliseconds: newPosMs));
  }

  /// Transactionally promotes the pending queue into active playback.
  ///
  /// The pending queue is not changed until the engine confirms that the
  /// snapshot was opened successfully.
  Future<PlaybackResult> drainPendingQueue(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    if (_pendingDrainInProgress || !queueProvider.hasPendingQueue) {
      return PlaybackResult(
        playbackState: pb,
        queueState: q,
      );
    }

    _pendingDrainInProgress = true;

    final pendingItemSnapshot = queueProvider.snapshotPendingQueueItems();

    if (pendingItemSnapshot.isEmpty) {
      _pendingDrainInProgress = false;

      return PlaybackResult(
        playbackState: pb,
        queueState: q,
      );
    }

    final pendingTrackSnapshot = pendingItemSnapshot
        .map((item) => item.track)
        .toList(growable: false);

    final pendingItemIds = pendingItemSnapshot
        .map((item) => item.id)
        .toList(growable: false);

    final previousEngineQueue = _coordinator.currentQueue;
    final previousEngineState = _coordinator.currentState;

    try {
      final (entry, entries) = toMediaEntries(
        pendingTrackSnapshot,
        0,
      );

      await _coordinator.open(
        entry,
        queue: entries,
        initialIndex: 0,
        autoPlay: false,
      );

      if (!_isExpectedQueueLoaded(entries, 0)) {
        final failure = _coordinator.currentFailure;

        throw StateError(
          failure?.message ??
              'The playback engine did not confirm the pending queue.',
        );
      }

      await applyDeferredConfig(settings);

      if (_coordinator.currentState.processingState ==
          PlaybackProcessingState.error) {
        final failure = _coordinator.currentFailure;

        throw StateError(
          failure?.message ?? 'Applying playback configuration failed.',
        );
      }

      queueProvider.removeMirroredPendingItems(
        pendingItemSnapshot,
      );

      final promotedQueue = QueueState(
        activeQueue: pendingTrackSnapshot,
        activeQueueItemIds: pendingItemIds,
      );

      Object? playError;
      StackTrace? playStackTrace;

      try {
        await _coordinator.play();
      } catch (error, stackTrace) {
        playError = error;
        playStackTrace = stackTrace;
      }

      final playbackFailed =
          playError != null ||
          _coordinator.currentState.processingState ==
              PlaybackProcessingState.error;

      if (playError != null) {
        debugPrint(
          '[PlaybackController] Pending queue opened, but autoplay failed: '
          '$playError\n$playStackTrace',
        );
      }

      LibraryState? updatedLibrary;

      if (!playbackFailed && pendingTrackSnapshot.isNotEmpty) {
        final firstTrack = pendingTrackSnapshot.first;

        updatedLibrary = _withRecentPlay(
          lib,
          firstTrack,
        );

        unawaited(
          _history.recordPlay(firstTrack).catchError(
            (Object error, StackTrace stackTrace) {
              debugPrint(
                '[PlaybackController] Failed to record pending-drain history: '
                '$error\n$stackTrace',
              );
            },
          ),
        );
      }

      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: 0,
          isSwitchingTrack: false,
          hasStartedPlayback: true,
          audioPlaylistLoaded: true,
          isPlaying: !playbackFailed,
          position: Duration.zero,
          totalDuration: null,
          activeContextType: ActiveContextType.none,
          activeContextName: '',
          activeContextId: -1,
        ),
        queueState: promotedQueue,
        libraryState: updatedLibrary,
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[PlaybackController] Pending queue drain failed; '
        'pending items were preserved: $error\n$stackTrace',
      );

      await _restoreAfterFailedPendingDrain(
        previousQueue: previousEngineQueue,
        previousState: previousEngineState,
      );

      return PlaybackResult(
        playbackState: pb,
        queueState: q,
      );
    } finally {
      _pendingDrainInProgress = false;
    }
  }

  Future<PlaybackResult> playFromUpNextItem(
    String queueItemId,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) {
    final index = _resolveUpNextIndexById(
      queueItemId,
      lib,
      pb,
      q,
      queueProvider,
    );

    if (index == -1) {
      return Future.value(
        PlaybackResult(
          playbackState: pb.copyWith(isSwitchingTrack: false),
          queueState: q,
        ),
      );
    }

    return playFromUpNext(
      index,
      lib,
      pb,
      q,
      settings,
      queueProvider,
    );
  }

  Future<PlaybackResult> removeFromUpNextItem(
    String queueItemId,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    QueueProvider queueProvider,
  ) {
    final index = _resolveUpNextIndexById(
      queueItemId,
      lib,
      pb,
      q,
      queueProvider,
    );

    if (index == -1) {
      return Future.value(
        PlaybackResult(
          playbackState: pb.copyWith(isSwitchingTrack: false),
          queueState: q,
        ),
      );
    }

    return removeFromUpNext(
      index,
      lib,
      pb,
      q,
      queueProvider,
    );
  }

  Future<PlaybackResult> reorderUpNextItems(
    String movingItemId,
    String targetItemId,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    QueueProvider queueProvider,
  ) {
    final oldIndex = _resolveUpNextIndexById(
      movingItemId,
      lib,
      pb,
      q,
      queueProvider,
    );

    final newIndex = _resolveUpNextIndexById(
      targetItemId,
      lib,
      pb,
      q,
      queueProvider,
    );

    if (oldIndex == -1 || newIndex == -1) {
      return Future.value(
        PlaybackResult(
          playbackState: pb.copyWith(isSwitchingTrack: false),
          queueState: q,
        ),
      );
    }

    return reorderUpNext(
      oldIndex,
      newIndex,
      lib,
      pb,
      q,
      queueProvider,
    );
  }

  Future<PlaybackResult> _playFromVisibleUpNext(
    int compositeIndex,
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    final queue =
        queueState.activeQueue.isNotEmpty ? queueState.activeQueue : library.tracks;
    final visibleItems = _visibleUpNextItems(
      library,
      playback,
      queueState,
      queueProvider,
    );

    if (queue.isEmpty ||
        compositeIndex < 0 ||
        compositeIndex >= visibleItems.length) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    final selectedItem = visibleItems[compositeIndex];

    if (selectedItem.isActive) {
      final targetIndex = selectedItem.sourceIndex;

      if (targetIndex < 0 || targetIndex >= queue.length) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      var nextPlayback = playback.copyWith(isSwitchingTrack: true);

      if (!hasLoadedPlaylist(playback)) {
        final (entry, entries) = toMediaEntries(queue, targetIndex);

        await _coordinator.open(
          entry,
          queue: entries,
          initialIndex: targetIndex,
          autoPlay: false,
        );

        await applyDeferredConfig(settings);
        nextPlayback = nextPlayback.copyWith(audioPlaylistLoaded: true);
      } else {
        await _coordinator.jumpTo(targetIndex);
      }

      await _coordinator.play();

      final selectedTrack = queue[targetIndex];
      unawaited(_recordPlaySafely(selectedTrack));

      return PlaybackResult(
        playbackState: nextPlayback.copyWith(
          nowIdx: targetIndex,
          hasStartedPlayback: true,
          isPlaying: true,
          isSwitchingTrack: false,
          position: Duration.zero,
          totalDuration: null,
        ),
        queueState: queueState,
        libraryState: _withRecentPlay(library, selectedTrack),
      );
    }

    final pendingSnapshot = queueProvider.snapshotPendingQueueItems();
    final pendingIndex = pendingSnapshot.indexWhere(
      (item) => item.id == selectedItem.id,
    );

    if (pendingIndex == -1) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    final selectedItemSnapshot = pendingSnapshot.sublist(pendingIndex);
    final selectedQueue = selectedItemSnapshot
        .map((item) => item.track)
        .toList(growable: false);
    final selectedIds =
        selectedItemSnapshot.map((item) => item.id).toList(growable: false);

    if (selectedQueue.isEmpty) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    try {
      final (entry, entries) = toMediaEntries(selectedQueue, 0);

      await _coordinator.open(
        entry,
        queue: entries,
        initialIndex: 0,
        autoPlay: false,
      );

      await applyDeferredConfig(settings);
      await _coordinator.play();

      queueProvider.removeMirroredPendingItems(selectedItemSnapshot);

      final selectedTrack = selectedQueue.first;
      unawaited(_recordPlaySafely(selectedTrack));

      return PlaybackResult(
        playbackState: playback.copyWith(
          nowIdx: 0,
          audioPlaylistLoaded: true,
          hasStartedPlayback: true,
          isPlaying: true,
          isSwitchingTrack: false,
          activeContextType: ActiveContextType.none,
          activeContextName: '',
          activeContextId: -1,
          position: Duration.zero,
          totalDuration: null,
        ),
        queueState: QueueState(
          activeQueue: selectedQueue,
          activeQueueItemIds: selectedIds,
        ),
        libraryState: _withRecentPlay(library, selectedTrack),
      );
    } catch (error, stackTrace) {
      debugPrint('[PlaybackController] playFromUpNext failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }
  }

  Future<PlaybackResult> _removeFromVisibleUpNext(
    int compositeIndex,
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    QueueProvider queueProvider,
  ) async {
    final queue = List<Track>.from(
      queueState.activeQueue.isNotEmpty ? queueState.activeQueue : library.tracks,
    );
    final visibleItems = _visibleUpNextItems(
      library,
      playback,
      queueState,
      queueProvider,
    );

    if (compositeIndex < 0 || compositeIndex >= visibleItems.length) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    final selectedItem = visibleItems[compositeIndex];

    if (selectedItem.isPending) {
      queueProvider.removePendingItemById(selectedItem.id);

      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    final targetIndex = selectedItem.sourceIndex;

    if (targetIndex < 0 || targetIndex >= queue.length) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    try {
      if (hasLoadedPlaylist(playback)) {
        await _coordinator.removeQueueEntry(targetIndex);
      }
    } catch (error, stackTrace) {
      debugPrint('[PlaybackController] removeFromUpNext failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    final updatedQueue = List<Track>.from(queue)..removeAt(targetIndex);
    final updatedIds = _activeQueueIdsFor(queueState, queue)..removeAt(targetIndex);
    var updatedCurrentIndex = playback.nowIdx;

    if (targetIndex < updatedCurrentIndex) {
      updatedCurrentIndex--;
    }

    return PlaybackResult(
      playbackState: playback.copyWith(
        nowIdx: updatedCurrentIndex,
        isSwitchingTrack: false,
      ),
      queueState: QueueState(
        activeQueue: updatedQueue,
        activeQueueItemIds: updatedIds,
      ),
    );
  }

  Future<PlaybackResult> _clearVisibleUpNext(
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    QueueProvider queueProvider,
  ) async {
    final queue = List<Track>.from(
      queueState.activeQueue.isNotEmpty ? queueState.activeQueue : library.tracks,
    );
    final visibleItems = _visibleUpNextItems(
      library,
      playback,
      queueState,
      queueProvider,
    );

    final activeIndexes = visibleItems
        .where((item) => item.isActive)
        .map((item) => item.sourceIndex)
        .where((index) => index >= 0 && index < queue.length)
        .toSet()
        .toList()
      ..sort((a, b) => b.compareTo(a));

    try {
      if (hasLoadedPlaylist(playback)) {
        for (final sourceIndex in activeIndexes) {
          await _coordinator.removeQueueEntry(sourceIndex);
        }
      }
    } catch (error, stackTrace) {
      debugPrint('[PlaybackController] clearUpNext failed: $error');
      debugPrintStack(stackTrace: stackTrace);

      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    queueProvider.clearPendingQueue();

    if (activeIndexes.isEmpty) {
      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    final updatedQueue = List<Track>.from(queue);
    final updatedIds = _activeQueueIdsFor(queueState, queue);
    var updatedCurrentIndex = playback.nowIdx;

    for (final sourceIndex in activeIndexes) {
      if (sourceIndex < updatedCurrentIndex) {
        updatedCurrentIndex--;
      }

      updatedQueue.removeAt(sourceIndex);
      updatedIds.removeAt(sourceIndex);
    }

    if (updatedQueue.isEmpty) {
      return PlaybackResult(
        playbackState: PlaybackState.initial(),
        queueState: QueueState.initial(),
      );
    }

    updatedCurrentIndex = updatedCurrentIndex.clamp(0, updatedQueue.length - 1);

    return PlaybackResult(
      playbackState: playback.copyWith(
        nowIdx: updatedCurrentIndex,
        isSwitchingTrack: false,
      ),
      queueState: QueueState(
        activeQueue: updatedQueue,
        activeQueueItemIds: updatedIds,
      ),
    );
  }

  Future<PlaybackResult> _reorderVisibleUpNext(
    int oldCompositeIndex,
    int newCompositeIndex,
    LibraryState library,
    PlaybackState playback,
    QueueState queueState,
    QueueProvider queueProvider,
  ) async {
    final visibleItems = _visibleUpNextItems(
      library,
      playback,
      queueState,
      queueProvider,
    );

    if (oldCompositeIndex < 0 ||
        newCompositeIndex < 0 ||
        oldCompositeIndex >= visibleItems.length ||
        newCompositeIndex >= visibleItems.length ||
        oldCompositeIndex == newCompositeIndex) {
      return PlaybackResult(playbackState: playback, queueState: queueState);
    }

    final movingItem = visibleItems[oldCompositeIndex];
    final targetItem = visibleItems[newCompositeIndex];

    if (_coordinator.currentQueue.shuffleEnabled &&
        (movingItem.isActive || targetItem.isActive)) {
      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    final queue = List<Track>.from(
      queueState.activeQueue.isNotEmpty ? queueState.activeQueue : library.tracks,
    );

    if (movingItem.isPending && targetItem.isPending) {
      final pendingItems = queueProvider.pendingQueueItems;
      final oldPendingIndex =
          pendingItems.indexWhere((item) => item.id == movingItem.id);
      final newPendingIndex =
          pendingItems.indexWhere((item) => item.id == targetItem.id);

      if (oldPendingIndex == -1 || newPendingIndex == -1) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      queueProvider.reorderPendingQueue(oldPendingIndex, newPendingIndex);

      return PlaybackResult(
        playbackState: playback.copyWith(isSwitchingTrack: false),
        queueState: queueState,
      );
    }

    if (movingItem.isActive && targetItem.isActive) {
      final oldIndex = movingItem.sourceIndex;
      final newIndex = targetItem.sourceIndex;

      if (oldIndex < 0 ||
          oldIndex >= queue.length ||
          newIndex < 0 ||
          newIndex >= queue.length) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      try {
        if (hasLoadedPlaylist(playback)) {
          await _coordinator.moveQueueEntry(oldIndex, newIndex);
        }
      } catch (error, stackTrace) {
        debugPrint('[PlaybackController] active Up Next reorder failed: $error');
        debugPrintStack(stackTrace: stackTrace);

        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final updatedQueue = List<Track>.from(queue);
      final movedTrack = updatedQueue.removeAt(oldIndex);
      updatedQueue.insert(newIndex, movedTrack);

      final updatedIds = _activeQueueIdsFor(queueState, queue);
      final movedId = updatedIds.removeAt(oldIndex);
      updatedIds.insert(newIndex, movedId);

      var updatedCurrentIndex = playback.nowIdx;

      if (updatedCurrentIndex == oldIndex) {
        updatedCurrentIndex = newIndex;
      } else if (oldIndex < updatedCurrentIndex &&
          newIndex >= updatedCurrentIndex) {
        updatedCurrentIndex--;
      } else if (oldIndex > updatedCurrentIndex &&
          newIndex <= updatedCurrentIndex) {
        updatedCurrentIndex++;
      }

      return PlaybackResult(
        playbackState: playback.copyWith(
          nowIdx: updatedCurrentIndex,
          isSwitchingTrack: false,
        ),
        queueState: QueueState(
          activeQueue: updatedQueue,
          activeQueueItemIds: updatedIds,
        ),
      );
    }

    if (movingItem.isActive && targetItem.isPending) {
      final oldIndex = movingItem.sourceIndex;

      if (oldIndex < 0 || oldIndex >= queue.length) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final pendingItems = queueProvider.pendingQueueItems;
      final targetPendingIndex =
          pendingItems.indexWhere((item) => item.id == targetItem.id);

      if (targetPendingIndex == -1) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final movedTrack = queue[oldIndex];
      final updatedIds = _activeQueueIdsFor(queueState, queue);
      final movedId = updatedIds[oldIndex];

      try {
        if (hasLoadedPlaylist(playback)) {
          await _coordinator.removeQueueEntry(oldIndex);
        }
      } catch (error, stackTrace) {
        debugPrint('[PlaybackController] active-to-pending reorder failed: $error');
        debugPrintStack(stackTrace: stackTrace);

        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final updatedQueue = List<Track>.from(queue)..removeAt(oldIndex);
      updatedIds.removeAt(oldIndex);
      queueProvider.insertPendingQueue(
        targetPendingIndex,
        movedTrack,
        queueItemId: movedId,
      );

      var updatedCurrentIndex = playback.nowIdx;

      if (oldIndex < updatedCurrentIndex) {
        updatedCurrentIndex--;
      }

      return PlaybackResult(
        playbackState: playback.copyWith(
          nowIdx: updatedCurrentIndex,
          isSwitchingTrack: false,
        ),
        queueState: QueueState(
          activeQueue: updatedQueue,
          activeQueueItemIds: updatedIds,
        ),
      );
    }

    if (movingItem.isPending && targetItem.isActive) {
      final pendingItems = queueProvider.pendingQueueItems;
      final pendingIndex =
          pendingItems.indexWhere((item) => item.id == movingItem.id);
      final insertionIndex = targetItem.sourceIndex;

      if (pendingIndex == -1 ||
          insertionIndex < 0 ||
          insertionIndex > queue.length) {
        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final movedItem = pendingItems[pendingIndex];

      try {
        if (hasLoadedPlaylist(playback)) {
          await _coordinator.insertQueueEntry(
            insertionIndex,
            movedItem.track.toMediaEntry(),
          );
        }
      } catch (error, stackTrace) {
        debugPrint('[PlaybackController] pending-to-active reorder failed: $error');
        debugPrintStack(stackTrace: stackTrace);

        return PlaybackResult(playbackState: playback, queueState: queueState);
      }

      final removed = queueProvider.removePendingItemById(movedItem.id);

      if (!removed) {
        debugPrint(
          '[PlaybackController] Engine insertion succeeded, but the pending '
          'queue item had already changed.',
        );
      }

      final updatedQueue = List<Track>.from(queue)
        ..insert(insertionIndex, movedItem.track);
      final updatedIds = _activeQueueIdsFor(queueState, queue)
        ..insert(insertionIndex, movedItem.id);
      var updatedCurrentIndex = playback.nowIdx;

      if (insertionIndex <= updatedCurrentIndex) {
        updatedCurrentIndex++;
      }

      return PlaybackResult(
        playbackState: playback.copyWith(
          nowIdx: updatedCurrentIndex,
          audioPlaylistLoaded: true,
          isSwitchingTrack: false,
        ),
        queueState: QueueState(
          activeQueue: updatedQueue,
          activeQueueItemIds: updatedIds,
        ),
      );
    }

    return PlaybackResult(
      playbackState: playback.copyWith(isSwitchingTrack: false),
      queueState: queueState,
    );
  }

  /// Play a track from the composite Up Next list.
  Future<PlaybackResult> playFromUpNext(
    int compositeIndex,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    return _playFromVisibleUpNext(
      compositeIndex,
      lib,
      pb,
      q,
      settings,
      queueProvider,
    );
  }

  /// Remove one item from the composite Up Next list.
  ///
  /// Composite index 0 is the next visible item, not the current track.
  Future<PlaybackResult> removeFromUpNext(
    int compositeIndex,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    QueueProvider queueProvider,
  ) async {
    return _removeFromVisibleUpNext(
      compositeIndex,
      lib,
      pb,
      q,
      queueProvider,
    );
  }

  /// Clear every upcoming item from Up Next.
  ///
  /// Keeps the current track playable, removes all active upcoming entries
  /// from the real engine queue, and clears all pending tracks.
  Future<PlaybackResult> clearUpNext(
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    QueueProvider queueProvider,
  ) async {
    return _clearVisibleUpNext(
      lib,
      pb,
      q,
      queueProvider,
    );
  }

  /// Reorder one item in the composite Up Next list.
  ///
  /// Active upcoming items are mirrored into the real engine queue.
  /// Pending-only movement is delegated to QueueProvider. Mixed active/pending
  /// movement edits the engine first, then updates Dart/provider state.
  Future<PlaybackResult> reorderUpNext(
    int oldCompositeIndex,
    int newCompositeIndex,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    QueueProvider queueProvider,
  ) async {
    return _reorderVisibleUpNext(
      oldCompositeIndex,
      newCompositeIndex,
      lib,
      pb,
      q,
      queueProvider,
    );
  }

  /// Enqueue a track into the current playback queue at the right position.
  Future<PlaybackResult> enqueueTrack(
    Track track,
    LibraryState lib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    if (!hasLoadedPlaylist(pb)) {
      queueProvider.enqueueTrack(track);
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    final baseQueue =
        List<Track>.from(q.activeQueue.isNotEmpty ? q.activeQueue : lib.tracks);
    if (baseQueue.isEmpty ||
        pb.nowIdx < 0 ||
        pb.nowIdx >= baseQueue.length) {
      queueProvider.enqueueTrack(track);
      return PlaybackResult(playbackState: pb, queueState: q);
    }

    final pendingItemsToMirror = queueProvider.snapshotPendingQueueItems();
    final pendingToMirror =
        pendingItemsToMirror.map((item) => item.track).toList(growable: false);
    final workingQueueIds = <String>[
      ..._activeQueueIdsFor(q, baseQueue),
      ...pendingItemsToMirror.map((item) => item.id),
    ];
    final workingQueue = <Track>[
      ...baseQueue,
      ...pendingToMirror,
    ];

    final queueMode = settings.queueMode;
    final rawInsertionIndex = switch (queueMode) {
      'Play next' => pb.nowIdx + 1,
      'Shuffle in' => pb.nowIdx +
          1 +
          (DateTime.now().microsecondsSinceEpoch %
              (workingQueue.length - pb.nowIdx)),
      _ => workingQueue.length, // 'Add to end'
    };

    final insertionIndex = rawInsertionIndex < 0
        ? 0
        : rawInsertionIndex > workingQueue.length
            ? workingQueue.length
            : rawInsertionIndex;

    workingQueue.insert(insertionIndex, track);
    workingQueueIds.insert(insertionIndex, QueueItemToken.create('active'));
    final mirroredPending = <Track>[];
    final mirroredPendingItems = <QueueItemView>[];

    try {
      for (final pendingItem in pendingItemsToMirror) {
        final pendingTrack = pendingItem.track;
        await _insertQueueEntry(baseQueue.length + mirroredPending.length,
            pendingTrack);
        mirroredPending.add(pendingTrack);
        mirroredPendingItems.add(pendingItem);
      }

      await _insertQueueEntry(insertionIndex, track);

      if (pendingItemsToMirror.isNotEmpty) {
        queueProvider.removeMirroredPendingItems(pendingItemsToMirror);
      }

      return PlaybackResult(
        playbackState: pb.copyWith(
          audioPlaylistLoaded: true,
          isSwitchingTrack: false,
        ),
        queueState: QueueState(
          activeQueue: workingQueue,
          activeQueueItemIds: workingQueueIds,
        ),
      );
    } catch (e) {
      debugPrint('[PlaybackController] enqueueTrack failed: $e');

      if (mirroredPendingItems.isNotEmpty) {
        queueProvider.removeMirroredPendingItems(mirroredPendingItems);

        return PlaybackResult(
          playbackState: pb.copyWith(isSwitchingTrack: false),
          queueState: QueueState(
            activeQueue: <Track>[
              ...baseQueue,
              ...mirroredPending,
            ],
            activeQueueItemIds: <String>[
              ..._activeQueueIdsFor(q, baseQueue),
              ...mirroredPendingItems.map((item) => item.id),
            ],
          ),
        );
      }

      return PlaybackResult(
        playbackState: pb.copyWith(isSwitchingTrack: false),
        queueState: q,
      );
    }
  }

  /// Reconcile the active playback queue after MediaStore changes.
  ///
  /// This is used after scan/sync updates the library. It refreshes Track
  /// objects, removes missing files, preserves the current track when possible,
  /// and rebuilds the real engine queue so just_audio no longer points at
  /// deleted/stale entries.
  Future<PlaybackResult> reconcileQueueAfterLibraryChange(
    LibraryState oldLib,
    LibraryState newLib,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
    QueueProvider queueProvider,
  ) async {
    final oldQueue = q.activeQueue.isNotEmpty ? q.activeQueue : oldLib.tracks;

    if (oldQueue.isEmpty) {
      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: 0,
          audioPlaylistLoaded: false,
          isSwitchingTrack: false,
        ),
        queueState: QueueState.initial(),
        libraryState: newLib,
      );
    }

    final oldCurrentIndex = pb.nowIdx.clamp(0, oldQueue.length - 1).toInt();
    final oldCurrentTrack = oldQueue[oldCurrentIndex];
    final refreshedCurrent = _findRefreshedTrack(oldCurrentTrack, newLib);
    final currentTrackSurvived = refreshedCurrent != null;

    final refreshedQueue = <Track>[];
    final refreshedQueueItemIds = <String>[];

    if (q.activeQueue.isNotEmpty) {
      for (var i = 0; i < q.activeQueue.length; i++) {
        final oldTrack = q.activeQueue[i];
        final refreshed = _findRefreshedTrack(oldTrack, newLib);
        if (refreshed != null) {
          refreshedQueue.add(refreshed);
          if (i < q.activeQueueItemIds.length) {
            refreshedQueueItemIds.add(q.activeQueueItemIds[i]);
          }
        }
      }
    } else {
      refreshedQueue.addAll(newLib.tracks);
    }

    final deletedTracks = oldLib.tracks
        .where((oldTrack) => _findRefreshedTrack(oldTrack, newLib) == null)
        .toList(growable: false);

    queueProvider.removeTrackRefs(deletedTracks);

    if (refreshedQueue.isEmpty) {
      await _coordinator.stop();

      return PlaybackResult(
        playbackState: pb.copyWith(
          nowIdx: 0,
          isPlaying: false,
          hasStartedPlayback: false,
          audioPlaylistLoaded: false,
          isSwitchingTrack: false,
          activeContextType: ActiveContextType.none,
          activeContextName: '',
          activeContextId: -1,
          position: Duration.zero,
          totalDuration: null,
        ),
        queueState: QueueState.initial(),
        libraryState: newLib,
      );
    }

    var newIndex = 0;
    var restorePosition = Duration.zero;

    if (currentTrackSurvived) {
      final current = refreshedCurrent;
      newIndex = refreshedQueue.indexWhere(
        (track) => _isSameQueueTrack(track, current),
      );

      if (newIndex < 0) {
        newIndex = oldCurrentIndex.clamp(0, refreshedQueue.length - 1).toInt();
      }

      restorePosition = pb.position;
    } else {
      // Current track was deleted. Prefer the next surviving item in the old
      // queue, then fall back backward. This avoids jumping to the start of the
      // library when only one file was removed.
      Track? replacement;

      for (var i = oldCurrentIndex + 1; i < oldQueue.length; i++) {
        replacement = _findRefreshedTrack(oldQueue[i], newLib);
        if (replacement != null) break;
      }

      if (replacement == null) {
        for (var i = oldCurrentIndex - 1; i >= 0; i--) {
          replacement = _findRefreshedTrack(oldQueue[i], newLib);
          if (replacement != null) break;
        }
      }

      final selectedReplacement = replacement;
      if (selectedReplacement != null) {
        newIndex = refreshedQueue.indexWhere(
          (track) => _isSameQueueTrack(track, selectedReplacement),
        );
      }

      if (newIndex < 0) {
        newIndex = oldCurrentIndex.clamp(0, refreshedQueue.length - 1).toInt();
      }
    }

    if (hasLoadedPlaylist(pb)) {
      final (entry, entries) = toMediaEntries(refreshedQueue, newIndex);

      await _coordinator.open(
        entry,
        queue: entries,
        initialIndex: newIndex,
        autoPlay: false,
      );

      await applyDeferredConfig(settings);

      if (currentTrackSurvived && restorePosition > Duration.zero) {
        await _coordinator.seek(restorePosition);
      }

      if (pb.isPlaying) {
        await _coordinator.play();
      }
    }

    return PlaybackResult(
      playbackState: pb.copyWith(
        nowIdx: newIndex,
        audioPlaylistLoaded: hasLoadedPlaylist(pb),
        isSwitchingTrack: false,
        position: currentTrackSurvived ? restorePosition : Duration.zero,
        totalDuration: null,
      ),
      queueState: q.activeQueue.isNotEmpty
          ? QueueState(
              activeQueue: refreshedQueue,
              activeQueueItemIds: refreshedQueueItemIds,
            )
          : QueueState.initial(),
      libraryState: newLib,
    );
  }

  /// Set shuffle mode to an explicit value.
  Future<PlaybackResult> setShuffleEnabled(
    bool enabled,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    await _coordinator.setShuffle(enabled);
    await settings.setShuffle(enabled);
    return PlaybackResult(playbackState: pb, queueState: q);
  }

  Future<PlaybackResult> toggleShuffle(
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    return setShuffleEnabled(!settings.isShuffle, pb, q, settings);
  }

  /// Cycle repeat mode (off → all → one → off).
  Future<PlaybackResult> setRepeatModeValue(
    PlaybackRepeatMode mode,
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    await _coordinator.setRepeatMode(mode);
    final modeIndex = switch (mode) {
      PlaybackRepeatMode.off => 0,
      PlaybackRepeatMode.all => 1,
      PlaybackRepeatMode.one => 2,
    };
    await settings.setRepeatMode(modeIndex);
    return PlaybackResult(playbackState: pb, queueState: q);
  }

  /// Cycle repeat mode (off -> all -> one -> off).
  Future<PlaybackResult> cycleRepeat(
    PlaybackState pb,
    QueueState q,
    SettingsProvider settings,
  ) async {
    final next = (settings.repeatMode + 1) % 3;
    final mode = [
      PlaybackRepeatMode.off,
      PlaybackRepeatMode.all,
      PlaybackRepeatMode.one,
    ][next];
    return setRepeatModeValue(mode, pb, q, settings);
  }

  // ── Track-changed handler ───────────────────────────────────────────────

  /// Called when the coordinator reports a queue index change.
  ///
  /// This method must stay off the critical visual-current-track path.
  /// MusicProvider updates nowIdx and notifies the UI immediately before
  /// calling this method. Everything below is side-effect work only:
  /// lyrics preparation, history persistence, widget artwork lookup, and
  /// in-memory recent history refresh.
  Future<LibraryState?> onTrackChanged(
    int newIdx,
    LibraryState lib,
    List<Track> activeQueue,
    LyricsProvider lyrics,
  ) async {
    final queue = activeQueue.isNotEmpty ? activeQueue : lib.tracks;
    final hasValidTrack = newIdx >= 0 && newIdx < queue.length;

    if (!hasValidTrack) {
      lyrics.clear();

      unawaited(
        PlaybackSystemService.updateWidget(
          title: 'No tracks',
          artist: 'Load your library',
          isPlaying: false,
        ),
      );

      return null;
    }

    final current = queue[newIdx];

    // Lyrics preparation is asynchronous and must not hold Now Playing behind.
    unawaited(lyrics.prepareTrack(current));

    // Database history writes must not delay the visible current-track identity.
    unawaited(_recordPlaySafely(current));

    // Widget artwork lookup can touch disk/cache; keep it outside the UI path.
    unawaited(_updateWidgetForTrack(current));

    // Return the lightweight in-memory recent-history update immediately.
    return _withRecentPlay(lib, current);
  }

  Future<void> _recordPlaySafely(Track track) async {
    try {
      await _history.recordPlay(track);
    } catch (e) {
      debugPrint('[PlaybackController] recordPlay failed: $e');
    }
  }

  Future<void> _updateWidgetForTrack(Track track) async {
    try {
      final artworkPath = track.artPath ??
          (track.albumId == null
              ? null
              : await ArtworkCacheService.getCachedPath(track.albumId!));

      await PlaybackSystemService.updateWidget(
        title: track.title,
        artist: track.artist,
        artworkPath: artworkPath,
        isPlaying: true,
      );
    } catch (e) {
      debugPrint('[PlaybackController] updateWidget failed: $e');
    }
  }

}
