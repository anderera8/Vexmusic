import 'package:audio_session/audio_session.dart';

enum PlaybackPauseReason {
  user,
  lifecycle,
  notification,
  noisyRoute,
  audioFocus,
  sleepTimer,
}

enum AudioInterruptionCommand {
  none,
  duck,
  restoreVolume,
  pause,
  resume,
}

bool shouldPauseForBackgroundTransition({
  required bool backgroundPlaybackEnabled,
  required bool isPlaying,
}) {
  return !backgroundPlaybackEnabled && isPlaying;
}

/// Tracks whether an audio-focus pause may be automatically resumed.
///
/// Explicit pauses cancel pending auto-resume so regaining audio focus never
/// overrides a user's decision to keep playback paused.
class AudioInterruptionPolicy {
  bool _pausedByInterruption = false;
  bool _ducked = false;

  bool get isDucked => _ducked;
  bool get mayAutoResume => _pausedByInterruption;

  AudioInterruptionCommand handle(
    AudioInterruptionEvent event, {
    required bool isPlaying,
  }) {
    switch (event.type) {
      case AudioInterruptionType.duck:
        if (event.begin) {
          if (!isPlaying || _ducked) return AudioInterruptionCommand.none;
          _ducked = true;
          return AudioInterruptionCommand.duck;
        }

        if (!_ducked) return AudioInterruptionCommand.none;
        _ducked = false;
        return AudioInterruptionCommand.restoreVolume;

      case AudioInterruptionType.pause:
        if (event.begin) {
          if (!isPlaying) return AudioInterruptionCommand.none;
          _pausedByInterruption = true;
          return AudioInterruptionCommand.pause;
        }

        if (!_pausedByInterruption) return AudioInterruptionCommand.none;
        _pausedByInterruption = false;
        return AudioInterruptionCommand.resume;

      case AudioInterruptionType.unknown:
        // audio_session does not expose a separate permanent-focus-loss enum.
        // Unknown begin events are therefore treated as non-resumable losses:
        // pause once, clear all automatic-resume and duck state, and never
        // resume unless a later explicit play command is received.
        _pausedByInterruption = false;
        _ducked = false;
        if (event.begin && isPlaying) {
          return AudioInterruptionCommand.pause;
        }
        return AudioInterruptionCommand.none;
    }
  }

  bool registerExplicitPause() {
    final restoreDuck = _ducked;
    _pausedByInterruption = false;
    _ducked = false;
    return restoreDuck;
  }

  bool registerExplicitPlay() {
    final restoreDuck = _ducked;
    _pausedByInterruption = false;
    _ducked = false;
    return restoreDuck;
  }

  bool registerExplicitStop() {
    final restoreDuck = _ducked;
    _pausedByInterruption = false;
    _ducked = false;
    return restoreDuck;
  }

  bool registerNoisyRoutePause() {
    final restoreDuck = _ducked;
    _pausedByInterruption = false;
    _ducked = false;
    return restoreDuck;
  }

  void reset() {
    _pausedByInterruption = false;
    _ducked = false;
  }
}
