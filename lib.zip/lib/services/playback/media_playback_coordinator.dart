import 'dart:async';

import '../../models/media_models.dart';
import 'media_engine.dart';
import 'just_audio_engine.dart';

typedef AudioSessionActivationDelegate = Future<bool> Function();
typedef AudioSessionDeactivationDelegate = Future<void> Function();

/// Application-scoped owner of the audio playback engine.
class MediaPlaybackCoordinator {
  static MediaPlaybackCoordinator? _instance;

  factory MediaPlaybackCoordinator() {
    if (_instance != null) return _instance!;
    late final MediaEngine engine;
    try {
      engine = JustAudioEngine();
    } catch (error) {
      engine = _UnavailableMediaEngine(error);
    }
    return _instance = MediaPlaybackCoordinator.withEngine(engine);
  }

  MediaPlaybackCoordinator.withEngine(this._engine);

  final MediaEngine _engine;
  AudioSessionActivationDelegate? _activateAudioSession;
  AudioSessionDeactivationDelegate? _deactivateAudioSession;

  void setAudioSessionDelegates({
    required AudioSessionActivationDelegate activate,
    required AudioSessionDeactivationDelegate deactivate,
  }) {
    _activateAudioSession = activate;
    _deactivateAudioSession = deactivate;
  }

  void clearAudioSessionDelegates() {
    _activateAudioSession = null;
    _deactivateAudioSession = null;
  }

  Future<void> _requireAudioSession() async {
    final activate = _activateAudioSession;
    if (activate == null) return;

    final activated = await activate();
    if (!activated) {
      throw const PlaybackCommandException(
        PlaybackFailure(
          PlaybackErrorType.interrupted,
          'The operating system did not grant audio focus.',
          operation: 'activate audio session',
        ),
      );
    }
  }

  Future<void> _releaseAudioSession() async {
    final deactivate = _deactivateAudioSession;
    if (deactivate == null) return;
    try {
      await deactivate();
    } catch (_) {}
  }

  void _requireSuccess(
    PlaybackCommandResult result, {
    required String operation,
  }) {
    if (result.succeeded) return;

    final failure = result.failure ??
        const PlaybackFailure(
          PlaybackErrorType.engine,
          'The playback engine rejected the command.',
        );

    throw PlaybackCommandException(
      failure.operation.isEmpty
          ? failure.copyWith(operation: operation)
          : failure,
    );
  }

  PlaybackSnapshot get currentState => _engine.currentState;
  PlaybackQueue get currentQueue => _engine.currentQueue;
  Stream<PlaybackSnapshot> get playbackState => _engine.playbackState;
  Stream<PlaybackQueue> get queueState => _engine.queueState;

  Future<void> open(
    MediaEntry entry, {
    List<MediaEntry> queue = const [],
    int initialIndex = 0,
    bool autoPlay = true,
  }) async {
    final openResult = await _engine.open(
      entry,
      queue: queue,
      initialIndex: initialIndex,
    );

    _requireSuccess(openResult, operation: 'open');

    if (autoPlay) {
      final playResult = await _engine.play();
      _requireSuccess(playResult, operation: 'play');
    }
  }

  Future<void> play() async {
    await _requireAudioSession();
    final result = await _engine.play();
    _requireSuccess(result, operation: 'play');
  }

  Future<void> insertQueueEntry(
    int index,
    MediaEntry entry,
  ) async {
    final result = await _engine.insertQueueEntry(
      index,
      entry,
    );

    _requireSuccess(result, operation: 'insert queue item');
  }

  Future<void> removeQueueEntry(int index) async {
    final result = await _engine.removeQueueEntry(index);
    _requireSuccess(result, operation: 'remove queue item');
  }

  Future<void> clearQueueAfter(int index) async {
    final result = await _engine.clearQueueAfter(index);
    _requireSuccess(result, operation: 'clear upcoming queue');
  }

  Future<void> moveQueueEntry(
    int oldIndex,
    int newIndex,
  ) async {
    final result = await _engine.moveQueueEntry(
      oldIndex,
      newIndex,
    );

    _requireSuccess(result, operation: 'move queue item');
  }

  Future<void> pause({bool releaseAudioSession = true}) async {
    final result = await _engine.pause();
    _requireSuccess(result, operation: 'pause');
    if (releaseAudioSession) {
      await _releaseAudioSession();
    }
  }

  Future<void> stop() async {
    final result = await _engine.stop();
    _requireSuccess(result, operation: 'stop');
    await _releaseAudioSession();
  }

  Future<void> seek(Duration position) async {
    final result = await _engine.seek(position);
    _requireSuccess(result, operation: 'seek');
  }

  Future<void> skipNext() async {
    final result = await _engine.skipNext();
    _requireSuccess(result, operation: 'skip next');
  }

  Future<void> skipPrevious() async {
    final result = await _engine.skipPrevious();
    _requireSuccess(result, operation: 'skip previous');
  }

  Future<void> jumpTo(int index) async {
    final result = await _engine.jumpTo(index);
    _requireSuccess(result, operation: 'jump to queue item');
  }

  Future<void> setVolume(double volume) async {
    final result = await _engine.setVolume(volume);
    _requireSuccess(result, operation: 'set volume');
  }

  Future<void> setSpeed(double speed) async {
    final result = await _engine.setSpeed(speed);
    _requireSuccess(result, operation: 'set speed');
  }

  Future<void> setShuffle(bool enabled) async {
    final result = await _engine.setShuffle(enabled);
    _requireSuccess(result, operation: 'set shuffle');
  }

  Future<void> setRepeatMode(
    PlaybackRepeatMode mode,
  ) async {
    final result = await _engine.setRepeatMode(mode);
    _requireSuccess(result, operation: 'set repeat mode');
  }

  Future<void> setCrossfade(int seconds) async {
    final result = await _engine.setCrossfade(seconds);
    _requireSuccess(result, operation: 'set crossfade');
  }

  Map<String, String> get diagnosticInfo => {
        'engine': 'just_audio (ExoPlayer)',
        'audioEngine': _engine.runtimeType.toString(),
        'hasInstance': (_instance != null).toString(),
      };

  PlaybackFailure? get currentFailure => _engine.currentState.failure;
  bool get isRecovering => _engine.currentState.isRecovering;
  int get consecutiveFailures =>
      _engine.currentState.consecutiveFailures;

  bool get needsPermissionGrant =>
      currentFailure?.type == PlaybackErrorType.accessDenied;

  bool get needsRescan =>
      currentFailure?.type == PlaybackErrorType.sourceUnavailable;

  void clearFailure() {
    // The engine clears failures when media is reopened or playback is stopped.
  }

  String get recoverySuggestion {
    final failure = currentFailure;

    if (failure == null) return '';

    return switch (failure.type) {
      PlaybackErrorType.invalidSource =>
        'This track has no valid playable source. Rescan the library.',

      PlaybackErrorType.accessDenied =>
        'Permission denied. Grant audio access in Settings and try again.',

      PlaybackErrorType.sourceUnavailable =>
        'File not found. It may have been moved or deleted. Try rescanning.',

      PlaybackErrorType.unsupportedFormat =>
        'This audio format is not supported by the current engine.',

      PlaybackErrorType.decoder =>
        'Decoder error. The file may be corrupt or use an unsupported codec.',

      PlaybackErrorType.interrupted =>
        'Playback was interrupted by another audio session or focus change.',

      PlaybackErrorType.cancelled =>
        'The playback command was cancelled before it completed.',

      PlaybackErrorType.timeout =>
        'The playback operation timed out. Check the file and try again.',

      PlaybackErrorType.invalidOperation =>
        'The requested queue operation is no longer valid. Refresh the queue.',

      PlaybackErrorType.engine =>
        'Playback engine error. Restart playback and try again.',
    };
  }

  bool get shouldPromptResume {
    final state = currentState;
    final queue = currentQueue;
    return queue.current != null &&
        state.position > const Duration(seconds: 5) &&
        state.duration > const Duration(seconds: 10) &&
        state.position < state.duration - const Duration(seconds: 3);
  }

  Map<String, dynamic> get technicalInfo {
    return <String, dynamic>{
      'engine': 'just_audio (ExoPlayer)',
      'kind': MediaKind.audio.name,
    };
  }

  Future<void> dispose() async {
    await _engine.stop().catchError((Object _) {
      return const PlaybackCommandResult.noChange();
    });
    await _engine.dispose();
    _instance = null;
  }
}

/// Reports a typed failure when native playback cannot be initialized.
class _UnavailableMediaEngine implements MediaEngine {
  _UnavailableMediaEngine(this.cause);

  final Object cause;
  final StreamController<PlaybackSnapshot> _stateController =
      StreamController<PlaybackSnapshot>.broadcast();
  final StreamController<PlaybackQueue> _queueController =
      StreamController<PlaybackQueue>.broadcast();

  PlaybackSnapshot _state = const PlaybackSnapshot();
  final PlaybackQueue _queue = const PlaybackQueue();

  PlaybackCommandResult _unavailableResult() {
    final failure = PlaybackFailure(
      PlaybackErrorType.engine,
      'The audio engine is not initialized.',
      cause: cause,
    );

    _state = PlaybackSnapshot(
      processingState: PlaybackProcessingState.error,
      failure: failure,
    );

    _stateController.add(_state);

    return PlaybackCommandResult.failure(failure);
  }

  @override
  MediaKind get kind => MediaKind.audio;

  @override
  PlaybackSnapshot get currentState => _state;

  @override
  PlaybackQueue get currentQueue => _queue;

  @override
  Stream<PlaybackSnapshot> get playbackState => _stateController.stream;

  @override
  Stream<PlaybackQueue> get queueState => _queueController.stream;

  @override
  Future<PlaybackCommandResult> open(
    MediaEntry entry, {
    List<MediaEntry> queue = const [],
    int initialIndex = 0,
  }) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> play() async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> pause() async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> stop() async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> seek(Duration position) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> skipNext() async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> skipPrevious() async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> jumpTo(int index) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> insertQueueEntry(
    int index,
    MediaEntry entry,
  ) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> removeQueueEntry(int index) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> clearQueueAfter(int index) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> moveQueueEntry(
    int oldIndex,
    int newIndex,
  ) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> setVolume(double volume) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> setSpeed(double speed) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> setShuffle(bool enabled) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> setRepeatMode(PlaybackRepeatMode mode) async {
    return _unavailableResult();
  }

  @override
  Future<PlaybackCommandResult> setCrossfade(int seconds) async {
    return _unavailableResult();
  }

  @override
  Future<void> dispose() async {
    await _stateController.close();
    await _queueController.close();
  }
}
