import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'native_media_library_service.dart';

/// MediaStore artwork target.
///
/// The enum names intentionally match the legacy on_audio_query values so
/// existing album-art call sites can retain their current logic.
enum ArtworkType {
  audio,
  album,
}

/// Disk-backed artwork cache.
///
/// Native MediaStore rows are addressed by `volumeName + native ID`. Album
/// IDs and audio IDs are not assumed to be globally unique across volumes.
///
/// Track artwork deliberately separates:
/// - [mediaStoreId] plus `volumeName`, which locate the current native row; and
/// - [stableKey], which owns the cache entry across MediaStore-ID remaps.
class ArtworkCacheService {
  static final NativeMediaLibraryService _mediaLibrary =
      NativeMediaLibraryService.instance;

  static final Map<String, Future<Uint8List?>> _pendingLoads = {};

  /// Cache identities queried during this process.
  ///
  /// Examples:
  /// - `album:42`
  /// - `audio:stable-<sha256>`
  /// - `audio:42` for a legacy/fallback audio cache entry
  static final Set<String> _queriedKeys = {};

  static Directory? _cacheDir;
  static Future<void>? _scheduledPrune;

  static const int _maxCacheBytes = 150 * 1024 * 1024;
  static const int _targetCacheBytes = 120 * 1024 * 1024;
  static const Duration _missingArtworkTtl = Duration(days: 7);

  static String _keyForToken(
    String cacheToken,
    ArtworkType type,
  ) {
    return '${type.name}:$cacheToken';
  }

  static String _legacyCacheToken(int id) => id.toString();

  static String _normalizeVolumeName(String? value) {
    final normalized = value?.trim().toLowerCase() ?? '';
    return normalized == 'external' ? 'external_primary' : normalized;
  }

  static String _volumeScopedCacheToken({
    required int nativeId,
    required String? volumeName,
  }) {
    final volume = _normalizeVolumeName(volumeName);

    if (volume.isEmpty) {
      return _legacyCacheToken(nativeId);
    }

    final digest = sha256.convert(
      utf8.encode('$volume:$nativeId'),
    );

    return 'source-$digest';
  }

  static String _nativeCacheToken({
    required int nativeId,
    required ArtworkType type,
    required String? volumeName,
  }) {
    return _volumeScopedCacheToken(
      nativeId: nativeId,
      volumeName: volumeName,
    );
  }

  static String _trackCacheToken({
    required int mediaStoreId,
    required String stableKey,
    required String? volumeName,
  }) {
    final normalized = stableKey.trim().toLowerCase();

    if (normalized.isEmpty) {
      return _volumeScopedCacheToken(
        nativeId: mediaStoreId,
        volumeName: volumeName,
      );
    }

    final digest = sha256.convert(
      utf8.encode(normalized),
    );

    return 'stable-$digest';
  }

  static String _prefixFor(ArtworkType type) {
    return type == ArtworkType.album ? 'album' : 'audio';
  }

  static NativeArtworkType _nativeTypeFor(ArtworkType type) {
    return type == ArtworkType.album
        ? NativeArtworkType.album
        : NativeArtworkType.audio;
  }

  /// Returns the artwork cache directory, creating it if needed.
  static Future<Directory> get _directory async {
    if (_cacheDir != null && _cacheDir!.existsSync()) {
      return _cacheDir!;
    }

    final appDir = await getTemporaryDirectory();
    final directory = Directory(
      p.join(appDir.path, 'artwork_cache'),
    );

    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }

    _cacheDir = directory;
    return directory;
  }

  static Future<String> _pathForToken(
    String cacheToken, {
    ArtworkType type = ArtworkType.album,
  }) async {
    final directory = await _directory;
    final prefix = _prefixFor(type);

    return p.join(
      directory.path,
      '$prefix-$cacheToken.jpg',
    );
  }

  static Future<String> _missingPathForToken(
    String cacheToken, {
    ArtworkType type = ArtworkType.album,
  }) async {
    final directory = await _directory;
    final prefix = _prefixFor(type);

    return p.join(
      directory.path,
      '$prefix-$cacheToken.missing',
    );
  }

  /// Checks whether a valid legacy ID-keyed cache file exists.
  ///
  /// Prefer [hasCachedTrack] for track artwork.
  static Future<bool> hasCached(
    int id, {
    ArtworkType type = ArtworkType.album,
    String? volumeName,
  }) {
    return _hasCachedToken(
      _nativeCacheToken(
        nativeId: id,
        type: type,
        volumeName: volumeName,
      ),
      type: type,
    );
  }

  static Future<bool> _hasCachedToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    final path = await _pathForToken(
      cacheToken,
      type: type,
    );

    final file = File(path);

    try {
      return await file.exists() &&
          await file.length() > 0;
    } catch (_) {
      return false;
    }
  }

  /// Returns a legacy ID-keyed cached path when it exists.
  ///
  /// Prefer [getCachedTrackPath] for track artwork.
  static Future<String?> getCachedPath(
    int id, {
    ArtworkType type = ArtworkType.album,
    String? volumeName,
  }) {
    return _getCachedPathForToken(
      _nativeCacheToken(
        nativeId: id,
        type: type,
        volumeName: volumeName,
      ),
      type: type,
    );
  }

  static Future<String?> _getCachedPathForToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    final path = await _pathForToken(
      cacheToken,
      type: type,
    );

    final file = File(path);

    try {
      if (await file.exists() &&
          await file.length() > 0) {
        return path;
      }
    } catch (_) {
      // Treat an unreadable cache file as absent.
    }

    return null;
  }

  /// Returns the stable track-art cache path when available.
  ///
  /// [legacyTrackId] is the app-owned ID used by older builds as an artwork
  /// cache key. When supplied, a valid old cache file is migrated once into
  /// the stable cache namespace.
  static Future<String?> getCachedTrackPath(
    int mediaStoreId, {
    required String stableKey,
    String? volumeName,
    int? legacyTrackId,
  }) async {
    if (mediaStoreId <= 0) {
      return null;
    }

    final cacheToken = _trackCacheToken(
      mediaStoreId: mediaStoreId,
      stableKey: stableKey,
      volumeName: volumeName,
    );

    await _migrateLegacyTrackCache(
      cacheToken: cacheToken,
      mediaStoreId: mediaStoreId,
      legacyTrackId: legacyTrackId,
    );

    return _getCachedPathForToken(
      cacheToken,
      type: ArtworkType.audio,
    );
  }

  static Future<bool> hasCachedTrack(
    int mediaStoreId, {
    required String stableKey,
    String? volumeName,
    int? legacyTrackId,
  }) async {
    return await getCachedTrackPath(
          mediaStoreId,
          stableKey: stableKey,
          volumeName: volumeName,
          legacyTrackId: legacyTrackId,
        ) !=
        null;
  }

  static Future<void> _migrateLegacyTrackCache({
    required String cacheToken,
    required int mediaStoreId,
    required int? legacyTrackId,
  }) async {
    if (cacheToken == _legacyCacheToken(mediaStoreId)) {
      return;
    }

    final currentPath = await _pathForToken(
      cacheToken,
      type: ArtworkType.audio,
    );

    final currentFile = File(currentPath);

    try {
      if (await currentFile.exists() &&
          await currentFile.length() > 0) {
        return;
      }
    } catch (_) {
      // Continue to legacy migration.
    }

    final legacyIds = <int>{
      mediaStoreId,
      if (legacyTrackId != null && legacyTrackId > 0)
        legacyTrackId,
    };

    for (final legacyId in legacyIds) {
      final legacyToken = _legacyCacheToken(legacyId);

      if (legacyToken == cacheToken) {
        continue;
      }

      final legacyPath = await _pathForToken(
        legacyToken,
        type: ArtworkType.audio,
      );

      final legacyFile = File(legacyPath);

      try {
        if (!await legacyFile.exists() ||
            await legacyFile.length() <= 0) {
          continue;
        }

        final bytes = await legacyFile.readAsBytes();

        if (bytes.isEmpty) {
          continue;
        }

        await currentFile.writeAsBytes(
          bytes,
          flush: false,
        );

        await _deleteMissingMarkerToken(
          cacheToken,
          type: ArtworkType.audio,
        );

        _queriedKeys.add(
          _keyForToken(
            cacheToken,
            ArtworkType.audio,
          ),
        );

        return;
      } catch (_) {
        // A failed migration must never block a fresh native artwork lookup.
      }
    }
  }

  static Future<bool> _hasFreshMissingMarkerToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    try {
      final path = await _missingPathForToken(
        cacheToken,
        type: type,
      );

      final file = File(path);

      if (!await file.exists()) {
        return false;
      }

      final stat = await file.stat();
      final age = DateTime.now().difference(
        stat.modified,
      );

      if (age <= _missingArtworkTtl) {
        return true;
      }

      await file.delete();
      return false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> _markMissingArtworkToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    try {
      final path = await _missingPathForToken(
        cacheToken,
        type: type,
      );

      await File(path).writeAsString(
        DateTime.now().toUtc().toIso8601String(),
        flush: false,
      );
    } catch (_) {
      // Missing-art markers are an optimization only.
    }
  }

  static Future<void> _deleteMissingMarkerToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    try {
      final path = await _missingPathForToken(
        cacheToken,
        type: type,
      );

      final file = File(path);

      if (await file.exists()) {
        await file.delete();
      }
    } catch (_) {
      // Cache invalidation must remain best-effort.
    }
  }

  /// Real artwork detector used by Artwork Manager.
  ///
  /// New call sites should pass [mediaStoreId] and [stableKey]. [trackId] is
  /// retained temporarily for source compatibility and, when both IDs are
  /// supplied, is treated as the app-owned legacy cache ID.
  static Future<bool> hasArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    int? trackId,
    String? artPath,
    bool forceRefresh = false,
  }) async {
    if (artPath?.trim().isNotEmpty == true) {
      try {
        final file = File(artPath!);

        if (await file.exists() &&
            await file.length() > 0) {
          return true;
        }
      } catch (_) {
        // Fall through to cache and MediaStore checks.
      }
    }

    if (albumId != null && albumId > 0) {
      final cached = await getCachedPath(
        albumId,
        type: ArtworkType.album,
        volumeName: volumeName,
      );

      if (cached != null) {
        return true;
      }
    }

    final nativeTrackId = mediaStoreId ?? trackId;

    if (nativeTrackId != null && nativeTrackId > 0) {
      final cached = await getCachedTrackPath(
        nativeTrackId,
        stableKey: stableKey,
        volumeName: volumeName,
        legacyTrackId:
            mediaStoreId == null ? null : trackId,
      );

      if (cached != null) {
        return true;
      }
    }

    if (albumId != null && albumId > 0) {
      final data = await loadArtwork(
        albumId,
        type: ArtworkType.album,
        volumeName: volumeName,
        size: 220,
        quality: 75,
        forceRefresh: forceRefresh,
      );

      if (data?.isNotEmpty == true) {
        return true;
      }
    }

    if (nativeTrackId != null && nativeTrackId > 0) {
      final data = await loadTrackArtwork(
        nativeTrackId,
        stableKey: stableKey,
        volumeName: volumeName,
        legacyTrackId:
            mediaStoreId == null ? null : trackId,
        size: 220,
        quality: 75,
        forceRefresh: forceRefresh,
      );

      if (data?.isNotEmpty == true) {
        return true;
      }
    }

    return false;
  }

  /// Fetches album or legacy ID-keyed artwork and writes it to disk cache.
  ///
  /// For track artwork, prefer [cacheTrackArtwork].
  static Future<String?> cacheArtwork(
    int id, {
    ArtworkType type = ArtworkType.album,
    String? volumeName,
    int size = 300,
    bool forceRefresh = false,
  }) async {
    final data = await loadArtwork(
      id,
      type: type,
      volumeName: volumeName,
      size: size,
      forceRefresh: forceRefresh,
    );

    if (data == null || data.isEmpty) {
      return null;
    }

    return getCachedPath(
      id,
      type: type,
      volumeName: volumeName,
    );
  }

  /// Fetches track artwork with the current MediaStore ID and caches it under
  /// the stable track identity.
  static Future<String?> cacheTrackArtwork(
    int mediaStoreId, {
    required String stableKey,
    String? volumeName,
    int? legacyTrackId,
    int size = 300,
    bool forceRefresh = false,
  }) async {
    final data = await loadTrackArtwork(
      mediaStoreId,
      stableKey: stableKey,
      volumeName: volumeName,
      legacyTrackId: legacyTrackId,
      size: size,
      forceRefresh: forceRefresh,
    );

    if (data == null || data.isEmpty) {
      return null;
    }

    return getCachedTrackPath(
      mediaStoreId,
      stableKey: stableKey,
      volumeName: volumeName,
      legacyTrackId: legacyTrackId,
    );
  }

  /// Loads album or legacy ID-keyed artwork from disk cache or MediaStore.
  ///
  /// Concurrent requests for the same native/cache identity share one Future.
  /// For track artwork, prefer [loadTrackArtwork].
  static Future<Uint8List?> loadArtwork(
    int nativeId, {
    ArtworkType type = ArtworkType.album,
    String? volumeName,
    int size = 300,
    int quality = 85,
    bool forceRefresh = false,
  }) {
    if (nativeId <= 0) {
      return Future<Uint8List?>.value(null);
    }

    return _loadArtworkShared(
      nativeId: nativeId,
      cacheToken: _nativeCacheToken(
        nativeId: nativeId,
        type: type,
        volumeName: volumeName,
      ),
      type: type,
      volumeName: volumeName,
      size: size,
      quality: quality,
      forceRefresh: forceRefresh,
    );
  }

  /// Loads track artwork from Android with [mediaStoreId], while disk and
  /// negative-cache state are owned by [stableKey].
  static Future<Uint8List?> loadTrackArtwork(
    int mediaStoreId, {
    required String stableKey,
    String? volumeName,
    int? legacyTrackId,
    int size = 300,
    int quality = 85,
    bool forceRefresh = false,
  }) async {
    if (mediaStoreId <= 0) {
      return null;
    }

    final cacheToken = _trackCacheToken(
      mediaStoreId: mediaStoreId,
      stableKey: stableKey,
      volumeName: volumeName,
    );

    await _migrateLegacyTrackCache(
      cacheToken: cacheToken,
      mediaStoreId: mediaStoreId,
      legacyTrackId: legacyTrackId,
    );

    return _loadArtworkShared(
      nativeId: mediaStoreId,
      cacheToken: cacheToken,
      type: ArtworkType.audio,
      volumeName: volumeName,
      size: size,
      quality: quality,
      forceRefresh: forceRefresh,
    );
  }

  static Future<Uint8List?> _loadArtworkShared({
    required int nativeId,
    required String cacheToken,
    required ArtworkType type,
    required String? volumeName,
    required int size,
    required int quality,
    required bool forceRefresh,
  }) {
    final key = _keyForToken(
      cacheToken,
      type,
    );

    if (forceRefresh) {
      return _loadArtwork(
        nativeId: nativeId,
        cacheToken: cacheToken,
        type: type,
        volumeName: volumeName,
        size: size,
        quality: quality,
        forceRefresh: true,
      );
    }

    return _pendingLoads.putIfAbsent(
      key,
      () async {
        try {
          return await _loadArtwork(
            nativeId: nativeId,
            cacheToken: cacheToken,
            type: type,
            volumeName: volumeName,
            size: size,
            quality: quality,
          );
        } finally {
          _pendingLoads.remove(key);
        }
      },
    );
  }

  static Future<Uint8List?> _loadArtwork({
    required int nativeId,
    required String cacheToken,
    required ArtworkType type,
    required String? volumeName,
    required int size,
    required int quality,
    bool forceRefresh = false,
  }) async {
    final key = _keyForToken(
      cacheToken,
      type,
    );

    if (!forceRefresh) {
      final existingPath =
          await _getCachedPathForToken(
        cacheToken,
        type: type,
      );

      if (existingPath != null) {
        try {
          final data =
              await File(existingPath).readAsBytes();

          if (data.isNotEmpty) {
            return data;
          }
        } catch (_) {
          // Fall through and replace an unreadable cache entry.
        }
      }

      if (await _hasFreshMissingMarkerToken(
        cacheToken,
        type: type,
      )) {
        _queriedKeys.add(key);
        return null;
      }

      if (_queriedKeys.contains(key)) {
        return null;
      }
    } else {
      await _invalidateArtworkToken(
        cacheToken,
        type: type,
      );
    }

    _queriedKeys.add(key);

    Uint8List? data;

    try {
      data = await _mediaLibrary.loadArtwork(
        nativeId,
        type: _nativeTypeFor(type),
        volumeName: volumeName,
        size: size.clamp(100, 600).toInt(),
        quality: quality.clamp(1, 100).toInt(),
      );
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkCache] Native artwork load failed '
        '(nativeId=$nativeId, volume=${_normalizeVolumeName(volumeName)}, '
        'cache=$cacheToken, type=${type.name}): $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      return null;
    }

    if (data == null || data.isEmpty) {
      await _markMissingArtworkToken(
        cacheToken,
        type: type,
      );

      return null;
    }

    try {
      final path = await _pathForToken(
        cacheToken,
        type: type,
      );

      await File(path).writeAsBytes(
        data,
        flush: false,
      );

      await _deleteMissingMarkerToken(
        cacheToken,
        type: type,
      );

      _schedulePrune();
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkCache] Failed to persist artwork cache: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );
    }

    return data;
  }

  /// Stores known-fresh artwork bytes after the app writes embedded artwork.
  ///
  /// New call sites should pass [mediaStoreId] and [stableKey]. [trackId] is
  /// retained for compatibility and can identify the old app-ID cache entry
  /// when [mediaStoreId] is also supplied.
  static Future<String?> cacheWrittenArtworkBytes({
    required Uint8List bytes,
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    int? trackId,
  }) async {
    if (bytes.isEmpty) {
      return null;
    }

    String? primaryPath;

    if (albumId != null && albumId > 0) {
      primaryPath = await _writeBytesToCacheToken(
        _nativeCacheToken(
          nativeId: albumId,
          type: ArtworkType.album,
          volumeName: volumeName,
        ),
        type: ArtworkType.album,
        bytes: bytes,
      );
    }

    final nativeTrackId = mediaStoreId ?? trackId;

    if (nativeTrackId != null && nativeTrackId > 0) {
      final cacheToken = _trackCacheToken(
        mediaStoreId: nativeTrackId,
        stableKey: stableKey,
        volumeName: volumeName,
      );

      final audioPath =
          await _writeBytesToCacheToken(
        cacheToken,
        type: ArtworkType.audio,
        bytes: bytes,
      );

      primaryPath ??= audioPath;

      if (mediaStoreId != null &&
          trackId != null &&
          trackId > 0 &&
          trackId != mediaStoreId) {
        await _invalidateArtworkToken(
          _legacyCacheToken(trackId),
          type: ArtworkType.audio,
        );
      }
    }

    _schedulePrune();
    return primaryPath;
  }

  static Future<String?> _writeBytesToCacheToken(
    String cacheToken, {
    required ArtworkType type,
    required Uint8List bytes,
  }) async {
    try {
      final path = await _pathForToken(
        cacheToken,
        type: type,
      );

      await File(path).writeAsBytes(
        bytes,
        flush: false,
      );

      await _deleteMissingMarkerToken(
        cacheToken,
        type: type,
      );

      final key = _keyForToken(
        cacheToken,
        type,
      );

      _queriedKeys.add(key);
      _pendingLoads.remove(key);

      return path;
    } catch (error, stackTrace) {
      debugPrint(
        '[ArtworkCache] Failed to write fresh artwork cache: $error',
      );

      debugPrintStack(
        stackTrace: stackTrace,
      );

      return null;
    }
  }

  /// Invalidates album artwork, stable track artwork, and known legacy audio
  /// cache entries.
  ///
  /// New call sites should provide [mediaStoreId], [stableKey], and [trackId]
  /// during the migration period. Here [trackId] identifies the old app-ID
  /// cache entry; when [mediaStoreId] is absent it remains the legacy native ID.
  static Future<void> invalidateArtwork({
    int? albumId,
    int? mediaStoreId,
    String? volumeName,
    String stableKey = '',
    int? trackId,
  }) async {
    if (albumId != null && albumId > 0) {
      await invalidateArtworkId(
        albumId,
        type: ArtworkType.album,
        volumeName: volumeName,
      );
    }

    final nativeTrackId = mediaStoreId ?? trackId;

    if (nativeTrackId == null || nativeTrackId <= 0) {
      return;
    }

    final cacheTokens = <String>{
      _trackCacheToken(
        mediaStoreId: nativeTrackId,
        stableKey: stableKey,
        volumeName: volumeName,
      ),
      _legacyCacheToken(nativeTrackId),
      if (trackId != null && trackId > 0)
        _legacyCacheToken(trackId),
    };

    for (final cacheToken in cacheTokens) {
      await _invalidateArtworkToken(
        cacheToken,
        type: ArtworkType.audio,
      );
    }
  }

  /// Invalidates one legacy ID-keyed cache entry.
  static Future<void> invalidateArtworkId(
    int id, {
    ArtworkType type = ArtworkType.album,
    String? volumeName,
  }) async {
    if (id <= 0) {
      return;
    }

    final tokens = <String>{
      _nativeCacheToken(
        nativeId: id,
        type: type,
        volumeName: volumeName,
      ),
      _legacyCacheToken(id),
    };

    for (final token in tokens) {
      await _invalidateArtworkToken(
        token,
        type: type,
      );
    }
  }

  static Future<void> _invalidateArtworkToken(
    String cacheToken, {
    required ArtworkType type,
  }) async {
    final key = _keyForToken(
      cacheToken,
      type,
    );

    _queriedKeys.remove(key);
    _pendingLoads.remove(key);

    await _deleteMissingMarkerToken(
      cacheToken,
      type: type,
    );

    try {
      final path = await _pathForToken(
        cacheToken,
        type: type,
      );

      final file = File(path);

      if (await file.exists()) {
        await file.delete();
      }
    } catch (_) {
      // Cache invalidation is best-effort.
    }
  }

  /// Batch pre-fetches artwork for a list of album IDs.
  ///
  /// Returns albumId → cached file path/null.
  static Future<Map<int, String?>> cacheBatch(
    List<int> albumIds, {
    int size = 300,
    int concurrency = 4,
  }) async {
    final results = <int, String?>{};

    final uniqueIds = albumIds
        .where((id) => id > 0)
        .toSet()
        .toList(growable: false);

    if (uniqueIds.isEmpty) {
      return results;
    }

    final safeConcurrency =
        concurrency.clamp(1, 8).toInt();

    for (var index = 0;
        index < uniqueIds.length;
        index += safeConcurrency) {
      final end = (index + safeConcurrency)
          .clamp(0, uniqueIds.length)
          .toInt();

      final chunk = uniqueIds.sublist(
        index,
        end,
      );

      final entries = await Future.wait(
        chunk.map((id) async {
          final path = await cacheArtwork(
            id,
            size: size,
          );

          return MapEntry(id, path);
        }),
      );

      for (final entry in entries) {
        results[entry.key] = entry.value;
      }
    }

    await pruneCache();
    return results;
  }

  static Future<void> pruneCache() async {
    try {
      final directory = await _directory;

      if (!await directory.exists()) {
        return;
      }

      final files = <({
        File file,
        int size,
        DateTime modified,
      })>[];

      var total = 0;

      await for (final entity in directory.list()) {
        if (entity is! File) {
          continue;
        }

        final stat = await entity.stat();
        total += stat.size;

        files.add((
          file: entity,
          size: stat.size,
          modified: stat.modified,
        ));
      }

      if (total <= _maxCacheBytes) {
        return;
      }

      files.sort(
        (first, second) => first.modified.compareTo(
          second.modified,
        ),
      );

      for (final entry in files) {
        if (total <= _targetCacheBytes) {
          break;
        }

        try {
          await entry.file.delete();
          total -= entry.size;
        } catch (_) {
          // Continue pruning other entries.
        }
      }
    } catch (_) {
      // Pruning must never interrupt playback or artwork rendering.
    }
  }

  static void _schedulePrune() {
    if (_scheduledPrune != null) {
      return;
    }

    _scheduledPrune = Future<void>.delayed(
      const Duration(milliseconds: 250),
      pruneCache,
    ).whenComplete(() {
      _scheduledPrune = null;
    });
  }

  /// Clears all cached artwork files and process-local lookup state.
  static Future<void> clearCache() async {
    try {
      final directory = await _directory;

      if (await directory.exists()) {
        await directory.delete(
          recursive: true,
        );
      }

      _cacheDir = null;
    } catch (_) {
      // Cache clearing is best-effort.
    }

    _queriedKeys.clear();
    _pendingLoads.clear();
    _scheduledPrune = null;
  }

  /// Returns total artwork cache size in bytes.
  static Future<int> cacheSizeBytes() async {
    try {
      final directory = await _directory;

      if (!await directory.exists()) {
        return 0;
      }

      var total = 0;

      await for (final entity in directory.list()) {
        if (entity is File) {
          total += await entity.length();
        }
      }

      return total;
    } catch (_) {
      return 0;
    }
  }
}
