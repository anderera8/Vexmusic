import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'prefs_service.dart';

class UnifiedAudioEffectsService {
  static const _prefsKey = 'unified_audio_effects_state';
  static const _frequencies = <double>[
    31,
    62,
    125,
    250,
    500,
    1000,
    2000,
    4000,
    8000,
    16000,
  ];

  static const double minGainDb = -12;
  static const double maxGainDb = 12;
  static const Duration _persistenceDebounce = Duration(milliseconds: 180);

  static final StreamController<EqState> _changes =
      StreamController<EqState>.broadcast();

  static Future<void>? _initialization;
  static Future<void> _writeTail = Future<void>.value();
  static Timer? _persistenceTimer;
  static bool _initialized = false;
  static bool _enabled = true;
  static List<double> _gains = List<double>.filled(10, 0);
  static double _bassBoost = 0;
  static double _volumeBoost = 0;
  static double _virtualizer = 0;
  static bool _normalization = false;
  static String _preset = 'Normal';
  static Map<String, Map<String, dynamic>> _customPresets = {};

  static Stream<EqState> get changes => _changes.stream;
  static bool get isInitialized => _initialized;

  static const Map<String, List<double>> presetCurves = {
    'Normal': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    'Classical': [-1, -0.5, 0, 0, 0, 0, -0.5, -1, -1.5, -2],
    'Dance': [4, 3.5, 2.5, 1, 0, 1, 2, 1.5, 0, 0],
    'Flat': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    'Folk': [0, 0.5, 1, 2, 1, 0.5, 0, 0, 0, 0],
    'Hip Hop': [3.5, 3, 2, 0, 1, 2, 1.5, 0, 0.5, 1],
    'Jazz': [1.5, 1.5, 1, 0.5, 0, 0.5, 1, 1, 0.5, 0],
    'Pop': [-0.5, 0, 1.5, 3, 2, 1, 0.5, 0, -0.5, -1],
    'Rock': [3, 2.5, 1.5, -1, -1.5, -1, 0, 1.5, 2.5, 3],
    'Acoustic': [1, 1.5, 2, 1.5, 1, 0.5, 0, 0, 0, 0],
    'Bass Boost': [6, 5, 3, 1, 0, 0, 0, 0, 0, 0],
    'Bass Reducer': [-4, -2, 0, 1, 1, 1, 1, 1, 1, 1],
    'Deep': [4, 3, 1, 0, 0, -1, -2, -3, -4, -5],
    'Electronic': [3, 2, 1, 0, 1, 2, 3, 3, 2, 2],
    'Gaming': [2, 3, 2, 1, 2, 3, 3, 2, 1, 1],
    'Latin': [2, 1.5, 1, 0, 1, 1.5, 2, 2, 1.5, 1],
    'Loudness': [3, 2, 1, 1, 0.5, 0, 1, 2, 2.5, 3],
    'Lounge': [1, 0.5, 0, 1, 1.5, 1, 0.5, 0, 0, 0],
    'Metal': [2, 1, 0, -2, -1, 0, 1, 3, 4, 4],
    'Movie': [2, 1.5, 1, 0, 1, 2, 2, 1.5, 1, 1],
    'Piano': [1, 0.5, 1, 1.5, 1, 0.5, 0, 0, 0, 0],
    'Podcast': [-3, -2, -1, 2, 3, 3, 2, 1, 0, -1],
    'R&B': [3, 3, 2, 1, 2, 2, 1, 0.5, 0.5, 1],
    'Reggae': [3, 2, 0, -1, -1.5, -1, 0, 1, 1, 1],
    'Ska': [1, 1, 1.5, 2, 1.5, 1, 0.5, 0, 0, 0],
    'Soft': [1, 1, 0.5, 0, -0.5, -1, -1, -0.5, 0, 0],
    'Speech': [-4, -2, -1, 2, 3, 3, 2, 0, -1, -2],
    'Techno': [3, 2.5, 1, 0, 1.5, 2.5, 3, 2.5, 2, 2],
    'Treble Boost': [-3, -2, -1, 0, 1, 2, 3, 4, 5, 5],
    'Vocal Boost': [-2, -1, 0, 2, 3, 3, 2, 1, 0, -1],
  };

  static Future<void> ensureInitialized() {
    if (_initialized) return Future<void>.value();
    return _initialization ??= _load();
  }

  static List<String> getAllPresetNames() => <String>[
        ...presetCurves.keys,
        ..._customPresets.keys,
        'Custom',
      ];

  static Future<EqState> getState() async {
    await ensureInitialized();
    return _state;
  }

  static Future<bool> getEnabled() async {
    await ensureInitialized();
    return _enabled;
  }

  static Future<void> setEnabled(bool enabled) async {
    await ensureInitialized();
    if (_enabled == enabled) return;
    _enabled = enabled;
    _publish();
  }

  static Future<void> setBandGain(int index, double gainDb) async {
    await ensureInitialized();
    if (index < 0 || index >= _gains.length) return;
    final next = gainDb.clamp(minGainDb, maxGainDb).toDouble();
    if ((_gains[index] - next).abs() < 0.001) return;
    _gains[index] = next;
    _preset = 'Custom';
    _publish();
  }

  static Future<void> setBandGains(List<double> gains) async {
    await ensureInitialized();
    if (gains.length != _frequencies.length) {
      throw ArgumentError.value(
        gains.length,
        'gains.length',
        'Expected ${_frequencies.length} equalizer bands.',
      );
    }
    _gains = gains
        .map((value) => value.clamp(minGainDb, maxGainDb).toDouble())
        .toList(growable: false);
    _preset = 'Custom';
    _publish();
  }

  static Future<void> applyPresetCurve(String name) async {
    await ensureInitialized();
    if (name == 'Custom') return;

    final custom = _customPresets[name];
    if (custom != null) {
      _restoreEffect(custom);
      _preset = name;
      _publish(immediatePersistence: true);
      return;
    }

    final curve = presetCurves[name];
    if (curve == null) return;
    _gains = List<double>.from(curve);
    _preset = name;
    _bassBoost = 0;
    _volumeBoost = 0;
    _virtualizer = 0;
    _publish(immediatePersistence: true);
  }

  static Future<void> setBassBoost(double level) async {
    await ensureInitialized();
    _bassBoost = level.clamp(0, 1).toDouble();
    _preset = 'Custom';
    _publish();
  }

  static Future<void> setVolumeBoost(double level) async {
    await ensureInitialized();
    _volumeBoost = level.clamp(0, 1).toDouble();
    _preset = 'Custom';
    _publish();
  }

  static Future<void> setVirtualizer(double level) async {
    await ensureInitialized();
    _virtualizer = level.clamp(0, 1).toDouble();
    _preset = 'Custom';
    _publish();
  }

  static Future<void> setNormalization(bool enabled) async {
    await ensureInitialized();
    if (_normalization == enabled) return;
    _normalization = enabled;
    _publish(immediatePersistence: true);
  }

  static Future<void> setStateSnapshot(
    EqState state, {
    bool immediatePersistence = false,
  }) async {
    await ensureInitialized();
    if (state.bands.length != _frequencies.length) {
      throw ArgumentError.value(
        state.bands.length,
        'state.bands.length',
        'Expected ${_frequencies.length} equalizer bands.',
      );
    }

    _enabled = state.enabled;
    _gains = state.bands
        .map(
          (band) => band.gainDb
              .clamp(minGainDb, maxGainDb)
              .toDouble(),
        )
        .toList(growable: false);
    _bassBoost = (state.bassBoost / 100.0).clamp(0.0, 1.0).toDouble();
    _volumeBoost =
        (state.volumeBoost / 100.0).clamp(0.0, 1.0).toDouble();
    _virtualizer =
        (state.virtualizer / 100.0).clamp(0.0, 1.0).toDouble();
    _normalization = state.normalization;

    final names = getAllPresetNames();
    _preset = state.currentPreset >= 0 && state.currentPreset < names.length
        ? names[state.currentPreset]
        : 'Custom';
    _publish(immediatePersistence: immediatePersistence);
  }

  static Future<bool> saveCustomPreset(String name) async {
    await ensureInitialized();
    final trimmed = name.trim();
    if (trimmed.isEmpty ||
        trimmed == 'Custom' ||
        presetCurves.containsKey(trimmed)) {
      return false;
    }
    _customPresets[trimmed] = _effectJson;
    _preset = trimmed;
    _publish(immediatePersistence: true);
    return true;
  }

  static Future<void> resetAll() async {
    await ensureInitialized();
    _enabled = true;
    _gains = List<double>.filled(_frequencies.length, 0);
    _bassBoost = 0;
    _volumeBoost = 0;
    _virtualizer = 0;
    _normalization = false;
    _preset = 'Normal';
    _publish(immediatePersistence: true);
  }

  static Future<void> flushPendingPersistence() async {
    _persistenceTimer?.cancel();
    _persistenceTimer = null;
    await _enqueueWrite(_serializedState);
  }

  static EqState get _state {
    final presetIndex = getAllPresetNames().indexOf(_preset);
    return EqState(
      bands: List<EqBand>.unmodifiable(
        List<EqBand>.generate(
          _frequencies.length,
          (index) => EqBand(
            index: index,
            gainDb: _gains[index],
            minDb: minGainDb,
            maxDb: maxGainDb,
            centerFreqHz: _frequencies[index],
          ),
        ),
      ),
      currentPreset: presetIndex,
      enabled: _enabled,
      bassBoost: (_bassBoost * 100).round(),
      volumeBoost: (_volumeBoost * 100).round(),
      virtualizer: (_virtualizer * 100).round(),
      normalization: _normalization,
    );
  }

  static Future<void> _load() async {
    try {
      final raw = PrefsService.instance.getString(_prefsKey);
      if (raw != null) {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        final gains = (data['gains'] as List<dynamic>?)
            ?.map(
              (value) => (value as num)
                  .toDouble()
                  .clamp(minGainDb, maxGainDb)
                  .toDouble(),
            )
            .toList(growable: false);
        if (gains != null && gains.length == _frequencies.length) {
          _gains = gains;
        }
        _enabled = data['enabled'] as bool? ?? true;
        _preset = data['preset'] as String? ?? 'Custom';
        _bassBoost = ((data['bassBoost'] as num?)?.toDouble() ?? 0)
            .clamp(0, 1)
            .toDouble();
        _volumeBoost = ((data['volumeBoost'] as num?)?.toDouble() ?? 0)
            .clamp(0, 1)
            .toDouble();
        _virtualizer = ((data['virtualizer'] as num?)?.toDouble() ?? 0)
            .clamp(0, 1)
            .toDouble();
        _normalization = data['normalization'] as bool? ?? false;
        final custom = data['customPresets'];
        if (custom is Map<String, dynamic>) {
          _customPresets = custom.map(
            (name, value) => MapEntry(
              name,
              Map<String, dynamic>.from(value as Map),
            ),
          );
        }
      }
    } catch (error, stackTrace) {
      debugPrint('[UnifiedAudioEffects] Could not restore state: $error');
      debugPrintStack(stackTrace: stackTrace);
    } finally {
      _initialized = true;
      _initialization = null;
      _changes.add(_state);
    }
  }

  static void _publish({bool immediatePersistence = false}) {
    final state = _state;
    _changes.add(state);

    _persistenceTimer?.cancel();
    final serialized = _serializedState;

    if (immediatePersistence) {
      unawaited(_enqueueWrite(serialized));
      return;
    }

    _persistenceTimer = Timer(
      _persistenceDebounce,
      () => unawaited(_enqueueWrite(serialized)),
    );
  }

  static String get _serializedState => jsonEncode(<String, Object?>{
        'gains': List<double>.from(_gains),
        'enabled': _enabled,
        'preset': _preset,
        'bassBoost': _bassBoost,
        'volumeBoost': _volumeBoost,
        'virtualizer': _virtualizer,
        'normalization': _normalization,
        'customPresets': _customPresets,
      });

  static Future<void> _enqueueWrite(String serialized) {
    final completion = Completer<void>();
    _writeTail = _writeTail
        .catchError((Object _) {})
        .then((_) async {
      try {
        await PrefsService.instance.setString(_prefsKey, serialized);
      } catch (error, stackTrace) {
        debugPrint('[UnifiedAudioEffects] Could not persist state: $error');
        debugPrintStack(stackTrace: stackTrace);
      } finally {
        if (!completion.isCompleted) {
          completion.complete();
        }
      }
    });
    return completion.future;
  }

  static Map<String, dynamic> get _effectJson => <String, dynamic>{
        'gains': List<double>.from(_gains),
        'bassBoost': _bassBoost,
        'volumeBoost': _volumeBoost,
        'virtualizer': _virtualizer,
        'normalization': _normalization,
      };

  static void _restoreEffect(Map<String, dynamic> data) {
    final gains = (data['gains'] as List<dynamic>?)
        ?.map(
          (value) => (value as num)
              .toDouble()
              .clamp(minGainDb, maxGainDb)
              .toDouble(),
        )
        .toList(growable: false);
    if (gains != null && gains.length == _frequencies.length) {
      _gains = gains;
    }
    _bassBoost = ((data['bassBoost'] as num?)?.toDouble() ?? 0)
        .clamp(0, 1)
        .toDouble();
    _volumeBoost = ((data['volumeBoost'] as num?)?.toDouble() ?? 0)
        .clamp(0, 1)
        .toDouble();
    _virtualizer = ((data['virtualizer'] as num?)?.toDouble() ?? 0)
        .clamp(0, 1)
        .toDouble();
    _normalization = data['normalization'] as bool? ?? _normalization;
  }

  @visibleForTesting
  static void resetForTesting() {
    _persistenceTimer?.cancel();
    _persistenceTimer = null;
    _initialization = null;
    _writeTail = Future<void>.value();
    _initialized = false;
    _enabled = true;
    _gains = List<double>.filled(_frequencies.length, 0);
    _bassBoost = 0;
    _volumeBoost = 0;
    _virtualizer = 0;
    _normalization = false;
    _preset = 'Normal';
    _customPresets = {};
  }
}

class EqBand {
  final int index;
  final double gainDb;
  final double minDb;
  final double maxDb;
  final double centerFreqHz;

  const EqBand({
    required this.index,
    required this.gainDb,
    required this.minDb,
    required this.maxDb,
    required this.centerFreqHz,
  });

  String get freqLabel {
    if (centerFreqHz <= 0) return '?';
    if (centerFreqHz < 1000) return '${centerFreqHz.round()}Hz';
    return '${(centerFreqHz / 1000).toStringAsFixed(1)}kHz';
  }

  String get gainLabel {
    final sign = gainDb >= 0 ? '+' : '';
    return '$sign${gainDb.toStringAsFixed(0)}';
  }

  EqBand copyWith({double? gainDb}) => EqBand(
        index: index,
        gainDb: gainDb ?? this.gainDb,
        minDb: minDb,
        maxDb: maxDb,
        centerFreqHz: centerFreqHz,
      );
}

class EqState {
  final List<EqBand> bands;
  final int currentPreset;
  final bool enabled;
  final int bassBoost;
  final int volumeBoost;
  final int virtualizer;
  final bool normalization;

  const EqState({
    required this.bands,
    required this.currentPreset,
    required this.enabled,
    required this.bassBoost,
    required this.volumeBoost,
    this.virtualizer = 0,
    this.normalization = false,
  });

  EqState copyWith({
    List<EqBand>? bands,
    int? currentPreset,
    bool? enabled,
    int? bassBoost,
    int? volumeBoost,
    int? virtualizer,
    bool? normalization,
  }) {
    return EqState(
      bands: bands ?? this.bands,
      currentPreset: currentPreset ?? this.currentPreset,
      enabled: enabled ?? this.enabled,
      bassBoost: bassBoost ?? this.bassBoost,
      volumeBoost: volumeBoost ?? this.volumeBoost,
      virtualizer: virtualizer ?? this.virtualizer,
      normalization: normalization ?? this.normalization,
    );
  }
}
