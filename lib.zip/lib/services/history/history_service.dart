// lib/services/history/history_service.dart
// Recently played history tracking.

import '../../models/music_models.dart';
import '../database_service.dart';

class HistoryService {
  final DatabaseService _db;

  HistoryService({DatabaseService? db}) : _db = db ?? DatabaseService();

  Future<List<PlayHistory>> loadHistory({
    List<Track> tracks = const [],
  }) async {
    // Stable-key migration is committed with track reconciliation. Avoid
    // rewriting history on every read from a potentially reused numeric ID.
    return _db.getRecentHistory();
  }

  Future<void> clearHistory() async {
    await _db.clearHistory();
  }

  Future<void> removeTrackHistory(int trackId) =>
      _db.removeTrackHistory(trackId);

  Future<void> removeTrackHistoryRef(Track track) =>
      _db.removeTrackHistoryRef(track);

  Future<void> recordPlay(Track track, {int lastPositionMs = 0}) =>
      _db.recordPlay(track, lastPositionMs: lastPositionMs);

  Future<PlayHistory?> getLastResumePoint(int trackId) =>
      _db.getLastResumePointForTrack(trackId);

  Future<PlayHistory?> getLastResumePointForTrack(Track track) =>
      _db.getLastResumePointForTrackRef(track);

  Future<PlayHistory?> getLastPlay(int trackId) =>
      _db.getLastPlayForTrack(trackId);

  Future<PlayHistory?> getLastPlayForTrack(Track track) =>
      _db.getLastPlayForTrackRef(track);

  static List<Track> recentlyPlayed(
    List<PlayHistory> history,
    Map<int, Track> trackById, {
    List<Track> tracks = const [],
    int limit = 10,
  }) {
    final byStableKey = <String, Track>{};
    final ambiguousStableKeys = <String>{};

    for (final track in tracks) {
      final key = track.stableKey.trim().toLowerCase();
      if (key.isEmpty) continue;

      final existing = byStableKey[key];
      if (existing != null && existing.id != track.id) {
        ambiguousStableKeys.add(key);
        continue;
      }
      byStableKey[key] = track;
    }

    for (final key in ambiguousStableKeys) {
      byStableKey.remove(key);
    }

    final result = <Track>[];
    final seenStableKeys = <String>{};
    final seenIds = <int>{};

    for (final entry in history) {
      final entryStableKey = entry.stableKey.trim().toLowerCase();
      final match = entryStableKey.isNotEmpty
          ? byStableKey[entryStableKey]
          : trackById[entry.trackId];

      // A history row that already owns a stable key must never fall back to
      // an app ID that may now represent another physical file.
      if (match == null) continue;

      final stableKey = match.stableKey.trim().toLowerCase();

      if (seenIds.contains(match.id)) continue;
      if (stableKey.isNotEmpty && seenStableKeys.contains(stableKey)) continue;

      result.add(match);
      seenIds.add(match.id);
      if (stableKey.isNotEmpty) {
        seenStableKeys.add(stableKey);
      }

      if (result.length >= limit) break;
    }

    return result;
  }
}
