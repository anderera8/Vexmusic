// lib/services/favorites/like_service.dart
// Favorites management.

import '../../models/music_models.dart';
import '../database_service.dart';

class LikeService {
  final DatabaseService _db;

  LikeService({DatabaseService? db}) : _db = db ?? DatabaseService();

  Future<Set<int>> getLikedTrackIds() => _db.getLikedTrackIds();

  Future<List<Track>> applyLikes(List<Track> tracks) async {
    if (tracks.isEmpty) return tracks;

    // Relationship migration is performed transactionally during library
    // reconciliation. Reads must not rewrite legacy rows on every load because
    // a reused numeric ID is not proof of physical-track identity.
    // liked_tracks is the sole source of truth. A row with a non-empty
    // stable key must never like another track merely because its app ID now
    // matches. ID fallback is reserved for unresolved legacy rows only.
    final likedRefs = await _db.getLikedTrackIdentityRefs();

    return tracks.map((track) {
      final stableKey = track.stableKey.trim().toLowerCase();
      final likedByStableKey = stableKey.isNotEmpty &&
          likedRefs.stableKeys.contains(stableKey);
      final likedByLegacyId =
          likedRefs.legacyTrackIds.contains(track.id);

      return track.copyWith(
        liked: likedByStableKey || likedByLegacyId,
      );
    }).toList(growable: false);
  }

  Future<({Track track, bool liked})> toggleLike(Track track) async {
    // Never derive the write operation from an in-memory flag that may have
    // survived a reload or scan. Read the authoritative relationship first.
    final currentlyLiked = await _db.isTrackLikedRef(track);
    final newLiked = !currentlyLiked;

    if (newLiked) {
      await _db.likeTrackRef(track);
    } else {
      await _db.unlikeTrackRef(track);
    }

    return (track: track.copyWith(liked: newLiked), liked: newLiked);
  }

  Future<void> unlikeTrack(int trackId) => _db.unlikeTrack(trackId);
}
