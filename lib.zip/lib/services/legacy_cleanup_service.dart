import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'prefs_service.dart';

class LegacyCleanupService {
  static const _completedKey = 'audioOnlyCleanupV1';

  static Future<void> runOnce() async {
    if (PrefsService.getBool(_completedKey) == true) return;

    for (final key in PrefsService.instance.getKeys().toList()) {
      final normalized = key.toLowerCase();
      if (normalized.contains('video') || normalized.contains('pip')) {
        await PrefsService.remove(key);
      }
    }

    try {
      final roots = [
        await getApplicationDocumentsDirectory(),
        await getTemporaryDirectory(),
      ];
      for (final root in roots) {
        final thumbnails = Directory(p.join(root.path, 'video_thumbnails'));
        if (await thumbnails.exists()) {
          await thumbnails.delete(recursive: true);
        }
      }
    } catch (error) {
      debugPrint('Legacy media cache cleanup failed: $error');
      return;
    }

    await PrefsService.setBool(_completedKey, true);
  }
}
