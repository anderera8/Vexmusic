class SystemFontService {
  static Future<String?> loadCurrentFamily() async => null;
}
