// Frequency policy for interstitial ads, sitting in front of
// [UnityAdsService.showInterstitialAd].
//
// This is the single place that decides *whether* an interstitial should
// show right now. Every call site in the app that wants to show an
// interstitial after the person completes an action should go through
// [InterstitialAdController.maybeShow] rather than calling
// [UnityAdsService.showInterstitialAd] directly, so the frequency rules
// below apply everywhere consistently instead of being re-implemented (or
// forgotten) at each call site.
//
// Two rules, both required for a show:
//
// 1. Global cooldown — at most one interstitial every [cooldown] (60s),
//    counted across every trigger in the app combined. A person unlocking
//    a player skin and then immediately liking a track should not see two
//    interstitials back to back.
// 2. Per-action-type threshold — some actions (Favorite, Add to Playlist)
//    are cheap and can be tapped in rapid succession (liking ten tracks in
//    a row). Showing an interstitial on every single tap would be an
//    aggressive, spammy pattern likely to run afoul of Google Play's and
//    Unity's ad-placement policies (e.g. ads that interrupt normal, rapid
//    app navigation). Those trigger types are instead configured with a
//    `every: N` threshold and only fire on every Nth qualifying action.
//    Other triggers (opening the equaliser, applying a theme, saving
//    edited tags) are inherently one-off per session and use `every: 1`.
//
// Both counters persist across app restarts via [PrefsService] so quitting
// and reopening the app can't be used to bypass the cap.
//
// This never blocks or gates the feature it's attached to — see
// [UnityAdsService.showInterstitialAd] for that contract. [maybeShow]
// itself follows the same contract: it never throws and callers don't
// need to await it if they don't want to delay on it.
import '../prefs_service.dart';
import 'unity_ads_service.dart';

/// Identifies a place in the app that can trigger an interstitial, used to
/// key the per-action-type "every Nth time" counters below. Two different
/// triggers never share a counter, but they do share the global cooldown.
enum InterstitialTrigger {
  playerSkinApplied,
  equalizerOpened,
  lyricsOpened,
  lyricThemeApplied,
  customThemeApplied,
  artworkEdited,
  tagsEdited,
  playlistAction,
  favoriteToggled,

  /// Entering a browse-level Radio screen (search results, a genre/country
  /// list, or Favorites) with something to show. Repeatable browsing,
  /// not a one-off — every 4th qualifying visit, same as other
  /// repeatable-browsing triggers. Never fired from the player screen or
  /// from a playback action; call sites additionally check that neither
  /// player is actively playing before calling [maybeShow] with this
  /// trigger, since InterstitialAdController itself doesn't guard against
  /// showing over active playback.
  radioBrowse,
}

extension on InterstitialTrigger {
  /// How many qualifying actions of this type must accumulate before an
  /// interstitial is shown. `1` means "every time" (subject to the
  /// cooldown). Favorites and playlist actions are the only high-frequency,
  /// rapid-tap triggers in the app, so those are the only ones throttled
  /// below `1`.
  int get every {
    switch (this) {
      case InterstitialTrigger.favoriteToggled:
      case InterstitialTrigger.playlistAction:
        return 3;
      case InterstitialTrigger.radioBrowse:
        return 4;
      case InterstitialTrigger.playerSkinApplied:
      case InterstitialTrigger.equalizerOpened:
      case InterstitialTrigger.lyricsOpened:
      case InterstitialTrigger.lyricThemeApplied:
      case InterstitialTrigger.customThemeApplied:
      case InterstitialTrigger.artworkEdited:
      case InterstitialTrigger.tagsEdited:
        return 1;
    }
  }

  String get _countPrefsKey => 'interstitial_ads.count.$name';
}

class InterstitialAdController {
  InterstitialAdController._();

  /// Minimum time between interstitials, counted across every trigger in
  /// the app combined.
  static const Duration cooldown = Duration(seconds: 60);

  static const String _lastShownPrefsKey = 'interstitial_ads.last_shown_at';

  /// Call this right after the person completes the action associated with
  /// [trigger] — e.g. right after a theme is applied, or right after a
  /// track is added to a playlist. Never call it speculatively before the
  /// action is known to have succeeded.
  ///
  /// Internally checks the per-trigger "every Nth time" threshold and the
  /// global cooldown, and only asks [UnityAdsService] to show an ad if
  /// both allow it. Whether or not an ad actually shows (no fill, no
  /// internet, on cooldown, etc.) has no bearing on the action that already
  /// happened — this is fire-and-forget from the caller's perspective.
  static Future<void> maybeShow(InterstitialTrigger trigger) async {
    if (!_bumpAndCheckThreshold(trigger)) return;
    if (!_checkAndConsumeCooldown()) return;

    await UnityAdsService.instance.showInterstitialAd();
  }

  /// Increments the persisted counter for [trigger] and returns whether it
  /// has now reached its `every` threshold. Resets the counter back to 0
  /// whenever the threshold is hit, whether or not the cooldown ends up
  /// allowing the ad to actually show — the count is "actions since we
  /// last considered showing an ad for this trigger", not "actions since
  /// an ad last actually appeared", so a cooldown-blocked attempt doesn't
  /// cause the next N actions to bunch up into an immediate show.
  static bool _bumpAndCheckThreshold(InterstitialTrigger trigger) {
    final every = trigger.every;
    final key = trigger._countPrefsKey;

    final nextCount = (PrefsService.getInt(key) ?? 0) + 1;

    if (nextCount >= every) {
      PrefsService.setInt(key, 0);
      return true;
    }

    PrefsService.setInt(key, nextCount);
    return false;
  }

  /// Returns whether the global cooldown allows a show right now. If so,
  /// stamps "now" as the last-shown time so the next call (from any
  /// trigger) is blocked until the cooldown elapses again.
  static bool _checkAndConsumeCooldown() {
    final now = DateTime.now();
    final lastMillis = PrefsService.getInt(_lastShownPrefsKey);

    if (lastMillis != null) {
      final elapsed = now.difference(
        DateTime.fromMillisecondsSinceEpoch(lastMillis),
      );
      if (elapsed < cooldown) return false;
    }

    PrefsService.setInt(_lastShownPrefsKey, now.millisecondsSinceEpoch);
    return true;
  }
}
