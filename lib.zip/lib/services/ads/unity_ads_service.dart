// Thin wrapper around the Unity Ads SDK (unity_ads_plugin).
//
// This is the only file that talks to `unity_ads_plugin` directly — every
// screen goes through here (or through [AdBannerBar] /
// [InterstitialAdController]) so the ad SDK stays swappable and the
// placement IDs live in exactly one place.
//
// Configuration below matches the Unity Dashboard
// (Monetization → Placements) for this app:
//   Game ID               800006237
//   Banner_Android         banner placement
//   Rewarded_Android       rewarded placement (unused — no features are
//                          gated behind a reward anymore; kept wired in
//                          case a future feature wants it)
//   Interstitial_Android   interstitial placement, shown after the person
//                          completes an action (see InterstitialAdController
//                          for the frequency rules around this)
//
// Only Android placement IDs have been provided, so ad calls are gated on
// `Platform.isAndroid` and are safe no-ops on any other platform.
import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';

class UnityAdsService {
  UnityAdsService._();

  static final UnityAdsService instance = UnityAdsService._();

  // ── Unity Dashboard configuration ───────────────────────────────────────
  static const String gameId = '800006237';
  static const String bannerPlacementId = 'Banner_Android';
  static const String rewardedPlacementId = 'Rewarded_Android';
  static const String interstitialPlacementId = 'Interstitial_Android';

  static bool get _supported => Platform.isAndroid;

  bool _initialized = false;
  bool _rewardedReady = false;
  bool _interstitialReady = false;
  Completer<void>? _initCompleter;

  /// True once Unity Ads has finished starting up.
  bool get isInitialized => _initialized;

  /// Starts the Unity Ads SDK. Safe to call multiple times, including
  /// concurrently (e.g. the startup task and a rewarded-ad request racing
  /// on first launch both call this) — every call after the first shares
  /// the same in-flight attempt instead of re-triggering `UnityAds.init`.
  /// Never throws; ad failures should never be able to break app startup.
  Future<void> init() async {
    if (_initialized || !_supported) return;

    final inFlight = _initCompleter;
    if (inFlight != null) return inFlight.future;

    final completer = Completer<void>();
    _initCompleter = completer;

    try {
      UnityAds.init(
        gameId: gameId,
        testMode: kDebugMode,
        onComplete: () {
          _initialized = true;
          debugPrint('[UnityAdsService] initialized');
          _preloadRewarded();
          _preloadInterstitial();
          if (!completer.isCompleted) completer.complete();
        },
        onFailed: (error, message) {
          debugPrint('[UnityAdsService] init failed: $error $message');
          _initCompleter = null; // allow a later call to retry
          if (!completer.isCompleted) completer.complete();
        },
      );
    } catch (e) {
      // Covers e.g. the plugin not being linked (MissingPluginException) if
      // a build was run without a fresh `flutter pub get` — ads simply stay
      // off instead of taking the app down with them.
      debugPrint('[UnityAdsService] init threw: $e');
      _initCompleter = null; // allow a later call to retry
      if (!completer.isCompleted) completer.complete();
    }

    return completer.future;
  }

  void _preloadRewarded() {
    try {
      UnityAds.load(
        placementId: rewardedPlacementId,
        onComplete: (placementId) => _rewardedReady = true,
        onFailed: (placementId, error, message) {
          _rewardedReady = false;
          debugPrint('[UnityAdsService] rewarded preload failed: $error $message');
        },
      );
    } catch (e) {
      _rewardedReady = false;
      debugPrint('[UnityAdsService] rewarded preload threw: $e');
    }
  }

  /// Shows the rewarded placement and resolves `true` only if the person
  /// watched it all the way through — that's the only case a reward (a
  /// premium-feature unlock) should be granted. Resolves `false` if the ad
  /// was skipped, failed to show, wasn't available, or the SDK call threw.
  ///
  /// Loads the ad on demand if nothing was preloaded yet, so this is safe
  /// to call even right after [init] completes.
  Future<bool> showRewardedAd() async {
    if (!_supported) return false;
    if (!_initialized) await init();
    if (!_initialized) return false;

    final completer = Completer<bool>();

    void play() {
      try {
        UnityAds.showVideoAd(
          placementId: rewardedPlacementId,
          onComplete: (placementId) {
            _rewardedReady = false;
            _preloadRewarded();
            if (!completer.isCompleted) completer.complete(true);
          },
          onSkipped: (placementId) {
            _rewardedReady = false;
            _preloadRewarded();
            if (!completer.isCompleted) completer.complete(false);
          },
          onFailed: (placementId, error, message) {
            debugPrint('[UnityAdsService] rewarded show failed: $error $message');
            _rewardedReady = false;
            _preloadRewarded();
            if (!completer.isCompleted) completer.complete(false);
          },
        );
      } catch (e) {
        debugPrint('[UnityAdsService] rewarded show threw: $e');
        _rewardedReady = false;
        if (!completer.isCompleted) completer.complete(false);
      }
    }

    if (_rewardedReady) {
      play();
    } else {
      try {
        UnityAds.load(
          placementId: rewardedPlacementId,
          onComplete: (placementId) {
            _rewardedReady = true;
            play();
          },
          onFailed: (placementId, error, message) {
            debugPrint('[UnityAdsService] rewarded load failed: $error $message');
            if (!completer.isCompleted) completer.complete(false);
          },
        );
      } catch (e) {
        debugPrint('[UnityAdsService] rewarded load threw: $e');
        if (!completer.isCompleted) completer.complete(false);
      }
    }

    return completer.future;
  }

  void _preloadInterstitial() {
    try {
      UnityAds.load(
        placementId: interstitialPlacementId,
        onComplete: (placementId) => _interstitialReady = true,
        onFailed: (placementId, error, message) {
          _interstitialReady = false;
          debugPrint(
              '[UnityAdsService] interstitial preload failed: $error $message');
        },
      );
    } catch (e) {
      _interstitialReady = false;
      debugPrint('[UnityAdsService] interstitial preload threw: $e');
    }
  }

  /// Shows the interstitial placement after the person completes an
  /// action (see [InterstitialAdController] for when this gets called and
  /// how often).
  ///
  /// This never blocks or gates the feature it's attached to: no internet
  /// connection, an empty ad fill, an SDK error, or the ad being skipped
  /// are all treated exactly the same as a successful show. The completer
  /// always resolves (never throws), and callers should not — and do not
  /// need to — branch on the result; the action it's attached to has
  /// already happened by the time this is called.
  ///
  /// Loads the ad on demand if nothing was preloaded yet, so this is safe
  /// to call even right after [init] completes.
  Future<void> showInterstitialAd() async {
    if (!_supported) return;
    if (!_initialized) await init();
    if (!_initialized) return;

    final completer = Completer<void>();

    void play() {
      try {
        UnityAds.showVideoAd(
          placementId: interstitialPlacementId,
          onComplete: (placementId) {
            _interstitialReady = false;
            _preloadInterstitial();
            if (!completer.isCompleted) completer.complete();
          },
          onSkipped: (placementId) {
            _interstitialReady = false;
            _preloadInterstitial();
            if (!completer.isCompleted) completer.complete();
          },
          onFailed: (placementId, error, message) {
            debugPrint(
                '[UnityAdsService] interstitial show failed: $error $message');
            _interstitialReady = false;
            _preloadInterstitial();
            if (!completer.isCompleted) completer.complete();
          },
        );
      } catch (e) {
        debugPrint('[UnityAdsService] interstitial show threw: $e');
        _interstitialReady = false;
        if (!completer.isCompleted) completer.complete();
      }
    }

    if (_interstitialReady) {
      play();
    } else {
      try {
        UnityAds.load(
          placementId: interstitialPlacementId,
          onComplete: (placementId) {
            _interstitialReady = true;
            play();
          },
          onFailed: (placementId, error, message) {
            debugPrint(
                '[UnityAdsService] interstitial load failed: $error $message');
            // No fill / no connection: nothing to show. The action this
            // is attached to already completed, so this is a silent no-op.
            if (!completer.isCompleted) completer.complete();
          },
        );
      } catch (e) {
        debugPrint('[UnityAdsService] interstitial load threw: $e');
        if (!completer.isCompleted) completer.complete();
      }
    }

    return completer.future;
  }
}
