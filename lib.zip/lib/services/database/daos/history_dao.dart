// lib/services/database/daos/history_dao.dart
// Audio play history. Rows are keyed by current track_id and stable_key.

import 'package:flutter/foundation.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class HistoryDao {
  final DatabaseBase _database;

  HistoryDao(this._database);

  Future<void> recordPlay(Track track, {int lastPositionMs = 0}) async {
    if (track.id <= 0) {
      throw ArgumentError.value(
        track.id,
        'track.id',
        'History requires a valid app-owned track ID.',
      );
    }

    final database = await _database.db;

    await database.insert('play_history', {
      'track_id': track.id,
      'stable_key': _normalizeStableKey(track.stableKey),
      'title': track.title,
      'artist': track.artist,
      'played_at': DateTime.now().toUtc().toIso8601String(),
      'last_position_ms': lastPositionMs < 0 ? 0 : lastPositionMs,
    });

    await database.execute('''
      DELETE FROM play_history
      WHERE id NOT IN (
        SELECT id FROM play_history
        ORDER BY played_at DESC
        LIMIT 200
      )
    ''');
  }

  Future<PlayHistory?> getLastPlayForTrack(int trackId) async {
    final database = await _database.db;

    final rows = await database.query(
      'play_history',
      where: 'track_id = ? AND (stable_key IS NULL OR stable_key = ?)',
      whereArgs: [trackId, ''],
      orderBy: 'played_at DESC',
      limit: 1,
    );

    if (rows.isEmpty) return null;
    return PlayHistory.fromMap(rows.first);
  }

  Future<PlayHistory?> getLastPlayForTrackRef(Track track) async {
    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    final rows = stableKey.isEmpty
        ? await database.query(
            'play_history',
            where: 'track_id = ? AND (stable_key IS NULL OR stable_key = ?)',
            whereArgs: [track.id, ''],
            orderBy: 'played_at DESC',
            limit: 1,
          )
        : await database.query(
            'play_history',
            where: 'stable_key = ?',
            whereArgs: [stableKey],
            orderBy: 'played_at DESC',
            limit: 1,
          );

    if (rows.isEmpty) return null;
    return PlayHistory.fromMap(rows.first);
  }

  Future<PlayHistory?> getLastResumePointForTrack(int trackId) async {
    final database = await _database.db;

    final rows = await database.query(
      'play_history',
      where: 'track_id = ? AND (stable_key IS NULL OR stable_key = ?) '
          'AND last_position_ms > ?',
      whereArgs: [trackId, '', 2000],
      orderBy: 'played_at DESC',
      limit: 1,
    );

    if (rows.isEmpty) return null;
    return PlayHistory.fromMap(rows.first);
  }

  Future<PlayHistory?> getLastResumePointForTrackRef(Track track) async {
    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    final rows = stableKey.isEmpty
        ? await database.query(
            'play_history',
            where: 'track_id = ? AND (stable_key IS NULL OR stable_key = ?) '
                'AND last_position_ms > ?',
            whereArgs: [track.id, '', 2000],
            orderBy: 'played_at DESC',
            limit: 1,
          )
        : await database.query(
            'play_history',
            where: 'stable_key = ? AND last_position_ms > ?',
            whereArgs: [stableKey, 2000],
            orderBy: 'played_at DESC',
            limit: 1,
          );

    if (rows.isEmpty) return null;
    return PlayHistory.fromMap(rows.first);
  }

  Future<List<PlayHistory>> getRecentHistory({int limit = 30}) async {
    final database = await _database.db;

    final rows = await database.query(
      'play_history',
      orderBy: 'played_at DESC',
      limit: limit,
    );

    return rows.map(PlayHistory.fromMap).toList();
  }

  Future<void> removeTrack(int trackId) async {
    final database = await _database.db;

    await database.delete(
      'play_history',
      where: 'track_id = ?',
      whereArgs: [trackId],
    );
  }

  Future<void> removeTrackRef(Track track) async {
    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    if (stableKey.isEmpty) {
      await database.delete(
        'play_history',
        where: 'track_id = ?',
        whereArgs: [track.id],
      );

      return;
    }

    await database.delete(
      'play_history',
      where: 'stable_key = ? OR '
          '((stable_key IS NULL OR stable_key = ?) AND track_id = ?)',
      whereArgs: [
        stableKey,
        '',
        track.id,
      ],
    );
  }

  Future<void> removeTracks(Iterable<int> trackIds) async {
    final ids = trackIds.toSet().where((id) => id > 0).toList();
    if (ids.isEmpty) return;

    final database = await _database.db;

    for (final chunk in _chunks(ids, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM play_history WHERE track_id IN ($placeholders)',
        chunk,
      );
    }
  }

  Future<void> removeTrackRefs(Iterable<Track> tracks) async {
    final refs = tracks.toList(growable: false);

    final ids = refs
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet()
        .toList(growable: false);

    final stableKeys = refs
        .map((track) => _normalizeStableKey(track.stableKey))
        .where((key) => key.isNotEmpty)
        .toSet()
        .toList(growable: false);

    if (ids.isEmpty && stableKeys.isEmpty) return;

    final database = await _database.db;

    for (final chunk in _chunks(ids, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM play_history WHERE track_id IN ($placeholders) '
        "AND (stable_key IS NULL OR stable_key = '')",
        chunk,
      );
    }

    for (final chunk in _chunks(stableKeys, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM play_history WHERE stable_key IN ($placeholders)',
        chunk,
      );
    }
  }

  Future<void> backfillStableKeysForTracks(
    List<Track> tracks, {
    Map<String, Track> stableKeyAliases = const <String, Track>{},
  }) async {
    final currentTracks = tracks
        .where(
          (track) => track.id > 0 && track.stableKey.trim().isNotEmpty,
        )
        .toList(growable: false);

    if (currentTracks.isEmpty) return;

    final byId = <int, Track>{
      for (final track in currentTracks) track.id: track,
    };
    final byStableKey = _uniqueTracksByStableKey(currentTracks);
    final normalizedAliases = <String, Track>{};

    for (final entry in stableKeyAliases.entries) {
      final key = _normalizeStableKey(entry.key);
      final track = entry.value;

      if (key.isEmpty || track.id <= 0 || track.stableKey.trim().isEmpty) {
        continue;
      }

      normalizedAliases[key] = track;
    }

    final database = await _database.db;

    await database.transaction((transaction) async {
      final rows = await transaction.query(
        'play_history',
        columns: const [
          'id',
          'track_id',
          'stable_key',
        ],
      );
      final batch = transaction.batch();
      var changed = false;

      for (final row in rows) {
        final historyRowId = _readPositiveInt(row['id']);
        final rowTrackId = _readPositiveInt(row['track_id']);
        final rowStableKey = _normalizeStableKey(row['stable_key']);

        if (historyRowId <= 0) {
          continue;
        }

        Track? currentTrack;

        if (rowStableKey.isNotEmpty) {
          currentTrack =
              byStableKey[rowStableKey] ?? normalizedAliases[rowStableKey];
        } else {
          currentTrack = byId[rowTrackId];
        }

        if (currentTrack == null) {
          continue;
        }

        final desiredStableKey = _normalizeStableKey(currentTrack.stableKey);

        if (rowTrackId == currentTrack.id &&
            rowStableKey == desiredStableKey) {
          continue;
        }

        batch.update(
          'play_history',
          {
            'track_id': currentTrack.id,
            'stable_key': desiredStableKey,
          },
          where: 'id = ?',
          whereArgs: [historyRowId],
        );
        changed = true;
      }

      if (changed) {
        await batch.commit(noResult: true);
      }
    });
  }

  Future<void> clearHistory() async {
    final database = await _database.db;

    await database.delete('play_history');

    debugPrint('[HistoryDao] Play history cleared');
  }

  static Map<String, Track> _uniqueTracksByStableKey(
    Iterable<Track> tracks,
  ) {
    final result = <String, Track>{};
    final ambiguousKeys = <String>{};

    for (final track in tracks) {
      final key = _normalizeStableKey(track.stableKey);
      if (key.isEmpty) continue;

      final existing = result[key];
      if (existing != null && existing.id != track.id) {
        ambiguousKeys.add(key);
        continue;
      }

      result[key] = track;
    }

    for (final key in ambiguousKeys) {
      result.remove(key);
    }

    return result;
  }

  static String _normalizeStableKey(Object? value) {
    return value?.toString().trim().toLowerCase() ?? '';
  }

  static int _readPositiveInt(Object? value) {
    final parsed = switch (value) {
      int number => number,
      num number => number.toInt(),
      String text => int.tryParse(text.trim()) ?? 0,
      _ => 0,
    };

    return parsed > 0 ? parsed : 0;
  }

  static Iterable<List<T>> _chunks<T>(List<T> values, int size) sync* {
    for (var i = 0; i < values.length; i += size) {
      final end = i + size < values.length ? i + size : values.length;
      yield values.sublist(i, end);
    }
  }
}
