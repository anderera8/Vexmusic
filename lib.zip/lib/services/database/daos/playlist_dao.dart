// lib/services/database/daos/playlist_dao.dart
// Duplicate-safe playlist CRUD.
//
// Every playlist occurrence persists three aligned values:
// - track_ids          current app-owned track identity
// - track_stable_keys  cross-scan physical-track identity
// - track_entry_ids    immutable occurrence identity

import 'package:sqflite/sqflite.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class PlaylistDao {
  final DatabaseBase _database;

  PlaylistDao(this._database);

  static int _entryCounter = 0;

  Future<List<Playlist>> getPlaylists() async {
    final database = await _database.db;
    final rows = await database.query('playlists', orderBy: 'created_at DESC');
    return rows.map(Playlist.fromMap).toList(growable: false);
  }

  Future<int> createPlaylist(String name, {String art = '🎵'}) async {
    final database = await _database.db;
    return database.insert('playlists', {
      'name': name,
      'track_ids': '',
      'track_stable_keys': '',
      'track_entry_ids': '',
      'art': art,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<int> createPlaylistWithTracks(
    String name,
    List<int> trackIds, {
    List<String> stableKeys = const [],
    List<String> entryIds = const [],
    String art = '🎵',
  }) async {
    final database = await _database.db;
    final alignedStableKeys = _alignStableKeys(stableKeys, trackIds.length);
    final alignedEntryIds = _alignEntryIds(
      entryIds,
      length: trackIds.length,
      playlistId: 0,
      trackIds: trackIds,
      stableKeys: alignedStableKeys,
      generateFreshForMissing: true,
    );

    return database.insert('playlists', {
      'name': name,
      'track_ids': trackIds.join(','),
      'track_stable_keys': alignedStableKeys.join(','),
      'track_entry_ids': alignedEntryIds.join(','),
      'art': art,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<int> createPlaylistWithTrackRefs(
    String name,
    List<Track> tracks, {
    String art = '🎵',
  }) {
    return createPlaylistWithTracks(
      name,
      tracks.map((track) => track.id).toList(growable: false),
      stableKeys: tracks
          .map((track) => _normalizeStableKey(track.stableKey))
          .toList(growable: false),
      art: art,
    );
  }

  Future<void> deletePlaylist(int id) async {
    final database = await _database.db;
    await database.delete('playlists', where: 'id = ?', whereArgs: [id]);
  }

  Future<bool> addTrackToPlaylist(
    int playlistId,
    int trackId, {
    bool allowDuplicate = false,
  }) async {
    if (trackId <= 0) return false;

    final database = await _database.db;
    return database.transaction((transaction) async {
      final row = await _readPlaylistRow(transaction, playlistId);
      if (row == null) return false;

      final ids = _parseTrackIds(row['track_ids']);
      final stableKeys = _alignStableKeys(
        _parseStrings(row['track_stable_keys']),
        ids.length,
      );
      final entryIds = _alignEntryIds(
        _parseStrings(row['track_entry_ids']),
        length: ids.length,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
      );

      if (!allowDuplicate && ids.contains(trackId)) return false;

      ids.add(trackId);
      stableKeys.add('');
      entryIds.add(_newEntryId());

      await _writePlaylistEntries(
        transaction,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
        entryIds: entryIds,
      );
      return true;
    });
  }

  Future<bool> addTrackToPlaylistRef(
    int playlistId,
    Track track, {
    bool allowDuplicate = false,
  }) async {
    if (track.id <= 0) return false;

    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    return database.transaction((transaction) async {
      final row = await _readPlaylistRow(transaction, playlistId);
      if (row == null) return false;

      final ids = _parseTrackIds(row['track_ids']);
      final stableKeys = _alignStableKeys(
        _parseStrings(row['track_stable_keys']),
        ids.length,
      );
      final entryIds = _alignEntryIds(
        _parseStrings(row['track_entry_ids']),
        length: ids.length,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
      );

      final alreadyExistsById = ids.contains(track.id);
      final alreadyExistsByStableKey =
          stableKey.isNotEmpty && stableKeys.contains(stableKey);
      if (!allowDuplicate &&
          (alreadyExistsById || alreadyExistsByStableKey)) {
        return false;
      }

      ids.add(track.id);
      stableKeys.add(stableKey);
      entryIds.add(_newEntryId());

      await _writePlaylistEntries(
        transaction,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
        entryIds: entryIds,
      );
      return true;
    });
  }

  /// Legacy exact-position removal. New UI code should resolve by entry ID.
  Future<bool> removeTrackFromPlaylistAt(
    int playlistId,
    int playlistIndex,
  ) async {
    if (playlistIndex < 0) return false;

    final database = await _database.db;
    return database.transaction((transaction) async {
      final row = await _readPlaylistRow(transaction, playlistId);
      if (row == null) return false;

      final ids = _parseTrackIds(row['track_ids']);
      if (playlistIndex >= ids.length) return false;

      final stableKeys = _alignStableKeys(
        _parseStrings(row['track_stable_keys']),
        ids.length,
      );
      final entryIds = _alignEntryIds(
        _parseStrings(row['track_entry_ids']),
        length: ids.length,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
      );

      ids.removeAt(playlistIndex);
      stableKeys.removeAt(playlistIndex);
      entryIds.removeAt(playlistIndex);

      await _writePlaylistEntries(
        transaction,
        playlistId: playlistId,
        trackIds: ids,
        stableKeys: stableKeys,
        entryIds: entryIds,
      );
      return true;
    });
  }

  Future<void> removeTrackFromPlaylist(int playlistId, int trackId) async {
    final database = await _database.db;
    final row = await _readPlaylistRow(database, playlistId);
    if (row == null) return;

    final ids = _parseTrackIds(row['track_ids']);
    final stableKeys = _alignStableKeys(
      _parseStrings(row['track_stable_keys']),
      ids.length,
    );
    final entryIds = _alignEntryIds(
      _parseStrings(row['track_entry_ids']),
      length: ids.length,
      playlistId: playlistId,
      trackIds: ids,
      stableKeys: stableKeys,
    );

    final keptIds = <int>[];
    final keptStableKeys = <String>[];
    final keptEntryIds = <String>[];
    for (var index = 0; index < ids.length; index++) {
      if (ids[index] == trackId) continue;
      keptIds.add(ids[index]);
      keptStableKeys.add(stableKeys[index]);
      keptEntryIds.add(entryIds[index]);
    }

    await _writePlaylistEntries(
      database,
      playlistId: playlistId,
      trackIds: keptIds,
      stableKeys: keptStableKeys,
      entryIds: keptEntryIds,
    );
  }

  Future<void> removeTrackFromPlaylistRef(int playlistId, Track track) async {
    final database = await _database.db;
    final row = await _readPlaylistRow(database, playlistId);
    if (row == null) return;

    final ids = _parseTrackIds(row['track_ids']);
    final stableKeys = _alignStableKeys(
      _parseStrings(row['track_stable_keys']),
      ids.length,
    );
    final entryIds = _alignEntryIds(
      _parseStrings(row['track_entry_ids']),
      length: ids.length,
      playlistId: playlistId,
      trackIds: ids,
      stableKeys: stableKeys,
    );
    final targetStableKey = _normalizeStableKey(track.stableKey);

    final keptIds = <int>[];
    final keptStableKeys = <String>[];
    final keptEntryIds = <String>[];
    for (var index = 0; index < ids.length; index++) {
      final sameId = ids[index] == track.id;
      final sameStableKey = targetStableKey.isNotEmpty &&
          _normalizeStableKey(stableKeys[index]) == targetStableKey;
      if (sameId || sameStableKey) continue;

      keptIds.add(ids[index]);
      keptStableKeys.add(stableKeys[index]);
      keptEntryIds.add(entryIds[index]);
    }

    await _writePlaylistEntries(
      database,
      playlistId: playlistId,
      trackIds: keptIds,
      stableKeys: keptStableKeys,
      entryIds: keptEntryIds,
    );
  }

  Future<void> removeTracksFromAllPlaylists(
    Iterable<int> trackIds,
  ) async {
    final deletedIds = trackIds.where((id) => id > 0).toSet();
    if (deletedIds.isEmpty) return;

    final database = await _database.db;
    final rows = await database.query(
      'playlists',
      columns: const [
        'id',
        'track_ids',
        'track_stable_keys',
        'track_entry_ids',
      ],
    );

    for (final row in rows) {
      final playlistId = row['id'] as int;
      await _filterPlaylistEntries(
        database,
        row: row,
        playlistId: playlistId,
        shouldRemove: (id, stableKey) => deletedIds.contains(id),
      );
    }
  }

  Future<void> removeTrackRefsFromAllPlaylists(
    Iterable<Track> tracks,
  ) async {
    final refs = tracks.toList(growable: false);
    final deletedIds = refs
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet();
    final deletedStableKeys = refs
        .map((track) => _normalizeStableKey(track.stableKey))
        .where((key) => key.isNotEmpty)
        .toSet();
    if (deletedIds.isEmpty && deletedStableKeys.isEmpty) return;

    final database = await _database.db;
    final rows = await database.query(
      'playlists',
      columns: const [
        'id',
        'track_ids',
        'track_stable_keys',
        'track_entry_ids',
      ],
    );

    for (final row in rows) {
      final playlistId = row['id'] as int;
      await _filterPlaylistEntries(
        database,
        row: row,
        playlistId: playlistId,
        shouldRemove: (id, stableKey) =>
            deletedIds.contains(id) ||
            (stableKey.isNotEmpty && deletedStableKeys.contains(stableKey)),
      );
    }
  }

  /// Backfills stable keys for old playlist rows and repairs IDs when the same
  /// stableKey now points to a refreshed MediaStore/app ID.
  Future<void> backfillStableKeysForTracks(
    List<Track> tracks, {
    Map<String, Track> stableKeyAliases = const <String, Track>{},
  }) async {
    final currentTracks = tracks
        .where((track) => track.id > 0)
        .toList(growable: false);
    if (currentTracks.isEmpty) return;

    final byId = <int, Track>{
      for (final track in currentTracks) track.id: track,
    };
    final byStableKey = _uniqueTracksByStableKey(currentTracks);
    final normalizedAliases = <String, Track>{};
    for (final entry in stableKeyAliases.entries) {
      final key = _normalizeStableKey(entry.key);
      if (key.isNotEmpty && entry.value.id > 0) {
        normalizedAliases[key] = entry.value;
      }
    }

    final database = await _database.db;
    await database.transaction((transaction) async {
      final rows = await transaction.query(
        'playlists',
        columns: const [
          'id',
          'track_ids',
          'track_stable_keys',
          'track_entry_ids',
        ],
      );

      for (final row in rows) {
        final playlistId = row['id'] as int;
        final ids = _parseTrackIds(row['track_ids']);
        final stableKeys = _alignStableKeys(
          _parseStrings(row['track_stable_keys']),
          ids.length,
        );
        final rawEntryIds = _parseStrings(row['track_entry_ids']);
        final entryIds = _alignEntryIds(
          rawEntryIds,
          length: ids.length,
          playlistId: playlistId,
          trackIds: ids,
          stableKeys: stableKeys,
        );
        if (ids.isEmpty) continue;

        var changed = rawEntryIds.length != entryIds.length;
        if (!changed) {
          for (var index = 0; index < entryIds.length; index++) {
            if (rawEntryIds[index] != entryIds[index]) {
              changed = true;
              break;
            }
          }
        }

        for (var index = 0; index < ids.length; index++) {
          final originalStableKey = _normalizeStableKey(stableKeys[index]);
          Track? currentTrack;
          if (originalStableKey.isNotEmpty) {
            currentTrack = byStableKey[originalStableKey] ??
                normalizedAliases[originalStableKey];
          } else {
            currentTrack = byId[ids[index]];
          }
          if (currentTrack == null) continue;

          final desiredStableKey = _normalizeStableKey(currentTrack.stableKey);
          if (ids[index] != currentTrack.id) {
            ids[index] = currentTrack.id;
            changed = true;
          }
          if (stableKeys[index] != desiredStableKey) {
            stableKeys[index] = desiredStableKey;
            changed = true;
          }
        }

        if (!changed) continue;
        await _writePlaylistEntries(
          transaction,
          playlistId: playlistId,
          trackIds: ids,
          stableKeys: stableKeys,
          entryIds: entryIds,
        );
      }
    });
  }

  Future<void> renamePlaylist(int id, String newName) async {
    final database = await _database.db;

    await database.update(
      'playlists',
      {'name': newName},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<Map<String, Object?>?> _readPlaylistRow(
    DatabaseExecutor executor,
    int playlistId,
  ) async {
    final rows = await executor.query(
      'playlists',
      columns: const [
        'track_ids',
        'track_stable_keys',
        'track_entry_ids',
      ],
      where: 'id = ?',
      whereArgs: [playlistId],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> _writePlaylistEntries(
    DatabaseExecutor executor, {
    required int playlistId,
    required List<int> trackIds,
    required List<String> stableKeys,
    required List<String> entryIds,
  }) async {
    assert(trackIds.length == stableKeys.length);
    assert(trackIds.length == entryIds.length);

    await executor.update(
      'playlists',
      {
        'track_ids': trackIds.join(','),
        'track_stable_keys': stableKeys.join(','),
        'track_entry_ids': entryIds.join(','),
      },
      where: 'id = ?',
      whereArgs: [playlistId],
    );
  }

  Future<void> _filterPlaylistEntries(
    DatabaseExecutor executor, {
    required Map<String, Object?> row,
    required int playlistId,
    required bool Function(int id, String stableKey) shouldRemove,
  }) async {
    final ids = _parseTrackIds(row['track_ids']);
    final stableKeys = _alignStableKeys(
      _parseStrings(row['track_stable_keys']),
      ids.length,
    );
    final entryIds = _alignEntryIds(
      _parseStrings(row['track_entry_ids']),
      length: ids.length,
      playlistId: playlistId,
      trackIds: ids,
      stableKeys: stableKeys,
    );

    final keptIds = <int>[];
    final keptStableKeys = <String>[];
    final keptEntryIds = <String>[];
    for (var index = 0; index < ids.length; index++) {
      final stableKey = _normalizeStableKey(stableKeys[index]);
      if (shouldRemove(ids[index], stableKey)) continue;
      keptIds.add(ids[index]);
      keptStableKeys.add(stableKeys[index]);
      keptEntryIds.add(entryIds[index]);
    }

    if (keptIds.length == ids.length) return;
    await _writePlaylistEntries(
      executor,
      playlistId: playlistId,
      trackIds: keptIds,
      stableKeys: keptStableKeys,
      entryIds: keptEntryIds,
    );
  }

  static List<int> _parseTrackIds(Object? value) {
    final text = value?.toString().trim() ?? '';
    if (text.isEmpty) return <int>[];
    return text
        .split(',')
        .map((item) => int.tryParse(item.trim()))
        .whereType<int>()
        .where((id) => id > 0)
        .toList();
  }

  static List<String> _parseStrings(Object? value) {
    final text = value?.toString() ?? '';
    if (text.trim().isEmpty) return <String>[];
    return text.split(',').map((item) => item.trim()).toList();
  }

  static List<String> _alignStableKeys(List<String> keys, int length) {
    final result = List<String>.from(keys.take(length));
    while (result.length < length) {
      result.add('');
    }
    return result;
  }

  static List<String> _alignEntryIds(
    List<String> entryIds, {
    required int length,
    required int playlistId,
    required List<int> trackIds,
    required List<String> stableKeys,
    bool generateFreshForMissing = false,
  }) {
    final result = <String>[];
    final used = <String>{};

    for (var index = 0; index < length; index++) {
      final persisted = index < entryIds.length ? entryIds[index].trim() : '';
      if (persisted.isNotEmpty && used.add(persisted)) {
        result.add(persisted);
        continue;
      }

      var generated = generateFreshForMissing
          ? _newEntryId()
          : _legacyEntryId(
              playlistId: playlistId,
              index: index,
              trackId: index < trackIds.length ? trackIds[index] : 0,
              stableKey:
                  index < stableKeys.length ? stableKeys[index] : '',
            );
      while (!used.add(generated)) {
        generated = _newEntryId();
      }
      result.add(generated);
    }
    return result;
  }

  static String _newEntryId() {
    _entryCounter = (_entryCounter + 1) & 0x7fffffff;
    final micros = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    return 'pe-$micros-${_entryCounter.toRadixString(36)}';
  }

  static String _legacyEntryId({
    required int playlistId,
    required int index,
    required int trackId,
    required String stableKey,
  }) {
    final seed = '$playlistId|$index|$trackId|${_normalizeStableKey(stableKey)}';
    var hash = 0x811c9dc5;
    for (final codeUnit in seed.codeUnits) {
      hash ^= codeUnit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return 'legacy-$playlistId-$index-${hash.toRadixString(36)}';
  }

  static Map<String, Track> _uniqueTracksByStableKey(
    Iterable<Track> tracks,
  ) {
    final result = <String, Track>{};
    final ambiguousKeys = <String>{};
    for (final track in tracks) {
      final key = _normalizeStableKey(track.stableKey);
      if (key.isEmpty) {
        continue;
      }
      final existing = result[key];
      if (existing != null && existing.id != track.id) {
        ambiguousKeys.add(key);
      } else {
        result[key] = track;
      }
    }
    for (final key in ambiguousKeys) {
      result.remove(key);
    }
    return result;
  }

  static String _normalizeStableKey(Object? value) =>
      value?.toString().trim().toLowerCase() ?? '';
}
