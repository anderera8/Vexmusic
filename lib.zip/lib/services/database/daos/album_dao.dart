// lib/services/database/daos/album_dao.dart
// ─────────────────────────────────────────────────────────────────────────────
// album CRUD operations — extracted from DatabaseService.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:sqflite/sqflite.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class AlbumDao {
  final DatabaseBase _database;

  AlbumDao(this._database);

  Future<void> savealbums(List<Album> albums) async {
    final database = await _database.db;

    // MediaStore can occasionally return duplicate album IDs, especially on
    // Samsung/OEM libraries. Deduplicate before writing so release sync never
    // fails with: UNIQUE constraint failed: albums.id
    final deduped = <int, Album>{};

    for (final album in albums) {
      final existing = deduped[album.id];

      if (existing == null) {
        deduped[album.id] = album;
      } else {
        deduped[album.id] = Album(
          id: album.id,
          name: album.name.isNotEmpty ? album.name : existing.name,
          artist: album.artist.isNotEmpty ? album.artist : existing.artist,
          trackCount: album.trackCount > existing.trackCount
              ? album.trackCount
              : existing.trackCount,
          artPath: album.artPath ?? existing.artPath,
        );
      }
    }

    await database.transaction((txn) async {
      final batch = txn.batch();

      batch.delete('albums');

      for (final album in deduped.values) {
        batch.insert(
          'albums',
          {
            'id': album.id,
            'name': album.name,
            'artist': album.artist,
            'track_count': album.trackCount,
            'art_path': album.artPath,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      await batch.commit(noResult: true);
    });
  }

  Future<List<Album>> getAllalbums() async {
    final database = await _database.db;
    final rows = await database.query('albums', orderBy: 'name ASC');

    return rows
        .map(
          (row) => Album(
            id: row['id'] as int,
            name: row['name'] as String,
            artist: row['artist'] as String,
            trackCount: row['track_count'] as int,
            artPath: row['art_path'] as String?,
          ),
        )
        .toList();
  }
}
