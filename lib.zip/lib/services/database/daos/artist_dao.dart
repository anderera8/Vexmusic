// lib/services/database/daos/artist_dao.dart
// ─────────────────────────────────────────────────────────────────────────────
// Artist CRUD operations — extracted from DatabaseService.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:sqflite/sqflite.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class ArtistDao {
  final DatabaseBase _database;

  ArtistDao(this._database);

  Future<void> saveArtists(List<Artist> artists) async {
    final database = await _database.db;

    // MediaStore can occasionally return duplicate artist IDs on OEM devices.
    // Deduplicate before writing so release sync never fails with:
    // UNIQUE constraint failed: artists.id
    final deduped = <int, Artist>{};

    for (final artist in artists) {
      final existing = deduped[artist.id];

      if (existing == null) {
        deduped[artist.id] = artist;
      } else {
        deduped[artist.id] = Artist(
          id: artist.id,
          name: artist.name.isNotEmpty ? artist.name : existing.name,
          trackCount: artist.trackCount > existing.trackCount
              ? artist.trackCount
              : existing.trackCount,
          albumCount: artist.albumCount > existing.albumCount
              ? artist.albumCount
              : existing.albumCount,
        );
      }
    }

    await database.transaction((txn) async {
      final batch = txn.batch();

      batch.delete('artists');

      for (final artist in deduped.values) {
        batch.insert(
          'artists',
          {
            'id': artist.id,
            'name': artist.name,
            'track_count': artist.trackCount,
            'album_count': artist.albumCount,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      await batch.commit(noResult: true);
    });
  }

  Future<List<Artist>> getAllArtists() async {
    final database = await _database.db;
    final rows = await database.query('artists', orderBy: 'name ASC');

    return rows
        .map(
          (row) => Artist(
            id: row['id'] as int,
            name: row['name'] as String,
            trackCount: row['track_count'] as int,
            albumCount: row['album_count'] as int,
          ),
        )
        .toList();
  }
}
