// lib/services/database/daos/media_library_dao.dart
// ─────────────────────────────────────────────────────────────────────────────
// Media library DAO — reads/writes the media_library table.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

import '../../../models/media_models.dart';
import '../database_base.dart';

class MediaLibraryDao {
  final DatabaseBase _database;

  MediaLibraryDao(this._database);

  // ── Read ────────────────────────────────────────────────────────────

  /// Returns all available media entries of any kind, sorted by title.
  Future<List<MediaEntry>> getAll() async {
    final db = await _database.db;

    final rows = await db.query(
      'media_library',
      where: 'is_available = 1',
      orderBy: 'LOWER(title)',
    );

    return rows.map(MediaEntry.fromMap).toList();
  }

  /// Returns media entries of a specific [kind].
  Future<List<MediaEntry>> getByKind(MediaKind kind) async {
    final db = await _database.db;

    final rows = await db.query(
      'media_library',
      where: 'kind = ? AND is_available = 1',
      whereArgs: [kind.name],
      orderBy: 'LOWER(title)',
    );

    return rows.map(MediaEntry.fromMap).toList();
  }

  /// Returns audio entries only.
  Future<List<MediaEntry>> getAudio() => getByKind(MediaKind.audio);

  /// Returns all entries including unavailable ones.
  Future<List<MediaEntry>> getAllIncludingUnavailable() async {
    final db = await _database.db;

    final rows = await db.query(
      'media_library',
      orderBy: 'LOWER(title)',
    );

    return rows.map(MediaEntry.fromMap).toList();
  }

  /// Returns whether the media_library table has any rows.
  Future<bool> hasEntries() async {
    final db = await _database.db;

    final count = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM media_library'),
    );

    return (count ?? 0) > 0;
  }

  // ── Write ───────────────────────────────────────────────────────────

  /// Inserts or replaces a batch of media entries.
  ///
  /// Release-safe:
  /// - ignores empty input
  /// - uses ConflictAlgorithm.replace
  /// - writes in one transaction
  Future<void> upsertAll(List<MediaEntry> entries) async {
    if (entries.isEmpty) return;

    final db = await _database.db;

    await db.transaction((txn) async {
      final batch = txn.batch();

      for (final entry in entries) {
        batch.insert(
          'media_library',
          entry.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      await batch.commit(noResult: true);
    });
  }

  /// Inserts or replaces a single media entry.
  Future<void> upsert(MediaEntry entry) => upsertAll([entry]);

  Future<void> deleteById(String id, MediaKind kind) async {
    final db = await _database.db;

    await db.delete(
      'media_library',
      where: 'id = ? AND kind = ?',
      whereArgs: [id, kind.name],
    );
  }

  Future<void> deleteAudioIds(Iterable<int> ids) {
    return deleteAudioRefs(appIds: ids);
  }

  Future<void> deleteAudioRefs({
    Iterable<int> appIds = const <int>[],
    Iterable<String> stableKeys = const <String>[],
  }) async {
    final values = <String>{
      ...appIds.where((id) => id > 0).map((id) => id.toString()),
      ...stableKeys.map((key) => key.trim()).where((key) => key.isNotEmpty),
    }.toList(growable: false);

    if (values.isEmpty) return;

    final db = await _database.db;

    for (final chunk in _chunks(values, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await db.rawDelete(
        'DELETE FROM media_library '
        'WHERE kind = ? AND id IN ($placeholders)',
        [MediaKind.audio.name, ...chunk],
      );
    }
  }

  // ── Availability ────────────────────────────────────────────────────

  Future<void> deleteAllByKind(MediaKind kind) async {
    final db = await _database.db;

    await db.delete(
      'media_library',
      where: 'kind = ?',
      whereArgs: [kind.name],
    );
  }

  /// Marks entries with the given [ids] as unavailable.
  ///
  /// This preserves user metadata and does not delete rows.
  Future<void> markUnavailable(List<String> ids) async {
    if (ids.isEmpty) return;

    final db = await _database.db;

    for (final batchIds in _chunks(ids, 500)) {
      final placeholders = batchIds.map((_) => '?').join(',');

      await db.rawUpdate(
        'UPDATE media_library '
        'SET is_available = 0 '
        'WHERE id IN ($placeholders)',
        batchIds,
      );
    }
  }

  /// Marks entries with the given [ids] as available after a successful scan.
  Future<void> markAvailable(
    List<String> ids, {
    String scanTimestamp = '',
  }) async {
    if (ids.isEmpty) return;

    final ts = scanTimestamp.isNotEmpty
        ? scanTimestamp
        : DateTime.now().toUtc().toIso8601String();

    final db = await _database.db;

    for (final batchIds in _chunks(ids, 500)) {
      final placeholders = batchIds.map((_) => '?').join(',');

      await db.rawUpdate(
        'UPDATE media_library '
        'SET is_available = 1, last_seen_scan = ? '
        'WHERE id IN ($placeholders)',
        [ts, ...batchIds],
      );
    }
  }

  /// Removes entries whose IDs are NOT in [activeIds] and whose
  /// `is_available` is already 1.
  ///
  /// Never purges when [activeIds] is empty.
  Future<int> purgeMissing(List<String> activeIds) async {
    if (activeIds.isEmpty) {
      debugPrint('[MediaLibraryDao] Refusing to purge with empty activeIds');
      return 0;
    }

    final db = await _database.db;

    return db.transaction((txn) async {
      await txn.execute(
        'CREATE TEMP TABLE IF NOT EXISTS active_media_ids ('
        'id TEXT PRIMARY KEY'
        ')',
      );
      await txn.delete('active_media_ids');

      final batch = txn.batch();
      for (final id in activeIds.toSet()) {
        batch.insert(
          'active_media_ids',
          {'id': id},
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );
      }
      await batch.commit(noResult: true);

      final deleted = await txn.rawDelete(
        'DELETE FROM media_library '
        'WHERE is_available = 1 '
        'AND id NOT IN (SELECT id FROM active_media_ids)',
      );

      await txn.delete('active_media_ids');
      return deleted;
    });
  }

  // ── Migration ───────────────────────────────────────────────────────

  /// One-shot migration from legacy `tracks` table into `media_library`.
  ///
  /// Idempotent:
  /// - INSERT OR IGNORE prevents duplicates
  /// - errors are logged and kept non-fatal
  Future<void> migrateFromLegacyTables() async {
    final db = await _database.db;

    await db.transaction((txn) async {
      try {
        await txn.rawInsert('''
          INSERT OR IGNORE INTO media_library (
            id,
            kind,
            title,
            artist,
            album,
            duration,
            size,
            source_type,
            source_value,
            artwork_path,
            volume_name,
            relative_path,
            folder,
            date_added,
            is_available,
            last_seen_scan
          )
          SELECT
            CAST(id AS TEXT),
            'audio',
            title,
            artist,
            COALESCE(album, ''),
            duration,
            COALESCE(file_size, 0),
            'filePath',
            COALESCE(file_path, ''),
            COALESCE(art_path, ''),
            COALESCE(volume_name, ''),
            '',
            '',
            COALESCE(date_added, 0),
            1,
            ''
          FROM tracks
          WHERE file_path IS NOT NULL
            AND file_path != ''
        ''');
      } catch (e, stackTrace) {
        debugPrint('[MediaLibraryDao] Audio migration skipped: $e');
        debugPrintStack(stackTrace: stackTrace);
      }
    });
  }

  static Iterable<List<T>> _chunks<T>(List<T> values, int size) sync* {
    for (var i = 0; i < values.length; i += size) {
      final end = i + size < values.length ? i + size : values.length;
      yield values.sublist(i, end);
    }
  }
}
