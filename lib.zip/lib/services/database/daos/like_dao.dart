// lib/services/database/daos/like_dao.dart
// Favorites are dual-keyed by current track_id and stable_key.

import 'package:sqflite/sqflite.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class LikeDao {
  final DatabaseBase _database;

  LikeDao(this._database);

  Future<Set<int>> getLikedTrackIds() async {
    final database = await _database.db;
    final rows = await database.query('liked_tracks');
    return rows.map((r) => r['track_id'] as int).toSet();
  }

  Future<({Set<int> trackIds, Set<String> stableKeys})>
      getLikedTrackRefs() async {
    final database = await _database.db;

    final rows = await database.query(
      'liked_tracks',
      columns: const [
        'track_id',
        'stable_key',
      ],
    );

    final trackIds = <int>{};
    final stableKeys = <String>{};

    for (final row in rows) {
      final trackId = row['track_id'];

      if (trackId is int && trackId > 0) {
        trackIds.add(trackId);
      }

      final rawStableKey = row['stable_key'];

      if (rawStableKey is String) {
        final stableKey = _normalizeStableKey(rawStableKey);

        if (stableKey.isNotEmpty) {
          stableKeys.add(stableKey);
        }
      }
    }

    return (
      trackIds: trackIds,
      stableKeys: stableKeys,
    );
  }

  /// Returns Favorite references without conflating an app ID match with a
  /// stable-key match. IDs from rows that already carry a stable key are not
  /// valid legacy fallbacks for another physical track.
  Future<({
    Set<int> trackIds,
    Set<int> legacyTrackIds,
    Set<String> stableKeys,
  })> getLikedTrackIdentityRefs() async {
    final database = await _database.db;
    final rows = await database.query(
      'liked_tracks',
      columns: const ['track_id', 'stable_key'],
    );

    final trackIds = <int>{};
    final legacyTrackIds = <int>{};
    final stableKeys = <String>{};

    for (final row in rows) {
      final trackId = _readPositiveInt(row['track_id']);
      final stableKey = _normalizeStableKey(row['stable_key']);

      if (trackId > 0) {
        trackIds.add(trackId);
        if (stableKey.isEmpty) {
          legacyTrackIds.add(trackId);
        }
      }

      if (stableKey.isNotEmpty) {
        stableKeys.add(stableKey);
      }
    }

    return (
      trackIds: trackIds,
      legacyTrackIds: legacyTrackIds,
      stableKeys: stableKeys,
    );
  }

  /// Reads the persisted Favorite state for one physical track. Stable-key
  /// rows take precedence; app ID is used only for unresolved legacy rows.
  Future<bool> isTrackLikedRef(Track track) async {
    if (track.id <= 0) return false;

    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);
    final rows = stableKey.isEmpty
        ? await database.query(
            'liked_tracks',
            columns: const ['track_id'],
            where: 'track_id = ?',
            whereArgs: [track.id],
            limit: 1,
          )
        : await database.query(
            'liked_tracks',
            columns: const ['track_id'],
            where: 'stable_key = ? OR '
                '((stable_key IS NULL OR stable_key = ?) AND track_id = ?)',
            whereArgs: [stableKey, '', track.id],
            limit: 1,
          );

    return rows.isNotEmpty;
  }

  Future<void> likeTrack(int trackId) async {
    final database = await _database.db;

    await database.insert(
      'liked_tracks',
      {
        'track_id': trackId,
        'stable_key': '',
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<void> likeTrackRef(Track track) async {
    if (track.id <= 0) {
      throw ArgumentError.value(
        track.id,
        'track.id',
        'A Favorite requires a positive app-owned track ID.',
      );
    }

    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    await database.transaction((txn) async {
      // Remove an old Favorite row for the same physical track after an
      // app-ID remap. Never match empty stable keys because many legacy rows
      // can contain an empty string.
      if (stableKey.isNotEmpty) {
        await txn.delete(
          'liked_tracks',
          where: 'stable_key = ? AND track_id != ?',
          whereArgs: [
            stableKey,
            track.id,
          ],
        );
      }

      await txn.insert(
        'liked_tracks',
        {
          'track_id': track.id,
          'stable_key': stableKey,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  Future<void> unlikeTrack(int trackId) async {
    final database = await _database.db;

    await database.delete(
      'liked_tracks',
      where: 'track_id = ?',
      whereArgs: [trackId],
    );
  }

  Future<void> unlikeTrackRef(Track track) async {
    final database = await _database.db;
    final stableKey = _normalizeStableKey(track.stableKey);

    if (stableKey.isEmpty) {
      await database.delete(
        'liked_tracks',
        where: 'track_id = ?',
        whereArgs: [track.id],
      );

      return;
    }

    await database.delete(
      'liked_tracks',
      where: 'stable_key = ? OR '
          '((stable_key IS NULL OR stable_key = ?) AND track_id = ?)',
      whereArgs: [
        stableKey,
        '',
        track.id,
      ],
    );
  }

  Future<void> unlikeTracks(Iterable<int> trackIds) async {
    final ids = trackIds.toSet().where((id) => id > 0).toList();
    if (ids.isEmpty) return;

    final database = await _database.db;

    for (final chunk in _chunks(ids, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM liked_tracks WHERE track_id IN ($placeholders)',
        chunk,
      );
    }
  }

  Future<void> unlikeTrackRefs(Iterable<Track> tracks) async {
    final refs = tracks.toList(growable: false);

    final ids = refs
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet()
        .toList(growable: false);

    final stableKeys = refs
        .map((track) => _normalizeStableKey(track.stableKey))
        .where((key) => key.isNotEmpty)
        .toSet()
        .toList(growable: false);

    if (ids.isEmpty && stableKeys.isEmpty) return;

    final database = await _database.db;

    for (final chunk in _chunks(ids, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM liked_tracks WHERE track_id IN ($placeholders) '
        "AND (stable_key IS NULL OR stable_key = '')",
        chunk,
      );
    }

    for (final chunk in _chunks(stableKeys, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await database.rawDelete(
        'DELETE FROM liked_tracks WHERE stable_key IN ($placeholders)',
        chunk,
      );
    }
  }

  Future<void> backfillStableKeysForTracks(
    List<Track> tracks, {
    Map<String, Track> stableKeyAliases = const <String, Track>{},
  }) async {
    final currentTracks = tracks
        .where(
          (track) => track.id > 0 && track.stableKey.trim().isNotEmpty,
        )
        .toList(growable: false);

    if (currentTracks.isEmpty) return;

    final byId = <int, Track>{
      for (final track in currentTracks) track.id: track,
    };
    final byStableKey = _uniqueTracksByStableKey(currentTracks);
    final normalizedAliases = <String, Track>{};

    for (final entry in stableKeyAliases.entries) {
      final key = _normalizeStableKey(entry.key);
      final track = entry.value;

      if (key.isEmpty || track.id <= 0 || track.stableKey.trim().isEmpty) {
        continue;
      }

      normalizedAliases[key] = track;
    }

    final database = await _database.db;

    await database.transaction((transaction) async {
      final rows = await transaction.query(
        'liked_tracks',
        columns: const [
          'track_id',
          'stable_key',
        ],
      );

      final originalIdsToDelete = <int>{};
      final desiredRows = <int, String>{};

      for (final row in rows) {
        final rowTrackId = _readPositiveInt(row['track_id']);
        final rowStableKey = _normalizeStableKey(row['stable_key']);

        Track? currentTrack;

        if (rowStableKey.isNotEmpty) {
          currentTrack =
              byStableKey[rowStableKey] ?? normalizedAliases[rowStableKey];
        } else {
          currentTrack = byId[rowTrackId];
        }

        if (currentTrack == null) {
          continue;
        }

        if (rowTrackId > 0) {
          originalIdsToDelete.add(rowTrackId);
        }

        desiredRows[currentTrack.id] = _normalizeStableKey(
          currentTrack.stableKey,
        );
      }

      for (final trackId in originalIdsToDelete) {
        await transaction.delete(
          'liked_tracks',
          where: 'track_id = ?',
          whereArgs: [trackId],
        );
      }

      for (final entry in desiredRows.entries) {
        await transaction.insert(
          'liked_tracks',
          {
            'track_id': entry.key,
            'stable_key': entry.value,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  static Map<String, Track> _uniqueTracksByStableKey(
    Iterable<Track> tracks,
  ) {
    final result = <String, Track>{};
    final ambiguousKeys = <String>{};

    for (final track in tracks) {
      final stableKey = _normalizeStableKey(track.stableKey);
      if (stableKey.isEmpty) continue;

      final existing = result[stableKey];
      if (existing != null && existing.id != track.id) {
        ambiguousKeys.add(stableKey);
        continue;
      }

      result[stableKey] = track;
    }

    for (final key in ambiguousKeys) {
      result.remove(key);
    }

    return result;
  }

  static String _normalizeStableKey(Object? value) {
    return value?.toString().trim().toLowerCase() ?? '';
  }

  static int _readPositiveInt(Object? value) {
    final parsed = switch (value) {
      int number => number,
      num number => number.toInt(),
      String text => int.tryParse(text.trim()) ?? 0,
      _ => 0,
    };

    return parsed > 0 ? parsed : 0;
  }

  static Iterable<List<T>> _chunks<T>(List<T> values, int size) sync* {
    for (var i = 0; i < values.length; i += size) {
      final end = i + size < values.length ? i + size : values.length;
      yield values.sublist(i, end);
    }
  }
}
