// lib/services/database/daos/track_dao.dart
// ─────────────────────────────────────────────────────────────────────────────
// Track persistence and monotonic app-owned identity allocation.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:sqflite/sqflite.dart';

import '../../../models/music_models.dart';
import '../database_base.dart';

class TrackDao {
  TrackDao(this._database);

  final DatabaseBase _database;

  Future<void> saveTracks(
    List<Track> tracks,
  ) async {
    final database = await _database.db;
    await saveTracksWithExecutor(database, tracks);
  }

  /// Persists tracks through an existing database transaction/executor.
  ///
  /// Scan reconciliation uses this entry point so track rows and every
  /// relationship migration commit or roll back as one unit.
  Future<void> saveTracksWithExecutor(
    DatabaseExecutor executor,
    List<Track> tracks,
  ) async {
    if (tracks.isEmpty) return;

    for (final track in tracks) {
      _validatePersistableTrack(track);
    }

    final batch = executor.batch();

    for (final track in tracks) {
      batch.insert(
        'tracks',
        _trackValues(track),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }

    await batch.commit(noResult: true);
  }

  Future<List<Track>> getAllTracks() async {
    final database = await _database.db;

    final rows = await database.query(
      'tracks',
      orderBy: 'title COLLATE NOCASE ASC',
    );

    return List<Track>.unmodifiable(
      rows.map(Track.fromDatabaseMap),
    );
  }

  /// Reserves [count] monotonically increasing app-owned track IDs.
  ///
  /// IDs are never derived from Android MediaStore IDs and are never recycled.
  /// Relationship tables are included when calculating the lower bound so an
  /// interrupted cleanup cannot cause a historical ID to be assigned to a
  /// different physical track.
  Future<List<int>> reserveTrackIds(
    int count,
  ) async {
    if (count <= 0) {
      return const <int>[];
    }

    final database = await _database.db;

    return database.transaction(
      (transaction) async {
        await transaction.insert(
          'identity_counters',
          {
            'name': 'track',
            'next_value': 1,
          },
          conflictAlgorithm:
              ConflictAlgorithm.ignore,
        );

        final counterRows =
            await transaction.query(
          'identity_counters',
          columns: const ['next_value'],
          where: 'name = ?',
          whereArgs: const ['track'],
          limit: 1,
        );

        var nextValue = counterRows.isEmpty
            ? 1
            : _positiveInt(
                counterRows.first['next_value'],
                fallback: 1,
              );

        final maximumReferencedId =
            await _maxReferencedTrackId(
          transaction,
        );

        if (nextValue <= maximumReferencedId) {
          nextValue = maximumReferencedId + 1;
        }

        final reserved = List<int>.generate(
          count,
          (index) => nextValue + index,
          growable: false,
        );

        final updatedRows =
            await transaction.update(
          'identity_counters',
          {
            'next_value': nextValue + count,
          },
          where: 'name = ?',
          whereArgs: const ['track'],
        );

        if (updatedRows != 1) {
          throw StateError(
            'Could not advance the track identity counter.',
          );
        }

        return reserved;
      },
    );
  }

  Future<int> _maxReferencedTrackId(
    DatabaseExecutor executor,
  ) async {
    var maximum = 0;

    Future<void> includeMaximum(
      String sql,
    ) async {
      final rows = await executor.rawQuery(sql);

      if (rows.isEmpty) return;

      final value = _nonNegativeInt(
        rows.first['max_id'],
      );

      if (value > maximum) {
        maximum = value;
      }
    }

    await includeMaximum(
      'SELECT MAX(id) AS max_id FROM tracks',
    );

    await includeMaximum(
      'SELECT MAX(track_id) AS max_id '
      'FROM liked_tracks',
    );

    await includeMaximum(
      'SELECT MAX(track_id) AS max_id '
      'FROM play_history',
    );

    final playlistRows = await executor.query(
      'playlists',
      columns: const ['track_ids'],
    );

    for (final row in playlistRows) {
      final serializedIds =
          row['track_ids']?.toString() ?? '';

      for (final component
          in serializedIds.split(',')) {
        final value = int.tryParse(
          component.trim(),
        );

        if (value != null && value > maximum) {
          maximum = value;
        }
      }
    }

    return maximum;
  }

  Future<bool> hasTracks() async {
    final database = await _database.db;

    final result = await database.rawQuery(
      'SELECT COUNT(*) AS count FROM tracks',
    );

    if (result.isEmpty) return false;

    return _nonNegativeInt(
          result.first['count'],
        ) >
        0;
  }

  /// Removes tracks by immutable app-owned database ID.
  Future<void> removeTracksByIds(
    List<int> ids,
  ) async {
    final database = await _database.db;
    await removeTracksByIdsWithExecutor(database, ids);
  }

  Future<void> removeTracksByIdsWithExecutor(
    DatabaseExecutor executor,
    Iterable<int> ids,
  ) async {
    final safeIds = ids
        .where((id) => id > 0)
        .toSet()
        .toList(growable: false);

    if (safeIds.isEmpty) return;

    for (final chunk in _chunks(safeIds, 500)) {
      final placeholders = chunk.map((_) => '?').join(',');

      await executor.rawDelete(
        'DELETE FROM tracks WHERE id IN ($placeholders)',
        chunk,
      );
    }
  }

  Future<void> updateTrack(
    Track track,
  ) async {
    _validatePersistableTrack(track);

    final database = await _database.db;

    final values = _trackValues(track)
      ..remove('id');

    final updatedRows = await database.update(
      'tracks',
      values,
      where: 'id = ?',
      whereArgs: [track.id],
    );

    if (updatedRows == 0) {
      throw StateError(
        'Cannot update missing track with app ID ${track.id}.',
      );
    }
  }

  Map<String, Object?> _trackValues(
    Track track,
  ) {
    return <String, Object?>{
      'id': track.id,
      'media_store_id': track.mediaStoreId,
      'volume_name': track.normalizedVolumeName,
      'title': track.title,
      'artist': track.artist,
      'album': track.albumName ?? '',
      'album_id': track.albumId ?? 0,
      'duration': track.duration,
      'file_path': track.filePath ?? '',
      'playback_uri': track.playbackUri ?? '',
      'art_path': track.artPath,
      'liked': track.liked ? 1 : 0,
      'grad': track.grad,
      'genre': track.genre,
      'date_added': track.dateAdded,
      'file_size': track.size,
      'stable_key':
          track.stableKey.trim().toLowerCase(),
    };
  }

  void _validatePersistableTrack(
    Track track,
  ) {
    if (track.id <= 0) {
      throw StateError(
        'Cannot persist "${track.title}" without '
        'a positive app-owned track ID.',
      );
    }

    if (track.mediaStoreId <= 0) {
      throw StateError(
        'Cannot persist "${track.title}" without '
        'a positive Android MediaStore ID.',
      );
    }

    if (track.normalizedVolumeName.isEmpty) {
      throw StateError(
        'Cannot persist "${track.title}" without '
        'an Android MediaStore volume.',
      );
    }

    if (track.stableKey.trim().isEmpty) {
      throw StateError(
        'Cannot persist "${track.title}" without '
        'a stable identity key.',
      );
    }
  }

  static Iterable<List<T>> _chunks<T>(
    List<T> values,
    int size,
  ) sync* {
    for (var index = 0; index < values.length; index += size) {
      final end = index + size < values.length
          ? index + size
          : values.length;
      yield values.sublist(index, end);
    }
  }

  int _positiveInt(
    Object? value, {
    required int fallback,
  }) {
    final parsed = _nonNegativeInt(value);
    return parsed > 0 ? parsed : fallback;
  }

  int _nonNegativeInt(
    Object? value,
  ) {
    if (value is int) {
      return value < 0 ? 0 : value;
    }

    if (value is num) {
      final converted = value.toInt();
      return converted < 0 ? 0 : converted;
    }

    if (value is String) {
      final converted = int.tryParse(
            value.trim(),
          ) ??
          0;

      return converted < 0 ? 0 : converted;
    }

    return 0;
  }
}
