// lib/services/database/database_base.dart
// ─────────────────────────────────────────────────────────────────────────────
// Connection management & schema creation for the Vibes Player SQLite database.
// Extracted from DatabaseService to keep each file under 300 lines.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

const int _kDbVersion = 22;
const int _kSchemaMaintenanceVersion = 2;

class DatabaseBase {
  static Database? _db;

  @visibleForTesting
  static Database? testDatabase;

  Future<Database> get db async {
    if (_db != null) return _db!;

    if (testDatabase != null) {
      _db = testDatabase;
      return _db!;
    }

    _db = await _initDb();
    return _db!;
  }

  /// Resets the singleton state so a fresh instance is created next time.
  @visibleForTesting
  static void resetInstance() {
    _db = null;
    testDatabase = null;
  }

  Future<void> _ensureCurrentSchema(
    Database db,
  ) async {
    await _createTables(db);
    await _ensureLegacyColumns(db);
    await _runPendingMaintenance(db);
    await _createIndexes(db);
  }

  Future<void> _upgradeSchema(
    Database db, {
    required int oldVersion,
    required int newVersion,
  }) async {
    debugPrint(
      '[DatabaseBase] Upgrading from '
      'v$oldVersion to v$newVersion',
    );

    await _createTables(db);

    if (oldVersion < 12) {
      await _removeVideoData(db);
    }

    await _ensureLegacyColumns(db);
    await _runPendingMaintenance(db);
    await _createIndexes(db);
  }

  Future<Database> _initDb() async {
    final dir =
        await getApplicationDocumentsDirectory();

    final path = p.join(
      dir.path,
      'vexmusic.db',
    );

    Database? database;

    try {
      database = await openDatabase(
        path,
        version: _kDbVersion,
        onCreate: (
          db,
          version,
        ) async {
          await _ensureCurrentSchema(db);
        },
        onOpen: (db) async {
          // This also repairs databases that were previously marked version 17
          // without receiving the required identity columns.
          await _ensureCurrentSchema(db);
        },
        onUpgrade: (
          db,
          oldVersion,
          newVersion,
        ) async {
          await _upgradeSchema(
            db,
            oldVersion: oldVersion,
            newVersion: newVersion,
          );
        },
      );
    } on DatabaseException catch (error) {
      if (!isCorruptionError(error)) {
        rethrow;
      }

      final backupPath =
          await _backupDatabaseFiles(path);

      debugPrint(
        '[DatabaseBase] Corrupt database '
        'backed up to $backupPath; '
        'recreating.',
      );

      await _deleteDatabaseFiles(path);

      database = await openDatabase(
        path,
        version: _kDbVersion,
        onCreate: (
          db,
          version,
        ) async {
          await _ensureCurrentSchema(db);
        },
        onOpen: (db) async {
          await _ensureCurrentSchema(db);
        },
      );
    }

    return database;
  }

  @visibleForTesting
  static bool isCorruptionError(DatabaseException error) {
    final message = error.toString().toLowerCase();

    return message.contains('database disk image is malformed') ||
        message.contains('database is malformed') ||
        message.contains('file is not a database') ||
        message.contains('database corrupt') ||
        message.contains('database corruption');
  }

  @visibleForTesting
  Future<void> createAudioOnlySchemaForTesting(Database db) async {
    await _createTables(db);
    await _ensureLegacyColumns(db);
    await _createIndexes(db);
  }

  @visibleForTesting
  Future<void> removeVideoDataForTesting(Database db) => _removeVideoData(db);

  static Future<String> _backupDatabaseFiles(String dbPath) async {
    final timestamp =
        DateTime.now().toUtc().toIso8601String().replaceAll(':', '-');
    final backupPath = '$dbPath.corrupt-$timestamp';

    for (final suffix in ['', '-journal', '-wal', '-shm']) {
      final source = File('$dbPath$suffix');
      if (!await source.exists()) continue;
      await source.copy('$backupPath$suffix');
    }

    return backupPath;
  }

  /// Cleans up the main database file and any WAL/journal sidecars.
  static Future<void> _deleteDatabaseFiles(String dbPath) async {
    try {
      await deleteDatabase(dbPath);
    } catch (_) {}

    for (final suffix in ['-journal', '-wal', '-shm']) {
      try {
        final file = File('$dbPath$suffix');
        if (await file.exists()) await file.delete();
      } catch (_) {}
    }
  }

  Future<void> _addColumnIfMissing(
    Database db,
    String table,
    String columnName,
    String columnSql,
  ) async {
    final columns = await db.rawQuery('PRAGMA table_info($table)');
    final exists = columns.any((column) => column['name'] == columnName);

    if (!exists) {
      await db.execute('ALTER TABLE $table ADD COLUMN $columnSql');
    }
  }

  Future<void> _ensureLegacyColumns(Database db) async {
    await _addColumnIfMissing(
      db,
      'tracks',
      'media_store_id',
      'media_store_id INTEGER NOT NULL DEFAULT 0',
    );

    await _addColumnIfMissing(
      db,
      'tracks',
      'volume_name',
      "volume_name TEXT NOT NULL DEFAULT ''",
    );
    await _addColumnIfMissing(
      db,
      'tracks',
      'genre',
      "genre TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'tracks',
      'date_added',
      'date_added INTEGER NOT NULL DEFAULT 0',
    );

    await _addColumnIfMissing(
      db,
      'tracks',
      'file_size',
      'file_size INTEGER NOT NULL DEFAULT 0',
    );

    await _addColumnIfMissing(
      db,
      'tracks',
      'playback_uri',
      "playback_uri TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'tracks',
      'stable_key',
      "stable_key TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'liked_tracks',
      'stable_key',
      "stable_key TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'play_history',
      'last_position_ms',
      'last_position_ms INTEGER NOT NULL DEFAULT 0',
    );

    await _addColumnIfMissing(
      db,
      'play_history',
      'stable_key',
      "stable_key TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'playlists',
      'track_stable_keys',
      "track_stable_keys TEXT NOT NULL DEFAULT ''",
    );


    await _addColumnIfMissing(
      db,
      'playlists',
      'track_entry_ids',
      "track_entry_ids TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'media_library',
      'mime_type',
      "mime_type TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'media_library',
      'volume_name',
      "volume_name TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'media_library',
      'relative_path',
      "relative_path TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'media_library',
      'folder',
      "folder TEXT NOT NULL DEFAULT ''",
    );

    await _addColumnIfMissing(
      db,
      'media_library',
      'last_seen_scan',
      "last_seen_scan TEXT NOT NULL DEFAULT ''",
    );
  }

  Future<void> _runPendingMaintenance(Database db) async {
    final rows = await db.query(
      'app_meta',
      columns: const ['value'],
      where: 'key = ?',
      whereArgs: const ['schema_maintenance_version'],
      limit: 1,
    );

    final appliedVersion = rows.isEmpty
        ? 0
        : int.tryParse(rows.first['value']?.toString() ?? '') ?? 0;

    if (appliedVersion >= _kSchemaMaintenanceVersion) return;

    if (appliedVersion < 1) {
      await _backfillIdentityFoundation(db);
    }

    if (appliedVersion < 2) {
      await _backfillPlaylistEntryIds(db);
    }

    await db.insert(
      'app_meta',
      {
        'key': 'schema_maintenance_version',
        'value': _kSchemaMaintenanceVersion.toString(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> _backfillIdentityFoundation(Database db) async {
    final rows = await db.query(
      'tracks',
      columns: [
        'id',
        'title',
        'artist',
        'album',
        'duration',
        'file_path',
        'file_size',
        'stable_key',
      ],
    );

    final stableKeyByTrackId = <int, String>{};
    final batch = db.batch();

    for (final row in rows) {
      final trackId = _safeDbInt(row['id']);
      if (trackId == null) continue;

      var stableKey = _normalizeStableKey(
        row['stable_key']?.toString(),
      );

      if (stableKey.isEmpty) {
        stableKey = _buildFallbackStableKey(
          filePath: row['file_path']?.toString(),
          title: _safeDbStr(row['title'], 'Unknown Title'),
          artist: _safeDbStr(row['artist'], 'Unknown Artist'),
          albumName: _safeDbStr(row['album'], 'Unknown album'),
          duration: _safeDbInt(row['duration']) ?? 0,
          size: _safeDbInt(row['file_size']) ?? 0,
        );

        batch.update(
          'tracks',
          {'stable_key': stableKey},
          where: 'id = ?',
          whereArgs: [trackId],
        );
      }

      stableKeyByTrackId[trackId] = stableKey;
    }

    final likedRows = await db.query(
      'liked_tracks',
      columns: ['track_id', 'stable_key'],
      where: "stable_key = ''",
    );

    for (final row in likedRows) {
      final trackId = _safeDbInt(row['track_id']);
      final stableKey = stableKeyByTrackId[trackId];
      if (trackId == null || stableKey == null || stableKey.isEmpty) continue;

      batch.update(
        'liked_tracks',
        {'stable_key': stableKey},
        where: 'track_id = ?',
        whereArgs: [trackId],
      );
    }

    final historyRows = await db.query(
      'play_history',
      columns: ['id', 'track_id', 'stable_key'],
      where: "stable_key = ''",
    );

    for (final row in historyRows) {
      final historyId = _safeDbInt(row['id']);
      final stableKey = stableKeyByTrackId[_safeDbInt(row['track_id'])];
      if (historyId == null || stableKey == null || stableKey.isEmpty) {
        continue;
      }

      batch.update(
        'play_history',
        {'stable_key': stableKey},
        where: 'id = ?',
        whereArgs: [historyId],
      );
    }

    final playlistRows = await db.query(
      'playlists',
      columns: ['id', 'track_ids', 'track_stable_keys'],
      where: "track_stable_keys = '' AND track_ids != ''",
    );

    for (final row in playlistRows) {
      final playlistId = _safeDbInt(row['id']);
      if (playlistId == null) continue;

      final stableKeys = row['track_ids']
          .toString()
          .split(',')
          .map((id) => stableKeyByTrackId[int.tryParse(id.trim())] ?? '')
          .toList();

      batch.update(
        'playlists',
        {'track_stable_keys': stableKeys.join(',')},
        where: 'id = ?',
        whereArgs: [playlistId],
      );
    }

    await batch.commit(noResult: true);
  }

  Future<void> _backfillPlaylistEntryIds(Database db) async {
    final rows = await db.query(
      'playlists',
      columns: const [
        'id',
        'track_ids',
        'track_stable_keys',
        'track_entry_ids',
      ],
    );

    final batch = db.batch();
    var changedRows = 0;

    for (final row in rows) {
      final playlistId = _safeDbInt(row['id']);
      if (playlistId == null) continue;

      final rawTrackIds = row['track_ids']?.toString() ?? '';
      final rawStableKeys = row['track_stable_keys']?.toString() ?? '';
      final rawEntryIds = row['track_entry_ids']?.toString() ?? '';

      final trackIds = rawTrackIds.trim().isEmpty
          ? <String>[]
          : rawTrackIds.split(',').map((value) => value.trim()).toList();
      final stableKeys = rawStableKeys.trim().isEmpty
          ? <String>[]
          : rawStableKeys.split(',').map((value) => value.trim()).toList();
      final persistedEntryIds = rawEntryIds.trim().isEmpty
          ? <String>[]
          : rawEntryIds.split(',').map((value) => value.trim()).toList();

      final length = trackIds.length > stableKeys.length
          ? trackIds.length
          : stableKeys.length;
      if (length == 0) {
        if (rawEntryIds.isNotEmpty) {
          batch.update(
            'playlists',
            {'track_entry_ids': ''},
            where: 'id = ?',
            whereArgs: [playlistId],
          );
          changedRows++;
        }
        continue;
      }

      final used = <String>{};
      final entryIds = <String>[];
      var changed = persistedEntryIds.length != length;

      for (var index = 0; index < length; index++) {
        final persisted = index < persistedEntryIds.length
            ? persistedEntryIds[index]
            : '';
        if (persisted.isNotEmpty && used.add(persisted)) {
          entryIds.add(persisted);
          continue;
        }

        final trackId = index < trackIds.length ? trackIds[index] : '';
        final stableKey = index < stableKeys.length ? stableKeys[index] : '';
        var generated = _buildLegacyPlaylistEntryId(
          playlistId: playlistId,
          index: index,
          trackId: trackId,
          stableKey: stableKey,
        );
        var collision = 0;
        while (!used.add(generated)) {
          collision++;
          generated = '${generated}_$collision';
        }
        entryIds.add(generated);
        changed = true;
      }

      if (!changed) continue;
      batch.update(
        'playlists',
        {'track_entry_ids': entryIds.join(',')},
        where: 'id = ?',
        whereArgs: [playlistId],
      );
      changedRows++;
    }

    if (changedRows > 0) {
      await batch.commit(noResult: true);
    }
  }

  String _buildLegacyPlaylistEntryId({
    required int playlistId,
    required int index,
    required String trackId,
    required String stableKey,
  }) {
    final seed = '$playlistId|$index|$trackId|${stableKey.toLowerCase()}';
    return 'legacy-$playlistId-$index-'
        '${_stablePositiveHash(seed).toRadixString(36)}';
  }

  int? _safeDbInt(Object? value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value.trim());
    return null;
  }

  String _safeDbStr(Object? value, String fallback) {
    final text = value?.toString().trim();
    if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
      return fallback;
    }

    return text;
  }

  String _normalizeStableKey(String? value) {
    final text = value?.trim();
    if (text == null || text.isEmpty) return '';
    return text.toLowerCase();
  }

  String _buildFallbackStableKey({
    required String? filePath,
    required String title,
    required String artist,
    required String albumName,
    required int duration,
    required int size,
  }) {
    final normalizedPath = _normalizeRealFilePath(filePath);

    if (normalizedPath.isNotEmpty) {
      return 'audio:path:'
          '${_stablePositiveHash(normalizedPath).toRadixString(16)}';
    }

    final fingerprint = [
      _normalizeIdentityText(title),
      _normalizeIdentityText(artist),
      _normalizeIdentityText(albumName),
      duration,
      size,
    ].join('|');

    return 'audio:content:'
        '${_stablePositiveHash(fingerprint).toRadixString(16)}';
  }

  String _normalizeRealFilePath(String? value) {
    final normalized = _normalizeIdentityText(value);
    if (normalized.isEmpty || normalized.startsWith('content://')) {
      return '';
    }

    return normalized;
  }

  String _normalizeIdentityText(String? value) {
    final text = value?.trim();
    if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
      return '';
    }

    return text
        .replaceAll('\\', '/')
        .replaceAll(RegExp(r'/+'), '/')
        .toLowerCase();
  }

  int _stablePositiveHash(String input) {
    var hash = 0x811c9dc5;
    for (final codeUnit in input.codeUnits) {
      hash ^= codeUnit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }

    return hash == 0 ? 1 : hash;
  }

  Future<void> _createTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_meta (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS tracks (
        id              INTEGER PRIMARY KEY,
        media_store_id  INTEGER NOT NULL DEFAULT 0,
        volume_name     TEXT    NOT NULL DEFAULT '',
        title           TEXT    NOT NULL,
        artist          TEXT    NOT NULL,
        album           TEXT    NOT NULL DEFAULT '',
        album_id        INTEGER NOT NULL DEFAULT 0,
        duration        INTEGER NOT NULL DEFAULT 0,
        file_path       TEXT    NOT NULL DEFAULT '',
        playback_uri    TEXT    NOT NULL DEFAULT '',
        art_path        TEXT,
        liked           INTEGER NOT NULL DEFAULT 0,
        grad            TEXT    NOT NULL DEFAULT 'grad-a',
        genre           TEXT    NOT NULL DEFAULT '',
        date_added      INTEGER NOT NULL DEFAULT 0,
        file_size       INTEGER NOT NULL DEFAULT 0,
        stable_key      TEXT    NOT NULL DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS albums (
        id          INTEGER PRIMARY KEY,
        name        TEXT    NOT NULL,
        artist      TEXT    NOT NULL,
        track_count INTEGER NOT NULL DEFAULT 0,
        art_path    TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS artists (
        id          INTEGER PRIMARY KEY,
        name        TEXT    NOT NULL,
        track_count INTEGER NOT NULL DEFAULT 0,
        album_count INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS playlists (
        id                INTEGER PRIMARY KEY AUTOINCREMENT,
        name              TEXT    NOT NULL,
        track_ids         TEXT    NOT NULL DEFAULT '',
        track_stable_keys TEXT    NOT NULL DEFAULT '',
        track_entry_ids   TEXT    NOT NULL DEFAULT '',
        art               TEXT    NOT NULL DEFAULT '🎵',
        created_at        TEXT    NOT NULL DEFAULT (datetime('now'))
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS play_history (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        track_id         INTEGER NOT NULL,
        stable_key       TEXT    NOT NULL DEFAULT '',
        title            TEXT    NOT NULL,
        artist           TEXT    NOT NULL,
        played_at        TEXT    NOT NULL,
        last_position_ms INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS liked_tracks (
        track_id   INTEGER PRIMARY KEY,
        stable_key TEXT    NOT NULL DEFAULT ''
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS identity_counters (
        name       TEXT    PRIMARY KEY,
        next_value INTEGER NOT NULL DEFAULT 1
      )
    ''');

    await _createMediaLibraryTable(db);
  }

  /// Creates the media_library table.
  /// Safe to call on every open — uses IF NOT EXISTS.
  Future<void> _createMediaLibraryTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS media_library (
        id             TEXT PRIMARY KEY,
        kind           TEXT    NOT NULL,
        title          TEXT    NOT NULL,
        artist         TEXT    NOT NULL DEFAULT '',
        album          TEXT    NOT NULL DEFAULT '',
        duration       INTEGER NOT NULL DEFAULT 0,
        size           INTEGER NOT NULL DEFAULT 0,
        source_type    TEXT    NOT NULL DEFAULT 'filePath',
        source_value   TEXT    NOT NULL,
        mime_type      TEXT    NOT NULL DEFAULT '',
        artwork_path   TEXT,
        volume_name    TEXT    NOT NULL DEFAULT '',
        relative_path  TEXT    NOT NULL DEFAULT '',
        folder         TEXT    NOT NULL DEFAULT '',
        date_added     INTEGER NOT NULL DEFAULT 0,
        is_available   INTEGER NOT NULL DEFAULT 1,
        last_seen_scan TEXT    NOT NULL DEFAULT ''
      )
    ''');
  }

  Future<void> _removeVideoData(Database db) async {
    await db.execute("DELETE FROM media_library WHERE kind = 'video'");
    await db.execute('DROP TABLE IF EXISTS media_preferences');
    await db.execute('DROP TABLE IF EXISTS video_library');
    await db.execute('DROP TABLE IF EXISTS video_history');
    await db.execute('DROP TABLE IF EXISTS video_playlists');
  }

  /// Creates performance indexes for frequently queried columns.
  /// Uses IF NOT EXISTS so it's safe to call on every open.
  Future<void> _createIndexes(Database db) async {
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_tracks_title ON tracks(title)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_tracks_artist ON tracks(artist)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_tracks_album_id ON tracks(album_id)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_tracks_stable_key ON tracks(stable_key)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_liked_tracks_stable_key '
      'ON liked_tracks(stable_key)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_play_history_track_id '
      'ON play_history(track_id)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_play_history_stable_key '
      'ON play_history(stable_key)',
    );

    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_play_history_played_at '
      'ON play_history(played_at)',
    );
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}