export 'system_font_service_stub.dart'
    if (dart.library.io) 'system_font_service_io.dart';
