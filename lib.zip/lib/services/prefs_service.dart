import 'package:shared_preferences/shared_preferences.dart';

class PrefsService {
  static SharedPreferences? _prefs;

  /// Call once in main() before runApp().
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  /// Returns the shared instance.  Must call [init] first.
  static SharedPreferences get instance {
    assert(_prefs != null, 'PrefsService.init() must be called before use');
    return _prefs!;
  }

  // ── Convenience typed getters / setters (so callers don't need .instance) ──

  static String? getString(String key) => instance.getString(key);
  static Future<bool> setString(String key, String value) =>
      instance.setString(key, value);

  static bool? getBool(String key) => instance.getBool(key);
  static Future<bool> setBool(String key, bool value) =>
      instance.setBool(key, value);

  static int? getInt(String key) => instance.getInt(key);
  static Future<bool> setInt(String key, int value) =>
      instance.setInt(key, value);

  static double? getDouble(String key) => instance.getDouble(key);
  static Future<bool> setDouble(String key, double value) =>
      instance.setDouble(key, value);

  static List<String>? getStringList(String key) => instance.getStringList(key);
  static Future<bool> setStringList(String key, List<String> value) =>
      instance.setStringList(key, value);

  static Future<bool> remove(String key) => instance.remove(key);

  // ── Obfuscated storage (anti-tamper for simple boolean flags) ──────────
  static const int _obfuscationKey = 0x5A3C9F1E;

  /// Reads an obfuscated boolean. Returns false if the key doesn't exist.
  static bool getObfuscatedBool(String key) {
    final encrypted = getInt(key) ?? 0;
    return (encrypted ^ _obfuscationKey) == 1;
  }

  /// Writes an obfuscated boolean.
  static Future<bool> setObfuscatedBool(String key, bool value) {
    final encrypted = value ? 1 ^ _obfuscationKey : 0;
    return setInt(key, encrypted);
  }
}
