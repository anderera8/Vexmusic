// lib/services/library/library_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Music library management — extracted from MusicProvider.
// Handles loading, scanning, syncing, and artwork pre-fetching.
// Pure service — takes LibraryState in, returns new LibraryState out.
//
// Permanent MediaStore path:
// - no on_audio_query imports
// - scans through the app-owned native MediaStore bridge
// - derives albums/artists from the final Track list
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../models/music_models.dart';
import '../../providers/state/library_state.dart';
import '../audio_library_scanner.dart';
import '../artwork_cache_service.dart';
import '../database_service.dart';
import '../favorites/like_service.dart';
import '../native_media_library_service.dart';
import '../prefs_service.dart';

List<Track> _convertMediaStoreMapsToTracks(
  List<Map<String, Object?>> mediaRows,
) =>
    mediaRows.map(Track.fromMediaStoreMap).toList(growable: false);

class _DerivedLibrary {
  const _DerivedLibrary({required this.albums, required this.artists});

  final List<Album> albums;
  final List<Artist> artists;
}

class LibraryService {
  final DatabaseService _db;
  final AudioLibraryScanner _scanner;
  final LikeService _likeService;

  static const int _startupArtworkPrefetchLimit = 12;
  static const int _syncArtworkPrefetchLimit = 8;
  static const Duration _startupArtworkPrefetchDelay = Duration(seconds: 2);
  static const Duration _syncArtworkPrefetchDelay = Duration(milliseconds: 800);
  static const Duration _artworkPrefetchRepeatGap = Duration(minutes: 5);

  Future<void>? _artworkPrefetchFuture;
  DateTime? _lastArtworkPrefetchAt;
  String? _lastArtworkPrefetchSignature;

  LibraryService({
    DatabaseService? db,
    AudioLibraryScanner? scanner,
    LikeService? likeService,
  })  : _db = db ?? DatabaseService(),
        _scanner = scanner ?? AudioLibraryScanner(),
        _likeService = likeService ?? LikeService();

  // ── Public API ─────────────────────────────────────────────────────────

  /// Loads the music library.
  ///
  /// Release-safe rule:
  /// If the database already contains tracks, DB is the source of truth for
  /// startup. Do not force a fresh MediaStore scan just because the
  /// hasScannedMedia preference is missing or stale.
  Future<LibraryState> loadLibrary(
    LibraryState current, {
    bool forceScan = false,
  }) async {
    if (!forceScan && current.libraryLoaded && !current.isFirstLoad) {
      return current;
    }

    final prefs = PrefsService.instance;
    final hasScannedMedia = prefs.getBool('hasScannedMedia') ?? false;
    final hasStoredTracks = await _db.hasTracks();

    if (!forceScan && hasStoredTracks) {
      final dbState = await loadFromDatabase();

      if (dbState.tracks.isNotEmpty) {
        if (!hasScannedMedia) {
          await prefs.setBool('hasScannedMedia', true);
        }

        final state = dbState.copyWith(
          playlists: current.playlists,
          recentHistory: current.recentHistory,
          libraryLoaded: true,
          isFirstLoad: false,
          isLoading: false,
          loadError: null,
        );

        _prefetchArtwork(
          state.tracks,
          maxAlbums: _startupArtworkPrefetchLimit,
          delay: _startupArtworkPrefetchDelay,
        );
        return state;
      }
    }

    debugPrint(
      forceScan
          ? 'Manual refresh — performing full audio scan...'
          : 'First launch — performing full audio scan...',
    );

    var state = await performFullScan();

    // A successful empty scan is also a completed sync. Failed scans retain a
    // non-null loadError and must not advance the sync timestamp.
    if (state.loadError == null) {
      await prefs.setInt(
        'lastSyncTimestamp',
        DateTime.now().millisecondsSinceEpoch,
      );
    }

    state = state.copyWith(
      libraryLoaded: true,
      isFirstLoad: false,
      isLoading: false,
    );

    _prefetchArtwork(
      state.tracks,
      maxAlbums: _startupArtworkPrefetchLimit,
      delay: _startupArtworkPrefetchDelay,
    );

    return state;
  }

  /// Diff-based sync against actual device MediaStore audio.
  ///
  /// A successful empty scan clears stale library data. A failed scan preserves
  /// the current/database library and exposes an error state.
  Future<LibraryState> verifyAndSync(LibraryState current) async {
    if (current.isSyncing) return current;

    var state = current.copyWith(isSyncing: true);

    try {
      final previousTracks = state.tracks.isNotEmpty
          ? state.tracks
          : await _db.getAllTracks();

      final scanResult = await _queryDeviceAudio(
        knownVolumeNames: _knownVolumeNames(previousTracks),
      );

      if (!scanResult.succeeded) {
        state = await _handleScanFailure(state, scanResult);
      } else {
        state = await _applySuccessfulScan(
          state,
          scanResult,
          previousTracks,
          fullScan: false,
        );
      }
    } catch (error, stackTrace) {
      debugPrint('[Scan] Unexpected synchronization failure: $error');
      debugPrintStack(stackTrace: stackTrace);

      state = await _handleScanFailure(
        state,
        AudioScanResult.failure(
          permissionGranted: true,
          error: error,
          stackTrace: stackTrace,
        ),
      );
    } finally {
      state = state.copyWith(isSyncing: false);
    }

    return state;
  }

  /// Full rescan of every MediaStore audio file the app can access.
  Future<LibraryState> performFullScan() async {
    final existingTracks = await _db.getAllTracks();

    await _scanner.requestPermission(attempts: 3);

    final scanResult = await _queryDeviceAudio(
      knownVolumeNames: _knownVolumeNames(existingTracks),
    );

    if (!scanResult.succeeded) {
      return _handleScanFailure(
        LibraryState.initial(),
        scanResult,
      );
    }

    return _applySuccessfulScan(
      LibraryState.initial(),
      scanResult,
      existingTracks,
      fullScan: true,
    );
  }

  Future<LibraryState> _applySuccessfulScan(
    LibraryState current,
    AudioScanResult scanResult,
    List<Track> previousTracks, {
    required bool fullScan,
  }) async {
    assert(scanResult.succeeded);
    assert(scanResult.hasAuthoritativeVolumes);

    final eligibleRows = scanResult.records
        .map((record) => record.toMap())
        .where(_isEligibleMediaRow)
        .toList(growable: false);

    final convertedTracks = eligibleRows.isEmpty
        ? const <Track>[]
        : await compute(
            _convertMediaStoreMapsToTracks,
            eligibleRows,
          );

    final reconciledTracks = await _preserveStableIdsAndLikes(
      convertedTracks,
      previousTracks,
    );

    final stableKeyAliases = _buildStableKeyAliases(
      previousTracks,
      reconciledTracks,
    );

    final authoritativeVolumes = scanResult.authoritativeVolumeNames
        .map((volume) => volume.trim().toLowerCase())
        .where((volume) => volume.isNotEmpty)
        .toSet();

    bool isProtectedByIncompleteScan(Track track) {
      if (scanResult.isFullyAuthoritative) return false;

      final volume = track.normalizedVolumeName;
      return volume.isEmpty || !authoritativeVolumes.contains(volume);
    }

    final finalByAppId = <int, Track>{
      for (final track in reconciledTracks)
        if (track.id > 0) track.id: track,
    };

    for (final previous in previousTracks) {
      if (previous.id <= 0 || finalByAppId.containsKey(previous.id)) {
        continue;
      }

      if (isProtectedByIncompleteScan(previous)) {
        finalByAppId[previous.id] = previous;
      }
    }

    final finalTracks = finalByAppId.values.toList()
      ..sort((a, b) {
        final titleCompare =
            a.title.toLowerCase().compareTo(b.title.toLowerCase());
        if (titleCompare != 0) return titleCompare;

        final artistCompare =
            a.artist.toLowerCase().compareTo(b.artist.toLowerCase());
        if (artistCompare != 0) return artistCompare;

        return a.id.compareTo(b.id);
      });

    if (finalTracks.isEmpty && scanResult.isFullyAuthoritative) {
      debugPrint(
        '[Scan] Every authoritative volume completed with no eligible audio.',
      );
      return _applySuccessfulEmptyScan(current);
    }

    final previousIds = previousTracks
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet();
    final finalIds = finalTracks
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet();

    final removedTracks = previousTracks
        .where((track) => track.id > 0 && !finalIds.contains(track.id))
        .toList(growable: false);
    final addedIds = finalIds.difference(previousIds);

    final previousById = <int, Track>{
      for (final track in previousTracks)
        if (track.id > 0) track.id: track,
    };
    final updatedCount = finalTracks.where((track) {
      final previous = previousById[track.id];
      return previous != null && !_sameTrackMetadata(previous, track);
    }).length;

    await _db.commitTrackIdentityReconciliation(
      finalTracks,
      removedTracks: removedTracks,
      stableKeyAliases: stableKeyAliases,
    );

    await _db.saveMediaLibrary(
      finalTracks.map((track) => track.toMediaEntry()).toList(growable: false),
    );

    final likedTracks = await _likeService.applyLikes(finalTracks);
    final derived = await _deriveAndPersistalbumsAndArtists(likedTracks);

    await PrefsService.instance.setBool('hasScannedMedia', true);

    if (scanResult.isFullyAuthoritative) {
      await PrefsService.instance.setInt(
        'lastSyncTimestamp',
        DateTime.now().millisecondsSinceEpoch,
      );
    }

    if (addedIds.isNotEmpty) {
      _prefetchArtwork(
        likedTracks.where((track) => addedIds.contains(track.id)).toList(),
        maxAlbums: fullScan
            ? _startupArtworkPrefetchLimit
            : _syncArtworkPrefetchLimit,
        delay: fullScan
            ? _startupArtworkPrefetchDelay
            : _syncArtworkPrefetchDelay,
      );
    }

    final partialMessage = scanResult.partialFailureMessage;

    debugPrint(
      '[Scan] ${scanResult.isFullyAuthoritative ? 'Authoritative' : 'Partial'} '
      'sync: +${addedIds.length} ~$updatedCount -${removedTracks.length}; '
      'protected volumes=${scanResult.nonAuthoritativeVolumeNames.join(',')}',
    );

    return current.copyWith(
      tracks: likedTracks,
      albums: derived.albums,
      artists: derived.artists,
      trackById: LibraryState.buildTrackMap(likedTracks),
      genres: LibraryState.buildGenres(likedTracks),
      libraryLoaded: true,
      isFirstLoad: false,
      isLoading: false,
      loadError: partialMessage,
    );
  }

  Set<String> _knownVolumeNames(List<Track> tracks) {
    return tracks
        .map((track) => track.normalizedVolumeName)
        .where((volume) => volume.isNotEmpty)
        .toSet();
  }

  /// Loads library data from the database.
  Future<LibraryState> loadFromDatabase() async {
    try {
      final tracks = await _db.getAllTracks();
      final likedTracks = await _likeService.applyLikes(tracks);
      final derived = await _deriveAndPersistalbumsAndArtists(likedTracks);
      final trackMap = LibraryState.buildTrackMap(likedTracks);
      final genres = LibraryState.buildGenres(likedTracks);

      debugPrint('Database loaded: ${likedTracks.length} tracks');

      return LibraryState.initial().copyWith(
        tracks: likedTracks,
        albums: derived.albums,
        artists: derived.artists,
        genres: genres,
        trackById: trackMap,
        isLoading: false,
        libraryLoaded: true,
        isFirstLoad: false,
        loadError: null,
      );
    } catch (e) {
      debugPrint('Database load error: $e');
      rethrow;
    }
  }

  /// Pre-fetches a small number of album artworks after startup settles.
  ///
  /// This must never compete with first frame, library scan, DB writes, or the
  /// first player interaction. Missing artwork is common, so this method keeps
  /// prefetch small, delayed, de-duplicated, and low-concurrency.
  void _prefetchArtwork(
    List<Track> tracks, {
    required int maxAlbums,
    required Duration delay,
  }) {
    if (tracks.isEmpty || maxAlbums <= 0) return;

    final albumIds = <int>{};

    for (final track in tracks) {
      final albumId = track.albumId;
      if (albumId == null || albumId <= 0) continue;

      albumIds.add(albumId);

      if (albumIds.length >= maxAlbums) break;
    }

    if (albumIds.isEmpty) return;

    final orderedIds = albumIds.toList(growable: false);
    final signature = orderedIds.join(',');

    final now = DateTime.now();
    final recentlyScheduled = _lastArtworkPrefetchSignature == signature &&
        _lastArtworkPrefetchAt != null &&
        now.difference(_lastArtworkPrefetchAt!) < _artworkPrefetchRepeatGap;

    if (recentlyScheduled) return;

    if (_artworkPrefetchFuture != null &&
        _lastArtworkPrefetchSignature == signature) {
      return;
    }

    _lastArtworkPrefetchSignature = signature;
    _lastArtworkPrefetchAt = now;

    debugPrint(
      '[ArtworkCache] Scheduling artwork prefetch for '
      '${orderedIds.length} albums after ${delay.inMilliseconds}ms...',
    );

    final future = Future<void>.delayed(delay).then((_) async {
      await ArtworkCacheService.cacheBatch(
        orderedIds,
        concurrency: 1,
      );
    });

    _artworkPrefetchFuture = future.whenComplete(() {
      if (_lastArtworkPrefetchSignature == signature) {
        _artworkPrefetchFuture = null;
      }
    });

    unawaited(
      _artworkPrefetchFuture!.catchError((Object e) {
        debugPrint('[ArtworkCache] Pre-fetch failed (non-critical): $e');
      }),
    );
  }

  Map<String, Track> _uniqueStableTrackMap(
    List<Track> tracks,
  ) {
    final result = <String, Track>{};
    final duplicates = <String>{};

    for (final track in tracks) {
      final key = _normalizeStableKey(track.stableKey);
      if (key.isEmpty) continue;

      if (result.containsKey(key)) {
        duplicates.add(key);
      } else {
        result[key] = track;
      }
    }

    for (final key in duplicates) {
      result.remove(key);
    }

    return result;
  }

  Map<String, Track> _uniqueSourceTrackMap(
    List<Track> tracks,
  ) {
    final result = <String, Track>{};
    final duplicates = <String>{};

    for (final track in tracks) {
      final key = track.normalizedSourcePath;
      if (key.isEmpty) continue;

      if (result.containsKey(key)) {
        duplicates.add(key);
      } else {
        result[key] = track;
      }
    }

    for (final key in duplicates) {
      result.remove(key);
    }

    return result;
  }

  Map<String, Track> _uniqueFingerprintTrackMap(
    List<Track> tracks,
  ) {
    final result = <String, Track>{};
    final duplicates = <String>{};

    for (final track in tracks) {
      if (!track.hasUsableContentFingerprint) continue;

      final key = track.contentFingerprint;

      if (result.containsKey(key)) {
        duplicates.add(key);
      } else {
        result[key] = track;
      }
    }

    for (final key in duplicates) {
      result.remove(key);
    }

    return result;
  }

  Map<String, Track> _uniqueMediaStoreTrackMap(
    List<Track> tracks,
  ) {
    final result = <String, Track>{};
    final duplicates = <String>{};

    for (final track in tracks) {
      final key = track.volumeScopedMediaStoreKey;
      if (key.isEmpty) continue;

      if (result.containsKey(key)) {
        duplicates.add(key);
      } else {
        result[key] = track;
      }
    }

    for (final key in duplicates) {
      result.remove(key);
    }

    return result;
  }

  Map<String, Track> _buildStableKeyAliases(
    List<Track> previousTracks,
    List<Track> currentTracks,
  ) {
    final currentByAppId = <int, Track>{
      for (final track in currentTracks)
        if (track.id > 0) track.id: track,
    };
    final aliases = <String, Track>{};
    final ambiguous = <String>{};

    for (final previous in previousTracks) {
      final current = currentByAppId[previous.id];
      if (current == null) continue;

      final oldStableKey = _normalizeStableKey(previous.stableKey);
      final newStableKey = _normalizeStableKey(current.stableKey);

      if (oldStableKey.isEmpty ||
          newStableKey.isEmpty ||
          oldStableKey == newStableKey) {
        continue;
      }

      final existing = aliases[oldStableKey];
      if (existing != null && existing.id != current.id) {
        ambiguous.add(oldStableKey);
        continue;
      }

      aliases[oldStableKey] = current;
    }

    for (final key in ambiguous) {
      aliases.remove(key);
    }

    return Map<String, Track>.unmodifiable(aliases);
  }

  bool _mediaStoreFallbackIsCompatible(
    Track scanned,
    Track previous,
  ) {
    if (scanned.normalizedVolumeName.isEmpty ||
        scanned.normalizedVolumeName != previous.normalizedVolumeName) {
      return false;
    }

    final scannedPath = scanned.normalizedSourcePath;
    final previousPath = previous.normalizedSourcePath;

    if (scannedPath.isNotEmpty &&
        previousPath.isNotEmpty &&
        scannedPath == previousPath) {
      return true;
    }

    final scannedStableKey = _normalizeStableKey(scanned.stableKey);
    final previousStableKey = _normalizeStableKey(previous.stableKey);

    if (scannedStableKey.isNotEmpty &&
        previousStableKey.isNotEmpty &&
        scannedStableKey == previousStableKey) {
      return true;
    }

    return scanned.hasUsableContentFingerprint &&
        previous.hasUsableContentFingerprint &&
        scanned.contentFingerprint == previous.contentFingerprint;
  }

  Track? _findPreviousTrackForScan(
    Track scanned,
    Map<String, Track> previousByStableKey,
    Map<String, Track> previousBySourcePath,
    Map<String, Track> previousByFingerprint,
    Map<String, Track> previousByMediaStoreId,
  ) {
    final stableKey = _normalizeStableKey(scanned.stableKey);

    if (stableKey.isNotEmpty) {
      final match = previousByStableKey[stableKey];
      if (match != null) return match;
    }

    final sourcePath = scanned.normalizedSourcePath;

    if (sourcePath.isNotEmpty) {
      final match = previousBySourcePath[sourcePath];
      if (match != null) return match;
    }

    if (scanned.hasUsableContentFingerprint) {
      final match = previousByFingerprint[scanned.contentFingerprint];
      if (match != null) return match;
    }

    final nativeKey = scanned.volumeScopedMediaStoreKey;

    if (nativeKey.isNotEmpty) {
      final match = previousByMediaStoreId[nativeKey];

      if (match != null &&
          _mediaStoreFallbackIsCompatible(scanned, match)) {
        return match;
      }
    }

    return null;
  }

  Future<List<Track>> _preserveStableIdsAndLikes(
    List<Track> scannedTracks,
    List<Track> previousTracks,
  ) async {
    if (scannedTracks.isEmpty) {
      return const <Track>[];
    }

    final validPreviousTracks = previousTracks
        .where((track) => track.id > 0)
        .toList(growable: false);

    final previousByStableKey =
        _uniqueStableTrackMap(validPreviousTracks);
    final previousBySourcePath =
        _uniqueSourceTrackMap(validPreviousTracks);
    final previousByFingerprint =
        _uniqueFingerprintTrackMap(validPreviousTracks);
    final previousByMediaStoreId =
        _uniqueMediaStoreTrackMap(validPreviousTracks);

    final usedPreviousIds = <int>{};
    final matches = List<Track?>.filled(
      scannedTracks.length,
      null,
      growable: false,
    );

    var unmatchedCount = 0;

    for (var index = 0; index < scannedTracks.length; index++) {
      final previous = _findPreviousTrackForScan(
        scannedTracks[index],
        previousByStableKey,
        previousBySourcePath,
        previousByFingerprint,
        previousByMediaStoreId,
      );

      if (previous == null ||
          previous.id <= 0 ||
          usedPreviousIds.contains(previous.id)) {
        unmatchedCount++;
        continue;
      }

      matches[index] = previous;
      usedPreviousIds.add(previous.id);
    }

    final reservedIds = await _db.reserveTrackIds(unmatchedCount);

    if (reservedIds.length != unmatchedCount) {
      throw StateError(
        'Track ID allocator returned ${reservedIds.length} IDs for '
        '$unmatchedCount unmatched tracks.',
      );
    }

    final reservedIdSet = reservedIds.toSet();

    if (reservedIdSet.length != reservedIds.length ||
        reservedIds.any((id) => id <= 0) ||
        reservedIdSet.any(usedPreviousIds.contains)) {
      throw StateError(
        'Track ID allocator returned invalid or conflicting app IDs.',
      );
    }

    var reservedIndex = 0;

    return List<Track>.generate(
      scannedTracks.length,
      (index) {
        final scanned = scannedTracks[index];
        final previous = matches[index];

        if (previous != null) {
          return scanned.copyWith(
            id: previous.id,
            liked: previous.liked,
          );
        }

        final appId = reservedIds[reservedIndex++];

        return scanned.copyWith(
          id: appId,
          liked: false,
        );
      },
      growable: false,
    );
  }

  String _normalizeStableKey(Object? value) {
    return value?.toString().trim().toLowerCase() ?? '';
  }

  Future<_DerivedLibrary> _deriveAndPersistalbumsAndArtists(
    List<Track> tracks,
  ) async {
    final albums = Album.buildFromTracks(tracks);
    final artists = Artist.buildFromTracks(tracks);

    try {
      await _db.savealbums(albums);
    } catch (e) {
      debugPrint('album save skipped (non-critical): $e');
    }

    try {
      await _db.saveArtists(artists);
    } catch (e) {
      debugPrint('Artist save skipped (non-critical): $e');
    }

    return _DerivedLibrary(albums: albums, artists: artists);
  }

  Future<AudioScanResult> _queryDeviceAudio({
    Iterable<String> knownVolumeNames = const <String>[],
  }) {
    return _scanner.queryAudio(
      minDuration: Duration.zero,
      includeInternal: false,
      includeRingtones: true,
      includeAlarms: true,
      includeNotifications: true,
      includePodcasts: true,
      knownVolumeNames: knownVolumeNames,
    );
  }

  Future<LibraryState> _handleScanFailure(
    LibraryState current,
    AudioScanResult result,
  ) async {
    assert(!result.succeeded);

    var preserved = current;

    if (preserved.tracks.isEmpty) {
      preserved = await _loadDatabaseFallback(
        preserved,
        '[Scan] Scan failed while memory was empty; restored DB library',
      );
    }

    final message = _scanFailureMessage(result);

    debugPrint('[Scan] $message Error: ${result.error}');

    if (result.stackTrace != null) {
      debugPrintStack(stackTrace: result.stackTrace);
    }

    return preserved.copyWith(
      isLoading: false,
      libraryLoaded: preserved.libraryLoaded || preserved.tracks.isNotEmpty,
      isFirstLoad: false,
      loadError: message,
    );
  }

  String _scanFailureMessage(AudioScanResult result) {
    final error = result.error;

    if (error is AudioScanException) {
      switch (error.kind) {
        case AudioScanFailureKind.unsupportedPlatform:
          return 'Audio scanning is not supported on this platform.';

        case AudioScanFailureKind.permissionDenied:
          return 'Audio permission is required to scan this device. '
              'Grant media/audio access in Android settings.';

        case AudioScanFailureKind.malformedResponse:
          return 'Android returned invalid audio-library data. '
              'Your saved library was preserved.';

        case AudioScanFailureKind.platformFailure:
          return 'Android could not complete the audio scan. '
              'Your saved library was preserved.';

        case AudioScanFailureKind.noAuthoritativeVolumes:
          return 'No storage volume completed a reliable audio scan. '
              'Your saved library was preserved.';

        case AudioScanFailureKind.unknown:
          return 'The device audio scan failed. '
              'Your saved library was preserved.';
      }
    }

    if (!result.permissionGranted) {
      return 'Audio permission is required to scan this device. '
          'Grant media/audio access in Android settings.';
    }

    return 'The device audio scan failed. Your saved library was preserved.';
  }

  Future<LibraryState> _applySuccessfulEmptyScan(
    LibraryState current,
  ) async {
    await _db.clearScannedAudioLibrary();

    final playlists = await _db.getPlaylists();

    await PrefsService.instance.setBool('hasScannedMedia', true);
    await PrefsService.instance.setInt(
      'lastSyncTimestamp',
      DateTime.now().millisecondsSinceEpoch,
    );

    return current.copyWith(
      tracks: const <Track>[],
      albums: const <Album>[],
      artists: const <Artist>[],
      playlists: playlists,
      genres: const <Genre>[],
      recentHistory: const <PlayHistory>[],
      trackById: const <int, Track>{},
      libraryLoaded: true,
      isFirstLoad: false,
      isLoading: false,
      loadError: null,
    );
  }

  Future<LibraryState> _loadDatabaseFallback(
    LibraryState current,
    String debugMessage,
  ) async {
    try {
      final hasStoredTracks = await _db.hasTracks();

      if (!hasStoredTracks) {
        return current.copyWith(isLoading: false);
      }

      final dbState = await loadFromDatabase();

      if (dbState.tracks.isEmpty) {
        return current.copyWith(isLoading: false);
      }

      debugPrint(debugMessage);

      await PrefsService.instance.setBool('hasScannedMedia', true);

      final state = dbState.copyWith(
        playlists: current.playlists,
        recentHistory: current.recentHistory,
        libraryLoaded: true,
        isFirstLoad: false,
        isLoading: false,
        isSyncing: current.isSyncing,
        loadError: null,
      );

      _prefetchArtwork(
        state.tracks,
        maxAlbums: _startupArtworkPrefetchLimit,
        delay: _startupArtworkPrefetchDelay,
      );

      return state;
    } catch (e) {
      debugPrint('[Scan] Database fallback unavailable: $e');
      return current.copyWith(isLoading: false);
    }
  }

  // ── Static helpers ─────────────────────────────────────────────────────

  /// Compatibility name kept for tests/callers.
  ///
  /// New rule:
  /// - include ringtones, alarms, notifications, downloads, WhatsApp,
  ///   Telegram, Xender, browser downloads, and other shared-storage audio.
  /// - exclude only Android/OEM system partition sounds.
  static bool isActualMusicTrack(dynamic audio) {
    return _isEligibleMediaRow(_audioToMap(audio));
  }

  static bool _isEligibleMediaRow(Map<String, Object?> row) {
    if (_isSystemAudio(row)) return false;

    // Do not reject:
    // - isMusic == false
    // - isRingtone == true
    // - isAlarm == true
    // - isNotification == true
    // - short files
    return true;
  }

  static bool _isSystemAudio(Map<String, Object?> row) {
    final path = _pathFromRow(row).trim().toLowerCase();

    if (path.isEmpty) return false;

    // These are Android/OEM system partitions, not user phone storage.
    // User-accessible /storage/emulated/0/Ringtones, Alarms, Notifications,
    // Downloads, WhatsApp, Telegram, Xender, etc. are intentionally allowed.
    return path.startsWith('/system/media/audio/') ||
        path.startsWith('/product/media/audio/') ||
        path.startsWith('/vendor/media/audio/') ||
        path.startsWith('/system/product/media/') ||
        path.startsWith('/oem/media/audio/');
  }

  static String _pathFromRow(Map<String, Object?> row) {
    for (final key in const ['path', 'data', 'filePath', 'resolvedPath']) {
      final value = row[key]?.toString().trim();
      if (value != null && value.isNotEmpty) return value;
    }
    return '';
  }

  static Map<String, Object?> _audioToMap(dynamic audio) {
    if (audio is NativeAudioRecord) return audio.toMap();

    if (audio is Map) {
      return audio.map(
        (key, value) => MapEntry(key.toString(), value),
      );
    }

    return <String, Object?>{
      'id': _readDynamic(audio, 'id'),
      'mediaStoreId': _readDynamic(audio, 'mediaStoreId'),
      'volumeName': _readDynamic(audio, 'volumeName'),
      'uri': _readDynamic(audio, 'uri'),
      'title': _readDynamic(audio, 'title'),
      'artist': _readDynamic(audio, 'artist'),
      'album': _readDynamic(audio, 'album'),
      'albumId': _readDynamic(audio, 'albumId'),
      'duration': _readDynamic(audio, 'duration'),
      'data': _readDynamic(audio, 'data'),
      'path': _readDynamic(audio, 'path') ?? _readDynamic(audio, 'data'),
      'genre': _readDynamic(audio, 'genre'),
      'dateAdded': _readDynamic(audio, 'dateAdded'),
      'size': _readDynamic(audio, 'size'),
      'isMusic': _readDynamic(audio, 'isMusic'),
      'isRingtone': _readDynamic(audio, 'isRingtone'),
      'isAlarm': _readDynamic(audio, 'isAlarm'),
      'isNotification': _readDynamic(audio, 'isNotification'),
      'isPodcast': _readDynamic(audio, 'isPodcast'),
    };
  }

  static dynamic _readDynamic(dynamic object, String fieldName) {
    try {
      switch (fieldName) {
        case 'id':
          return object.id;
        case 'mediaStoreId':
          return object.mediaStoreId;
        case 'volumeName':
          return object.volumeName;
        case 'uri':
          return object.uri;
        case 'title':
          return object.title;
        case 'artist':
          return object.artist;
        case 'album':
          return object.album;
        case 'albumId':
          return object.albumId;
        case 'duration':
          return object.duration;
        case 'data':
          return object.data;
        case 'path':
          return object.path;
        case 'genre':
          return object.genre;
        case 'dateAdded':
          return object.dateAdded;
        case 'size':
          return object.size;
        case 'isMusic':
          return object.isMusic;
        case 'isRingtone':
          return object.isRingtone;
        case 'isAlarm':
          return object.isAlarm;
        case 'isNotification':
          return object.isNotification;
        case 'isPodcast':
          return object.isPodcast;
      }
    } catch (_) {
      return null;
    }
    return null;
  }

  static String _normalizeStableKeyStatic(Object? value) {
    return value?.toString().trim().toLowerCase() ?? '';
  }

  static bool _sameTrackMetadata(Track a, Track b) {
    return a.mediaStoreId == b.mediaStoreId &&
        a.normalizedVolumeName == b.normalizedVolumeName &&
        _normalizeStableKeyStatic(a.stableKey) ==
            _normalizeStableKeyStatic(b.stableKey) &&
        a.title == b.title &&
        a.artist == b.artist &&
        a.albumName == b.albumName &&
        a.albumId == b.albumId &&
        a.filePath == b.filePath &&
        a.playbackUri == b.playbackUri &&
        a.duration == b.duration &&
        a.genre == b.genre &&
        a.dateAdded == b.dateAdded &&
        a.size == b.size;
  }
}
