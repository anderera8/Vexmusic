// lib/services/library/media_store_observer.dart
// ─────────────────────────────────────────────────────────────────────────────
// MediaStore content observer — extracted from MusicProvider.
// Listens to native ContentObserver events (debounced) and app lifecycle
// changes, then triggers a library sync via a callback.
// Pure service — no ChangeNotifier, no dependency on providers or models.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:rxdart/rxdart.dart';

enum LibrarySyncReason {
  mediaStoreChanged,
  coldStart,
  resume,
}

typedef SyncCallback = Future<void> Function(LibrarySyncReason reason);

class MediaStoreObserver {
  static const String _channelName = 'com.vextech.vexmusic/mediastore';

  final SyncCallback _onSyncNeeded;

  StreamSubscription<dynamic>? _mediaStoreSub;
  Timer? _lifecycleDebounceTimer;
  Set<String> _lastChangedVolumeNames = const <String>{};
  bool _disposed = false;

  MediaStoreObserver(this._onSyncNeeded);

  /// Starts listening to the native ContentObserver EventChannel.
  ///
  /// Release-safe:
  /// - no duplicate subscriptions
  /// - no events after dispose
  /// - channel errors are logged but non-fatal
  void start() {
    if (_disposed) return;
    if (_mediaStoreSub != null) return;

    try {
      _mediaStoreSub = const EventChannel(_channelName)
          .receiveBroadcastStream()
          .debounceTime(const Duration(seconds: 2))
          .listen(
        (event) {
          _lastChangedVolumeNames = _volumeNamesFromEvent(event);
          unawaited(_onChangeDetected());
        },
        onError: (Object error, StackTrace stackTrace) {
          debugPrint('[MediaObserver] EventChannel error: $error');
          debugPrintStack(stackTrace: stackTrace);
        },
        cancelOnError: false,
      );

      debugPrint('[MediaObserver] EventChannel listening');
    } catch (error, stackTrace) {
      debugPrint('[MediaObserver] EventChannel unavailable: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  /// Called whenever the native ContentObserver fires after debounce.
  Future<void> _onChangeDetected() async {
    if (_disposed) return;

    try {
      final volumes = _lastChangedVolumeNames;
      debugPrint(
        '[MediaObserver] MediaStore change detected '
        '(${volumes.isEmpty ? 'unknown volume' : volumes.join(', ')}) '
        '— starting authoritative per-volume sync',
      );
      await _onSyncNeeded(LibrarySyncReason.mediaStoreChanged);
    } catch (error, stackTrace) {
      debugPrint('[MediaObserver] Change sync failed safely: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  Set<String> get lastChangedVolumeNames =>
      Set<String>.unmodifiable(_lastChangedVolumeNames);

  Set<String> _volumeNamesFromEvent(Object? event) {
    if (event is Map) {
      final value = event['volumeName']?.toString().trim().toLowerCase();
      if (value != null && value.isNotEmpty) return <String>{value};
    }

    return const <String>{};
  }

  /// Handle app lifecycle resume with debounce.
  ///
  /// The provider still decides whether sync is allowed. This class only
  /// debounces the trigger.
  void onLifecycleResumed() {
    if (_disposed) return;

    _lifecycleDebounceTimer?.cancel();

    _lifecycleDebounceTimer = Timer(const Duration(milliseconds: 500), () {
      _lifecycleDebounceTimer = null;

      if (_disposed) return;

      unawaited(_syncOnResume());
    });
  }

  Future<void> _syncOnResume() async {
    try {
      await _onSyncNeeded(LibrarySyncReason.resume);
    } catch (error, stackTrace) {
      debugPrint('[MediaObserver] Resume sync failed safely: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  /// Cancel any pending lifecycle sync on pause.
  void onLifecyclePaused() {
    _lifecycleDebounceTimer?.cancel();
    _lifecycleDebounceTimer = null;
  }

  /// Clean up subscriptions and timers.
  void dispose() {
    _disposed = true;

    _lifecycleDebounceTimer?.cancel();
    _lifecycleDebounceTimer = null;

    unawaited(_mediaStoreSub?.cancel());
    _mediaStoreSub = null;
  }
}
