// lib/services/playlist/playlist_manager.dart
// Playlist CRUD operations.
// Playlists resolve by ID first and stableKey second.

import '../../models/music_models.dart';
import '../database_service.dart';

class PlaylistManager {
  final DatabaseService _db;

  PlaylistManager({DatabaseService? db}) : _db = db ?? DatabaseService();

  /// Loads all playlists from the database.
  ///
  /// When tracks are provided, old playlist rows are backfilled with stableKey
  /// and rows whose stableKey survived a MediaStore ID change are repaired to
  /// the current track ID.
  Future<List<Playlist>> loadPlaylists({
    List<Track> tracks = const [],
  }) async {
    if (tracks.isNotEmpty) {
      await _db.syncPlaylistStableKeys(tracks);
    }

    return _db.getPlaylists();
  }

  Future<void> createPlaylist(String name) => _db.createPlaylist(name);

  Future<void> createPlaylistWithTracks(String name, List<int> trackIds) =>
      _db.createPlaylistWithTracks(name, trackIds);

  Future<void> createPlaylistWithTrackRefs(String name, List<Track> tracks) =>
      _db.createPlaylistWithTrackRefs(name, tracks);

  Future<void> deletePlaylist(int id) => _db.deletePlaylist(id);

  Future<void> renamePlaylist(int id, String newName) =>
      _db.renamePlaylist(id, newName);

  /// Legacy ID-only add path.
  Future<bool> addTrackToPlaylist(
    int playlistId,
    int trackId, {
    bool allowDuplicate = false,
  }) =>
      _db.addTrackToPlaylist(
        playlistId,
        trackId,
        allowDuplicate: allowDuplicate,
      );

  /// Preferred dual-identity add path.
  Future<bool> addTrackToPlaylistRef(
    int playlistId,
    Track track, {
    bool allowDuplicate = false,
  }) =>
      _db.addTrackToPlaylistRef(
        playlistId,
        track,
        allowDuplicate: allowDuplicate,
      );

  /// Removes one exact playlist row, preserving other duplicate occurrences.
  Future<bool> removeTrackFromPlaylistAt(
    int playlistId,
    int playlistIndex,
  ) =>
      _db.removeTrackFromPlaylistAt(
        playlistId,
        playlistIndex,
      );

  /// Removes one immutable playlist occurrence.
  ///
  /// The index is resolved from the latest persisted playlist snapshot, so a
  /// duplicate row remains targetable even after another row is removed.
  Future<bool> removeTrackFromPlaylistEntryId(
    Playlist playlist,
    String entryId,
  ) {
    final normalized = entryId.trim();
    if (normalized.isEmpty) return Future<bool>.value(false);

    final index = playlist.trackEntryIds.indexOf(normalized);
    if (index < 0) return Future<bool>.value(false);

    return _db.removeTrackFromPlaylistAt(playlist.id, index);
  }

  /// Legacy ID-only remove path.
  Future<void> removeTrackFromPlaylist(int playlistId, int trackId) =>
      _db.removeTrackFromPlaylist(playlistId, trackId);

  /// Preferred remove path.
  Future<void> removeTrackFromPlaylistRef(int playlistId, Track track) =>
      _db.removeTrackFromPlaylistRef(playlistId, track);

  bool trackExistsInPlaylist(Playlist playlist, int trackId) =>
      playlist.trackIds.contains(trackId);

  bool trackExistsInPlaylistRef(
    Playlist playlist,
    Track track,
  ) {
    final stableKey = track.stableKey.trim();

    return playlist.trackIds.contains(track.id) ||
        (stableKey.isNotEmpty &&
            playlist.trackStableKeys.contains(stableKey));
  }

  /// Resolves playlist rows while preserving their actual stored positions.
  ///
  /// Missing/deleted tracks are omitted from the returned list, but the
  /// [PlaylistTrackEntry.playlistIndex] still points to the correct position in
  /// the persisted playlist.
  static List<PlaylistTrackEntry> entriesForPlaylist(
    Playlist playlist,
    Map<int, Track> trackById, {
    List<Track> tracks = const [],
  }) {
    final byStableKey = <String, Track>{};

    for (final track in tracks) {
      final stableKey = track.stableKey.trim();

      if (stableKey.isNotEmpty) {
        byStableKey[stableKey] = track;
      }
    }

    final result = <PlaylistTrackEntry>[];
    var length = playlist.trackIds.length;
    if (playlist.trackStableKeys.length > length) {
      length = playlist.trackStableKeys.length;
    }
    if (playlist.trackEntryIds.length > length) {
      length = playlist.trackEntryIds.length;
    }

    for (var index = 0; index < length; index++) {
      final id = index < playlist.trackIds.length
          ? playlist.trackIds[index]
          : -1;

      final stableKey = index < playlist.trackStableKeys.length
          ? playlist.trackStableKeys[index].trim()
          : '';

      final entryId = index < playlist.trackEntryIds.length
          ? playlist.trackEntryIds[index].trim()
          : '';

      final match =
          trackById[id] ?? (stableKey.isNotEmpty ? byStableKey[stableKey] : null);

      if (match == null || entryId.isEmpty) continue;

      result.add(
        PlaylistTrackEntry(
          entryId: entryId,
          playlistIndex: index,
          track: match,
        ),
      );
    }

    return result;
  }

  /// Returns the playable tracks in their stored playlist order.
  ///
  /// Duplicate entries are intentionally preserved.
  static List<Track> tracksForPlaylist(
    Playlist playlist,
    Map<int, Track> trackById, {
    List<Track> tracks = const [],
  }) {
    return entriesForPlaylist(
      playlist,
      trackById,
      tracks: tracks,
    ).map((entry) => entry.track).toList(growable: false);
  }
}
