import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;

import '../../models/music_models.dart';

class PlaylistImportResult {
  final String name;
  final List<int> trackIds;
  final List<String> unresolvedEntries;

  const PlaylistImportResult({
    required this.name,
    required this.trackIds,
    required this.unresolvedEntries,
  });
}

class PlaylistFileService {
  const PlaylistFileService._();

  static Future<PlaylistImportResult?> pickAndParse(
    List<Track> library, {
    bool allowDuplicates = false,
  }) async {
    final result = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['m3u', 'm3u8'],
    );
    if (result == null) return null;

    final selected = result;
    final bytes = await _readPlatformFileBytes(selected);
    if (bytes.isEmpty) {
      throw const FormatException('The selected playlist is empty.');
    }

    return parseBytes(
      bytes,
      fileName: selected.name,
      sourcePath: selected.path,
      library: library,
      allowDuplicates: allowDuplicates,
    );
  }

  static Future<Uint8List> _readPlatformFileBytes(PlatformFile file) async {
    final bytes = await file.readAsBytes();
    if (bytes.isNotEmpty) return bytes;
    return Uint8List(0);
  }

  static PlaylistImportResult parseBytes(
    List<int> bytes, {
    required String fileName,
    required List<Track> library,
    String? sourcePath,
    bool allowDuplicates = false,
  }) {
    final offset = bytes.length >= 3 &&
            bytes[0] == 0xef &&
            bytes[1] == 0xbb &&
            bytes[2] == 0xbf
        ? 3
        : 0;
    final content = utf8.decode(bytes.sublist(offset), allowMalformed: true);
    final entries = const LineSplitter()
        .convert(content)
        .map((line) => line.trim())
        .where((line) => line.isNotEmpty && !line.startsWith('#'))
        .toList(growable: false);

    final byPath = <String, Track>{};
    final byName = <String, List<Track>>{};
    for (final track in library) {
      final path = track.filePath;
      if (path == null || path.isEmpty) continue;
      byPath[_normalize(path)] = track;
      byName.putIfAbsent(p.basename(path).toLowerCase(), () => []).add(track);
    }

    final baseDirectory = sourcePath == null ? null : p.dirname(sourcePath);
    final ids = <int>[];
    final unresolved = <String>[];
    for (final entry in entries) {
      final resolved = baseDirectory != null && !p.isAbsolute(entry)
          ? p.normalize(p.join(baseDirectory, entry))
          : entry;
      var match = byPath[_normalize(resolved)];
      if (match == null) {
        final named = byName[p.basename(entry).toLowerCase()];
        if (named != null && named.length == 1) match = named.single;
      }
      if (match == null) {
        unresolved.add(entry);
      } else if (allowDuplicates || !ids.contains(match.id)) {
        ids.add(match.id);
      }
    }

    return PlaylistImportResult(
      name: p.basenameWithoutExtension(fileName).trim(),
      trackIds: ids,
      unresolvedEntries: unresolved,
    );
  }

  static Future<bool> export({
    required Playlist playlist,
    required List<Track> tracks,
  }) async {
    final lines = <String>['#EXTM3U'];
    for (final track in tracks) {
      final path = track.filePath;
      if (path == null || path.isEmpty) continue;
      lines
        ..add('#EXTINF:${track.duration},${track.artist} - ${track.title}')
        ..add(path);
    }
    final bytes = Uint8List.fromList(utf8.encode('${lines.join('\n')}\n'));
    final saved = await FilePicker.saveFile(
      dialogTitle: 'Export playlist',
      fileName: '${_safeFileName(playlist.name)}.m3u8',
      type: FileType.custom,
      allowedExtensions: const ['m3u8'],
      bytes: bytes,
    );
    return saved != null;
  }

  static String _normalize(String value) =>
      p.normalize(value).replaceAll('\\', '/').toLowerCase();

  static String _safeFileName(String value) {
    final cleaned = value.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_').trim();
    return cleaned.isEmpty ? 'playlist' : cleaned;
  }
}
