// lib/services/database_service.dart
// ─────────────────────────────────────────────────────────────────────────────
// Facade over the database layer.  All existing callers keep working exactly
// as before — the implementation is delegated to individual DAO classes under
// lib/services/database/daos/ so each file stays under 300 lines.
// ─────────────────────────────────────────────────────────────────────────────

// ignore_for_file: invalid_use_of_visible_for_testing_member

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import '../models/music_models.dart';
import '../models/media_models.dart';
import 'database/database_base.dart';
import 'database/daos/track_dao.dart';
import 'database/daos/album_dao.dart';
import 'database/daos/artist_dao.dart';
import 'database/daos/playlist_dao.dart';
import 'database/daos/history_dao.dart';
import 'database/daos/like_dao.dart';
import 'database/daos/media_library_dao.dart';

class DatabaseService {
  static DatabaseService? _instance;

  late final DatabaseBase _database;
  late final TrackDao _trackDao;
  late final AlbumDao _albumDao;
  late final ArtistDao _artistDao;
  late final PlaylistDao _playlistDao;
  late final HistoryDao _historyDao;
  late final LikeDao _likeDao;

  DatabaseService._() {
    _database = DatabaseBase();
    _trackDao = TrackDao(_database);
    _albumDao = AlbumDao(_database);
    _artistDao = ArtistDao(_database);
    _playlistDao = PlaylistDao(_database);
    _historyDao = HistoryDao(_database);
    _likeDao = LikeDao(_database);
  }

  factory DatabaseService() {
    _instance ??= DatabaseService._();
    return _instance!;
  }

  /// Resets the singleton so a fresh instance is created next time.
  @visibleForTesting
  static void resetInstance() {
    _instance = null;
    DatabaseBase.resetInstance();
  }

  /// Exposes the raw database for testing purposes.
  @visibleForTesting
  static Database? get testDatabase => DatabaseBase.testDatabase;

  @visibleForTesting
  static set testDatabase(Database? db) {
    DatabaseBase.testDatabase = db;
  }

  // ── Track methods (delegated) ─────────────────────────────────────────────

  Future<void> saveTracks(List<Track> tracks) => _trackDao.saveTracks(tracks);

  Future<void> commitTrackIdentityReconciliation(
    List<Track> tracks, {
    List<Track> removedTracks = const <Track>[],
    Map<String, Track> stableKeyAliases = const <String, Track>{},
  }) async {
    if (tracks.isEmpty) return;

    await _trackDao.saveTracks(tracks);
    await cleanupDeletedAudioTrackReferences(
      removedTracks,
      survivingTracks: tracks,
    );
    await synchronizeTrackIdentityReferences(
      tracks,
      stableKeyAliases: stableKeyAliases,
    );
  }

  Future<List<int>> reserveTrackIds(int count) =>
      _trackDao.reserveTrackIds(count);

  Future<List<Track>> getAllTracks() => _trackDao.getAllTracks();
  Future<bool> hasTracks() => _trackDao.hasTracks();
  Future<void> removeTracksByIds(List<int> ids) =>
      _trackDao.removeTracksByIds(ids);

  Future<void> cleanupDeletedAudioTrackReferences(
    Iterable<Track> removedTracks, {
    Iterable<Track> survivingTracks = const <Track>[],
  }) async {
    final removed = removedTracks.toList(growable: false);

    if (removed.isEmpty) return;

    final survivors = survivingTracks.toList(growable: false);

    final survivingIds = survivors
        .map((track) => track.id)
        .where((id) => id > 0)
        .toSet();

    final survivingStableKeys = survivors
        .map((track) => track.stableKey.trim())
        .where((key) => key.isNotEmpty)
        .toSet();

    final survivingPaths = survivors
        .map((track) => track.normalizedSourcePath)
        .where((path) => path.isNotEmpty)
        .toSet();

    bool survivedUnderAnotherIdentity(Track removedTrack) {
      if (survivingIds.contains(removedTrack.id)) {
        return true;
      }

      final stableKey = removedTrack.stableKey.trim();

      if (stableKey.isNotEmpty && survivingStableKeys.contains(stableKey)) {
        return true;
      }

      final path = removedTrack.normalizedSourcePath;

      return path.isNotEmpty && survivingPaths.contains(path);
    }

    final staleAppIds = removed
        .map((track) => track.id)
        .where((id) => id > 0 && !survivingIds.contains(id))
        .toSet()
        .toList(growable: false);

    final trulyDeleted = removed
        .where((track) => !survivedUnderAnotherIdentity(track))
        .toList(growable: false);

    if (staleAppIds.isNotEmpty) {
      await _trackDao.removeTracksByIds(staleAppIds);
    }

    if (trulyDeleted.isNotEmpty) {
      await _likeDao.unlikeTrackRefs(trulyDeleted);
      await _historyDao.removeTrackRefs(trulyDeleted);
      await _playlistDao.removeTrackRefsFromAllPlaylists(trulyDeleted);
    }

    await _ensureMediaLibraryDao();

    await _mediaLibraryDao!.deleteAudioRefs(
      appIds: staleAppIds,
      stableKeys: trulyDeleted.map((track) => track.stableKey),
    );

    debugPrint(
      '[DatabaseService] Cleaned audio identities: '
      '${staleAppIds.length} stale app IDs, '
      '${trulyDeleted.length} deleted tracks',
    );
  }

  Future<void> cleanupDeletedAudioTrackIds(
    Iterable<int> trackIds,
  ) async {
    final ids = trackIds.toSet().where((id) => id > 0).toList();
    if (ids.isEmpty) return;

    await _trackDao.removeTracksByIds(ids);
    await _likeDao.unlikeTracks(ids);
    await _historyDao.removeTracks(ids);
    await _playlistDao.removeTracksFromAllPlaylists(ids);

    await _ensureMediaLibraryDao();
    await _mediaLibraryDao!.deleteAudioIds(ids);

    debugPrint(
      '[DatabaseService] Cleaned deleted audio references: ${ids.length}',
    );
  }

  /// Clears the persisted audio library after a successful scan confirms that
  /// no eligible audio remains on the device.
  ///
  /// This must never be called for a failed scan.
  Future<void> clearScannedAudioLibrary() async {
    final tracks = await _trackDao.getAllTracks();

    await cleanupDeletedAudioTrackReferences(tracks);

    await _albumDao.savealbums(const <Album>[]);
    await _artistDao.saveArtists(const <Artist>[]);

    await _ensureMediaLibraryDao();
    await _mediaLibraryDao!.deleteAllByKind(MediaKind.audio);

    debugPrint(
      '[DatabaseService] Cleared successfully scanned empty library',
    );
  }

  Future<void> updateTrack(Track track) => _trackDao.updateTrack(track);

  // ── album methods (delegated) ─────────────────────────────────────────────

  Future<void> savealbums(List<Album> albums) => _albumDao.savealbums(albums);
  Future<List<Album>> getAllalbums() => _albumDao.getAllalbums();

  // ── Artist methods (delegated) ────────────────────────────────────────────

  Future<void> saveArtists(List<Artist> artists) =>
      _artistDao.saveArtists(artists);
  Future<List<Artist>> getAllArtists() => _artistDao.getAllArtists();

  // ── Playlist methods (delegated) ──────────────────────────────────────────

  Future<List<Playlist>> getPlaylists() => _playlistDao.getPlaylists();
  Future<int> createPlaylist(String name, {String art = '🎵'}) =>
      _playlistDao.createPlaylist(name, art: art);

  Future<int> createPlaylistWithTracks(
    String name,
    List<int> trackIds, {
    List<String> stableKeys = const [],
  }) =>
      _playlistDao.createPlaylistWithTracks(
        name,
        trackIds,
        stableKeys: stableKeys,
      );

  Future<int> createPlaylistWithTrackRefs(String name, List<Track> tracks) =>
      _playlistDao.createPlaylistWithTrackRefs(name, tracks);
  Future<void> deletePlaylist(int id) => _playlistDao.deletePlaylist(id);

  Future<bool> addTrackToPlaylist(
    int playlistId,
    int trackId, {
    bool allowDuplicate = false,
  }) =>
      _playlistDao.addTrackToPlaylist(
        playlistId,
        trackId,
        allowDuplicate: allowDuplicate,
      );

  Future<bool> addTrackToPlaylistRef(
    int playlistId,
    Track track, {
    bool allowDuplicate = false,
  }) =>
      _playlistDao.addTrackToPlaylistRef(
        playlistId,
        track,
        allowDuplicate: allowDuplicate,
      );

  Future<bool> removeTrackFromPlaylistAt(
    int playlistId,
    int playlistIndex,
  ) =>
      _playlistDao.removeTrackFromPlaylistAt(
        playlistId,
        playlistIndex,
      );

  Future<void> removeTrackFromPlaylist(int playlistId, int trackId) =>
      _playlistDao.removeTrackFromPlaylist(playlistId, trackId);

  Future<void> removeTrackFromPlaylistRef(int playlistId, Track track) =>
      _playlistDao.removeTrackFromPlaylistRef(playlistId, track);

  Future<void> syncPlaylistStableKeys(List<Track> tracks) =>
      _playlistDao.backfillStableKeysForTracks(tracks);

  Future<void> synchronizeTrackIdentityReferences(
    List<Track> tracks, {
    Map<String, Track> stableKeyAliases = const <String, Track>{},
  }) async {
    if (tracks.isEmpty) return;

    await _likeDao.backfillStableKeysForTracks(
      tracks,
      stableKeyAliases: stableKeyAliases,
    );
    await _historyDao.backfillStableKeysForTracks(
      tracks,
      stableKeyAliases: stableKeyAliases,
    );
    await _playlistDao.backfillStableKeysForTracks(
      tracks,
      stableKeyAliases: stableKeyAliases,
    );
  }

  Future<void> removeTracksFromAllPlaylists(Iterable<int> trackIds) =>
      _playlistDao.removeTracksFromAllPlaylists(trackIds);

  Future<void> renamePlaylist(int id, String newName) =>
      _playlistDao.renamePlaylist(id, newName);

  // ── History methods (delegated) ───────────────────────────────────────────

  Future<void> recordPlay(Track track, {int lastPositionMs = 0}) =>
      _historyDao.recordPlay(track, lastPositionMs: lastPositionMs);

  Future<PlayHistory?> getLastPlayForTrack(int trackId) =>
      _historyDao.getLastPlayForTrack(trackId);

  Future<PlayHistory?> getLastPlayForTrackRef(Track track) =>
      _historyDao.getLastPlayForTrackRef(track);

  Future<PlayHistory?> getLastResumePointForTrack(int trackId) =>
      _historyDao.getLastResumePointForTrack(trackId);

  Future<PlayHistory?> getLastResumePointForTrackRef(Track track) =>
      _historyDao.getLastResumePointForTrackRef(track);

  Future<List<PlayHistory>> getRecentHistory({int limit = 30}) =>
      _historyDao.getRecentHistory(limit: limit);

  Future<void> syncPlayHistoryStableKeys(List<Track> tracks) =>
      _historyDao.backfillStableKeysForTracks(tracks);

  Future<void> clearHistory() => _historyDao.clearHistory();

  Future<void> removeTrackHistory(int trackId) =>
      _historyDao.removeTrack(trackId);

  Future<void> removeTrackHistoryRef(Track track) =>
      _historyDao.removeTrackRef(track);

  // ── Likes methods (delegated) ─────────────────────────────────────────────

  Future<Set<int>> getLikedTrackIds() => _likeDao.getLikedTrackIds();

  Future<({Set<int> trackIds, Set<String> stableKeys})> getLikedTrackRefs() =>
      _likeDao.getLikedTrackRefs();

  Future<({
    Set<int> trackIds,
    Set<int> legacyTrackIds,
    Set<String> stableKeys,
  })> getLikedTrackIdentityRefs() =>
      _likeDao.getLikedTrackIdentityRefs();

  Future<bool> isTrackLikedRef(Track track) =>
      _likeDao.isTrackLikedRef(track);

  Future<void> likeTrack(int trackId) => _likeDao.likeTrack(trackId);

  Future<void> likeTrackRef(Track track) => _likeDao.likeTrackRef(track);

  Future<void> unlikeTrack(int trackId) => _likeDao.unlikeTrack(trackId);

  Future<void> unlikeTrackRef(Track track) => _likeDao.unlikeTrackRef(track);

  Future<void> syncLikedTrackStableKeys(List<Track> tracks) =>
      _likeDao.backfillStableKeysForTracks(tracks);

  // ── Media library ─────────────────────────────────────────────────────

  /// Returns all available media entries from the unified library.
  Future<List<MediaEntry>> getMediaLibrary() async {
    await _ensureMediaLibraryDao();
    return _mediaLibraryDao!.getAll();
  }

  /// Returns whether the media library has any entries.
  Future<bool> hasMediaLibrary() async {
    await _ensureMediaLibraryDao();
    return _mediaLibraryDao!.hasEntries();
  }

  /// Upserts a batch of media entries into the unified library.
  Future<void> saveMediaLibrary(List<MediaEntry> entries) async {
    await _ensureMediaLibraryDao();
    await _mediaLibraryDao!.upsertAll(entries);
  }

  Future<void> deleteMediaLibraryEntry(String id, MediaKind kind) async {
    await _ensureMediaLibraryDao();
    await _mediaLibraryDao!.deleteById(id, kind);
  }

  /// Migrates legacy audio tracks into the media library.
  Future<void> migrateToMediaLibrary() async {
    await _ensureMediaLibraryDao();
    await _mediaLibraryDao!.migrateFromLegacyTables();
  }

  MediaLibraryDao? _mediaLibraryDao;

  Future<void> _ensureMediaLibraryDao() async {
    _mediaLibraryDao ??= MediaLibraryDao(_database);
  }

  // ── Utility (delegated) ───────────────────────────────────────────────────

  Future<void> clearAllData() async {
    final database = await _database.db;
    await database.delete('tracks');
    await database.delete('albums');
    await database.delete('artists');
    await database.delete('playlists');
    await database.delete('play_history');
    await database.delete('liked_tracks');
    debugPrint('[DatabaseService] All data cleared');
  }

  Future<void> close() => _database.close();
}
