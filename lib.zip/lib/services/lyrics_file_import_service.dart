import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

import 'lyrics_service.dart';

class LyricsFileImportService {
  const LyricsFileImportService._();

  static Future<LyricsData?> pickAndParse() async {
    final result = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['lrc', 'txt'],
    );
    if (result == null) return null;

    final bytes = await _readPlatformFileBytes(result);
    if (bytes.isEmpty) {
      throw const FormatException('The selected file could not be read.');
    }

    return parseBytes(bytes);
  }

  static Future<Uint8List> _readPlatformFileBytes(PlatformFile file) async {
    final bytes = await file.readAsBytes();
    if (bytes.isNotEmpty) return bytes;
    return Uint8List(0);
  }

  static LyricsData parseBytes(List<int> bytes) {
    final content = LyricsService.decodeTextBytes(bytes);
    if (content.trim().isEmpty) {
      throw const FormatException('The selected lyrics file is empty.');
    }

    return content.contains(RegExp(r'\[\d{1,3}:\d{2}'))
        ? LyricsService.parseLrc(content)
        : LyricsService.parsePlainText(content);
  }


}
