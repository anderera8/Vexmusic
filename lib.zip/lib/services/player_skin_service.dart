import 'prefs_service.dart';

class PlayerSkinSettings {
  final String layoutStyle;
  final String artworkShape;
  final String artworkStyle;
  final String backgroundStyle;
  final String headerStyle;
  final bool showalbumArt;
  final bool showSeekBar;
  final bool showQueueInfo;
  final bool adaptiveColors;
  final bool lyricsFocusMode;
  final String visualizerMode;
  final double artworkRadius;
  final double visualizerHue;

  const PlayerSkinSettings({
    this.layoutStyle = 'default',
    this.artworkShape = 'rounded',
    this.artworkStyle = 'standard',
    this.backgroundStyle = 'gradient',
    this.headerStyle = 'shimmer',
    this.showalbumArt = true,
    this.showSeekBar = true,
    this.showQueueInfo = true,
    this.adaptiveColors = true,
    this.lyricsFocusMode = true,
    this.visualizerMode = 'off',
    this.artworkRadius = 28,
    this.visualizerHue = 261, // a violet close to the app's default accent
  });

  PlayerSkinSettings copyWith({
    String? layoutStyle,
    String? artworkShape,
    String? artworkStyle,
    String? backgroundStyle,
    String? headerStyle,
    bool? showalbumArt,
    bool? showSeekBar,
    bool? showQueueInfo,
    bool? adaptiveColors,
    bool? lyricsFocusMode,
    String? visualizerMode,
    double? artworkRadius,
    double? visualizerHue,
  }) {
    return PlayerSkinSettings(
      layoutStyle: layoutStyle ?? this.layoutStyle,
      artworkShape: artworkShape ?? this.artworkShape,
      artworkStyle: artworkStyle ?? this.artworkStyle,
      backgroundStyle: backgroundStyle ?? this.backgroundStyle,
      headerStyle: headerStyle ?? this.headerStyle,
      showalbumArt: showalbumArt ?? this.showalbumArt,
      showSeekBar: showSeekBar ?? this.showSeekBar,
      showQueueInfo: showQueueInfo ?? this.showQueueInfo,
      adaptiveColors: adaptiveColors ?? this.adaptiveColors,
      lyricsFocusMode: lyricsFocusMode ?? this.lyricsFocusMode,
      visualizerMode: visualizerMode ?? this.visualizerMode,
      artworkRadius: artworkRadius ?? this.artworkRadius,
      visualizerHue: visualizerHue ?? this.visualizerHue,
    );
  }
}

class PlayerSkinService {
  static const _layoutStyleKey = 'playerSkin.layoutStyle';
  static const _artworkShapeKey = 'playerSkin.artworkShape';
  static const _artworkStyleKey = 'playerSkin.artworkStyle';
  static const _backgroundStyleKey = 'playerSkin.backgroundStyle';
  static const _headerStyleKey = 'playerSkin.headerStyle';
  static const _showalbumArtKey = 'playerSkin.showalbumArt';
  static const _showSeekBarKey = 'playerSkin.showSeekBar';
  static const _showQueueInfoKey = 'playerSkin.showQueueInfo';
  static const _adaptiveColorsKey = 'playerSkin.adaptiveColors';
  static const _lyricsFocusModeKey = 'playerSkin.lyricsFocusMode';
  static const _visualizerModeKey = 'playerSkin.visualizerMode';
  static const _artworkRadiusKey = 'playerSkin.artworkRadius';
  static const _visualizerHueKey = 'playerSkin.visualizerHue';

  static Future<PlayerSkinSettings> getSettings() async {
    return PlayerSkinSettings(
      layoutStyle: PrefsService.getString(_layoutStyleKey) ?? 'default',
      artworkShape: PrefsService.getString(_artworkShapeKey) ?? 'rounded',
      artworkStyle: PrefsService.getString(_artworkStyleKey) ?? 'standard',
      backgroundStyle:
          PrefsService.getString(_backgroundStyleKey) ?? 'gradient',
      headerStyle: PrefsService.getString(_headerStyleKey) ?? 'shimmer',
      showalbumArt: PrefsService.getBool(_showalbumArtKey) ?? true,
      showSeekBar: PrefsService.getBool(_showSeekBarKey) ?? true,
      showQueueInfo: PrefsService.getBool(_showQueueInfoKey) ?? true,
      adaptiveColors: PrefsService.getBool(_adaptiveColorsKey) ?? true,
      lyricsFocusMode: PrefsService.getBool(_lyricsFocusModeKey) ?? true,
      visualizerMode: _normalizeVisualizerMode(
        PrefsService.getString(_visualizerModeKey),
      ),
      artworkRadius: PrefsService.getDouble(_artworkRadiusKey) ?? 28,
      visualizerHue: _normalizeHue(
        PrefsService.getDouble(_visualizerHueKey),
      ),
    );
  }

  static String _normalizeVisualizerMode(String? value) {
    if (value == 'bars' || value == 'wave' || value == 'mirror') {
      return value!;
    }
    return 'off';
  }

  static double _normalizeHue(double? value) {
    if (value == null || value.isNaN) return 261;
    return value % 360;
  }

  static Future<void> saveSettings(PlayerSkinSettings settings) async {
    await Future.wait([
      PrefsService.setString(_layoutStyleKey, settings.layoutStyle),
      PrefsService.setString(_artworkShapeKey, settings.artworkShape),
      PrefsService.setString(_artworkStyleKey, settings.artworkStyle),
      PrefsService.setString(_backgroundStyleKey, settings.backgroundStyle),
      PrefsService.setString(_headerStyleKey, settings.headerStyle),
      PrefsService.setBool(_showalbumArtKey, settings.showalbumArt),
      PrefsService.setBool(_showSeekBarKey, settings.showSeekBar),
      PrefsService.setBool(_showQueueInfoKey, settings.showQueueInfo),
      PrefsService.setBool(_adaptiveColorsKey, settings.adaptiveColors),
      PrefsService.setBool(_lyricsFocusModeKey, settings.lyricsFocusMode),
      PrefsService.setString(
        _visualizerModeKey,
        _normalizeVisualizerMode(settings.visualizerMode),
      ),
      PrefsService.setDouble(_artworkRadiusKey, settings.artworkRadius),
      PrefsService.setDouble(
        _visualizerHueKey,
        _normalizeHue(settings.visualizerHue),
      ),
    ]);
  }
}
