import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class NativeMediaLibraryService {
  static const String _channelName = 'com.vextech.vexmusic/media_library';
  static const MethodChannel _channel = MethodChannel(_channelName);

  static NativeMediaLibraryService? _instance;

  /// Shared singleton used by scanners, artwork cache, and permission checks.
  static NativeMediaLibraryService get instance =>
      _instance ??= NativeMediaLibraryService._();

  NativeMediaLibraryService._();

  /// The native MediaStore bridge is Android-only.
  static bool get isSupported => !kIsWeb && Platform.isAndroid;
  Future<bool> hasPermission() async {
    if (!isSupported) return false;

    final granted = await _channel.invokeMethod<bool>('hasPermission');
    return granted ?? false;
  }

  Future<NativeAudioScanSnapshot> queryAudioVolumes({
    Duration minDuration = Duration.zero,
    bool includeInternal = false,
    bool includeRingtones = false,
    bool includeAlarms = false,
    bool includeNotifications = false,
    bool includePodcasts = true,
    Iterable<String> knownVolumeNames = const <String>[],
  }) async {
    if (!isSupported) {
      throw UnsupportedError(
        'The native MediaStore audio bridge is only available on Android.',
      );
    }

    final normalizedKnownVolumes = knownVolumeNames
        .map((value) => value.trim().toLowerCase())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList(growable: false)
      ..sort();

    final args = <String, Object?>{
      'minDurationMs': minDuration.inMilliseconds,
      'includeInternal': includeInternal,
      'includeRingtones': includeRingtones,
      'includeAlarms': includeAlarms,
      'includeNotifications': includeNotifications,
      'includePodcasts': includePodcasts,
      'knownVolumeNames': normalizedKnownVolumes,
    };

    try {
      final response = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'queryAudioVolumes',
        args,
      );

      if (response == null) {
        throw const FormatException(
          'Native volume scan returned a null response.',
        );
      }

      final snapshot = NativeAudioScanSnapshot.fromMap(response);
      final normalizedVolumes = snapshot.volumes
          .map(
            (volume) => volume.copyWith(
              records: _dedupeAndSort(volume.records),
            ),
          )
          .toList(growable: false);

      return snapshot.copyWith(volumes: normalizedVolumes);
    } on PlatformException catch (error, stackTrace) {
      debugPrint(
        '[NativeMediaLibrary] queryAudioVolumes failed: '
        '${error.code} ${error.message}',
      );
      Error.throwWithStackTrace(error, stackTrace);
    } catch (error, stackTrace) {
      debugPrint('[NativeMediaLibrary] queryAudioVolumes failed: $error');
      Error.throwWithStackTrace(error, stackTrace);
    }
  }

  /// Compatibility API that returns records from authoritative volumes only.
  Future<List<NativeAudioRecord>> queryAudio({
    Duration minDuration = Duration.zero,
    bool includeInternal = false,
    bool includeRingtones = false,
    bool includeAlarms = false,
    bool includeNotifications = false,
    bool includePodcasts = true,
    Iterable<String> knownVolumeNames = const <String>[],
  }) async {
    final snapshot = await queryAudioVolumes(
      minDuration: minDuration,
      includeInternal: includeInternal,
      includeRingtones: includeRingtones,
      includeAlarms: includeAlarms,
      includeNotifications: includeNotifications,
      includePodcasts: includePodcasts,
      knownVolumeNames: knownVolumeNames,
    );

    return snapshot.records;
  }

  Future<Uint8List?> loadArtwork(
    int id, {
    NativeArtworkType type = NativeArtworkType.audio,
    String? volumeName,
    int size = 512,
    int quality = 90,
    String format = 'jpeg',
  }) async {
    if (!isSupported || id <= 0) return null;

    final safeSize = size.clamp(64, 2048).toInt();
    final safeQuality = quality.clamp(1, 100).toInt();
    final safeFormat = format.toLowerCase() == 'png' ? 'png' : 'jpeg';
    final normalizedVolumeName = _normalizeVolumeName(volumeName);

    try {
      final bytes = await _channel.invokeMethod<Uint8List>(
        'loadArtwork',
        <String, Object?>{
          'id': id,
          'type': type.nativeValue,
          'volumeName': _emptyToNull(normalizedVolumeName),
          'size': safeSize,
          'quality': safeQuality,
          'format': safeFormat,
        },
      );

      if (bytes == null || bytes.isEmpty) return null;
      return bytes;
    } on PlatformException catch (error) {
      debugPrint(
        '[NativeMediaLibrary] loadArtwork failed: '
        '${error.code} ${error.message}',
      );
      return null;
    } catch (error) {
      debugPrint('[NativeMediaLibrary] loadArtwork failed: $error');
      return null;
    }
  }

  List<NativeAudioRecord> _dedupeAndSort(
    List<NativeAudioRecord> records,
  ) {
    if (records.isEmpty) {
      return const <NativeAudioRecord>[];
    }

    final byNativeIdentity =
        <String, NativeAudioRecord>{};

    for (final record in records) {
      final stableKey =
          record.stableKey.trim().toLowerCase();

      final identity = stableKey.isNotEmpty
          ? 'stable:$stableKey'
          : 'source:${record.volumeScopedMediaStoreKey}';

      byNativeIdentity.putIfAbsent(
        identity,
        () => record,
      );
    }

    final result =
        byNativeIdentity.values.toList(
      growable: false,
    );

    result.sort((a, b) {
      final titleCompare =
          a.title.toLowerCase().compareTo(
                b.title.toLowerCase(),
              );

      if (titleCompare != 0) {
        return titleCompare;
      }

      final artistCompare =
          a.artist.toLowerCase().compareTo(
                b.artist.toLowerCase(),
              );

      if (artistCompare != 0) {
        return artistCompare;
      }

      final volumeCompare =
          a.normalizedVolumeName.compareTo(
                b.normalizedVolumeName,
              );

      if (volumeCompare != 0) {
        return volumeCompare;
      }

      return a.mediaStoreId.compareTo(
        b.mediaStoreId,
      );
    });

    return List<NativeAudioRecord>.unmodifiable(
      result,
    );
  }
}

enum NativeVolumeScanStatus {
  success,
  unavailable,
  permissionDenied,
  failed;

  factory NativeVolumeScanStatus.fromNative(Object? value) {
    switch (value?.toString().trim().toLowerCase()) {
      case 'success':
        return NativeVolumeScanStatus.success;
      case 'unavailable':
        return NativeVolumeScanStatus.unavailable;
      case 'permission_denied':
        return NativeVolumeScanStatus.permissionDenied;
      default:
        return NativeVolumeScanStatus.failed;
    }
  }
}

@immutable
class NativeVolumeScanResult {
  const NativeVolumeScanResult({
    required this.volumeName,
    required this.status,
    required this.records,
    this.errorCode,
    this.message,
  });

  factory NativeVolumeScanResult.fromMap(Map<dynamic, dynamic> map) {
    final volumeName = _normalizeVolumeName(map['volumeName']);
    if (volumeName.isEmpty) {
      throw const FormatException('Volume scan result has no volume name.');
    }

    var status = NativeVolumeScanStatus.fromNative(map['status']);
    final rawRecords = map['records'];
    final records = <NativeAudioRecord>[];
    var malformedRows = 0;

    if (rawRecords is Iterable) {
      for (final row in rawRecords) {
        if (row is! Map) {
          malformedRows++;
          continue;
        }

        try {
          records.add(NativeAudioRecord.fromMap(row));
        } catch (error) {
          malformedRows++;
          debugPrint(
            '[NativeMediaLibrary] skipped malformed $volumeName row: $error',
          );
        }
      }
    } else if (status == NativeVolumeScanStatus.success) {
      malformedRows++;
    }

    if (malformedRows > 0 && status == NativeVolumeScanStatus.success) {
      status = NativeVolumeScanStatus.failed;
    }

    return NativeVolumeScanResult(
      volumeName: volumeName,
      status: status,
      records: List<NativeAudioRecord>.unmodifiable(records),
      errorCode: _emptyToNull(_asString(map['errorCode'])),
      message: _emptyToNull(_asString(map['message'])),
    );
  }

  final String volumeName;
  final NativeVolumeScanStatus status;
  final List<NativeAudioRecord> records;
  final String? errorCode;
  final String? message;

  bool get isAuthoritative => status == NativeVolumeScanStatus.success;

  NativeVolumeScanResult copyWith({
    List<NativeAudioRecord>? records,
  }) {
    return NativeVolumeScanResult(
      volumeName: volumeName,
      status: status,
      records: records ?? this.records,
      errorCode: errorCode,
      message: message,
    );
  }
}

@immutable
class NativeAudioScanSnapshot {
  const NativeAudioScanSnapshot({
    required this.permissionGranted,
    required this.volumes,
    required this.generatedAtMillis,
  });

  factory NativeAudioScanSnapshot.fromMap(Map<dynamic, dynamic> map) {
    final rawVolumes = map['volumes'];
    if (rawVolumes is! Iterable) {
      throw const FormatException(
        'Native volume scan response has no volume results.',
      );
    }

    final volumes = <NativeVolumeScanResult>[];
    for (final rawVolume in rawVolumes) {
      if (rawVolume is! Map) continue;
      volumes.add(NativeVolumeScanResult.fromMap(rawVolume));
    }

    if (volumes.isEmpty) {
      throw const FormatException(
        'Native volume scan response contained no valid volumes.',
      );
    }

    return NativeAudioScanSnapshot(
      permissionGranted: _asBool(
        map['permissionGranted'],
        defaultValue: true,
      ),
      volumes: List<NativeVolumeScanResult>.unmodifiable(volumes),
      generatedAtMillis: _asInt(map['generatedAtMillis']) ?? 0,
    );
  }

  final bool permissionGranted;
  final List<NativeVolumeScanResult> volumes;
  final int generatedAtMillis;

  List<NativeAudioRecord> get records => List<NativeAudioRecord>.unmodifiable(
        volumes
            .where((volume) => volume.isAuthoritative)
            .expand((volume) => volume.records),
      );

  Set<String> get authoritativeVolumeNames => volumes
      .where((volume) => volume.isAuthoritative)
      .map((volume) => volume.volumeName)
      .toSet();

  Set<String> get nonAuthoritativeVolumeNames => volumes
      .where((volume) => !volume.isAuthoritative)
      .map((volume) => volume.volumeName)
      .toSet();

  bool get hasAuthoritativeVolumes => authoritativeVolumeNames.isNotEmpty;

  bool get isFullyAuthoritative =>
      volumes.isNotEmpty && volumes.every((volume) => volume.isAuthoritative);

  NativeAudioScanSnapshot copyWith({
    List<NativeVolumeScanResult>? volumes,
  }) {
    return NativeAudioScanSnapshot(
      permissionGranted: permissionGranted,
      volumes: volumes ?? this.volumes,
      generatedAtMillis: generatedAtMillis,
    );
  }
}

enum NativeArtworkType {
  audio('audio'),
  album('album');

  const NativeArtworkType(this.nativeValue);

  final String nativeValue;
}


class NativeAudioRecord {
  final int id;
  final int mediaStoreId;
  final String stableKey;
  final String uri;
  final String title;
  final String artist;
  final String album;
  final int? albumId;
  final int? artistId;
  final int durationMs;
  final int size;
  final int dateAdded;
  final int dateModified;
  final int? track;
  final int? year;
  final String? mimeType;
  final String? displayName;
  final String? data;
  final String? path;
  final String? relativePath;
  final String? volumeName;
  final String? composer;
  final String? folder;
  final String? extension;
  final bool isMusic;
  final bool isRingtone;
  final bool isAlarm;
  final bool isNotification;
  final bool isPodcast;

  const NativeAudioRecord({
    required this.id,
    required this.mediaStoreId,
    required this.stableKey,
    required this.uri,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.artistId,
    required this.durationMs,
    required this.size,
    required this.dateAdded,
    required this.dateModified,
    required this.track,
    required this.year,
    required this.mimeType,
    required this.displayName,
    required this.data,
    required this.path,
    required this.relativePath,
    required this.volumeName,
    required this.composer,
    required this.folder,
    required this.extension,
    required this.isMusic,
    required this.isRingtone,
    required this.isAlarm,
    required this.isNotification,
    required this.isPodcast,
  });

  factory NativeAudioRecord.fromMap(
    Map<dynamic, dynamic> map,
  ) {
    final mediaStoreId =
        _asInt(map['mediaStoreId']) ??
            _asInt(map['id']) ??
            0;

    if (mediaStoreId <= 0) {
      throw const FormatException(
        'Native audio row has no valid MediaStore ID.',
      );
    }

    final uri = _asString(map['uri']) ?? '';

    if (uri.isEmpty) {
      throw const FormatException(
        'Native audio row has no playback URI.',
      );
    }

    final volumeName = _normalizeVolumeName(
      _emptyToNull(
            _asString(map['volumeName']),
          ) ??
          _volumeNameFromUri(uri),
    );

    if (volumeName.isEmpty) {
      throw const FormatException(
        'Native audio row has no MediaStore volume.',
      );
    }

    final stableKey =
        _asString(map['stableKey'])?.toLowerCase() ?? '';

    if (stableKey.isEmpty) {
      throw const FormatException(
        'Native audio row has no stable source identity.',
      );
    }

    final durationMs =
        _asInt(map['durationMs']) ??
            _asInt(map['duration']) ??
            0;

    return NativeAudioRecord(
      id: mediaStoreId,
      mediaStoreId: mediaStoreId,
      stableKey: stableKey,
      uri: uri,
      title: _cleanUnknown(_asString(map['title']), 'Unknown Title'),
      artist: _cleanUnknown(_asString(map['artist']), 'Unknown Artist'),
      album: _cleanUnknown(_asString(map['album']), 'Unknown album'),
      albumId: _positiveOrNull(_asInt(map['albumId'])),
      artistId: _positiveOrNull(_asInt(map['artistId'])),
      durationMs: durationMs < 0 ? 0 : durationMs,
      size: (_asInt(map['size']) ?? 0).clamp(0, 1 << 62).toInt(),
      dateAdded: _normalizeEpochMillis(_asInt(map['dateAdded'])),
      dateModified: _normalizeEpochMillis(_asInt(map['dateModified'])),
      track: _asInt(map['track']),
      year: _asInt(map['year']),
      mimeType: _emptyToNull(_asString(map['mimeType'])),
      displayName: _emptyToNull(_asString(map['displayName'])),
      data: _emptyToNull(_asString(map['data'])),
      path: _emptyToNull(_asString(map['path'])),
      relativePath: _emptyToNull(_asString(map['relativePath'])),
      volumeName: volumeName,
      composer: _emptyToNull(_asString(map['composer'])),
      folder: _emptyToNull(_asString(map['folder'])),
      extension: _emptyToNull(_asString(map['extension']))?.toLowerCase(),
      isMusic: _asBool(map['isMusic'], defaultValue: true),
      isRingtone: _asBool(map['isRingtone']),
      isAlarm: _asBool(map['isAlarm']),
      isNotification: _asBool(map['isNotification']),
      isPodcast: _asBool(map['isPodcast']),
    );
  }

  int get durationSeconds =>
      (durationMs / 1000).round();

  String get normalizedVolumeName =>
      _normalizeVolumeName(volumeName);

  String get volumeScopedMediaStoreKey =>
      '$normalizedVolumeName:$mediaStoreId';

  String get resolvedPath => path?.trim().isNotEmpty == true
      ? path!.trim()
      : data?.trim().isNotEmpty == true
          ? data!.trim()
          : uri;

  Map<String, Object?> toMap() => <String, Object?>{
        'id': mediaStoreId,
        'mediaStoreId': mediaStoreId,
        'stableKey': stableKey,
        'uri': uri,
        'title': title,
        'artist': artist,
        'album': album,
        'albumId': albumId,
        'artistId': artistId,
        'duration': durationMs,
        'durationSeconds': durationSeconds,
        'size': size,
        'dateAdded': dateAdded,
        'dateModified': dateModified,
        'track': track,
        'year': year,
        'mimeType': mimeType,
        'displayName': displayName,
        'data': data,
        'path': path,
        'relativePath': relativePath,
        'volumeName': volumeName,
        'composer': composer,
        'folder': folder,
        'extension': extension,
        'isMusic': isMusic,
        'isRingtone': isRingtone,
        'isAlarm': isAlarm,
        'isNotification': isNotification,
        'isPodcast': isPodcast,
      };
}

String? _volumeNameFromUri(
  String uriText,
) {
  final uri = Uri.tryParse(uriText);

  if (uri == null ||
      uri.scheme.toLowerCase() != 'content' ||
      uri.authority.toLowerCase() != 'media' ||
      uri.pathSegments.isEmpty) {
    return null;
  }

  final volume = _normalizeVolumeName(uri.pathSegments.first);

  return volume.isEmpty ? null : volume;
}

String _normalizeVolumeName(Object? value) {
  final normalized = value?.toString().trim().toLowerCase() ?? '';
  if (normalized == 'external') return 'external_primary';
  return normalized;
}

int? _asInt(dynamic value) {
  if (value == null) return null;
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim());
  return null;
}

String? _asString(dynamic value) {
  if (value == null) return null;
  final text = value.toString().trim();
  return text.isEmpty ? null : text;
}

bool _asBool(dynamic value, {bool defaultValue = false}) {
  if (value == null) return defaultValue;
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) {
    final lower = value.trim().toLowerCase();
    if (lower == 'true' || lower == '1' || lower == 'yes') return true;
    if (lower == 'false' || lower == '0' || lower == 'no') return false;
  }
  return defaultValue;
}

int? _positiveOrNull(int? value) {
  if (value == null || value <= 0) return null;
  return value;
}

String? _emptyToNull(String? value) {
  final text = value?.trim();
  if (text == null || text.isEmpty) return null;
  return text;
}

String _cleanUnknown(String? value, String fallback) {
  final text = value?.trim();
  if (text == null || text.isEmpty || text.toLowerCase() == '<unknown>') {
    return fallback;
  }
  return text;
}

int _normalizeEpochMillis(int? value) {
  if (value == null || value <= 0) return 0;
  if (value < 1000000000000) return value * 1000;
  return value;
}
