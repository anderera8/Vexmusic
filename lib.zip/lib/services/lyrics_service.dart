import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// A word-level timestamp from enhanced LRC (`<mm:ss.xx>word`) data.
class LyricWord {
  final Duration timestamp;
  final String text;

  const LyricWord({
    required this.timestamp,
    required this.text,
  });

  Map<String, Object?> toJson() => <String, Object?>{
        'timestampMs': timestamp.inMilliseconds,
        'text': text,
      };

  factory LyricWord.fromJson(Map<String, dynamic> json) => LyricWord(
        timestamp: Duration(
          milliseconds: (json['timestampMs'] as num?)?.toInt() ?? 0,
        ),
        text: json['text']?.toString() ?? '',
      );
}

/// Represents a single line of synced lyrics with its timestamp.
class LyricLine {
  final Duration timestamp;
  final String text;
  final List<LyricWord> words;

  const LyricLine({
    required this.timestamp,
    required this.text,
    this.words = const <LyricWord>[],
  });

  Map<String, Object?> toJson() => <String, Object?>{
        'timestampMs': timestamp.inMilliseconds,
        'text': text,
        'words': words.map((word) => word.toJson()).toList(growable: false),
      };

  factory LyricLine.fromJson(Map<String, dynamic> json) => LyricLine(
        timestamp: Duration(
          milliseconds: (json['timestampMs'] as num?)?.toInt() ?? 0,
        ),
        text: json['text']?.toString() ?? '',
        words: (json['words'] as List<dynamic>? ?? const <dynamic>[])
            .whereType<Map>()
            .map(
              (word) => LyricWord.fromJson(
                Map<String, dynamic>.from(word),
              ),
            )
            .toList(growable: false),
      );

  @override
  String toString() => '[${_formatDuration(timestamp)}] $text';

  static String _formatDuration(Duration d) {
    final min = d.inMinutes.toString().padLeft(2, '0');
    final sec = (d.inSeconds % 60).toString().padLeft(2, '0');
    final ms =
        (d.inMilliseconds % 1000).toString().padLeft(2, '0').substring(0, 2);
    return '$min:$sec.$ms';
  }
}

enum LyricsTiming { plain, synced }

class LyricsFetchException implements Exception {
  final String message;

  const LyricsFetchException(this.message);

  @override
  String toString() => message;
}

/// Parsed lyric content with optional metadata and timing.
class LyricsData {
  final String? title;
  final String? artist;
  final String? album;
  final String? author;
  final List<LyricLine> lines;
  final Duration totalDuration;
  final LyricsTiming timing;

  const LyricsData({
    this.title,
    this.artist,
    this.album,
    this.author,
    required this.lines,
    required this.totalDuration,
    this.timing = LyricsTiming.plain,
  });

  bool get isSynced => timing == LyricsTiming.synced && lines.isNotEmpty;
  bool get hasWordTiming => lines.any((line) => line.words.isNotEmpty);

  Map<String, Object?> toJson() => <String, Object?>{
        'title': title,
        'artist': artist,
        'album': album,
        'author': author,
        'lines': lines.map((line) => line.toJson()).toList(growable: false),
        'totalDurationMs': totalDuration.inMilliseconds,
        'timing': timing.name,
      };

  factory LyricsData.fromJson(Map<String, dynamic> json) {
    final timingName = json['timing']?.toString();
    final timing = LyricsTiming.values.firstWhere(
      (value) => value.name == timingName,
      orElse: () => LyricsTiming.plain,
    );

    return LyricsData(
      title: json['title']?.toString(),
      artist: json['artist']?.toString(),
      album: json['album']?.toString(),
      author: json['author']?.toString(),
      lines: (json['lines'] as List<dynamic>? ?? const <dynamic>[])
          .whereType<Map>()
          .map(
            (line) => LyricLine.fromJson(
              Map<String, dynamic>.from(line),
            ),
          )
          .toList(growable: false),
      totalDuration: Duration(
        milliseconds: (json['totalDurationMs'] as num?)?.toInt() ?? 0,
      ),
      timing: timing,
    );
  }

  /// Get the active lyric line for a given playback position.
  LyricLine? lineAt(Duration position) {
    if (lines.isEmpty) return null;
    // Binary search for the last line whose timestamp <= position
    int lo = 0, hi = lines.length - 1;
    int result = -1;
    while (lo <= hi) {
      final mid = (lo + hi) ~/ 2;
      if (lines[mid].timestamp <= position) {
        result = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return result >= 0 ? lines[result] : null;
  }

  /// Get the index of the active lyric line.
  int activeIndexAt(Duration position) {
    if (lines.isEmpty) return -1;
    int lo = 0, hi = lines.length - 1;
    int result = -1;
    while (lo <= hi) {
      final mid = (lo + hi) ~/ 2;
      if (lines[mid].timestamp <= position) {
        result = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return result;
  }
}

/// A single LRCLIB search result ranked against the user's query.
class LyricsCandidate {
  final int id;
  final String trackName;
  final String artistName;
  final String albumName;
  final int durationSeconds;
  final bool hasSynced;
  final bool hasPlain;
  final String? syncedLyrics;
  final String? plainLyrics;
  final double score;

  const LyricsCandidate({
    required this.id,
    required this.trackName,
    required this.artistName,
    required this.albumName,
    required this.durationSeconds,
    required this.hasSynced,
    required this.hasPlain,
    this.syncedLyrics,
    this.plainLyrics,
    required this.score,
  });

  LyricsData toLyricsData() {
    if (syncedLyrics != null && syncedLyrics!.trim().isNotEmpty) {
      return LyricsService.parseLrc(syncedLyrics!);
    }
    if (plainLyrics != null && plainLyrics!.trim().isNotEmpty) {
      return LyricsService.parsePlainText(plainLyrics!);
    }
    return LyricsService.parsePlainText('');
  }

  String get durationLabel {
    final minutes = durationSeconds ~/ 60;
    final seconds = (durationSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }
}

/// Parses LRC (Lyrics) files and plain text lyrics.
class LyricsService {
  static const _requestTimeout = Duration(seconds: 12);
  static const _userAgent = 'VibesPlayer/1.0 (Android)';

  /// Parse standard and enhanced LRC content.
  ///
  /// Supports multiple line timestamps, `[offset:+/-milliseconds]`, and
  /// enhanced word timestamps such as `<00:12.34>Hello`.
  static LyricsData parseLrc(String content) {
    final parsedLines = <LyricLine>[];
    String? title, artist, album, author;
    var totalDuration = Duration.zero;
    var offsetMilliseconds = 0;

    final timestampRegex = RegExp(
      r'\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]',
    );
    final inlineTimestampRegex = RegExp(
      r'<(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?>',
    );
    final metaRegex = RegExp(
      r'\[(ti|ar|al|au|length|offset):(.+)\]',
      caseSensitive: false,
    );

    for (final rawLine in content.replaceAll('\r\n', '\n').split('\n')) {
      final trimmed = rawLine.trim();
      if (trimmed.isEmpty) continue;

      final metaMatch = metaRegex.firstMatch(trimmed);
      if (metaMatch != null) {
        final tag = metaMatch.group(1)!.toLowerCase();
        final value = metaMatch.group(2)!.trim();
        switch (tag) {
          case 'ti':
            title = value;
            break;
          case 'ar':
            artist = value;
            break;
          case 'al':
            album = value;
            break;
          case 'au':
            author = value;
            break;
          case 'length':
            totalDuration = _parseLength(value);
            break;
          case 'offset':
            offsetMilliseconds = int.tryParse(value) ?? 0;
            break;
        }
        continue;
      }

      final lineMatches = timestampRegex.allMatches(trimmed).toList();
      final words = _parseEnhancedWords(trimmed, inlineTimestampRegex);

      if (lineMatches.isEmpty && words.isEmpty) continue;

      final lyricText = trimmed
          .replaceAll(timestampRegex, '')
          .replaceAll(inlineTimestampRegex, '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (lyricText.isEmpty) continue;

      final timestamps = lineMatches.isNotEmpty
          ? lineMatches.map(_durationFromTimestampMatch).toList()
          : <Duration>[words.first.timestamp];

      for (final timestamp in timestamps) {
        parsedLines.add(
          LyricLine(
            timestamp: timestamp,
            text: lyricText,
            words: words,
          ),
        );
      }
    }

    final adjustedLines = parsedLines
        .map(
          (line) => LyricLine(
            timestamp: _applyOffset(line.timestamp, offsetMilliseconds),
            text: line.text,
            words: line.words
                .map(
                  (word) => LyricWord(
                    timestamp: _applyOffset(
                      word.timestamp,
                      offsetMilliseconds,
                    ),
                    text: word.text,
                  ),
                )
                .toList(growable: false),
          ),
        )
        .toList(growable: false)
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));

    return LyricsData(
      title: title,
      artist: artist,
      album: album,
      author: author,
      lines: adjustedLines,
      totalDuration: totalDuration,
      timing: LyricsTiming.synced,
    );
  }

  static List<LyricWord> _parseEnhancedWords(
    String line,
    RegExp inlineTimestampRegex,
  ) {
    final matches = inlineTimestampRegex.allMatches(line).toList();
    if (matches.isEmpty) return const <LyricWord>[];

    final words = <LyricWord>[];
    for (var index = 0; index < matches.length; index++) {
      final match = matches[index];
      final segmentEnd = index + 1 < matches.length
          ? matches[index + 1].start
          : line.length;
      final text = line
          .substring(match.end, segmentEnd)
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.isEmpty) continue;

      words.add(
        LyricWord(
          timestamp: _durationFromTimestampMatch(match),
          text: text,
        ),
      );
    }
    return List<LyricWord>.unmodifiable(words);
  }

  static Duration _durationFromTimestampMatch(RegExpMatch match) {
    final minutes = int.tryParse(match.group(1) ?? '') ?? 0;
    final seconds = int.tryParse(match.group(2) ?? '') ?? 0;
    final fraction = match.group(3) ?? '0';
    final milliseconds = int.tryParse(
          fraction.padRight(3, '0').substring(0, 3),
        ) ??
        0;
    return Duration(
      minutes: minutes,
      seconds: seconds,
      milliseconds: milliseconds,
    );
  }

  static Duration _applyOffset(Duration value, int offsetMilliseconds) {
    final adjusted = value.inMilliseconds + offsetMilliseconds;
    return Duration(milliseconds: adjusted < 0 ? 0 : adjusted);
  }

  /// Parse plain text lyrics (one line per line, no timestamps).
  static LyricsData parsePlainText(String content) {
    final lines = <LyricLine>[];
    final textLines = content.split('\n').where((l) => l.trim().isNotEmpty);
    for (final line in textLines) {
      lines.add(LyricLine(
        timestamp: Duration.zero,
        text: line.trim(),
      ));
    }
    return LyricsData(
      lines: lines,
      totalDuration: Duration.zero,
      timing: LyricsTiming.plain,
    );
  }

  /// Fetch lyrics online — tries LRCLIB first (supports synced LRC lyrics),
  /// then falls back to the open-source lyrics.ovh API for plain text.
  /// Returns [LyricsData] if found, null otherwise.
  static Future<LyricsData?> fetchOnline(
    String artist,
    String title, {
    int durationSeconds = 0,
  }) async {
    final lrclib = await fetchFromLrclib(
      artist,
      title,
      durationSeconds: durationSeconds,
    );
    if (lrclib != null) return lrclib;

    return null;
  }

  /// Fetch lyrics from the LRCLIB API (https://lrclib.net).
  /// Returns [LyricsData] with synced LRC timing when available, or plain
  /// text timing when only plain lyrics are available. Returns null if the
  /// track is not found, is instrumental, or an error occurs.
  static Future<LyricsData?> fetchFromLrclib(
    String artist,
    String title, {
    int durationSeconds = 0,
  }) async {
    final normalizedTitle = cleanTrackTitle(title);
    final normalizedArtist = cleanArtistName(artist);
    if (normalizedTitle.isEmpty) return null;

    final searchResult = await _searchLrclib(
      normalizedArtist,
      normalizedTitle,
      durationSeconds: durationSeconds,
    );
    if (searchResult != null) return searchResult;

    if (_hasUsableArtist(normalizedArtist)) {
      return _fetchLrclibExact(normalizedArtist, normalizedTitle);
    }
    return null;
  }

  static Future<LyricsData?> _fetchLrclibExact(
    String artist,
    String title,
  ) async {
    final client = HttpClient();
    try {
      client.connectionTimeout = _requestTimeout;
      final request = await client.getUrl(Uri.https(
        'lrclib.net',
        '/api/get',
        {
          'artist_name': artist,
          'track_name': title,
        },
      ));
      _setRequestHeaders(request);
      final response = await request.close().timeout(
            _requestTimeout,
          );

      if (response.statusCode == 200) {
        final body = await response
            .transform(utf8.decoder)
            .join()
            .timeout(_requestTimeout);
        final json = jsonDecode(body) as Map<String, dynamic>;
        return _lyricsFromLrclibRecord(json);
      }
      return null;
    } on TimeoutException {
      throw const LyricsFetchException(
        'Online lyrics request timed out. Check your connection and retry.',
      );
    } on SocketException {
      throw const LyricsFetchException(
        'Unable to reach the online lyrics service.',
      );
    } on HandshakeException {
      throw const LyricsFetchException(
        'Secure connection to the lyrics service failed.',
      );
    } on FormatException {
      throw const LyricsFetchException(
        'The online lyrics service returned an invalid response.',
      );
    } finally {
      client.close();
    }
  }

  static Future<LyricsData?> _searchLrclib(
    String artist,
    String title, {
    required int durationSeconds,
  }) async {
    final client = HttpClient();
    try {
      client.connectionTimeout = _requestTimeout;
      final query = <String, String>{'track_name': title};
      if (_hasUsableArtist(artist)) {
        query['artist_name'] = artist.trim();
      }
      final request = await client.getUrl(
        Uri.https('lrclib.net', '/api/search', query),
      );
      _setRequestHeaders(request);
      final response = await request.close().timeout(_requestTimeout);
      if (response.statusCode != 200) return null;

      final body = await response
          .transform(utf8.decoder)
          .join()
          .timeout(_requestTimeout);
      final decoded = jsonDecode(body);
      if (decoded is! List) return null;

      final candidates = decoded
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .where((item) => _lyricsFromLrclibRecord(item) != null)
          .toList();
      if (candidates.isEmpty) {
        if (_hasUsableArtist(artist)) {
          return _searchLrclib(
            '',
            title,
            durationSeconds: durationSeconds,
          );
        }
        return null;
      }

      final ranked = candidates
          .map(
            (record) => (
              record: record,
              score: _recordMatchScore(
                record,
                queryTitle: title,
                queryArtist: artist,
                durationSeconds: durationSeconds,
              ),
            ),
          )
          .toList(growable: false)
        ..sort((a, b) => b.score.compareTo(a.score));

      // Do not silently attach a weak match to the current track. The caller
      // can still present the candidate picker for manual selection.
      if (ranked.first.score < 0.58) return null;
      return _lyricsFromLrclibRecord(ranked.first.record);
    } on TimeoutException {
      throw const LyricsFetchException(
        'Online lyrics request timed out. Check your connection and retry.',
      );
    } on SocketException {
      throw const LyricsFetchException(
        'Unable to reach the online lyrics service.',
      );
    } on HandshakeException {
      throw const LyricsFetchException(
        'Secure connection to the lyrics service failed.',
      );
    } on FormatException {
      throw const LyricsFetchException(
        'The online lyrics service returned an invalid response.',
      );
    } finally {
      client.close();
    }
  }

  static LyricsData? _lyricsFromLrclibRecord(Map<String, dynamic> json) {
    if (json['instrumental'] == true) return null;

    final synced = json['syncedLyrics'] as String?;
    if (synced != null && synced.trim().isNotEmpty) {
      return parseLrc(synced);
    }

    final plain = json['plainLyrics'] as String?;
    if (plain != null && plain.trim().isNotEmpty) {
      return parsePlainText(plain);
    }
    return null;
  }

  /// Searches LRCLIB and returns the best matching lyric records.
  static Future<List<LyricsCandidate>> searchCandidates(
    String artist,
    String title, {
    int durationSeconds = 0,
    int maxResults = 5,
  }) async {
    final cleanTitle = cleanTrackTitle(title);
    final cleanArtist = cleanArtistName(artist);
    if (cleanTitle.isEmpty || maxResults <= 0) return const [];

    final client = HttpClient();
    try {
      client.connectionTimeout = _requestTimeout;
      final query = <String, String>{'track_name': cleanTitle};
      if (_hasUsableArtist(cleanArtist)) {
        query['artist_name'] = cleanArtist;
      }

      final request = await client.getUrl(
        Uri.https('lrclib.net', '/api/search', query),
      );
      _setRequestHeaders(request);
      final response = await request.close().timeout(_requestTimeout);
      if (response.statusCode != 200) return const [];

      final body = await response
          .transform(utf8.decoder)
          .join()
          .timeout(_requestTimeout);
      final decoded = jsonDecode(body);
      if (decoded is! List) {
        throw const LyricsFetchException(
          'The online lyrics service returned an invalid response.',
        );
      }

      final candidates = <LyricsCandidate>[];
      for (final item in decoded.whereType<Map>()) {
        final record = Map<String, dynamic>.from(item);
        if (record['instrumental'] == true) continue;

        final synced = record['syncedLyrics'] as String?;
        final plain = record['plainLyrics'] as String?;
        final hasSynced = synced != null && synced.trim().isNotEmpty;
        final hasPlain = plain != null && plain.trim().isNotEmpty;
        if (!hasSynced && !hasPlain) continue;

        final candidateTitle = (record['trackName'] as String?) ?? '';
        final candidateArtist = (record['artistName'] as String?) ?? '';
        final candidateDuration = (record['duration'] as num?)?.round() ?? 0;
        var score = _similarityScore(
          queryTitle: cleanTitle,
          queryArtist: cleanArtist,
          candidateTitle: candidateTitle,
          candidateArtist: candidateArtist,
        );

        if (durationSeconds > 0 && candidateDuration > 0) {
          final delta = (candidateDuration - durationSeconds).abs();
          if (delta <= 10) {
            score = (score + 0.15).clamp(0.0, 1.0);
          } else if (delta <= 30) {
            score = (score + 0.05).clamp(0.0, 1.0);
          }
        }
        if (hasSynced) {
          score = (score + 0.05).clamp(0.0, 1.0);
        }

        candidates.add(LyricsCandidate(
          id: (record['id'] as num?)?.toInt() ?? 0,
          trackName: candidateTitle,
          artistName: candidateArtist,
          albumName: (record['albumName'] as String?) ?? '',
          durationSeconds: candidateDuration,
          hasSynced: hasSynced,
          hasPlain: hasPlain,
          syncedLyrics: synced,
          plainLyrics: plain,
          score: score,
        ));
      }

      candidates.sort((a, b) => b.score.compareTo(a.score));
      return candidates.take(maxResults).toList(growable: false);
    } on LyricsFetchException {
      rethrow;
    } on TimeoutException {
      throw const LyricsFetchException(
        'Online lyrics request timed out. Check your connection and retry.',
      );
    } on SocketException {
      throw const LyricsFetchException(
        'Unable to reach the online lyrics service.',
      );
    } on HandshakeException {
      throw const LyricsFetchException(
        'Secure connection to the lyrics service failed.',
      );
    } on FormatException {
      throw const LyricsFetchException(
        'The online lyrics service returned an invalid response.',
      );
    } finally {
      client.close();
    }
  }

  static double _recordMatchScore(
    Map<String, dynamic> record, {
    required String queryTitle,
    required String queryArtist,
    required int durationSeconds,
  }) {
    final candidateTitle = record['trackName']?.toString() ?? '';
    final candidateArtist = record['artistName']?.toString() ?? '';
    final candidateDuration = (record['duration'] as num?)?.round() ?? 0;

    var score = _similarityScore(
      queryTitle: queryTitle,
      queryArtist: queryArtist,
      candidateTitle: candidateTitle,
      candidateArtist: candidateArtist,
    );

    if (durationSeconds > 0 && candidateDuration > 0) {
      final delta = (candidateDuration - durationSeconds).abs();
      if (delta <= 5) {
        score += 0.18;
      } else if (delta <= 15) {
        score += 0.10;
      } else if (delta > 45) {
        score -= 0.18;
      }
    }

    final synced = record['syncedLyrics']?.toString().trim() ?? '';
    if (synced.isNotEmpty) score += 0.04;
    return score.clamp(0.0, 1.0).toDouble();
  }

  static double _similarityScore({
    required String queryTitle,
    required String queryArtist,
    required String candidateTitle,
    required String candidateArtist,
  }) {
    final titleScore = _tokenSimilarity(
      queryTitle.toLowerCase(),
      candidateTitle.toLowerCase(),
    );
    if (!_hasUsableArtist(queryArtist)) return titleScore;

    final artistScore = _tokenSimilarity(
      queryArtist.toLowerCase(),
      candidateArtist.toLowerCase(),
    );
    return (titleScore * 0.7) + (artistScore * 0.3);
  }

  static double _tokenSimilarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.isEmpty || b.isEmpty) return 0.0;

    final tokensA = _tokenize(a);
    final tokensB = _tokenize(b);
    if (tokensA.isEmpty || tokensB.isEmpty) return 0.0;

    var matches = 0;
    for (final tokenA in tokensA) {
      for (final tokenB in tokensB) {
        if (tokenA == tokenB ||
            tokenA.contains(tokenB) ||
            tokenB.contains(tokenA)) {
          matches++;
          break;
        }
      }
    }
    final union = tokensA.length + tokensB.length - matches;
    return union == 0 ? 0.0 : matches / union;
  }

  static Set<String> _tokenize(String value) {
    return value
        .replaceAll(RegExp(r'[^\w\s]'), ' ')
        .split(RegExp(r'\s+'))
        .where((token) => token.length > 1)
        .toSet();
  }

  static bool _hasUsableArtist(String artist) {
    final normalized = artist.trim().toLowerCase();
    return normalized.isNotEmpty &&
        normalized != '<unknown>' &&
        normalized != 'unknown' &&
        normalized != 'unknown artist';
  }

  static String cleanTrackTitle(String title) {
    final parts = title.split(RegExp(r'(?:\s|_)+-(?:\s|_)+'));
    final prefix = parts.first.replaceAll('_', ' ').trim();
    final prefixIsDownloadNoise = RegExp(
      r'\baudio$',
      caseSensitive: false,
    ).hasMatch(prefix);
    final baseTitle = parts.length > 1 && !prefixIsDownloadNoise
        ? parts.last
        : title.replaceAll(RegExp(r'(?:\s|_)+-(?:\s|_)+'), ' ');
    final likelyTitle = baseTitle.replaceAll('_', ' ');

    return likelyTitle
        .replaceAll(RegExp(r'\.[a-z0-9]{2,5}$', caseSensitive: false), '')
        .replaceAll(RegExp(r'[_]+'), ' ')
        .replaceAll(
          RegExp(
            r'\((?:\d+\s*k|official[^)]*|(?:feat|ft|featuring)\.?\s+[^)]*)\)',
            caseSensitive: false,
          ),
          ' ',
        )
        .replaceAll(
          RegExp(
            r'\b(?:feat|ft|featuring)\.?\s+.*$',
            caseSensitive: false,
          ),
          ' ',
        )
        .replaceAll(
          RegExp(r'\b(?:official|audio|video|lyrics?|visualizer)\b',
              caseSensitive: false),
          ' ',
        )
        .replaceAll(RegExp(r'\s*-\s*'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static String cleanArtistName(String artist) {
    return artist
        .replaceAll(
          RegExp(
            r'\b(?:feat|ft|featuring)\.?\s+.*$',
            caseSensitive: false,
          ),
          '',
        )
        .trim();
  }

  /// Main fetch entry point. Local sidecars are authoritative and are checked
  /// before optional network lookup.
  static Future<({LyricsData lyrics, bool isOnline})?> fetchLyrics({
    required String? filePath,
    required String artist,
    required String title,
    int durationSeconds = 0,
    bool allowOnline = true,
  }) async {
    if (filePath != null && filePath.isNotEmpty) {
      final sidecar = await _loadSidecarLrc(filePath);
      if (sidecar != null) return (lyrics: sidecar, isOnline: false);
    }

    if (!allowOnline) return null;

    final online = await fetchOnline(
      artist,
      title,
      durationSeconds: durationSeconds,
    );
    return online == null ? null : (lyrics: online, isOnline: true);
  }

  static Future<({LyricsData lyrics, bool isOnline})?> fetchLocalLyrics({
    required String? filePath,
    required String artist,
    required String title,
    int durationSeconds = 0,
  }) async {
    if (filePath == null || filePath.isEmpty) return null;
    final sidecar = await _loadSidecarLrc(filePath);
    return sidecar == null ? null : (lyrics: sidecar, isOnline: false);
  }

  /// Checks for a .lrc or .txt file with the same base name as [audioPath].
  static Future<LyricsData?> _loadSidecarLrc(String audioPath) async {
    final basePath = audioPath.replaceAll(RegExp(r'\.[^.]+$'), '');
    for (final ext in ['.lrc', '.LRC', '.txt']) {
      final candidate = File('$basePath$ext');
      try {
        if (await candidate.exists()) {
          final content = decodeTextBytes(await candidate.readAsBytes());
          if (content.trim().isEmpty) continue;
          return ext.toLowerCase() == '.lrc'
              ? parseLrc(content)
              : parsePlainText(content);
        }
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// Decodes UTF-8 and UTF-16 lyrics files, including BOM-marked sidecars.
  static String decodeTextBytes(List<int> bytes) {
    if (bytes.isEmpty) return '';

    if (bytes.length >= 2) {
      if (bytes[0] == 0xff && bytes[1] == 0xfe) {
        return _decodeUtf16(bytes.sublist(2), littleEndian: true);
      }
      if (bytes[0] == 0xfe && bytes[1] == 0xff) {
        return _decodeUtf16(bytes.sublist(2), littleEndian: false);
      }
    }

    final utf8Offset = bytes.length >= 3 &&
            bytes[0] == 0xef &&
            bytes[1] == 0xbb &&
            bytes[2] == 0xbf
        ? 3
        : 0;

    // Some sidecars omit the UTF-16 BOM. A strong alternating-NUL pattern is
    // safer than decoding those files as malformed UTF-8.
    final sampleLength = bytes.length < 128 ? bytes.length : 128;
    var evenNulls = 0;
    var oddNulls = 0;
    for (var index = 0; index < sampleLength; index++) {
      if (bytes[index] != 0) continue;
      if (index.isEven) {
        evenNulls++;
      } else {
        oddNulls++;
      }
    }
    if (oddNulls >= 4 && oddNulls > evenNulls * 2) {
      return _decodeUtf16(bytes, littleEndian: true);
    }
    if (evenNulls >= 4 && evenNulls > oddNulls * 2) {
      return _decodeUtf16(bytes, littleEndian: false);
    }

    return utf8.decode(bytes.sublist(utf8Offset), allowMalformed: true);
  }

  static String _decodeUtf16(
    List<int> bytes, {
    required bool littleEndian,
  }) {
    final codeUnits = <int>[];
    for (var index = 0; index + 1 < bytes.length; index += 2) {
      final first = bytes[index];
      final second = bytes[index + 1];
      codeUnits.add(
        littleEndian ? first | (second << 8) : (first << 8) | second,
      );
    }
    return String.fromCharCodes(codeUnits);
  }

  static void _setRequestHeaders(HttpClientRequest request) {
    request.headers.set(HttpHeaders.userAgentHeader, _userAgent);
    request.headers.set(HttpHeaders.acceptHeader, 'application/json');
  }

  static Duration _parseLength(String value) {
    try {
      final parts = value.split(':');
      if (parts.length == 2) {
        final min = int.parse(parts[0]);
        final secParts = parts[1].split('.');
        final sec = int.parse(secParts[0]);
        final ms = secParts.length > 1
            ? int.parse(secParts[1].padRight(3, '0').substring(0, 3))
            : 0;
        return Duration(minutes: min, seconds: sec, milliseconds: ms);
      }
    } catch (_) {
      // Malformed LRC timestamp — fall back to zero.
    }
    return Duration.zero;
  }
}
