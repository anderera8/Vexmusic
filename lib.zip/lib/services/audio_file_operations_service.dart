import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../models/music_models.dart';

class AudioFileEditException implements Exception {
  final String code;
  final String message;
  final Object? details;

  const AudioFileEditException({
    required this.code,
    required this.message,
    this.details,
  });

  @override
  String toString() => message;
}


enum AudioFileOperationStatus {
  success,
  cancelled,
  denied,
  notFound,
  failed,
}

@immutable
class AudioFileOperationResult {
  const AudioFileOperationResult({
    required this.status,
    required this.code,
    required this.message,
    this.details,
  });

  final AudioFileOperationStatus status;
  final String code;
  final String message;
  final Object? details;

  bool get succeeded => status == AudioFileOperationStatus.success;

  bool get sourceAbsent =>
      succeeded || status == AudioFileOperationStatus.notFound;

  factory AudioFileOperationResult.fromPlatform(
    Object? raw, {
    required String fallbackAction,
    bool nullMeansSuccess = true,
  }) {
    if (raw is bool) {
      return AudioFileOperationResult(
        status: raw
            ? AudioFileOperationStatus.success
            : AudioFileOperationStatus.failed,
        code: raw ? 'SUCCESS' : 'FAILED',
        message: raw
            ? '$fallbackAction completed.'
            : '$fallbackAction did not complete.',
      );
    }

    if (raw is Map) {
      final map = Map<Object?, Object?>.from(raw);
      final statusName = map['status']?.toString().trim().toLowerCase();
      final status = switch (statusName) {
        'success' => AudioFileOperationStatus.success,
        'cancelled' => AudioFileOperationStatus.cancelled,
        'denied' => AudioFileOperationStatus.denied,
        'not_found' || 'notfound' => AudioFileOperationStatus.notFound,
        _ => AudioFileOperationStatus.failed,
      };

      return AudioFileOperationResult(
        status: status,
        code: map['code']?.toString() ?? 'UNKNOWN',
        message: map['message']?.toString() ??
            '$fallbackAction did not complete.',
        details: map['details'],
      );
    }

    if (raw == null && nullMeansSuccess) {
      return AudioFileOperationResult(
        status: AudioFileOperationStatus.success,
        code: 'SUCCESS',
        message: '$fallbackAction completed.',
      );
    }

    return AudioFileOperationResult(
      status: AudioFileOperationStatus.failed,
      code: 'INVALID_NATIVE_RESPONSE',
      message: '$fallbackAction returned an invalid native response.',
      details: raw,
    );
  }
}

class AudioEditFormatInfo {
  final String extension;
  final String label;
  final bool supportsTags;
  final bool supportsArtwork;
  final bool bestEffort;

  const AudioEditFormatInfo({
    required this.extension,
    required this.label,
    required this.supportsTags,
    required this.supportsArtwork,
    required this.bestEffort,
  });
}

class AudioFileOperationsService {
  static const MethodChannel _channel =
      MethodChannel('com.vextech.vexmusic/file_operations');
  static const Set<String> _stableTagExtensions = {
    'mp3',
    'm4a',
    'mp4',
    'flac',
  };

  static const Set<String> _bestEffortTagExtensions = {
    'ogg',
    'wav',
  };

  static const Set<String> _stableArtworkExtensions = {
    'mp3',
    'm4a',
    'mp4',
    'flac',
    'ogg',
    'wav',
  };

  static const Map<String, String> _formatLabels = {
    'mp3': 'MP3',
    'm4a': 'M4A',
    'mp4': 'MP4 audio',
    'flac': 'FLAC',
    'ogg': 'OGG',
    'opus': 'OPUS',
    'wav': 'WAV',
    'aac': 'AAC',
    'wma': 'WMA',
    'amr': 'AMR',
    '3gp': '3GP',
    'mka': 'MKA',
  };

  // ─────────────────────────────────────────────────────────────────────
  // Format helpers
  // ─────────────────────────────────────────────────────────────────────

  static String extensionForTrack(Track track) {
    final fromPath = _extensionFromValue(track.filePath);
    if (fromPath.isNotEmpty) return fromPath;

    final fromPlaybackUri = _extensionFromValue(track.playbackUri);
    if (fromPlaybackUri.isNotEmpty) return fromPlaybackUri;

    return '';
  }

  static String labelForTrack(Track track) {
    final extension = extensionForTrack(track);
    if (extension.isEmpty) return 'Unknown format';
    return _formatLabels[extension] ?? extension.toUpperCase();
  }

  static AudioEditFormatInfo formatInfoForTrack(Track track) {
    final extension = extensionForTrack(track);
    final label = extension.isEmpty
        ? 'Unknown format'
        : (_formatLabels[extension] ?? extension.toUpperCase());

    final stableTags = _stableTagExtensions.contains(extension);
    final bestEffortTags = _bestEffortTagExtensions.contains(extension);
    final supportsArtwork = _stableArtworkExtensions.contains(extension);

    return AudioEditFormatInfo(
      extension: extension,
      label: label,
      supportsTags: stableTags || bestEffortTags,
      supportsArtwork: supportsArtwork,
      bestEffort: bestEffortTags,
    );
  }

  static bool canEditTags(Track track) {
    return formatInfoForTrack(track).supportsTags && _hasEditableSource(track);
  }

  static bool canEditArtwork(Track track) {
    return formatInfoForTrack(track).supportsArtwork &&
        _hasEditableSource(track);
  }

  static String _extensionFromValue(String? value) {
    final raw = value?.trim();
    if (raw == null || raw.isEmpty) return '';

    final parsed = Uri.tryParse(raw);
    final path = parsed?.path.isNotEmpty == true ? parsed!.path : raw;

    final lastSlash = path.lastIndexOf('/');
    final fileName = lastSlash >= 0 ? path.substring(lastSlash + 1) : path;

    final lastDot = fileName.lastIndexOf('.');
    if (lastDot < 0 || lastDot == fileName.length - 1) return '';

    return fileName.substring(lastDot + 1).toLowerCase();
  }

  static bool _hasEditableSource(Track track) {
    final hasMediaStoreId = track.mediaStoreId > 0;
    final hasPath = track.filePath?.trim().isNotEmpty == true;
    final hasUri = track.playbackUri?.trim().isNotEmpty == true;
    final hasVolume = track.volumeName.trim().isNotEmpty;

    return hasMediaStoreId && (hasUri || hasVolume || hasPath);
  }

  static Map<String, Object?> _basePayloadForTrack(Track track) {
    if (track.mediaStoreId <= 0) {
      throw ArgumentError.value(
        track.mediaStoreId,
        'track.mediaStoreId',
        'A native audio-file operation requires a valid MediaStore ID.',
      );
    }

    final format = formatInfoForTrack(track);

    return {
      'mediaStoreId': track.mediaStoreId,
      'appTrackId': track.id,
      'stableKey': track.stableKey,
      'volumeName': track.volumeName,
      'filePath': track.filePath,
      'playbackUri': track.playbackUri,
      'format': format.extension,
    };
  }

  // ─────────────────────────────────────────────────────────────────────
  // Delete
  // ─────────────────────────────────────────────────────────────────────

  Future<AudioFileOperationResult> deleteWithResult(Track track) async {
    if (Platform.isAndroid) {
      if (!_hasEditableSource(track)) {
        return AudioFileOperationResult(
          status: AudioFileOperationStatus.failed,
          code: 'NO_EDITABLE_SOURCE',
          message: 'This track has no editable MediaStore file source.',
          details: <String, Object?>{
            'appTrackId': track.id,
            'mediaStoreId': track.mediaStoreId,
            'volumeName': track.volumeName,
          },
        );
      }

      try {
        final raw = await _channel.invokeMethod<Object?>(
          'deleteTrack',
          _basePayloadForTrack(track),
        );

        return AudioFileOperationResult.fromPlatform(
          raw,
          fallbackAction: 'Delete',
          nullMeansSuccess: false,
        );
      } on PlatformException catch (error, stackTrace) {
        debugPrint(
          '[AudioFileOperationsService] delete failed: '
          'appTrackId=${track.id}, mediaStoreId=${track.mediaStoreId}, '
          'volume=${track.volumeName}, code=${error.code}, '
          'message=${error.message}, details=${error.details}',
        );
        debugPrintStack(stackTrace: stackTrace);

        return _operationResultFromPlatformException(
          error,
          action: 'Delete',
        );
      } on MissingPluginException catch (error, stackTrace) {
        debugPrintStack(stackTrace: stackTrace);
        return AudioFileOperationResult(
          status: AudioFileOperationStatus.failed,
          code: 'MISSING_PLUGIN',
          message: 'File deletion service is unavailable.',
          details: error.message,
        );
      } on ArgumentError catch (error, stackTrace) {
        debugPrintStack(stackTrace: stackTrace);
        return AudioFileOperationResult(
          status: AudioFileOperationStatus.failed,
          code: 'INVALID_ARG',
          message: error.message?.toString() ?? 'Invalid delete request.',
          details: error.invalidValue,
        );
      }
    }

    final path = track.filePath?.trim();
    if (path == null || path.isEmpty) {
      return const AudioFileOperationResult(
        status: AudioFileOperationStatus.notFound,
        code: 'SOURCE_NOT_FOUND',
        message: 'The audio file could not be found.',
      );
    }

    try {
      final file = File(path);
      if (!await file.exists()) {
        return const AudioFileOperationResult(
          status: AudioFileOperationStatus.notFound,
          code: 'SOURCE_NOT_FOUND',
          message: 'The audio file could not be found.',
        );
      }

      await file.delete();
      return const AudioFileOperationResult(
        status: AudioFileOperationStatus.success,
        code: 'SUCCESS',
        message: 'Track deleted.',
      );
    } on FileSystemException catch (error, stackTrace) {
      debugPrintStack(stackTrace: stackTrace);
      return AudioFileOperationResult(
        status: AudioFileOperationStatus.failed,
        code: 'DELETE_ERROR',
        message: 'Could not delete this audio file.',
        details: error.message,
      );
    }
  }

  Future<bool> delete(Track track) async =>
      (await deleteWithResult(track)).sourceAbsent;

  // ─────────────────────────────────────────────────────────────────────
  // Tag writing
  // ─────────────────────────────────────────────────────────────────────

  Future<void> writeTags({
    required Track track,
    required String title,
    required String artist,
    required String album,
  }) async {
    if (!Platform.isAndroid) {
      throw const AudioFileEditException(
        code: 'ANDROID_ONLY',
        message: 'Writing audio tags is currently supported on Android only.',
      );
    }

    final normalizedTitle = title.trim();
    final normalizedArtist = artist.trim();
    final normalizedAlbum = album.trim();

    if (normalizedTitle.isEmpty) {
      throw const AudioFileEditException(
        code: 'INVALID_TITLE',
        message: 'Track title cannot be empty.',
      );
    }

    final format = formatInfoForTrack(track);

    try {
      final raw = await _channel.invokeMethod<Object?>('writeTags', {
        ..._basePayloadForTrack(track),
        'title': normalizedTitle,
        'artist': normalizedArtist,
        'album': normalizedAlbum,
      });

      _throwIfOperationFailed(
        AudioFileOperationResult.fromPlatform(
          raw,
          fallbackAction: 'Tag update',
        ),
        action: 'save tags',
        format: format,
      );
    } on PlatformException catch (e, st) {
      debugPrint(
        '[AudioFileOperationsService] writeTags failed: '
        'code=${e.code}, message=${e.message}, details=${e.details}',
      );
      debugPrintStack(stackTrace: st);
      throw _mapPlatformException(e, action: 'save tags', format: format);
    } on MissingPluginException catch (e) {
      throw AudioFileEditException(
        code: 'MISSING_PLUGIN',
        message:
            'File editing service is unavailable. Restart the app and try again.',
        details: e.message,
      );
    }
  }

  // ─────────────────────────────────────────────────────────────────────
  // Artwork writing
  // ─────────────────────────────────────────────────────────────────────

  Future<bool> writeArtwork({
    required Track track,
    required Uint8List imageBytes,
    String mimeType = 'image/jpeg',
  }) async {
    if (!Platform.isAndroid) {
      throw const AudioFileEditException(
        code: 'ANDROID_ONLY',
        message:
            'Writing audio artwork is currently supported on Android only.',
      );
    }

    if (imageBytes.isEmpty) return false;

    final format = formatInfoForTrack(track);

    if (!format.supportsArtwork) {
      throw AudioFileEditException(
        code: 'UNSUPPORTED_FORMAT',
        message:
            '${format.label} artwork editing is not supported yet. Supported artwork formats are MP3, M4A, MP4, FLAC, OGG, and WAV.',
        details: format.extension,
      );
    }

    try {
      final raw = await _channel.invokeMethod<Object?>('writeArtwork', {
        ..._basePayloadForTrack(track),
        'imageBytes': imageBytes,
        'mimeType': mimeType,
      });

      final operation = AudioFileOperationResult.fromPlatform(
        raw,
        fallbackAction: 'Artwork update',
      );

      _throwIfOperationFailed(
        operation,
        action: 'update artwork',
        format: format,
      );

      return operation.succeeded;
    } on PlatformException catch (e, st) {
      debugPrint(
        '[AudioFileOperationsService] writeArtwork failed: '
        'code=${e.code}, message=${e.message}, details=${e.details}',
      );
      debugPrintStack(stackTrace: st);
      throw _mapPlatformException(e, action: 'update artwork', format: format);
    } on MissingPluginException catch (e) {
      throw AudioFileEditException(
        code: 'MISSING_PLUGIN',
        message:
            'File editing service is unavailable. Restart the app and try again.',
        details: e.message,
      );
    }
  }

  // ─────────────────────────────────────────────────────────────────────
  // Share
  // ─────────────────────────────────────────────────────────────────────.
  Future<void> share(Track track) async {
    if (!_hasEditableSource(track)) {
      throw const AudioFileEditException(
        code: 'NO_EDITABLE_SOURCE',
        message: 'This track has no shareable MediaStore file source.',
      );
    }

    final format = formatInfoForTrack(track);

    try {
      final raw = await _channel.invokeMethod<Object?>(
        'prepareShareFile',
        _basePayloadForTrack(track),
      );

      final operation = AudioFileOperationResult.fromPlatform(
        raw,
        fallbackAction: 'Share preparation',
        nullMeansSuccess: false,
      );

      _throwIfOperationFailed(
        operation,
        action: 'prepare this file for sharing',
        format: format,
      );

      final details = operation.details;
      final sharePath = details is Map
          ? details['path']?.toString().trim()
          : null;

      if (sharePath == null || sharePath.isEmpty) {
        throw AudioFileEditException(
          code: 'INVALID_NATIVE_RESPONSE',
          message: 'Share preparation returned no file path.',
          details: raw,
        );
      }

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(sharePath)],
          text: '${track.title} — ${track.artist}',
        ),
      );
    } on PlatformException catch (e, st) {
      debugPrint(
        '[AudioFileOperationsService] share failed: '
        'code=${e.code}, message=${e.message}, details=${e.details}',
      );
      debugPrintStack(stackTrace: st);
      throw _mapPlatformException(e, action: 'share this file', format: format);
    } on MissingPluginException catch (e) {
      throw AudioFileEditException(
        code: 'MISSING_PLUGIN',
        message:
            'File sharing service is unavailable. Restart the app and try again.',
        details: e.message,
      );
    }
  }

  static void _throwIfOperationFailed(
    AudioFileOperationResult operation, {
    required String action,
    required AudioEditFormatInfo format,
  }) {
    if (operation.succeeded) return;

    throw AudioFileEditException(
      code: operation.code,
      message: operation.message.isNotEmpty
          ? operation.message
          : 'Unable to $action for this ${format.label} file.',
      details: operation.details,
    );
  }

  static AudioFileOperationResult _operationResultFromPlatformException(
    PlatformException error, {
    required String action,
  }) {
    final status = switch (error.code) {
      'WRITE_CANCELLED' || 'DELETE_CANCELLED' =>
        AudioFileOperationStatus.cancelled,
      'WRITE_DENIED' || 'DELETE_DENIED' =>
        AudioFileOperationStatus.denied,
      'SOURCE_NOT_FOUND' => AudioFileOperationStatus.notFound,
      _ => AudioFileOperationStatus.failed,
    };

    return AudioFileOperationResult(
      status: status,
      code: error.code,
      message: error.message?.trim().isNotEmpty == true
          ? error.message!.trim()
          : '$action did not complete.',
      details: error.details,
    );
  }

  // ─────────────────────────────────────────────────────────────────────
  // Error mapping
  // ─────────────────────────────────────────────────────────────────────

  static AudioFileEditException _mapPlatformException(
    PlatformException error, {
    required String action,
    required AudioEditFormatInfo format,
  }) {
    final rawMessage = error.message?.trim();
    final message = rawMessage == null || rawMessage.isEmpty
        ? 'Unable to $action for this track.'
        : rawMessage;

    switch (error.code) {
      case 'WRITE_CANCELLED':
        return AudioFileEditException(
          code: error.code,
          message: 'The Android file edit request was cancelled.',
          details: error.details,
        );

      case 'WRITE_DENIED':
        return AudioFileEditException(
          code: error.code,
          message:
              'Permission to edit this file was denied. Accept the Android edit request to change this track.',
          details: error.details,
        );

      case 'OPERATION_IN_PROGRESS':
        return AudioFileEditException(
          code: error.code,
          message:
              'Another file edit is still waiting for Android permission. Finish it first, then try again.',
          details: error.details,
        );

      case 'NO_ACTIVITY':
        return AudioFileEditException(
          code: error.code,
          message:
              'The edit permission screen could not open because the app activity is unavailable.',
          details: error.details,
        );

      case 'CONFIRMATION_ERROR':
        return AudioFileEditException(
          code: error.code,
          message:
              'Android could not open the file edit confirmation screen: $message',
          details: error.details,
        );

      case 'TAG_WRITE_ERROR':
        return AudioFileEditException(
          code: error.code,
          message: "File can't be edited",
          details: error.details,
        );

      case 'ARTWORK_WRITE_ERROR':
        return AudioFileEditException(
          code: error.code,
          message:
              'Could not update artwork for this ${format.label} file: $message',
          details: error.details,
        );

      case 'SOURCE_NOT_FOUND':
        return AudioFileEditException(
          code: error.code,
          message: 'The source audio file is no longer available.',
          details: error.details,
        );

      case 'INVALID_ARG':
        return AudioFileEditException(
          code: error.code,
          message: 'Invalid file edit request: $message',
          details: error.details,
        );

      case 'ACTIVITY_DESTROYED':
        return AudioFileEditException(
          code: error.code,
          message:
              'The app was closed before the file edit finished. Reopen the app and try again.',
          details: error.details,
        );

      default:
        return AudioFileEditException(
          code: error.code,
          message: 'Unable to $action for this ${format.label} file: $message',
          details: error.details,
        );
    }
  }
}
