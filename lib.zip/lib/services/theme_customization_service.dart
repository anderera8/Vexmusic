import 'dart:convert';
import 'package:flutter/material.dart';
import 'prefs_service.dart';

class CustomThemeData {
  final String id;
  final String name;
  final int primaryColor; // 0xAARRGGBB
  final int backgroundColor;
  final int surfaceColor;
  final int accentColor;
  final int textColor;
  final bool isDark;
  final DateTime createdAt;

  const CustomThemeData({
    required this.id,
    required this.name,
    required this.primaryColor,
    required this.backgroundColor,
    required this.surfaceColor,
    required this.accentColor,
    required this.textColor,
    this.isDark = true,
    required this.createdAt,
  });

  Color get primary => Color(primaryColor);
  Color get background => Color(backgroundColor);
  Color get surface => Color(surfaceColor);
  Color get accent => Color(accentColor);
  Color get text => Color(textColor);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'primaryColor': primaryColor,
        'backgroundColor': backgroundColor,
        'surfaceColor': surfaceColor,
        'accentColor': accentColor,
        'textColor': textColor,
        'isDark': isDark,
        'createdAt': createdAt.toIso8601String(),
      };

  factory CustomThemeData.fromJson(Map<String, dynamic> json) =>
      CustomThemeData(
        id: json['id'] as String,
        name: json['name'] as String,
        primaryColor: json['primaryColor'] as int,
        backgroundColor: json['backgroundColor'] as int,
        surfaceColor: json['surfaceColor'] as int,
        accentColor: json['accentColor'] as int,
        textColor: json['textColor'] as int,
        isDark: json['isDark'] as bool? ?? true,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

/// Manages user-created custom themes.
class ThemeCustomizationService {
  static const _key = 'custom_themes';
  static const _activeKey = 'active_custom_theme';

  static Future<List<CustomThemeData>> getThemes() async {
    final prefs = PrefsService.instance;
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list
        .map((e) => CustomThemeData.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  static Future<void> saveTheme(CustomThemeData theme) async {
    final themes = await getThemes();
    final idx = themes.indexWhere((t) => t.id == theme.id);
    if (idx >= 0) {
      themes[idx] = theme;
    } else {
      themes.add(theme);
    }
    final prefs = PrefsService.instance;
    await prefs.setString(
        _key, jsonEncode(themes.map((t) => t.toJson()).toList()));
  }

  static Future<void> deleteTheme(String id) async {
    final themes = await getThemes();
    themes.removeWhere((t) => t.id == id);
    final prefs = PrefsService.instance;
    await prefs.setString(
        _key, jsonEncode(themes.map((t) => t.toJson()).toList()));

    // If this was the active theme, clear it
    final active = prefs.getString(_activeKey);
    if (active == id) {
      await prefs.remove(_activeKey);
    }
  }

  static Future<void> setActiveTheme(String? id) async {
    final prefs = PrefsService.instance;
    if (id == null) {
      await prefs.remove(_activeKey);
    } else {
      await prefs.setString(_activeKey, id);
    }
  }

  static Future<String?> getActiveTheme() async {
    final prefs = PrefsService.instance;
    return prefs.getString(_activeKey);
  }

  static Future<CustomThemeData?> getActiveThemeData() async {
    final id = await getActiveTheme();
    if (id == null) return null;
    final themes = await getThemes();
    try {
      return themes.firstWhere((t) => t.id == id);
    } catch (_) {
      await setActiveTheme(null);
      return null;
    }
  }
}
