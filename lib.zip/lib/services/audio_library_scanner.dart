import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'media_permission_service.dart';
import 'native_media_library_service.dart';

enum AudioScanFailureKind {
  unsupportedPlatform,
  permissionDenied,
  platformFailure,
  malformedResponse,
  noAuthoritativeVolumes,
  unknown,
}

class AudioScanException implements Exception {
  const AudioScanException({
    required this.kind,
    required this.message,
    this.code,
    this.cause,
  });

  final AudioScanFailureKind kind;
  final String message;
  final String? code;
  final Object? cause;

  @override
  String toString() {
    final prefix = code == null ? kind.name : '${kind.name}($code)';

    return 'AudioScanException[$prefix]: $message';
  }
}

class AudioScanResult {
  const AudioScanResult._({
    required this.succeeded,
    required this.permissionGranted,
    required this.records,
    this.error,
    this.stackTrace,
  });

  factory AudioScanResult.success(
    List<NativeAudioRecord> records,
  ) {
    return AudioScanResult._(
      succeeded: true,
      permissionGranted: true,
      records: List<NativeAudioRecord>.unmodifiable(records),
    );
  }

  factory AudioScanResult.failure({
    required bool permissionGranted,
    required Object error,
    StackTrace? stackTrace,
  }) {
    return AudioScanResult._(
      succeeded: false,
      permissionGranted: permissionGranted,
      records: const <NativeAudioRecord>[],
      error: error,
      stackTrace: stackTrace,
    );
  }

  final bool succeeded;
  final bool permissionGranted;
  final List<NativeAudioRecord> records;
  final Object? error;
  final StackTrace? stackTrace;

  bool get isSuccessfulEmpty => succeeded && records.isEmpty;

  Set<String> get authoritativeVolumeNames => records
      .map((record) => record.normalizedVolumeName)
      .where((volumeName) => volumeName.isNotEmpty)
      .toSet();

  Set<String> get nonAuthoritativeVolumeNames => const <String>{};

  bool get hasAuthoritativeVolumes => authoritativeVolumeNames.isNotEmpty;

  bool get isFullyAuthoritative =>
      succeeded && permissionGranted && error == null;

  String get partialFailureMessage => error?.toString() ?? '';
}

class AudioLibraryScanner {
  AudioLibraryScanner({
    NativeMediaLibraryService? mediaLibrary,
    MediaPermissionService? permissionService,
  })  : _mediaLibrary = mediaLibrary ?? NativeMediaLibraryService.instance,
        _permissionService =
            permissionService ?? MediaPermissionService.instance;

  final NativeMediaLibraryService _mediaLibrary;
  final MediaPermissionService _permissionService;

  static const int _queryAttempts = 3;
  static const Duration _defaultMinDuration = Duration(seconds: 1);

  Future<bool> requestPermission({
    int attempts = 1,
    bool interactive = false,
  }) async {
    final result = interactive
        ? await _permissionService.request(attempts: attempts)
        : await _permissionService.check();

    if (!result.granted) {
      debugPrint(
        '[AudioScanner] Permission request did not grant scan access: '
        '${result.state.name}',
      );
    }

    return result.granted;
  }

  /// Checks whether the native MediaStore bridge can currently read audio.
  Future<bool> hasPermission() async {
    final result = await _permissionService.check();

    if (!result.granted && result.error != null) {
      debugPrint(
        '[AudioScanner] Permission status check failed: ${result.error}',
      );
    }

    return result.granted;
  }

  Future<AudioScanResult> queryAudio({
    Duration minDuration = _defaultMinDuration,
    bool includeInternal = false,
    bool includeRingtones = false,
    bool includeAlarms = false,
    bool includeNotifications = false,
    bool includePodcasts = true,
    Iterable<String> knownVolumeNames = const <String>[],
  }) async {
    if (!NativeMediaLibraryService.isSupported) {
      return AudioScanResult.failure(
        permissionGranted: false,
        error: const AudioScanException(
          kind: AudioScanFailureKind.unsupportedPlatform,
          message: 'Audio scanning is only supported on Android.',
        ),
      );
    }

    final permission = await _permissionService.check();

    if (!permission.granted) {
      final permissionError = permission.error;
      final isVerificationFailure =
          permission.state == MediaPermissionState.error;

      return AudioScanResult.failure(
        permissionGranted: false,
        error: AudioScanException(
          kind: isVerificationFailure
              ? AudioScanFailureKind.platformFailure
              : AudioScanFailureKind.permissionDenied,
          code: isVerificationFailure
              ? 'PERMISSION_CHECK_FAILED'
              : 'PERMISSION_DENIED',
          message: permission.message,
          cause: permissionError,
        ),
        stackTrace: permission.stackTrace,
      );
    }

    Object? lastError;
    StackTrace? lastStackTrace;

    for (var attempt = 0; attempt < _queryAttempts; attempt++) {
      try {
        final records = await _mediaLibrary.queryAudio(
          minDuration: minDuration,
          includeInternal: includeInternal,
          includeRingtones: includeRingtones,
          includeAlarms: includeAlarms,
          includeNotifications: includeNotifications,
          includePodcasts: includePodcasts,
        );

        return AudioScanResult.success(
          _dedupeRecords(records),
        );
      } on PlatformException catch (error, stackTrace) {
        final permissionDenied = error.code == 'PERMISSION_DENIED';

        final scanError = AudioScanException(
          kind: permissionDenied
              ? AudioScanFailureKind.permissionDenied
              : AudioScanFailureKind.platformFailure,
          code: error.code,
          message: error.message ?? 'Android MediaStore query failed.',
          cause: error,
        );

        if (permissionDenied) {
          return AudioScanResult.failure(
            permissionGranted: false,
            error: scanError,
            stackTrace: stackTrace,
          );
        }

        lastError = scanError;
        lastStackTrace = stackTrace;
      } on FormatException catch (error, stackTrace) {
        lastError = AudioScanException(
          kind: AudioScanFailureKind.malformedResponse,
          message: error.message,
          cause: error,
        );

        lastStackTrace = stackTrace;
      } catch (error, stackTrace) {
        lastError = AudioScanException(
          kind: AudioScanFailureKind.unknown,
          message: 'Android MediaStore query failed.',
          cause: error,
        );

        lastStackTrace = stackTrace;
      }

      if (attempt + 1 < _queryAttempts) {
        debugPrint(
          '[AudioScanner] MediaStore query failed; retrying '
          '${attempt + 1}/$_queryAttempts: $lastError',
        );

        await Future<void>.delayed(
          Duration(milliseconds: 350 + (attempt * 450)),
        );
      }
    }

    final error = lastError ??
        const AudioScanException(
          kind: AudioScanFailureKind.unknown,
          message: 'Android MediaStore query failed without an error.',
        );

    debugPrint('[AudioScanner] MediaStore audio query failed: $error');

    return AudioScanResult.failure(
      permissionGranted: true,
      error: error,
      stackTrace: lastStackTrace,
    );
  }

  List<NativeAudioRecord> _dedupeRecords(List<NativeAudioRecord> records) {
    if (records.isEmpty) return const <NativeAudioRecord>[];

    final byStableKey = <String, NativeAudioRecord>{};
    final byPath = <String, NativeAudioRecord>{};
    final byId = <int, NativeAudioRecord>{};

    for (final record in records) {
      final stableKey = record.stableKey.trim();
      if (stableKey.isNotEmpty) {
        byStableKey.putIfAbsent(stableKey, () => record);
        continue;
      }

      final path = record.resolvedPath.trim();
      if (path.isNotEmpty) {
        byPath.putIfAbsent(path, () => record);
        continue;
      }

      byId.putIfAbsent(record.id, () => record);
    }

    final result = <NativeAudioRecord>[
      ...byStableKey.values,
      ...byPath.values.where(
        (record) => !byStableKey.values.any(
          (existing) => existing.id == record.id,
        ),
      ),
      ...byId.values.where(
        (record) => !byStableKey.values.any(
              (existing) => existing.id == record.id,
            ) &&
            !byPath.values.any(
              (existing) => existing.id == record.id,
            ),
      ),
    ];

    result.sort((a, b) {
      final titleCompare = a.title.toLowerCase().compareTo(
            b.title.toLowerCase(),
          );
      if (titleCompare != 0) return titleCompare;

      final artistCompare = a.artist.toLowerCase().compareTo(
            b.artist.toLowerCase(),
          );
      if (artistCompare != 0) return artistCompare;

      return a.id.compareTo(b.id);
    });

    return List<NativeAudioRecord>.unmodifiable(result);
  }
}
