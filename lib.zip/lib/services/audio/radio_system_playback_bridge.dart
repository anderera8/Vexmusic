// lib/services/audio/radio_system_playback_bridge.dart
// ─────────────────────────────────────────────────────────────────────────────
// RadioSystemPlaybackBridge — gives the Radio feature lock-screen and
// notification play/pause/stop controls by publishing its state through the
// same audio_service / CoordinatorAudioHandler plumbing local music already
// uses (see PlaybackSystemService).
//
// RadioProvider is deliberately self-contained and never imports anything
// from services/playback/* (see its own header comment) — this bridge is
// the one place that connects the two, from the outside, so that boundary
// stays intact. Constructed once in main.dart, alongside the existing
// mutual-exclusion wiring between MusicProvider and RadioProvider.
//
// What it does, each time RadioProvider notifies:
//   • No station loaded at all → release system controls back to local
//     playback (a no-op if we never held them).
//   • A station is loaded (playing, paused, loading, buffering, or
//     errored) → take temporary ownership of play/pause/stop (once) and
//     (re-)publish the station's name/art/status so the notification
//     reflects it, skipping the publish if nothing it cares about
//     actually changed since the last notification.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:audio_service/audio_service.dart';

import '../../providers/radio_provider.dart';
import '../playback/playback_system_service.dart';
import '../radio/radio_player_service.dart' show RadioPlaybackStatus;

class RadioSystemPlaybackBridge {
  final RadioProvider _radio;

  bool _ownsSystemControls = false;
  String? _lastStationUuid;
  bool? _lastPlaying;
  RadioPlaybackStatus? _lastStatus;
  String? _lastNowPlayingText;

  RadioSystemPlaybackBridge(this._radio) {
    _radio.addListener(_sync);
  }

  void _sync() {
    final station = _radio.currentStation;

    if (station == null) {
      _release();
      return;
    }

    if (!_ownsSystemControls) {
      _ownsSystemControls = true;
      PlaybackSystemService.pushTemporaryQueueControlCallbacks(
        onPlay: _radio.systemPlay,
        onPause: _radio.systemPause,
        onStop: _radio.stopAndClear,
      );
      PlaybackSystemService.enterExternalPlaybackMode();
    }

    final playing = _radio.isPlaying;
    final status = _radio.playbackStatus;
    final nowPlaying = _radio.nowPlayingText;

    // ChangeNotifier's notifyListeners() doesn't say *what* changed (e.g.
    // toggling a favorite elsewhere notifies too) — skip the platform-
    // channel call unless something the notification actually shows
    // changed since the last publish.
    if (station.uuid == _lastStationUuid &&
        playing == _lastPlaying &&
        status == _lastStatus &&
        nowPlaying == _lastNowPlayingText) {
      return;
    }

    final processingState = switch (status) {
      RadioPlaybackStatus.idle => AudioProcessingState.idle,
      RadioPlaybackStatus.loading => AudioProcessingState.loading,
      RadioPlaybackStatus.buffering => AudioProcessingState.buffering,
      RadioPlaybackStatus.playing => AudioProcessingState.ready,
      RadioPlaybackStatus.paused => AudioProcessingState.ready,
      RadioPlaybackStatus.error => AudioProcessingState.error,
    };

    final favicon = station.favicon.trim();
    final artUri = favicon.isEmpty ? null : Uri.tryParse(favicon);

    final subtitle = (nowPlaying != null && nowPlaying.trim().isNotEmpty)
        ? nowPlaying.trim()
        : (station.country.isNotEmpty ? station.country : 'Live Radio');

    final published = PlaybackSystemService.publishExternalNowPlaying(
      id: 'radio:${station.uuid}',
      title: station.name,
      subtitle: subtitle,
      artUri: (artUri != null && artUri.hasScheme) ? artUri : null,
      playing: playing,
      processingState: processingState,
    );
    // Only remember this as "last published" if a handler actually
    // received it — otherwise (the startup window before
    // PlaybackSystemService.initialize finishes, in practice unreachable
    // but cheap to be correct about) the next _sync() call would wrongly
    // see this as unchanged and skip retrying, leaving the notification
    // never showing anything for the rest of the session.
    if (published) {
      _lastStationUuid = station.uuid;
      _lastPlaying = playing;
      _lastStatus = status;
      _lastNowPlayingText = nowPlaying;
    }
  }

  void _release() {
    if (!_ownsSystemControls) return;
    _ownsSystemControls = false;
    _lastStationUuid = null;
    _lastPlaying = null;
    _lastStatus = null;
    _lastNowPlayingText = null;

    PlaybackSystemService.exitExternalPlaybackMode();
    PlaybackSystemService.popTemporaryQueueControlCallbacks();
  }

  void dispose() {
    _radio.removeListener(_sync);
  }
}
