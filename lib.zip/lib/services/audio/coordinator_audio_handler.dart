// lib/services/audio/coordinator_audio_handler.dart
// ─────────────────────────────────────────────────────────────────────────────
// CoordinatorAudioHandler — bridges MediaPlaybackCoordinator to audio_service.
//
// System controls route through the JustAudioEngine.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import '../../models/media_models.dart';
import '../playback/media_playback_coordinator.dart';

typedef SystemPlaybackCommand = Future<void> Function();
typedef SystemSeekCommand = Future<void> Function(Duration position);
typedef SystemShuffleCommand = Future<void> Function(bool enabled);
typedef SystemRepeatCommand = Future<void> Function(PlaybackRepeatMode mode);

class CoordinatorAudioHandler extends BaseAudioHandler with SeekHandler {
  final MediaPlaybackCoordinator _coordinator;
  final List<StreamSubscription<dynamic>> _subscriptions = [];

  SystemPlaybackCommand? _onPlay;
  SystemPlaybackCommand? _onPause;
  SystemPlaybackCommand? _onStop;
  SystemSeekCommand? _onSeek;
  SystemPlaybackCommand? _onSkipNext;
  SystemPlaybackCommand? _onSkipPrevious;
  SystemShuffleCommand? _onSetShuffle;
  SystemRepeatCommand? _onSetRepeatMode;

  bool _controlsEnabled = true;
  Future<void> _systemCommandTail = Future<void>.value();

  /// While true, [_onPlaybackStateChanged] and [_onQueueStateChanged]
  /// ignore updates from [_coordinator] instead of publishing them, so an
  /// external source (Radio, via [publishExternalNowPlaying]) can drive
  /// the lock screen/notification without local-queue updates racing in
  /// and overwriting it. Set via [enterExternalPlaybackMode] /
  /// [exitExternalPlaybackMode].
  bool _externalActive = false;

  CoordinatorAudioHandler(
    this._coordinator, {
    SystemPlaybackCommand? onPlay,
    SystemPlaybackCommand? onPause,
    SystemPlaybackCommand? onStop,
    SystemSeekCommand? onSeek,
    SystemPlaybackCommand? onSkipNext,
    SystemPlaybackCommand? onSkipPrevious,
    SystemShuffleCommand? onSetShuffle,
    SystemRepeatCommand? onSetRepeatMode,
  })  : _onPlay = onPlay,
        _onPause = onPause,
        _onStop = onStop,
        _onSeek = onSeek,
        _onSkipNext = onSkipNext,
        _onSkipPrevious = onSkipPrevious,
        _onSetShuffle = onSetShuffle,
        _onSetRepeatMode = onSetRepeatMode {
    // ── Publish playback state to audio_service ──────────────────────
    _subscriptions.add(
      _coordinator.playbackState.listen(_onPlaybackStateChanged),
    );

    // ── Publish queue/metadata to audio_service ──────────────────────
    _subscriptions.add(
      _coordinator.queueState.listen(_onQueueStateChanged),
    );

    // Seed initial state
    _publishCurrentState();
  }

  // ── State mapping: coordinator → audio_service ────────────────────

  void _onPlaybackStateChanged(PlaybackSnapshot snapshot) {
    if (_externalActive) return;
    _publishState(snapshot);
  }

  void _onQueueStateChanged(PlaybackQueue queue) {
    if (_externalActive) return;
    final items = queue.entries.map(_toMediaItem).toList(growable: false);
    this.queue.add(items);

    final current = queue.current;
    if (current != null) {
      mediaItem.add(_toMediaItem(current));
    }
    _publishCurrentState();
  }

  MediaItem _toMediaItem(MediaEntry entry) => MediaItem(
        id: entry.id,
        title: entry.title,
        artist: entry.artist.isNotEmpty ? entry.artist : 'Unknown Artist',
        album: entry.album,
        duration: entry.duration,
        artUri: _artUri(entry.artworkPath),
      );

  Uri? _artUri(String path) {
    if (path.isEmpty) return null;
    final uri = Uri.tryParse(path);
    if (uri != null && uri.hasScheme) return uri;
    return Uri.file(path);
  }

  void _publishCurrentState() {
    _publishState(_coordinator.currentState);
  }

  void _publishState(PlaybackSnapshot snapshot) {
    final processingState = switch (snapshot.processingState) {
      PlaybackProcessingState.idle => AudioProcessingState.idle,
      PlaybackProcessingState.loading => AudioProcessingState.loading,
      PlaybackProcessingState.buffering => AudioProcessingState.buffering,
      PlaybackProcessingState.ready => AudioProcessingState.ready,
      PlaybackProcessingState.completed => AudioProcessingState.completed,
      PlaybackProcessingState.error => AudioProcessingState.error,
    };

    final queue = _coordinator.currentQueue;

    playbackState.add(PlaybackState(
      controls: _controlsEnabled
          ? [
              MediaControl.skipToPrevious,
              if (snapshot.playing) MediaControl.pause else MediaControl.play,
              MediaControl.stop,
              MediaControl.skipToNext,
            ]
          : const [],
      systemActions: _controlsEnabled
          ? const {
              MediaAction.seek,
              MediaAction.skipToNext,
              MediaAction.skipToPrevious,
              MediaAction.play,
              MediaAction.pause,
              MediaAction.stop,
            }
          : const {},
      androidCompactActionIndices:
          _controlsEnabled ? const [0, 1, 3] : const [],
      processingState: processingState,
      playing: snapshot.playing,
      updatePosition: snapshot.position,
      bufferedPosition: snapshot.bufferedPosition,
      speed: snapshot.speed,
      queueIndex: queue.currentIndex >= 0 ? queue.currentIndex : null,
      repeatMode: switch (queue.repeatMode) {
        PlaybackRepeatMode.off => AudioServiceRepeatMode.none,
        PlaybackRepeatMode.all => AudioServiceRepeatMode.all,
        PlaybackRepeatMode.one => AudioServiceRepeatMode.one,
      },
      shuffleMode: queue.shuffleEnabled
          ? AudioServiceShuffleMode.all
          : AudioServiceShuffleMode.none,
    ));
  }

  // ── External source support (Radio) ────────────────────────────────

  /// Stops publishing [_coordinator]'s state to the lock screen/
  /// notification. Call [publishExternalNowPlaying] afterward to show
  /// something in its place; this alone just stops local updates, it
  /// doesn't publish anything itself.
  void enterExternalPlaybackMode() {
    _externalActive = true;
  }

  /// Resumes publishing [_coordinator]'s state, immediately refreshing
  /// from its current queue/snapshot so the notification doesn't keep
  /// showing whatever the external source last published.
  void exitExternalPlaybackMode() {
    _externalActive = false;
    final current = _coordinator.currentQueue.current;
    if (current != null) {
      mediaItem.add(_toMediaItem(current));
    }
    _publishCurrentState();
  }

  /// Publishes now-playing info for an external (non-local-queue) source.
  /// Only takes visible effect between [enterExternalPlaybackMode] and
  /// [exitExternalPlaybackMode] — [_coordinator] would otherwise overwrite
  /// it on its next update.
  ///
  /// Deliberately minimal compared to [_publishState]: no queue index, no
  /// duration/seek support, no shuffle/repeat, and no skip controls — none
  /// of those map onto a live stream. Just play/pause (reflecting
  /// [playing]) and stop.
  void publishExternalNowPlaying({
    required String id,
    required String title,
    String? subtitle,
    Uri? artUri,
    required bool playing,
    required AudioProcessingState processingState,
  }) {
    mediaItem.add(MediaItem(
      id: id,
      title: title,
      artist: subtitle,
      artUri: artUri,
    ));
    queue.add(const []);

    playbackState.add(PlaybackState(
      controls: [
        playing ? MediaControl.pause : MediaControl.play,
        MediaControl.stop,
      ],
      systemActions: const {
        MediaAction.play,
        MediaAction.pause,
        MediaAction.stop,
      },
      androidCompactActionIndices: const [0, 1],
      processingState: processingState,
      playing: playing,
    ));
  }

  void setControlsEnabled(bool enabled) {
    _controlsEnabled = enabled;
    _publishCurrentState();
  }

  void setQueueControlCallbacks({
    SystemPlaybackCommand? onPlay,
    SystemPlaybackCommand? onPause,
    SystemPlaybackCommand? onStop,
    SystemSeekCommand? onSeek,
    SystemPlaybackCommand? onSkipNext,
    SystemPlaybackCommand? onSkipPrevious,
    SystemShuffleCommand? onSetShuffle,
    SystemRepeatCommand? onSetRepeatMode,
  }) {
    _onPlay = onPlay;
    _onPause = onPause;
    _onStop = onStop;
    _onSeek = onSeek;
    _onSkipNext = onSkipNext;
    _onSkipPrevious = onSkipPrevious;
    _onSetShuffle = onSetShuffle;
    _onSetRepeatMode = onSetRepeatMode;
  }

  Future<void> _runSerializedSystemCommand(
    String label,
    SystemPlaybackCommand? command,
    Future<void> Function() fallback,
  ) {
    Future<void> run() async {
      if (command != null) {
        await command();
      } else {
        await fallback();
      }
    }

    final operation = _systemCommandTail.then((_) => run());
    _systemCommandTail = operation.catchError(
      (Object error, StackTrace stack) {
        debugPrint('[AudioHandler] $label failed: $error');
        debugPrintStack(stackTrace: stack);
      },
    );

    return operation;
  }

  // ── System control → coordinator ──────────────────────────────────

  @override
  Future<void> play() {
    return _runSerializedSystemCommand(
      'notification play',
      _onPlay,
      _coordinator.play,
    );
  }

  @override
  Future<void> pause() {
    debugPrint('[Playback] pause requested: notification/system control');
    return _runSerializedSystemCommand(
      'notification pause',
      _onPause,
      _coordinator.pause,
    );
  }

  @override
  Future<void> stop() {
    return _runSerializedSystemCommand(
      'notification stop',
      _onStop,
      _coordinator.stop,
    );
  }

  @override
  Future<void> onTaskRemoved() async {
    debugPrint('[Playback] task removed: retaining active audio playback');
    // Playback is intentionally retained when Android removes the activity
    // task. Explicit Stop remains the only task-removal termination path.
  }

  @override
  Future<void> seek(Duration position) {
    final callback = _onSeek;
    return _runSerializedSystemCommand(
      'notification seek',
      callback == null ? null : () => callback(position),
      () => _coordinator.seek(position),
    );
  }

  @override
  Future<void> skipToNext() => _runSerializedSystemCommand(
        'notification skipToNext',
        _onSkipNext,
        _coordinator.skipNext,
      );

  @override
  Future<void> skipToPrevious() => _runSerializedSystemCommand(
        'notification skipToPrevious',
        _onSkipPrevious,
        _coordinator.skipPrevious,
      );

  @override
  Future<void> skipToQueueItem(int index) =>
      _runSerializedSystemCommand(
        'notification skipToQueueItem',
        null,
        () => _coordinator.jumpTo(index),
      );

  @override
  Future<void> setShuffleMode(AudioServiceShuffleMode shuffleMode) async {
    final enabled = shuffleMode == AudioServiceShuffleMode.all;
    final callback = _onSetShuffle;
    await _runSerializedSystemCommand(
      'notification setShuffleMode',
      callback == null ? null : () => callback(enabled),
      () => _coordinator.setShuffle(enabled),
    );
  }

  @override
  Future<void> setRepeatMode(AudioServiceRepeatMode repeatMode) async {
    final mode = switch (repeatMode) {
      AudioServiceRepeatMode.none => PlaybackRepeatMode.off,
      AudioServiceRepeatMode.all => PlaybackRepeatMode.all,
      AudioServiceRepeatMode.one => PlaybackRepeatMode.one,
      _ => PlaybackRepeatMode.off,
    };
    final callback = _onSetRepeatMode;
    await _runSerializedSystemCommand(
      'notification setRepeatMode',
      callback == null ? null : () => callback(mode),
      () => _coordinator.setRepeatMode(mode),
    );
  }

  Future<void> disposeSubscriptions() async {
    for (final subscription in _subscriptions) {
      await subscription.cancel();
    }
    _subscriptions.clear();
  }
}
