import 'dart:io';

import 'package:flutter/services.dart';

class SystemFontService {
  static const _androidFallbackFamily = 'sans-serif';
  static const _samsungFontRoot = '/data/app_fonts/';
  static const _samsungLocatorPath = '/data/app_fonts/0/sans.loc';

  static String? _loadedSignature;
  static String? _loadedFamily;

  static Future<String?> loadCurrentFamily() async {
    if (!Platform.isAndroid) return null;

    try {
      final locator = File(_samsungLocatorPath);
      if (!await locator.exists()) return _androidFallbackFamily;

      final location = (await locator.readAsString()).split('#').first.trim();
      if (!location.startsWith(_samsungFontRoot)) {
        return _androidFallbackFamily;
      }

      final regular = File('$location/DroidSans.ttf');
      if (!await regular.exists()) return _androidFallbackFamily;

      final bold = File('$location/DroidSans-Bold.ttf');
      final regularStat = await regular.stat();
      final boldStat = await bold.exists() ? await bold.stat() : null;
      final signature = [
        location,
        regularStat.modified.millisecondsSinceEpoch,
        regularStat.size,
        boldStat?.modified.millisecondsSinceEpoch ?? 0,
        boldStat?.size ?? 0,
      ].join(':');

      if (_loadedSignature == signature && _loadedFamily != null) {
        return _loadedFamily;
      }

      final family = 'SamsungSystemFont_'
          '${regularStat.modified.millisecondsSinceEpoch}_${regularStat.size}';
      final loader = FontLoader(family)..addFont(_readFont(regular));
      if (boldStat != null) {
        loader.addFont(_readFont(bold));
      }
      await loader.load();

      _loadedSignature = signature;
      _loadedFamily = family;
      return family;
    } catch (_) {
      return _androidFallbackFamily;
    }
  }

  static Future<ByteData> _readFont(File file) async {
    final bytes = await file.readAsBytes();
    return ByteData.sublistView(bytes);
  }
}
