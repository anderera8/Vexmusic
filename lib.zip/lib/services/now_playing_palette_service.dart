import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/music_models.dart';
import 'artwork_cache_service.dart';

/// Extracts and caches one theme-safe accent color for Now Playing artwork.
class NowPlayingPaletteService {
  NowPlayingPaletteService._();

  static final Map<String, Color?> _cache = <String, Color?>{};
  static final Map<String, Future<Color?>> _pending =
      <String, Future<Color?>>{};

  static Future<Color?> colorForTrack(
    Track track, {
    required Brightness brightness,
  }) {
    final key = _cacheKey(track, brightness);
    if (_cache.containsKey(key)) {
      return Future<Color?>.value(_cache[key]);
    }

    return _pending.putIfAbsent(key, () async {
      try {
        final bytes = await _loadArtwork(track);
        if (bytes == null || bytes.isEmpty) {
          _cache[key] = null;
          return null;
        }

        final color = await _extractColor(bytes, brightness);
        _cache[key] = color;
        return color;
      } catch (_) {
        _cache[key] = null;
        return null;
      } finally {
        _pending.remove(key);
      }
    });
  }

  static void invalidateTrack(Track track) {
    final prefix = _identityKey(track);
    _cache.removeWhere((key, _) => key.startsWith('$prefix:'));
    _pending.removeWhere((key, _) => key.startsWith('$prefix:'));
  }

  static String _cacheKey(Track track, Brightness brightness) =>
      '${_identityKey(track)}:${brightness.name}';

  static String _identityKey(Track track) {
    final stableKey = track.stableKey.trim().toLowerCase();
    if (stableKey.isNotEmpty) return 'stable:$stableKey';

    final volume = track.volumeName.trim().toLowerCase();
    if (track.mediaStoreId > 0) {
      return 'native:$volume:${track.mediaStoreId}';
    }

    return 'app:${track.id}';
  }

  static Future<Uint8List?> _loadArtwork(Track track) async {
    if (track.mediaStoreId > 0) {
      final bytes = await ArtworkCacheService.loadTrackArtwork(
        track.mediaStoreId,
        stableKey: track.stableKey,
        volumeName: track.volumeName,
        legacyTrackId: track.id,
        size: 64,
        quality: 72,
      );
      if (bytes != null && bytes.isNotEmpty) return bytes;
    }

    final albumId = track.albumId;
    if (albumId != null && albumId > 0) {
      return ArtworkCacheService.loadArtwork(
        albumId,
        type: ArtworkType.album,
        volumeName: track.volumeName,
        size: 64,
        quality: 72,
      );
    }

    return null;
  }

  static Future<Color?> _extractColor(
    Uint8List bytes,
    Brightness brightness,
  ) async {
    final codec = await ui.instantiateImageCodec(
      bytes,
      targetWidth: 32,
      targetHeight: 32,
    );

    try {
      final frame = await codec.getNextFrame();
      try {
        final data = await frame.image.toByteData(
          format: ui.ImageByteFormat.rawRgba,
        );
        if (data == null) return null;

        final rgba = data.buffer.asUint8List();
        final bins = <int, _ColorBin>{};

        for (var offset = 0; offset + 3 < rgba.length; offset += 4) {
          final alpha = rgba[offset + 3];
          if (alpha < 180) continue;

          final red = rgba[offset];
          final green = rgba[offset + 1];
          final blue = rgba[offset + 2];
          final maxChannel = red > green
              ? (red > blue ? red : blue)
              : (green > blue ? green : blue);
          final minChannel = red < green
              ? (red < blue ? red : blue)
              : (green < blue ? green : blue);
          final chroma = maxChannel - minChannel;

          // Ignore near-black, near-white, and almost-grey pixels.
          if (maxChannel < 34 || minChannel > 226 || chroma < 18) continue;

          final key = ((red >> 4) << 8) | ((green >> 4) << 4) | (blue >> 4);
          final saturationWeight = 1.0 + (chroma / 255.0) * 2.5;
          final luminance =
              (0.2126 * red + 0.7152 * green + 0.0722 * blue) / 255.0;
          final luminanceWeight = 1.0 - (luminance - 0.52).abs() * 0.65;
          final weight = saturationWeight *
              luminanceWeight.clamp(0.35, 1.0).toDouble();

          bins.putIfAbsent(key, _ColorBin.new).add(
                red,
                green,
                blue,
                weight,
              );
        }

        if (bins.isEmpty) return null;

        final best = bins.values.reduce(
          (left, right) => left.score >= right.score ? left : right,
        );
        final raw = best.color;
        final hsl = HSLColor.fromColor(raw);
        final targetLightness = brightness == Brightness.dark
            ? hsl.lightness.clamp(0.42, 0.62).toDouble()
            : hsl.lightness.clamp(0.30, 0.48).toDouble();

        return hsl
            .withSaturation(
              hsl.saturation.clamp(0.48, 0.88).toDouble(),
            )
            .withLightness(targetLightness)
            .toColor();
      } finally {
        frame.image.dispose();
      }
    } finally {
      codec.dispose();
    }
  }
}

class _ColorBin {
  double red = 0;
  double green = 0;
  double blue = 0;
  double weight = 0;
  double score = 0;

  void add(int r, int g, int b, double sampleWeight) {
    red += r * sampleWeight;
    green += g * sampleWeight;
    blue += b * sampleWeight;
    weight += sampleWeight;
    score += sampleWeight;
  }

  Color get color {
    final divisor = weight <= 0 ? 1.0 : weight;
    return Color.fromARGB(
      255,
      (red / divisor).round().clamp(0, 255).toInt(),
      (green / divisor).round().clamp(0, 255).toInt(),
      (blue / divisor).round().clamp(0, 255).toInt(),
    );
  }
}
