// android/app/src/main/kotlin/com/vextech/vexmusic/handlers/SpectrumCaptureHandler.kt
//
// Bridges the SoftwareEqProcessor's Goertzel spectrum analyser to Flutter
// via an EventChannel.  The processor computes FFT magnitudes for all 10
// EQ bands on the audio thread; this handler receives them on the main
// thread and streams them to Dart.
//
// Channel: "vexmusic/audio_spectrum"
// Data format: List<Double> of 10 normalised magnitudes (0.0–1.0)

package com.vextech.vexmusic.handlers

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.vextech.vexmusic.dsp.SoftwareEqProcessor
import com.vextech.vexmusic.dsp.SoftwareEqProcessorHolder
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel

class SpectrumCaptureHandler : BaseHandler() {

    companion object {
        private const val CHANNEL_NAME = "vexmusic/audio_spectrum"
        private const val TAG = "SpectrumCaptureHandler"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var eventChannel: EventChannel? = null

    @Volatile
    private var eventSink: EventChannel.EventSink? = null

    @Volatile
    private var isListening = false

    // The Goertzel FFT capture listener, attached to the software EQ processor.
    // SoftwareEqProcessor invokes this from ExoPlayer's audio-processing
    // thread, but EventChannel.EventSink is only safe to call from the main
    // thread, so every reading is hopped over before touching the sink.
    private val spectrumListener = SoftwareEqProcessor.SpectrumListener { magnitudes ->
        if (!isListening) return@SpectrumListener
        val values = magnitudes.toList()
        mainHandler.post {
            val sink = eventSink ?: return@post
            try {
                sink.success(values)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to send spectrum data: ${e.message}")
            }
        }
    }

    // ── BaseHandler ───────────────────────────────────────────────────────────

    override fun register(flutterEngine: FlutterEngine) {
        eventChannel = EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )
        eventChannel!!.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                Log.d(TAG, "Spectrum stream started")
                eventSink = events
                isListening = true
                SoftwareEqProcessorHolder.instance.spectrumListener = spectrumListener
            }

            override fun onCancel(arguments: Any?) {
                Log.d(TAG, "Spectrum stream stopped")
                isListening = false
                eventSink = null
                SoftwareEqProcessorHolder.instance.spectrumListener = null
            }
        })
        Log.d(TAG, "Spectrum capture handler registered")
    }

    override fun cleanup() {
        isListening = false
        eventSink = null
        SoftwareEqProcessorHolder.instance.spectrumListener = null
        eventChannel = null
    }
}
