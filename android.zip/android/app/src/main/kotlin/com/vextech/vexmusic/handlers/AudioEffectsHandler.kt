package com.vextech.vexmusic.handlers

import android.content.Context
import android.util.Log
import com.vextech.vexmusic.dsp.SoftwareEqProcessor
import com.vextech.vexmusic.dsp.SoftwareEqProcessorHolder
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result

class AudioEffectsHandler(
    @Suppress("UNUSED_PARAMETER") context: Context
) : BaseHandler(), MethodCallHandler {

    companion object {
        private const val CHANNEL_NAME = "vexmusic/audio_effects"
        private const val TAG = "AudioEffectsHandler"
        private const val BAND_COUNT = 10
    }

    private val processor: SoftwareEqProcessor
        get() = SoftwareEqProcessorHolder.instance

    override fun register(flutterEngine: FlutterEngine) {
        channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )
        channel.setMethodCallHandler(this)
    }

    override fun cleanup() = Unit

    override fun onMethodCall(call: MethodCall, result: Result) {
        when (call.method) {
            "initializeEffects" -> handleInitialize(result)
            "applyConfiguration" -> handleApplyConfiguration(call, result)
            "setBandGains" -> handleSetBandGains(call, result)
            "setBandGain" -> handleSetBandGain(call, result)
            "setEnabled" -> handleSetEnabled(call, result)
            "resetAll" -> handleResetAll(result)
            "setVolumeGain" -> handleLegacyVolumeGain(call, result)
            "setStereoWidth" -> handleSetStereoWidth(call, result)
            "setLoudnessEnhancer" -> handleLegacyBassBoost(call, result)
            "setVirtualizer" -> handleLegacyVirtualizer(call, result)
            "setEqualizer" -> result.success(true)
            "releaseEffects" -> result.success(true)
            "getAudioSessionId" -> result.success(-1)
            else -> result.notImplemented()
        }
    }

    private fun handleInitialize(result: Result) {
        try {
            val attached = SoftwareEqProcessorHolder.isRendererAttached()
            val bands = SoftwareEqProcessor.CENTRE_FREQUENCIES.mapIndexed { index, frequency ->
                mapOf(
                    "band" to index,
                    "centerFreqHz" to frequency,
                    "minDb" to -12.0,
                    "maxDb" to 12.0
                )
            }

            result.success(
                mapOf(
                    "softwareEqAvailable" to attached,
                    "rendererAttached" to attached,
                    "processorConfigured" to processor.isConfigured,
                    "loudnessEnhancerAvailable" to attached,
                    "virtualizerAvailable" to attached,
                    "equalizerAvailable" to attached,
                    "bandCount" to BAND_COUNT,
                    "bands" to bands,
                    "message" to if (attached) {
                        "Software DSP renderer attached."
                    } else {
                        "The custom just_audio renderer has not attached yet."
                    }
                )
            )
        } catch (error: Exception) {
            Log.e(TAG, "initializeEffects failed", error)
            result.error("INIT_ERROR", error.message, null)
        }
    }

    private fun handleApplyConfiguration(call: MethodCall, result: Result) {
        try {
            if (!SoftwareEqProcessorHolder.isRendererAttached()) {
                return result.error(
                    "DSP_UNAVAILABLE",
                    "The software DSP renderer is not attached.",
                    null
                )
            }

            val enabled = call.argument<Boolean>("enabled")
                ?: return result.error("INVALID_ARG", "'enabled' is required", null)
            val gains = readGains(call)
                ?: return result.error(
                    "INVALID_ARG",
                    "'gains' must contain exactly $BAND_COUNT numeric values",
                    null
                )
            val bassBoost = readNumber(call, "bassBoost") ?: 0.0
            val volumeBoost = readNumber(call, "volumeBoost") ?: 0.0
            val stereoWidth = readNumber(call, "stereoWidth") ?: 1.0
            val normalization = call.argument<Boolean>("normalization") ?: false
            val revision = readNumber(call, "revision")?.toLong() ?: 0L

            processor.applyConfiguration(
                enabled = enabled,
                gainsDb = gains,
                bassBoost = bassBoost,
                volumeBoost = volumeBoost,
                stereoWidth = stereoWidth,
                normalization = normalization,
                revision = revision
            )

            result.success(
                mapOf(
                    "applied" to true,
                    "revision" to revision,
                    "processorConfigured" to processor.isConfigured
                )
            )
        } catch (error: Exception) {
            Log.e(TAG, "applyConfiguration failed", error)
            result.error("APPLY_ERROR", error.message, null)
        }
    }

    private fun handleSetBandGains(call: MethodCall, result: Result) {
        try {
            val gains = readGains(call)
                ?: return result.error(
                    "INVALID_ARG",
                    "'gains' must contain exactly $BAND_COUNT numeric values",
                    null
                )
            processor.setBandGains(gains)
            result.success(true)
        } catch (error: Exception) {
            result.error("SET_ERROR", error.message, null)
        }
    }

    private fun handleSetBandGain(call: MethodCall, result: Result) {
        try {
            val band = call.argument<Int>("band")
                ?: return result.error("INVALID_ARG", "'band' is required", null)
            val gain = readNumber(call, "gainDb")
                ?: return result.error("INVALID_ARG", "'gainDb' is required", null)
            processor.setBandGain(band, gain)
            result.success(true)
        } catch (error: Exception) {
            result.error("SET_ERROR", error.message, null)
        }
    }

    private fun handleSetEnabled(call: MethodCall, result: Result) {
        val enabled = call.argument<Boolean>("enabled")
            ?: return result.error("INVALID_ARG", "'enabled' is required", null)
        processor.setEnabled(enabled)
        result.success(true)
    }

    private fun handleResetAll(result: Result) {
        processor.resetAll()
        result.success(true)
    }

    private fun handleLegacyVolumeGain(call: MethodCall, result: Result) {
        val linearGain = readNumber(call, "gain")
            ?: return result.error("INVALID_ARG", "'gain' is required", null)
        val normalized = ((linearGain.coerceIn(1.0, 1.5) - 1.0) / 0.5)
            .coerceIn(0.0, 1.0)
        processor.setVolumeBoost(normalized)
        result.success(true)
    }

    private fun handleSetStereoWidth(call: MethodCall, result: Result) {
        val width = readNumber(call, "width")
            ?: return result.error("INVALID_ARG", "'width' is required", null)
        processor.setStereoWidth(width)
        result.success(true)
    }

    private fun handleLegacyBassBoost(call: MethodCall, result: Result) {
        val gainMb = readNumber(call, "gainMb") ?: 0.0
        processor.setBassBoost((gainMb / 2000.0).coerceIn(0.0, 1.0))
        result.success(true)
    }

    private fun handleLegacyVirtualizer(call: MethodCall, result: Result) {
        val strength = readNumber(call, "strength") ?: 0.0
        processor.setStereoWidth(1.0 + (strength / 1000.0).coerceIn(0.0, 1.0) * 0.5)
        result.success(true)
    }

    private fun readGains(call: MethodCall): DoubleArray? {
        val values = call.argument<List<*>>("gains") ?: return null
        if (values.size != BAND_COUNT) return null
        return DoubleArray(BAND_COUNT) { index ->
            (values[index] as? Number)?.toDouble() ?: return null
        }
    }

    private fun readNumber(call: MethodCall, key: String): Double? =
        (call.argument<Any>(key) as? Number)?.toDouble()
}
