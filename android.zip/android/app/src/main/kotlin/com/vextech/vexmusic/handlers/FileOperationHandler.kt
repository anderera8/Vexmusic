package com.vextech.vexmusic.handlers

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import com.vextech.vexmusic.audioformat.AudioContainerSniffer
import com.vextech.vexmusic.audioformat.AudioFormatCapabilities
import com.vextech.vexmusic.audioformat.AudioFormatProfile
import com.vextech.vexmusic.audioformat.SniffResult
import com.vextech.vexmusic.audioformat.SniffedContainer
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.Result
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.Tag
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

class FileOperationHandler(private val context: Context) : BaseHandler() {

    companion object {
        private const val CHANNEL = "com.vextech.vexmusic/file_operations"
        private const val DELETE_REQUEST_CODE = 9001
        private const val WRITE_REQUEST_CODE = 9003
        private const val LOG_TAG = "FileOperationHandler"
    }

    private data class PendingFileOperation(
        val result: Result,
        val approvedAction: () -> Unit,
        val cancelledAction: () -> Unit
    )

    private var pendingDelete: PendingFileOperation? = null
    private var pendingWrite: PendingFileOperation? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val fileIoExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "vibes-file-operations").apply {
            isDaemon = true
        }
    }

    @Volatile
    private var cleanedUp = false

    override fun register(flutterEngine: FlutterEngine) {
        channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        )

        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "deleteTrack" -> {
                    val mediaStoreId =
                        call.argument<Number>("mediaStoreId")?.toLong() ?: 0L
                    val volumeName = call.argument<String>("volumeName")
                    val playbackUri = call.argument<String>("playbackUri")
                    val filePath = call.argument<String>("filePath")

                    if (mediaStoreId <= 0L) {
                        result.error(
                            "INVALID_ARG",
                            "A positive mediaStoreId is required.",
                            null
                        )
                        return@setMethodCallHandler
                    }

                    deleteMediaFile(
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        playbackUri = playbackUri,
                        filePath = filePath,
                        result = result
                    )
                }

                "writeTags" -> {
                    val mediaStoreId =
                        call.argument<Number>("mediaStoreId")?.toLong() ?: 0L
                    val volumeName = call.argument<String>("volumeName")
                    val filePath = call.argument<String>("filePath")
                    val playbackUri = call.argument<String>("playbackUri")
                    val format = call.argument<String>("format")
                    val title = call.argument<String>("title")?.trim().orEmpty()
                    val artist = call.argument<String>("artist")?.trim().orEmpty()
                    val album = call.argument<String>("album")?.trim().orEmpty()

                    if (mediaStoreId <= 0L || title.isEmpty()) {
                        result.error(
                            "INVALID_ARG",
                            "A positive mediaStoreId and non-empty title are required.",
                            null
                        )
                        return@setMethodCallHandler
                    }

                    writeTags(
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        filePath = filePath,
                        playbackUri = playbackUri,
                        format = format,
                        title = title,
                        artist = artist,
                        album = album,
                        result = result
                    )
                }

                "writeArtwork" -> {
                    val mediaStoreId =
                        call.argument<Number>("mediaStoreId")?.toLong() ?: 0L
                    val volumeName = call.argument<String>("volumeName")
                    val filePath = call.argument<String>("filePath")
                    val playbackUri = call.argument<String>("playbackUri")
                    val format = call.argument<String>("format")
                    val imageBytes = call.argument<ByteArray>("imageBytes")
                    val mimeType =
                        call.argument<String>("mimeType") ?: "image/jpeg"

                    if (mediaStoreId <= 0L) {
                        result.error(
                            "INVALID_ARG",
                            "A positive mediaStoreId is required.",
                            null
                        )
                        return@setMethodCallHandler
                    }

                    if (imageBytes == null || imageBytes.isEmpty()) {
                        result.error(
                            "INVALID_ARG",
                            "imageBytes is required.",
                            null
                        )
                        return@setMethodCallHandler
                    }

                    writeArtwork(
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        filePath = filePath,
                        playbackUri = playbackUri,
                        format = format,
                        imageBytes = imageBytes,
                        mimeType = mimeType,
                        result = result
                    )
                }

                "prepareShareFile" -> {
                    val mediaStoreId =
                        call.argument<Number>("mediaStoreId")?.toLong() ?: 0L
                    val volumeName = call.argument<String>("volumeName")
                    val filePath = call.argument<String>("filePath")
                    val playbackUri = call.argument<String>("playbackUri")
                    val format = call.argument<String>("format")

                    if (mediaStoreId <= 0L) {
                        result.error(
                            "INVALID_ARG",
                            "A positive mediaStoreId is required.",
                            null
                        )
                        return@setMethodCallHandler
                    }

                    prepareShareFile(
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        filePath = filePath,
                        playbackUri = playbackUri,
                        format = format,
                        result = result
                    )
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun postToMain(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action()
        } else {
            mainHandler.post { action() }
        }
    }

    private fun postSuccess(result: Result, value: Any?) {
        postToMain { result.success(value) }
    }

    private fun postError(
        result: Result,
        code: String,
        message: String,
        details: Any? = null
    ) {
        postToMain { result.error(code, message, details) }
    }

    private fun executeFileOperation(
        result: Result,
        rejectedCode: String,
        rejectedMessage: String,
        work: () -> Unit
    ) {
        if (cleanedUp) {
            postError(
                result,
                "ACTIVITY_DESTROYED",
                "The activity was destroyed before the file operation could run."
            )
            return
        }

        try {
            fileIoExecutor.execute {
                if (!cleanedUp) {
                    work()
                }
            }
        } catch (error: RejectedExecutionException) {
            postError(
                result,
                rejectedCode,
                safeErrorMessage(error, rejectedMessage)
            )
        }
    }

    private fun executePendingOperation(
        onRejected: (Throwable) -> Unit,
        work: () -> Unit
    ) {
        if (cleanedUp) {
            onRejected(
                IllegalStateException(
                    "The activity was destroyed before the approved operation could run."
                )
            )
            return
        }

        try {
            fileIoExecutor.execute {
                if (!cleanedUp) {
                    work()
                }
            }
        } catch (error: RejectedExecutionException) {
            onRejected(error)
        }
    }

    private fun operationResult(
        status: String,
        code: String,
        message: String,
        details: Any? = null
    ): Map<String, Any?> {
        return mapOf(
            "status" to status,
            "code" to code,
            "message" to message,
            "details" to details
        )
    }

    private fun sourceDetails(
        uri: Uri,
        mediaStoreId: Long,
        volumeName: String?
    ): Map<String, Any?> {
        return mapOf(
            "mediaStoreId" to mediaStoreId,
            "volumeName" to normalizedVolumeName(volumeName, uri),
            "playbackUri" to uri.toString()
        )
    }

    // ─────────────────────────────────────────────────────────────────────
    // Tag writing
    // ─────────────────────────────────────────────────────────────────────

    private fun writeTags(
        mediaStoreId: Long,
        volumeName: String?,
        filePath: String?,
        playbackUri: String?,
        format: String?,
        title: String,
        artist: String,
        album: String,
        result: Result
    ) {
        if (isProbablyReadOnlySystemPath(filePath)) {
            result.error(
                "READ_ONLY_SOURCE",
                "This audio file is in a read-only system location.",
                filePath
            )
            return
        }

        val uri = resolveAudioUri(mediaStoreId, volumeName, playbackUri)

        executeFileOperation(
            result = result,
            rejectedCode = "TAG_WRITE_ERROR",
            rejectedMessage = "Could not start tag writing."
        ) {
            try {
                if (!mediaStoreSourceExists(uri)) {
                    postError(
                        result,
                        "SOURCE_NOT_FOUND",
                        "The source audio file is no longer available.",
                        sourceDetails(uri, mediaStoreId, volumeName)
                    )
                    return@executeFileOperation
                }

                // Resolved from the file's real bytes (plus a fresh
                // MediaStore MIME/display-name cross-check), never from a
                // filename or caller-supplied "format" string - see
                // resolveFormatProfile. Done here, inside the background
                // executor and after mediaStoreSourceExists, since it
                // requires actually opening and reading the file.
                val profile = resolveFormatProfile(uri)

                if (!profile.supportsTagWrite || profile.tagIoExtension == null) {
                    postError(
                        result,
                        "UNSUPPORTED_FORMAT",
                        "Tag writing is not supported for this file format.",
                        profile.displayLabel
                    )
                    return@executeFileOperation
                }

                writeTagsToUri(
                    uri = uri,
                    extension = profile.tagIoExtension,
                    title = title,
                    artist = artist,
                    album = album,
                    filePath = filePath
                )
                updateMediaStoreTagsBestEffort(uri, title, artist, album)

                postSuccess(
                    result,
                    operationResult(
                        status = "success",
                        code = "SUCCESS",
                        message = "Tags updated.",
                        details = sourceDetails(uri, mediaStoreId, volumeName)
                    )
                )
            } catch (error: SecurityException) {
                postToMain {
                    requestTagWriteConfirmation(
                        uri = uri,
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        title = title,
                        artist = artist,
                        album = album,
                        filePath = filePath,
                        result = result,
                        error = error
                    )
                }
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "Tag write failed", error)
                postError(
                    result,
                    "TAG_WRITE_ERROR",
                    "File can't be edited",
                    null
                )
            }
        }
    }

    /**
     * Edits tags for the file at [uri] and, only once the edit is verified
     * to have actually persisted, replaces the MediaStore content with it.
     *
     * The original bytes are copied once into [originalTempFile] and never
     * mutated again - that copy is what the real [uri] still holds if
     * anything below fails. The edit happens on a separate
     * [editTempFile]; jaudiotagger's `commit()` mutates that file in
     * place, so keeping it apart from [originalTempFile] is what makes
     * "preserve the original until the replacement is verified" actually
     * true rather than nominal. After `commit()`, the edited file is
     * re-opened fresh (a new `AudioFileIO.read`, not the in-memory
     * `audioFile` object that just wrote it) and the requested fields are
     * confirmed to have actually persisted before [writeTempFileBackToUri]
     * is ever called - so a `commit()` that silently no-ops or writes
     * something other than what was requested never reaches the real
     * file, and [uri] is not opened for writing until that check passes.
     */
    private fun writeTagsToUri(
        uri: Uri,
        extension: String,
        title: String,
        artist: String,
        album: String,
        filePath: String?
    ) {
        val originalTempFile =
            File.createTempFile("tag-original-", ".$extension", context.cacheDir)
        val editTempFile =
            File.createTempFile("tag-edit-", ".$extension", context.cacheDir)

        try {
            copyUriToFile(uri, originalTempFile)
            originalTempFile.copyTo(editTempFile, overwrite = true)

            val audioFile = AudioFileIO.read(editTempFile)
            val tag = audioFile.tagOrCreateAndSetDefault

            setRequiredTextField(tag, FieldKey.TITLE, title)
            setOptionalTextField(tag, FieldKey.ARTIST, artist)
            setOptionalTextField(tag, FieldKey.ALBUM, album)

            audioFile.commit()
            verifyTagsPersisted(editTempFile, title, artist, album)

            // Only now does the real file get touched.
            writeTempFileBackToUri(editTempFile, uri)
            notifyMediaStore(uri, filePath)
        } finally {
            runCatching { originalTempFile.delete() }
            runCatching { editTempFile.delete() }
        }
    }

    /**
     * Re-opens [editedFile] with a fresh `AudioFileIO.read` - deliberately
     * not the `audioFile`/`tag` objects `commit()` just used, since those
     * would only confirm what's in memory, not what `commit()` actually
     * persisted to disk - and confirms the requested fields are really
     * there. Blank optional fields (artist/album) are written as either an
     * empty string or a deleted field depending on what the format
     * supports (see [setOptionalTextField]), so both are accepted here.
     */
    private fun verifyTagsPersisted(
        editedFile: File,
        title: String,
        artist: String,
        album: String
    ) {
        val reread = try {
            AudioFileIO.read(editedFile)
        } catch (error: Throwable) {
            throw IllegalStateException(
                "The edited file could not be re-read after saving; the " +
                    "original file was left untouched.",
                error
            )
        }

        val tag = reread.tag

        // TITLE is required and, per setRequiredTextField, a write-side
        // failure for it is already treated as fatal - every format this
        // app supports is expected to map it. A read-back failure here is
        // as suspicious as a write failure would have been, so it fails
        // safe the same way, unlike the optional fields below.
        val persistedTitle = readTagFieldSafely(tag, FieldKey.TITLE)
            ?: throw IllegalStateException(
                "Tag verification failed: the title could not be read " +
                    "back after saving. The original file was left untouched."
            )

        if (persistedTitle != title) {
            throw IllegalStateException(
                "Tag verification failed: the title did not persist as " +
                    "written. The original file was left untouched."
            )
        }

        verifyOptionalFieldPersisted(tag, FieldKey.ARTIST, artist)
        verifyOptionalFieldPersisted(tag, FieldKey.ALBUM, album)
    }

    private fun verifyOptionalFieldPersisted(
        tag: Tag?,
        key: FieldKey,
        requestedValue: String
    ) {
        // A generic FieldKey can be unmapped for a given concrete Tag
        // implementation - jaudiotagger's own getFirst(FieldKey) is
        // documented to throw KeyNotFoundException in that case, not
        // return an empty string. That is a known format/key mismatch,
        // not evidence the edit failed, so it does not block the save the
        // way a genuine value mismatch below does.
        val persisted = readTagFieldSafely(tag, key) ?: return

        if (requestedValue.isBlank()) {
            // Accept either an empty value or a fully deleted field -
            // setOptionalTextField tries delete first and falls back to
            // an empty string only if the format can't represent absence.
            if (persisted.isNotBlank()) {
                throw IllegalStateException(
                    "Tag verification failed: ${key.name} did not clear " +
                        "as requested. The original file was left untouched."
                )
            }
            return
        }

        if (persisted != requestedValue) {
            throw IllegalStateException(
                "Tag verification failed: ${key.name} did not persist as " +
                    "written. The original file was left untouched."
            )
        }
    }

    /** Null means "could not be read back for this format" (e.g. an
     *  unmapped generic key) rather than "confirmed empty" - callers
     *  decide separately whether that's fatal for the field in question. */
    private fun readTagFieldSafely(tag: Tag?, key: FieldKey): String? {
        if (tag == null) return null

        return try {
            tag.getFirst(key)
        } catch (error: Throwable) {
            Log.w(
                LOG_TAG,
                "Could not read back ${key.name} for verification: " +
                    safeErrorMessage(error)
            )
            null
        }
    }

    private fun setRequiredTextField(tag: Tag, key: FieldKey, value: String) {
        try {
            tag.setField(key, value)
        } catch (error: Throwable) {
            throw IllegalStateException("Could not write ${key.name} tag.", error)
        }
    }

    private fun setOptionalTextField(tag: Tag, key: FieldKey, value: String) {
        try {
            if (value.isBlank()) {
                try {
                    tag.deleteField(key)
                } catch (_: Throwable) {
                    tag.setField(key, "")
                }
            } else {
                tag.setField(key, value)
            }
        } catch (error: Throwable) {
            throw IllegalStateException("Could not write ${key.name} tag.", error)
        }
    }

    private fun updateMediaStoreTagsBestEffort(
        uri: Uri,
        title: String,
        artist: String,
        album: String
    ) {
        try {
            val values = android.content.ContentValues().apply {
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.ARTIST, artist)
                put(MediaStore.Audio.Media.ALBUM, album)
            }
            context.contentResolver.update(uri, values, null, null)
        } catch (error: Throwable) {
            Log.w(
                LOG_TAG,
                "MediaStore metadata update skipped: ${safeErrorMessage(error)}"
            )
        }
    }

    private fun requestTagWriteConfirmation(
        uri: Uri,
        mediaStoreId: Long,
        volumeName: String?,
        title: String,
        artist: String,
        album: String,
        filePath: String?,
        result: Result,
        error: SecurityException
    ) {
        launchWriteConfirmation(
            uri = uri,
            result = result,
            error = error,
            deniedMessage = "Permission to edit this file was denied.",
            approvedAction = {
                executePendingOperation(
                    onRejected = { rejected ->
                        postToMain {
                            finishPendingWrite(
                                code = "TAG_WRITE_ERROR",
                                error = rejected,
                                errorDetails = null
                            )
                        }
                    }
                ) {
                    try {
                        // Re-resolved rather than reused: the profile from
                        // the first attempt was already consumed (and its
                        // temp files already cleaned up in
                        // writeTagsToUri's finally) by the time this
                        // SecurityException reached here, so this attempt
                        // redoes prepare+verify+writeback from the file's
                        // current bytes - which also means it gets its own
                        // fresh verification rather than skipping it.
                        val profile = resolveFormatProfile(uri)

                        if (!profile.supportsTagWrite ||
                            profile.tagIoExtension == null
                        ) {
                            postToMain {
                                finishPendingWrite(
                                    code = "UNSUPPORTED_FORMAT",
                                    error = IllegalStateException(
                                        "Tag writing is not supported for " +
                                            "this file format."
                                    ),
                                    errorDetails = profile.displayLabel
                                )
                            }
                            return@executePendingOperation
                        }

                        writeTagsToUri(
                            uri,
                            profile.tagIoExtension,
                            title,
                            artist,
                            album,
                            filePath
                        )
                        updateMediaStoreTagsBestEffort(uri, title, artist, album)
                        postToMain {
                            finishPendingWrite(
                                successValue = operationResult(
                                    status = "success",
                                    code = "SUCCESS",
                                    message = "Tags updated.",
                                    details = sourceDetails(
                                        uri,
                                        mediaStoreId,
                                        volumeName
                                    )
                                )
                            )
                        }
                    } catch (retryError: Throwable) {
                        Log.e(LOG_TAG, "Tag write retry failed", retryError)
                        postToMain {
                            finishPendingWrite(
                                code = "TAG_WRITE_ERROR",
                                error = retryError,
                                errorDetails = null
                            )
                        }
                    }
                }
            }
        )
    }

    // ─────────────────────────────────────────────────────────────────────
    // Artwork writing
    // ─────────────────────────────────────────────────────────────────────

    private fun writeArtwork(
        mediaStoreId: Long,
        volumeName: String?,
        filePath: String?,
        playbackUri: String?,
        format: String?,
        imageBytes: ByteArray,
        mimeType: String,
        result: Result
    ) {
        if (isProbablyReadOnlySystemPath(filePath)) {
            result.error(
                "READ_ONLY_SOURCE",
                "This audio file is in a read-only system location.",
                filePath
            )
            return
        }

        val uri = resolveAudioUri(mediaStoreId, volumeName, playbackUri)

        executeFileOperation(
            result = result,
            rejectedCode = "ARTWORK_WRITE_ERROR",
            rejectedMessage = "Could not start artwork writing."
        ) {
            try {
                if (!mediaStoreSourceExists(uri)) {
                    postError(
                        result,
                        "SOURCE_NOT_FOUND",
                        "The source audio file is no longer available.",
                        sourceDetails(uri, mediaStoreId, volumeName)
                    )
                    return@executeFileOperation
                }

                val profile = resolveFormatProfile(uri)

                if (!profile.supportsArtworkWrite ||
                    profile.tagIoExtension == null
                ) {
                    postError(
                        result,
                        "UNSUPPORTED_FORMAT",
                        "Artwork writing is not supported for this file format.",
                        profile.displayLabel
                    )
                    return@executeFileOperation
                }

                writeArtworkToUri(
                    uri,
                    profile.tagIoExtension,
                    imageBytes,
                    mimeType,
                    filePath
                )

                postSuccess(
                    result,
                    operationResult(
                        status = "success",
                        code = "SUCCESS",
                        message = "Artwork updated.",
                        details = sourceDetails(uri, mediaStoreId, volumeName)
                    )
                )
            } catch (error: SecurityException) {
                postToMain {
                    requestArtworkWriteConfirmation(
                        uri = uri,
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        imageBytes = imageBytes,
                        mimeType = mimeType,
                        filePath = filePath,
                        result = result,
                        error = error
                    )
                }
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "Artwork write failed", error)
                postError(
                    result,
                    "ARTWORK_WRITE_ERROR",
                    safeErrorMessage(
                        error,
                        "Could not update artwork for this file."
                    ),
                    null
                )
            }
        }
    }

    private fun writeArtworkToUri(
        uri: Uri,
        extension: String,
        imageBytes: ByteArray,
        mimeType: String,
        filePath: String?
    ) {
        val originalAudioFile =
            File.createTempFile("artwork-original-", ".$extension", context.cacheDir)
        val editAudioFile =
            File.createTempFile("artwork-edit-", ".$extension", context.cacheDir)
        val tempImageFile = File.createTempFile(
            "cover-art-",
            ".${imageExtensionForMimeType(mimeType)}",
            context.cacheDir
        )

        try {
            copyUriToFile(uri, originalAudioFile)
            originalAudioFile.copyTo(editAudioFile, overwrite = true)
            tempImageFile.writeBytes(imageBytes)

            val audioFile = AudioFileIO.read(editAudioFile)
            val tag = audioFile.tagOrCreateAndSetDefault
            val artwork = ArtworkFactory.createArtworkFromFile(tempImageFile)

            runCatching { tag.deleteArtworkField() }
            tag.setField(artwork)
            audioFile.commit()

            verifyArtworkPersisted(editAudioFile, imageBytes)

            // Only now does the real file get touched.
            writeTempFileBackToUri(editAudioFile, uri)
            notifyMediaStore(uri, filePath)
        } finally {
            runCatching { originalAudioFile.delete() }
            runCatching { editAudioFile.delete() }
            runCatching { tempImageFile.delete() }
        }
    }

    /**
     * Re-opens [editedFile] with a fresh `AudioFileIO.read` and confirms
     * the embedded artwork actually matches [expectedBytes] byte-for-byte.
     *
     * Every format this app writes artwork to stores or round-trips the
     * exact binary payload: MP3/MP4/FLAC/WAV keep the raw bytes in a
     * binary picture frame/block, and OGG Vorbis's METADATA_BLOCK_PICTURE
     * is a lossless base64 encoding of those same bytes (base64 is
     * bijective - decoding what was validly encoded reproduces the
     * original exactly), so an exact match is the correct bar here, not
     * merely "some artwork is present".
     */
    private fun verifyArtworkPersisted(editedFile: File, expectedBytes: ByteArray) {
        val reread = try {
            AudioFileIO.read(editedFile)
        } catch (error: Throwable) {
            throw IllegalStateException(
                "The edited file could not be re-read after saving; the " +
                    "original file was left untouched.",
                error
            )
        }

        val persistedArtwork = try {
            reread.tag?.firstArtwork
        } catch (error: Throwable) {
            Log.w(
                LOG_TAG,
                "Could not read back artwork for verification: " +
                    safeErrorMessage(error)
            )
            null
        }

        val persistedBytes = persistedArtwork?.binaryData

        if (persistedBytes == null || persistedBytes.isEmpty()) {
            throw IllegalStateException(
                "Artwork verification failed: no artwork was found after " +
                    "saving. The original file was left untouched."
            )
        }

        if (!persistedBytes.contentEquals(expectedBytes)) {
            throw IllegalStateException(
                "Artwork verification failed: the saved artwork did not " +
                    "match what was written. The original file was left " +
                    "untouched."
            )
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Share
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Copies the MediaStore-backed audio file into this app's private cache
     * directory and returns the resulting path. A raw external-storage path
     * (Track.filePath) cannot be opened directly by java.io.File on scoped
     * storage (Android 10+) unless the app created that file itself, which
     * throws EACCES for files owned by other apps (downloads, other media
     * apps, etc.). Reading through ContentResolver via the resolved
     * content:// URI is exempt from that restriction, and copying the bytes
     * into our own cache dir gives share_plus (which only knows how to open
     * java.io.File paths) something it can actually read.
     *
     * The returned temp file is intentionally NOT deleted here — the caller
     * (share_plus, via the Dart share() call) reads it after this method
     * returns. It is cleaned up passively: share_plus clears its own share
     * cache subfolder on every share() call, and the OS may reclaim
     * context.cacheDir under storage pressure. If tighter cleanup is ever
     * needed, delete the previous share-* temp file at the start of the next
     * prepareShareFile call.
     */
    private fun prepareShareFile(
        mediaStoreId: Long,
        volumeName: String?,
        filePath: String?,
        playbackUri: String?,
        format: String?,
        result: Result
    ) {
        val extension = detectExtension(filePath, playbackUri, format)
        val uri = resolveAudioUri(mediaStoreId, volumeName, playbackUri)

        executeFileOperation(
            result = result,
            rejectedCode = "SHARE_PREPARE_ERROR",
            rejectedMessage = "Could not start preparing this file for sharing."
        ) {
            try {
                if (!mediaStoreSourceExists(uri)) {
                    postError(
                        result,
                        "SOURCE_NOT_FOUND",
                        "The source audio file is no longer available.",
                        sourceDetails(uri, mediaStoreId, volumeName)
                    )
                    return@executeFileOperation
                }

                val suffix = if (extension.isNotEmpty()) ".$extension" else ""
                val tempFile =
                    File.createTempFile("share-", suffix, context.cacheDir)

                copyUriToFile(uri, tempFile)

                postSuccess(
                    result,
                    operationResult(
                        status = "success",
                        code = "SUCCESS",
                        message = "File ready to share.",
                        details = mapOf("path" to tempFile.absolutePath)
                    )
                )
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "Share file preparation failed", error)
                postError(
                    result,
                    "SHARE_PREPARE_ERROR",
                    safeErrorMessage(
                        error,
                        "Could not prepare this file for sharing."
                    ),
                    extension
                )
            }
        }
    }

    private fun requestArtworkWriteConfirmation(
        uri: Uri,
        mediaStoreId: Long,
        volumeName: String?,
        imageBytes: ByteArray,
        mimeType: String,
        filePath: String?,
        result: Result,
        error: SecurityException
    ) {
        launchWriteConfirmation(
            uri = uri,
            result = result,
            error = error,
            deniedMessage = "Permission to edit artwork was denied.",
            approvedAction = {
                executePendingOperation(
                    onRejected = { rejected ->
                        postToMain {
                            finishPendingWrite(
                                code = "ARTWORK_WRITE_ERROR",
                                error = rejected,
                                errorDetails = null
                            )
                        }
                    }
                ) {
                    try {
                        // Re-resolved for the same reason as the tag-write
                        // retry: the first attempt's temp files are
                        // already cleaned up by the time this
                        // SecurityException reached here, so this attempt
                        // redoes prepare+verify+writeback from the file's
                        // current bytes.
                        val profile = resolveFormatProfile(uri)

                        if (!profile.supportsArtworkWrite ||
                            profile.tagIoExtension == null
                        ) {
                            postToMain {
                                finishPendingWrite(
                                    code = "UNSUPPORTED_FORMAT",
                                    error = IllegalStateException(
                                        "Artwork writing is not supported " +
                                            "for this file format."
                                    ),
                                    errorDetails = profile.displayLabel
                                )
                            }
                            return@executePendingOperation
                        }

                        writeArtworkToUri(
                            uri,
                            profile.tagIoExtension,
                            imageBytes,
                            mimeType,
                            filePath
                        )
                        postToMain {
                            finishPendingWrite(
                                successValue = operationResult(
                                    status = "success",
                                    code = "SUCCESS",
                                    message = "Artwork updated.",
                                    details = sourceDetails(
                                        uri,
                                        mediaStoreId,
                                        volumeName
                                    )
                                )
                            )
                        }
                    } catch (retryError: Throwable) {
                        Log.e(LOG_TAG, "Artwork write retry failed", retryError)
                        postToMain {
                            finishPendingWrite(
                                code = "ARTWORK_WRITE_ERROR",
                                error = retryError,
                                errorDetails = null
                            )
                        }
                    }
                }
            }
        )
    }

    private fun imageExtensionForMimeType(mimeType: String): String {
        return when (mimeType.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
    }

    private fun launchWriteConfirmation(
        uri: Uri,
        result: Result,
        error: SecurityException,
        deniedMessage: String,
        approvedAction: () -> Unit
    ) {
        if (pendingWrite != null || pendingDelete != null) {
            result.error(
                "OPERATION_IN_PROGRESS",
                "Another file operation is awaiting confirmation.",
                null
            )
            return
        }

        val intentSender = try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                    MediaStore.createWriteRequest(
                        context.contentResolver,
                        listOf(uri)
                    ).intentSender

                Build.VERSION.SDK_INT == Build.VERSION_CODES.Q &&
                    error is RecoverableSecurityException ->
                    error.userAction.actionIntent.intentSender

                else -> {
                    result.error("WRITE_DENIED", deniedMessage, null)
                    return
                }
            }
        } catch (confirmationError: Throwable) {
            result.error(
                "CONFIRMATION_ERROR",
                safeErrorMessage(confirmationError),
                null
            )
            return
        }

        val activity = context as? Activity ?: run {
            result.error("NO_ACTIVITY", "Activity is unavailable.", null)
            return
        }

        pendingWrite = PendingFileOperation(
            result = result,
            approvedAction = approvedAction,
            cancelledAction = {
                val pending = pendingWrite
                pendingWrite = null
                pending?.result?.error(
                    "WRITE_CANCELLED",
                    "The Android file edit request was cancelled.",
                    null
                )
            }
        )

        try {
            activity.startIntentSenderForResult(
                intentSender,
                WRITE_REQUEST_CODE,
                null,
                0,
                0,
                0
            )
        } catch (launchError: Throwable) {
            pendingWrite = null
            result.error(
                "CONFIRMATION_ERROR",
                safeErrorMessage(launchError),
                null
            )
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Delete
    // ─────────────────────────────────────────────────────────────────────

    private fun deleteMediaFile(
        mediaStoreId: Long,
        volumeName: String?,
        playbackUri: String?,
        filePath: String?,
        result: Result
    ) {
        if (pendingDelete != null || pendingWrite != null) {
            result.error(
                "OPERATION_IN_PROGRESS",
                "Another file operation is awaiting confirmation.",
                null
            )
            return
        }

        val uri = resolveAudioUri(mediaStoreId, volumeName, playbackUri)

        executeFileOperation(
            result = result,
            rejectedCode = "DELETE_ERROR",
            rejectedMessage = "Could not start delete operation."
        ) {
            try {
                val existedBefore = mediaStoreSourceExists(uri)

                if (!existedBefore) {
                    postSuccess(
                        result,
                        operationResult(
                            status = "not_found",
                            code = "SOURCE_NOT_FOUND",
                            message = "The audio file is already unavailable.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    )
                    return@executeFileOperation
                }

                val rows = context.contentResolver.delete(uri, null, null)
                val deleted = rows > 0 || waitForSourceRemoval(uri)

                postSuccess(
                    result,
                    if (deleted) {
                        operationResult(
                            status = "success",
                            code = "SUCCESS",
                            message = "Track deleted.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    } else {
                        operationResult(
                            status = "failed",
                            code = "DELETE_NOT_CONFIRMED",
                            message = "Android did not confirm that the file was deleted.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    }
                )
            } catch (error: SecurityException) {
                postToMain {
                    requestDeleteConfirmation(
                        uri = uri,
                        mediaStoreId = mediaStoreId,
                        volumeName = volumeName,
                        result = result,
                        error = error
                    )
                }
            } catch (error: Throwable) {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    postSuccess(
                        result,
                        directPathDeleteResult(filePath)
                    )
                } else {
                    Log.e(LOG_TAG, "MediaStore delete failed", error)
                    postSuccess(
                        result,
                        operationResult(
                            status = "failed",
                            code = "DELETE_ERROR",
                            message = safeErrorMessage(
                                error,
                                "Could not delete this audio file."
                            ),
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    )
                }
            }
        }
    }

    private fun requestDeleteConfirmation(
        uri: Uri,
        mediaStoreId: Long,
        volumeName: String?,
        result: Result,
        error: SecurityException
    ) {
        val intentSender = try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
                    MediaStore.createDeleteRequest(
                        context.contentResolver,
                        listOf(uri)
                    ).intentSender

                Build.VERSION.SDK_INT == Build.VERSION_CODES.Q &&
                    error is RecoverableSecurityException ->
                    error.userAction.actionIntent.intentSender

                else -> {
                    result.success(
                        operationResult(
                            status = "denied",
                            code = "DELETE_DENIED",
                            message = "Permission to delete this file was denied.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    )
                    return
                }
            }
        } catch (confirmationError: Throwable) {
            result.error(
                "CONFIRMATION_ERROR",
                safeErrorMessage(confirmationError),
                null
            )
            return
        }

        val approvedAction = {
            executePendingOperation(
                onRejected = { rejected ->
                    postToMain {
                        finishPendingDelete(
                            operationResult(
                                status = "failed",
                                code = "DELETE_ERROR",
                                message = safeErrorMessage(rejected),
                                details = sourceDetails(
                                    uri,
                                    mediaStoreId,
                                    volumeName
                                )
                            )
                        )
                    }
                }
            ) {
                val completion = try {
                    val rows = if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
                        context.contentResolver.delete(uri, null, null)
                    } else {
                        0
                    }
                    val deleted = rows > 0 || waitForSourceRemoval(uri)

                    if (deleted) {
                        operationResult(
                            status = "success",
                            code = "SUCCESS",
                            message = "Track deleted.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    } else {
                        operationResult(
                            status = "failed",
                            code = "DELETE_NOT_CONFIRMED",
                            message = "Android approved deletion but the source still exists.",
                            details = sourceDetails(uri, mediaStoreId, volumeName)
                        )
                    }
                } catch (retryError: Throwable) {
                    operationResult(
                        status = "failed",
                        code = "DELETE_ERROR",
                        message = safeErrorMessage(
                            retryError,
                            "Could not complete the approved delete request."
                        ),
                        details = sourceDetails(uri, mediaStoreId, volumeName)
                    )
                }

                postToMain { finishPendingDelete(completion) }
            }
        }

        launchDeleteConfirmation(
            intentSender = intentSender,
            result = result,
            approvedAction = approvedAction,
            cancelledAction = {
                finishPendingDelete(
                    operationResult(
                        status = "cancelled",
                        code = "DELETE_CANCELLED",
                        message = "The Android delete request was cancelled.",
                        details = sourceDetails(uri, mediaStoreId, volumeName)
                    )
                )
            }
        )
    }

    private fun launchDeleteConfirmation(
        intentSender: IntentSender,
        result: Result,
        approvedAction: () -> Unit,
        cancelledAction: () -> Unit
    ) {
        val activity = context as? Activity ?: run {
            result.error("NO_ACTIVITY", "Activity is unavailable.", null)
            return
        }

        if (pendingDelete != null || pendingWrite != null) {
            result.error(
                "OPERATION_IN_PROGRESS",
                "Another file operation is awaiting confirmation.",
                null
            )
            return
        }

        pendingDelete = PendingFileOperation(
            result = result,
            approvedAction = approvedAction,
            cancelledAction = cancelledAction
        )

        try {
            activity.startIntentSenderForResult(
                intentSender,
                DELETE_REQUEST_CODE,
                null,
                0,
                0,
                0
            )
        } catch (launchError: Throwable) {
            pendingDelete = null
            result.error(
                "CONFIRMATION_ERROR",
                safeErrorMessage(launchError),
                null
            )
        }
    }

    private fun directPathDeleteResult(filePath: String?): Map<String, Any?> {
        val path = filePath?.trim().orEmpty()

        if (path.isEmpty()) {
            return operationResult(
                status = "not_found",
                code = "SOURCE_NOT_FOUND",
                message = "The audio file could not be found."
            )
        }

        return try {
            val file = File(path)
            if (!file.exists()) {
                operationResult(
                    status = "not_found",
                    code = "SOURCE_NOT_FOUND",
                    message = "The audio file is already unavailable."
                )
            } else if (file.delete()) {
                operationResult(
                    status = "success",
                    code = "SUCCESS",
                    message = "Track deleted."
                )
            } else {
                operationResult(
                    status = "failed",
                    code = "DELETE_ERROR",
                    message = "The file system did not delete this audio file."
                )
            }
        } catch (error: Throwable) {
            operationResult(
                status = "failed",
                code = "DELETE_ERROR",
                message = safeErrorMessage(error, "Could not delete this audio file.")
            )
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // URI and file helpers
    // ─────────────────────────────────────────────────────────────────────

    private fun resolveAudioUri(
        mediaStoreId: Long,
        volumeName: String?,
        playbackUri: String?
    ): Uri {
        val exactUri = playbackUri
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?.let { raw -> runCatching { Uri.parse(raw) }.getOrNull() }
            ?.takeIf { uri ->
                uri.scheme.equals("content", ignoreCase = true) &&
                    uri.authority.equals("media", ignoreCase = true) &&
                    runCatching { ContentUris.parseId(uri) }.getOrNull() == mediaStoreId
            }

        if (exactUri != null) {
            return exactUri
        }

        val baseUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(
                normalizedVolumeName(volumeName, null)
            )
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        return ContentUris.withAppendedId(baseUri, mediaStoreId)
    }

    private fun normalizedVolumeName(volumeName: String?, uri: Uri?): String {
        val fromArgument = volumeName?.trim()?.lowercase().orEmpty()
        if (fromArgument.isNotEmpty()) {
            return if (fromArgument == "external") {
                MediaStore.VOLUME_EXTERNAL_PRIMARY
            } else {
                fromArgument
            }
        }

        val fromUri = uri
            ?.pathSegments
            ?.firstOrNull()
            ?.trim()
            ?.lowercase()
            .orEmpty()

        if (fromUri.isNotEmpty()) {
            return if (fromUri == "external") {
                MediaStore.VOLUME_EXTERNAL_PRIMARY
            } else {
                fromUri
            }
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.VOLUME_EXTERNAL_PRIMARY
        } else {
            "external"
        }
    }

    private fun mediaStoreSourceExists(uri: Uri): Boolean {
        return context.contentResolver.query(
            uri,
            arrayOf(MediaStore.MediaColumns._ID),
            null,
            null,
            null
        )?.use { cursor -> cursor.moveToFirst() } ?: false
    }

    private fun waitForSourceRemoval(uri: Uri): Boolean {
        repeat(4) { attempt ->
            if (!mediaStoreSourceExists(uri)) {
                return true
            }

            if (attempt < 3) {
                Thread.sleep(75L)
            }
        }

        return false
    }

    /**
     * The real, byte-verified format of the file at [uri], used to decide
     * whether jaudiotagger can actually edit it and, if so, which
     * extension to hand its extension-keyed reader/writer dispatch.
     *
     * This replaces filename/URI-extension guessing for the two call sites
     * that actually feed jaudiotagger ([writeTagsToUri], [writeArtworkToUri]).
     * `content://` URIs frequently have no useful path segment to guess
     * from, and even when a MIME type is available it can be stale,
     * generic ("application/octet-stream"), or simply wrong for a file
     * that was copied or renamed outside MediaStore's own scanner - none
     * of that is byte-verified. This is:
     *
     *  1. Read the file's own leading bytes and match them against the
     *     real container/codec specifications (ID3/MPEG sync, "ftyp",
     *     "fLaC", "OggS" + inner codec packet, "RIFF"/"WAVE").
     *  2. Separately re-query MediaStore's MIME_TYPE and DISPLAY_NAME for
     *     [uri] at this exact moment (not a value captured at some earlier
     *     library scan, which could be stale if the file changed since).
     *
     * The byte sniff is authoritative when the two disagree: it is the
     * only one of the two signals that cannot be wrong about what the
     * container/codec actually is. The MediaStore signals are logged for
     * diagnostics so a genuine mismatch (a mislabeled file, a MediaStore
     * entry pointing at content that no longer matches) is visible without
     * ever being allowed to override a real byte-level read.
     */
    private fun resolveFormatProfile(uri: Uri): AudioFormatProfile {
        val mediaStoreMimeType = queryMediaStoreMimeType(uri)
        val mediaStoreDisplayName = queryMediaStoreDisplayName(uri)

        val sniff = try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to read the selected audio file." }
                AudioContainerSniffer.sniff(input)
            }
        } catch (error: Throwable) {
            Log.w(
                LOG_TAG,
                "Container sniff failed for $uri " +
                    "(mediaStoreMimeType=$mediaStoreMimeType, " +
                    "mediaStoreDisplayName=$mediaStoreDisplayName): " +
                    safeErrorMessage(error)
            )
            SniffResult(SniffedContainer.UNKNOWN)
        }

        if (!sniff.isRecognized) {
            Log.w(
                LOG_TAG,
                "Unrecognized container for $uri " +
                    "(mediaStoreMimeType=$mediaStoreMimeType, " +
                    "mediaStoreDisplayName=$mediaStoreDisplayName)"
            )
        } else if (mediaStoreMimeType != null &&
            !mimeTypeAgrees(mediaStoreMimeType, sniff.container)
        ) {
            // Not fatal - the byte sniff still wins - but worth knowing
            // about, since it usually means a renamed/mislabeled file.
            Log.w(
                LOG_TAG,
                "MediaStore MIME type ($mediaStoreMimeType) disagrees with " +
                    "sniffed container (${sniff.container}) for $uri " +
                    "(mediaStoreDisplayName=$mediaStoreDisplayName); " +
                    "trusting the byte-verified container."
            )
        }

        return AudioFormatCapabilities.profileFor(sniff)
    }

    private fun queryMediaStoreMimeType(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.MIME_TYPE),
                null,
                null,
                null
            )?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val index = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                if (index < 0) null else cursor.getString(index)
            }
        }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun queryMediaStoreDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (!cursor.moveToFirst()) return@use null
                val index = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                if (index < 0) null else cursor.getString(index)
            }
        }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() }
    }

    /**
     * A loose, diagnostics-only cross-check - never used to override the
     * byte-verified [SniffedContainer]. Ogg-family MIME types are treated
     * as agreeing with any Ogg-derived container since a generic
     * "audio/ogg" MIME type does not by itself distinguish Vorbis from
     * Opus from Ogg-FLAC; the byte sniff already made that distinction.
     */
    private fun mimeTypeAgrees(mimeType: String, container: SniffedContainer): Boolean {
        val normalized = mimeType.lowercase()

        return when (container) {
            SniffedContainer.MP3 ->
                normalized.contains("mpeg") || normalized.contains("mp3")

            SniffedContainer.MP4_FAMILY ->
                normalized.contains("mp4") || normalized.contains("m4a") ||
                    normalized.contains("aac") || normalized.contains("quicktime")

            SniffedContainer.FLAC_NATIVE ->
                normalized.contains("flac")

            SniffedContainer.OGG_VORBIS,
            SniffedContainer.OGG_OPUS,
            SniffedContainer.OGG_FLAC,
            SniffedContainer.OGG_UNKNOWN_CODEC ->
                normalized.contains("ogg") || normalized.contains("opus")

            SniffedContainer.WAV ->
                normalized.contains("wav")

            SniffedContainer.UNKNOWN -> true
        }
    }

    private fun detectExtension(
        filePath: String?,
        playbackUri: String?,
        format: String?
    ): String {
        val fromFormat = normalizeExtension(format)
        if (fromFormat.isNotEmpty()) return fromFormat

        val fromPath = extensionFromValue(filePath)
        if (fromPath.isNotEmpty()) return fromPath

        return extensionFromValue(playbackUri)
    }

    private fun normalizeExtension(value: String?): String {
        return value
            ?.trim()
            ?.lowercase()
            ?.removePrefix(".")
            ?.takeIf { it.matches(Regex("^[a-z0-9]+$")) }
            ?: ""
    }

    private fun extensionFromValue(value: String?): String {
        val raw = value?.trim()
        if (raw.isNullOrEmpty()) return ""

        val path = runCatching {
            val parsed = Uri.parse(raw)
            if (!parsed.path.isNullOrEmpty()) parsed.path.orEmpty() else raw
        }.getOrDefault(raw)

        return normalizeExtension(
            path.substringAfterLast('/').substringAfterLast('.', "")
        )
    }

    private fun copyUriToFile(uri: Uri, target: File) {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to read the selected audio file." }
            target.outputStream().use { output -> input.copyTo(output) }
        }
    }

    private fun writeTempFileBackToUri(tempFile: File, uri: Uri) {
        context.contentResolver.openFileDescriptor(uri, "rwt").use { descriptor ->
            requireNotNull(descriptor) {
                "Unable to open the audio file for writing."
            }

            FileOutputStream(descriptor.fileDescriptor).use { output ->
                tempFile.inputStream().use { input -> input.copyTo(output) }
            }
        }
    }

    private fun notifyMediaStore(uri: Uri, filePath: String?) {
        runCatching { context.contentResolver.notifyChange(uri, null) }

        val path = filePath?.trim().orEmpty()
        if (path.isNotEmpty()) {
            runCatching {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(path),
                    null,
                    null
                )
            }
        }
    }

    private fun isProbablyReadOnlySystemPath(filePath: String?): Boolean {
        val path = filePath?.trim()?.lowercase() ?: return false
        return path.startsWith("/system/") ||
            path.startsWith("/product/") ||
            path.startsWith("/vendor/") ||
            path.startsWith("/apex/") ||
            path.startsWith("/odm/")
    }

    private fun safeErrorMessage(
        error: Throwable,
        fallback: String = "Unknown file operation error."
    ): String {
        val message = error.message?.trim()
        if (!message.isNullOrEmpty()) return message

        val causeMessage = error.cause?.message?.trim()
        if (!causeMessage.isNullOrEmpty()) return causeMessage

        return error.javaClass.simpleName.takeIf { it.isNotBlank() } ?: fallback
    }

    // ─────────────────────────────────────────────────────────────────────
    // Activity results and cleanup
    // ─────────────────────────────────────────────────────────────────────

    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            DELETE_REQUEST_CODE -> {
                val pending = pendingDelete ?: return
                if (resultCode == Activity.RESULT_OK) {
                    pending.approvedAction()
                } else {
                    pending.cancelledAction()
                }
            }

            WRITE_REQUEST_CODE -> {
                val pending = pendingWrite ?: return
                if (resultCode == Activity.RESULT_OK) {
                    pending.approvedAction()
                } else {
                    pending.cancelledAction()
                }
            }
        }
    }

    private fun finishPendingDelete(value: Map<String, Any?>) {
        val pending = pendingDelete
        pendingDelete = null
        pending?.result?.success(value)
    }

    private fun finishPendingWrite(
        code: String = "TAG_WRITE_ERROR",
        error: Throwable? = null,
        successValue: Any? = null,
        errorDetails: Any? = null
    ) {
        val pending = pendingWrite
        pendingWrite = null

        if (error == null) {
            pending?.result?.success(successValue)
        } else {
            pending?.result?.error(
                code,
                safeErrorMessage(error),
                errorDetails
            )
        }
    }

    override fun cleanup() {
        cleanedUp = true

        runCatching { channel.setMethodCallHandler(null) }

        pendingDelete?.result?.error(
            "ACTIVITY_DESTROYED",
            "The activity was destroyed during delete confirmation.",
            null
        )
        pendingDelete = null

        pendingWrite?.result?.error(
            "ACTIVITY_DESTROYED",
            "The activity was destroyed during file edit confirmation.",
            null
        )
        pendingWrite = null

        fileIoExecutor.shutdownNow()
    }
}
