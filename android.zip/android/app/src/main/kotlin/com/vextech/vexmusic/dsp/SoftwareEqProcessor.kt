package com.vextech.vexmusic.dsp

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Allocation-stable software DSP chain for just_audio / ExoPlayer.
 *
 * Signal order:
 *   automatic headroom -> stereo width -> ten-band EQ -> normalization /
 *   output boost -> linked limiter -> PCM conversion.
 */
class SoftwareEqProcessor : AudioProcessor {

    /** Listener for reporting spectral magnitudes (10-band) from the processor. */
    fun interface SpectrumListener {
        fun onSpectrum(magnitudes: DoubleArray)
    }

    @Volatile
    var spectrumListener: SpectrumListener? = null


    companion object {
        val CENTRE_FREQUENCIES = doubleArrayOf(
            31.0, 62.0, 125.0, 250.0, 500.0,
            1000.0, 2000.0, 4000.0, 8000.0, 16000.0
        )

        private const val BAND_COUNT = 10
        private const val Q = 1.41
        private const val PARAMETER_SMOOTH_MS = 12.0
        private const val LIMITER_CEILING = 0.8912509381 // -1 dBFS
        private const val NORMALIZATION_TARGET_RMS = 0.18
        private const val NORMALIZATION_MAX_GAIN = 2.0
        private const val NORMALIZATION_MIN_GAIN = 0.5

        // Goertzel spectrum analyser: samples-per-block controls the update
        // rate (~43 Hz at 44.1 kHz / ~47 Hz at 48 kHz), independent of the
        // EQ's own smoothing/limiter state.
        private const val SPECTRUM_BLOCK_SIZE = 1024
        private const val SPECTRUM_GAIN = 3.5

        private val EMPTY_BUFFER: ByteBuffer = ByteBuffer
            .allocateDirect(0)
            .order(ByteOrder.nativeOrder())
    }

    data class Configuration(
        val enabled: Boolean,
        val gainsDb: DoubleArray,
        val bassBoost: Double,
        val volumeBoost: Double,
        val stereoWidth: Double,
        val normalization: Boolean,
        val revision: Long
    ) {
        companion object {
            val FLAT = Configuration(
                enabled = true,
                gainsDb = DoubleArray(BAND_COUNT),
                bassBoost = 0.0,
                volumeBoost = 0.0,
                stereoWidth = 1.0,
                normalization = false,
                revision = 0L
            )
        }
    }

    private data class TargetState(
        val enabled: Boolean,
        val b0: DoubleArray,
        val b1: DoubleArray,
        val b2: DoubleArray,
        val a1: DoubleArray,
        val a2: DoubleArray,
        val preampLinear: Double,
        val outputGainLinear: Double,
        val stereoWidth: Double,
        val normalization: Boolean,
        val revision: Long
    )

    private val configurationRef = AtomicReference(Configuration.FLAT)
    private val targetRef = AtomicReference(buildTarget(Configuration.FLAT, 44_100))
    private val revisionCounter = AtomicLong(0L)
    private val configurationLock = Any()

    @Volatile
    private var configured = false

    @Volatile
    private var sampleRateHz = 0

    @Volatile
    private var channelCount = 0

    @Volatile
    private var floatPcm = false

    private var inputFormat: AudioFormat = AudioFormat.NOT_SET
    private var reusableBuffer: ByteBuffer = EMPTY_BUFFER
    private var outputBuffer: ByteBuffer = EMPTY_BUFFER
    private var inputEnded = false

    private var frameSamples = DoubleArray(0)
    private var filterState = emptyArray<DoubleArray>()

    private val currentB0 = DoubleArray(BAND_COUNT) { 1.0 }
    private val currentB1 = DoubleArray(BAND_COUNT)
    private val currentB2 = DoubleArray(BAND_COUNT)
    private val currentA1 = DoubleArray(BAND_COUNT)
    private val currentA2 = DoubleArray(BAND_COUNT)

    private var currentPreamp = 1.0
    private var currentOutputGain = 1.0
    private var currentWidth = 1.0
    private var activeTarget = targetRef.get()
    private var targetRevision = Long.MIN_VALUE
    private var smoothingSamplesRemaining = 0

    private var normalizationEnvelope = 0.0
    private var normalizationGain = 1.0
    private var limiterGain = 1.0
    private var normalizationEnvelopeCoefficient = 0.0
    private var normalizationGainCoefficient = 0.0
    private var limiterReleaseCoefficient = 0.0

    // Goertzel spectrum analyser state (one running filter per EQ band,
    // fed by the mono-summed post-limiter signal — i.e. what is actually
    // audible — and drained every SPECTRUM_BLOCK_SIZE samples).
    private val goertzelCoeff = DoubleArray(BAND_COUNT)
    private val goertzelQ1 = DoubleArray(BAND_COUNT)
    private val goertzelQ2 = DoubleArray(BAND_COUNT)
    private val spectrumMagnitudes = DoubleArray(BAND_COUNT)
    private var spectrumSampleCount = 0

    val isConfigured: Boolean
        get() = configured

    fun applyConfiguration(
        enabled: Boolean,
        gainsDb: DoubleArray,
        bassBoost: Double,
        volumeBoost: Double,
        stereoWidth: Double,
        normalization: Boolean,
        revision: Long = revisionCounter.incrementAndGet()
    ) {
        require(gainsDb.size == BAND_COUNT) {
            "gainsDb must have exactly $BAND_COUNT elements"
        }

        val internalRevision = revisionCounter.updateAndGet { current ->
            max(current + 1L, revision)
        }
        val configuration = Configuration(
            enabled = enabled,
            gainsDb = gainsDb.copyOf().also { gains ->
                for (index in gains.indices) {
                    gains[index] = gains[index].coerceIn(-12.0, 12.0)
                }
            },
            bassBoost = bassBoost.coerceIn(0.0, 1.0),
            volumeBoost = volumeBoost.coerceIn(0.0, 1.0),
            stereoWidth = stereoWidth.coerceIn(1.0, 1.5),
            normalization = normalization,
            revision = internalRevision
        )

        synchronized(configurationLock) {
            configurationRef.set(configuration)
            targetRef.set(buildTarget(configuration, effectiveSampleRate()))
        }
    }

    fun setEnabled(enabled: Boolean) {
        updateConfiguration { current -> current.copy(enabled = enabled) }
    }

    fun setBandGain(bandIndex: Int, gainDb: Double) {
        if (bandIndex !in 0 until BAND_COUNT) return
        updateConfiguration { current ->
            val gains = current.gainsDb.copyOf()
            gains[bandIndex] = gainDb.coerceIn(-12.0, 12.0)
            current.copy(gainsDb = gains)
        }
    }

    fun setBandGains(gainsDb: DoubleArray) {
        require(gainsDb.size == BAND_COUNT)
        updateConfiguration { current ->
            current.copy(
                gainsDb = gainsDb.copyOf().also { gains ->
                    for (index in gains.indices) {
                        gains[index] = gains[index].coerceIn(-12.0, 12.0)
                    }
                }
            )
        }
    }

    fun setBassBoost(level: Double) {
        updateConfiguration { it.copy(bassBoost = level.coerceIn(0.0, 1.0)) }
    }

    fun setVolumeBoost(level: Double) {
        updateConfiguration { it.copy(volumeBoost = level.coerceIn(0.0, 1.0)) }
    }

    fun setStereoWidth(width: Double) {
        updateConfiguration { it.copy(stereoWidth = width.coerceIn(1.0, 1.5)) }
    }

    fun setNormalization(enabled: Boolean) {
        updateConfiguration { it.copy(normalization = enabled) }
    }

    fun resetAll() {
        applyConfiguration(
            enabled = true,
            gainsDb = DoubleArray(BAND_COUNT),
            bassBoost = 0.0,
            volumeBoost = 0.0,
            stereoWidth = 1.0,
            normalization = false
        )
    }

    private fun updateConfiguration(transform: (Configuration) -> Configuration) {
        synchronized(configurationLock) {
            val current = configurationRef.get()
            val updated = transform(current).copy(
                revision = revisionCounter.incrementAndGet()
            )
            configurationRef.set(updated)
            targetRef.set(buildTarget(updated, effectiveSampleRate()))
        }
    }

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        val supported = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
            inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT

        if (!supported) {
            inputFormat = AudioFormat.NOT_SET
            configured = false
            return AudioFormat.NOT_SET
        }

        inputFormat = inputAudioFormat
        sampleRateHz = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount
        floatPcm = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        configured = true

        frameSamples = DoubleArray(channelCount)
        filterState = Array(channelCount) { DoubleArray(BAND_COUNT * 2) }

        normalizationEnvelopeCoefficient =
            1.0 - exp(-1.0 / (sampleRateHz * 0.050))
        normalizationGainCoefficient =
            1.0 - exp(-1.0 / (sampleRateHz * 0.250))
        limiterReleaseCoefficient =
            1.0 - exp(-1.0 / (sampleRateHz * 0.120))

        for (band in 0 until BAND_COUNT) {
            val omega = 2.0 * PI * CENTRE_FREQUENCIES[band] / sampleRateHz
            goertzelCoeff[band] = 2.0 * cos(omega)
        }
        resetSpectrumState()

        synchronized(configurationLock) {
            targetRef.set(buildTarget(configurationRef.get(), sampleRateHz))
        }
        loadTarget(force = true)
        resetRuntimeState()
        return inputAudioFormat
    }

    override fun isActive(): Boolean = inputFormat != AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        loadTarget(force = false)
        val listener = spectrumListener

        val bytesPerSample = if (floatPcm) 4 else 2
        val bytesPerFrame = bytesPerSample * channelCount
        val inputBytes = inputBuffer.remaining()
        val frameCount = inputBytes / bytesPerFrame
        val completeBytes = frameCount * bytesPerFrame

        val output = replaceOutputBuffer(completeBytes)

        if (canBypass()) {
            val oldLimit = inputBuffer.limit()
            inputBuffer.limit(inputBuffer.position() + completeBytes)
            output.put(inputBuffer)
            inputBuffer.limit(oldLimit)
            output.flip()
            return
        }

        repeat(frameCount) {
            advanceSmoothing()

            var frameEnergy = 0.0
            for (channel in 0 until channelCount) {
                val sample = if (floatPcm) {
                    inputBuffer.float.toDouble().coerceIn(-1.0, 1.0)
                } else {
                    inputBuffer.short.toDouble() / 32768.0
                }
                frameSamples[channel] = sample * currentPreamp
            }

            if (channelCount == 2 && currentWidth != 1.0) {
                val left = frameSamples[0]
                val right = frameSamples[1]
                val mid = (left + right) * 0.5
                val side = (left - right) * 0.5 * currentWidth
                frameSamples[0] = mid + side
                frameSamples[1] = mid - side
            }

            for (channel in 0 until channelCount) {
                val filtered = applyFilters(frameSamples[channel], channel)
                frameSamples[channel] = filtered
                frameEnergy += filtered * filtered
            }

            val meanSquare = frameEnergy / channelCount.coerceAtLeast(1)
            normalizationEnvelope +=
                (meanSquare - normalizationEnvelope) * normalizationEnvelopeCoefficient

            val normalizationTarget = if (activeTarget.normalization &&
                normalizationEnvelope > 0.000025
            ) {
                (NORMALIZATION_TARGET_RMS / sqrt(normalizationEnvelope))
                    .coerceIn(NORMALIZATION_MIN_GAIN, NORMALIZATION_MAX_GAIN)
            } else {
                1.0
            }
            normalizationGain +=
                (normalizationTarget - normalizationGain) * normalizationGainCoefficient

            var peak = 0.0
            val postGain = currentOutputGain * normalizationGain
            for (channel in 0 until channelCount) {
                val value = frameSamples[channel] * postGain
                frameSamples[channel] = value
                peak = max(peak, kotlin.math.abs(value))
            }

            val requiredLimiterGain = if (peak > LIMITER_CEILING) {
                LIMITER_CEILING / peak
            } else {
                1.0
            }

            limiterGain = if (requiredLimiterGain < limiterGain) {
                requiredLimiterGain
            } else {
                limiterGain + (1.0 - limiterGain) * limiterReleaseCoefficient
            }

            var monoSum = 0.0
            for (channel in 0 until channelCount) {
                val limited = (frameSamples[channel] * limiterGain)
                    .coerceIn(-LIMITER_CEILING, LIMITER_CEILING)
                monoSum += limited

                if (floatPcm) {
                    output.putFloat(limited.toFloat())
                } else {
                    val pcm = (limited * 32767.0)
                        .toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    output.putShort(pcm.toShort())
                }
            }

            if (listener != null) {
                feedSpectrum(monoSum / channelCount.coerceAtLeast(1), listener)
            }
        }

        output.flip()
        val trailingBytes = inputBytes - completeBytes
        if (trailingBytes > 0) {
            inputBuffer.position(inputBuffer.position() + trailingBytes)
        }
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val output = outputBuffer
        outputBuffer = EMPTY_BUFFER
        return output
    }

    override fun isEnded(): Boolean = inputEnded && !outputBuffer.hasRemaining()

    override fun flush() {
        outputBuffer = EMPTY_BUFFER
        inputEnded = false
        resetRuntimeState()
        clearFilterState()
        resetSpectrumState()
    }

    override fun reset() {
        flush()
        inputFormat = AudioFormat.NOT_SET
        configured = false
        sampleRateHz = 0
        channelCount = 0
        floatPcm = false
        frameSamples = DoubleArray(0)
        filterState = emptyArray()
    }

    private fun replaceOutputBuffer(requiredCapacity: Int): ByteBuffer {
        if (reusableBuffer.capacity() < requiredCapacity) {
            reusableBuffer = ByteBuffer
                .allocateDirect(requiredCapacity)
                .order(ByteOrder.nativeOrder())
        } else {
            reusableBuffer.clear()
        }
        outputBuffer = reusableBuffer
        return reusableBuffer
    }

    private fun loadTarget(force: Boolean) {
        val next = targetRef.get()
        if (!force && next.revision == targetRevision) return

        activeTarget = next
        targetRevision = next.revision
        smoothingSamplesRemaining = if (force) {
            0
        } else {
            max(1, (effectiveSampleRate() * PARAMETER_SMOOTH_MS / 1000.0).toInt())
        }

        if (force) {
            for (band in 0 until BAND_COUNT) {
                currentB0[band] = next.b0[band]
                currentB1[band] = next.b1[band]
                currentB2[band] = next.b2[band]
                currentA1[band] = next.a1[band]
                currentA2[band] = next.a2[band]
            }
            currentPreamp = next.preampLinear
            currentOutputGain = next.outputGainLinear
            currentWidth = next.stereoWidth
        }
    }

    private fun advanceSmoothing() {
        val remaining = smoothingSamplesRemaining
        if (remaining <= 0) return

        val divisor = remaining.toDouble()
        for (band in 0 until BAND_COUNT) {
            currentB0[band] += (activeTarget.b0[band] - currentB0[band]) / divisor
            currentB1[band] += (activeTarget.b1[band] - currentB1[band]) / divisor
            currentB2[band] += (activeTarget.b2[band] - currentB2[band]) / divisor
            currentA1[band] += (activeTarget.a1[band] - currentA1[band]) / divisor
            currentA2[band] += (activeTarget.a2[band] - currentA2[band]) / divisor
        }
        currentPreamp += (activeTarget.preampLinear - currentPreamp) / divisor
        currentOutputGain +=
            (activeTarget.outputGainLinear - currentOutputGain) / divisor
        currentWidth += (activeTarget.stereoWidth - currentWidth) / divisor
        smoothingSamplesRemaining--
    }

    private fun canBypass(): Boolean {
        return smoothingSamplesRemaining == 0 &&
            !activeTarget.enabled &&
            !activeTarget.normalization &&
            kotlin.math.abs(normalizationGain - 1.0) < 0.0001 &&
            limiterGain > 0.9999 &&
            spectrumListener == null
    }

    private fun applyFilters(input: Double, channel: Int): Double {
        var value = input
        val state = filterState[channel]

        for (band in 0 until BAND_COUNT) {
            val stateIndex = band * 2
            val w1 = state[stateIndex]
            val w2 = state[stateIndex + 1]
            val output = currentB0[band] * value + w1
            state[stateIndex] =
                currentB1[band] * value - currentA1[band] * output + w2
            state[stateIndex + 1] =
                currentB2[band] * value - currentA2[band] * output
            value = output
        }

        return value
    }

    private fun resetRuntimeState() {
        normalizationEnvelope = 0.0
        normalizationGain = 1.0
        limiterGain = 1.0
    }

    private fun clearFilterState() {
        for (channelState in filterState) {
            channelState.fill(0.0)
        }
    }

    private fun resetSpectrumState() {
        goertzelQ1.fill(0.0)
        goertzelQ2.fill(0.0)
        spectrumSampleCount = 0
    }

    /**
     * Advances the 10-band Goertzel filter bank by one sample of the
     * post-limiter, mono-summed signal. Every [SPECTRUM_BLOCK_SIZE] samples
     * the accumulated energy is drained into normalised 0.0-1.0 magnitudes
     * and handed to [listener]; the filter state is then reset for the next
     * block so successive readings don't bleed into each other.
     */
    private fun feedSpectrum(monoSample: Double, listener: SpectrumListener) {
        for (band in 0 until BAND_COUNT) {
            val q0 = goertzelCoeff[band] * goertzelQ1[band] - goertzelQ2[band] + monoSample
            goertzelQ2[band] = goertzelQ1[band]
            goertzelQ1[band] = q0
        }

        spectrumSampleCount++
        if (spectrumSampleCount < SPECTRUM_BLOCK_SIZE) return

        for (band in 0 until BAND_COUNT) {
            val q1 = goertzelQ1[band]
            val q2 = goertzelQ2[band]
            val power = q1 * q1 + q2 * q2 - goertzelCoeff[band] * q1 * q2
            val magnitude = sqrt(max(0.0, power)) / SPECTRUM_BLOCK_SIZE
            spectrumMagnitudes[band] = (magnitude * SPECTRUM_GAIN).coerceIn(0.0, 1.0)
        }

        resetSpectrumState()
        listener.onSpectrum(spectrumMagnitudes.copyOf())
    }

    private fun effectiveSampleRate(): Int =
        if (sampleRateHz > 0) sampleRateHz else 44_100

    private fun buildTarget(
        configuration: Configuration,
        sampleRate: Int
    ): TargetState {
        val gains = configuration.gainsDb.copyOf()

        if (configuration.enabled) {
            val bassDb = configuration.bassBoost * 6.0
            gains[0] = (gains[0] + bassDb).coerceIn(-12.0, 12.0)
            gains[1] = (gains[1] + bassDb * 0.8).coerceIn(-12.0, 12.0)
        } else {
            gains.fill(0.0)
        }

        val b0 = DoubleArray(BAND_COUNT)
        val b1 = DoubleArray(BAND_COUNT)
        val b2 = DoubleArray(BAND_COUNT)
        val a1 = DoubleArray(BAND_COUNT)
        val a2 = DoubleArray(BAND_COUNT)

        var highestPositiveGain = 0.0
        for (band in 0 until BAND_COUNT) {
            highestPositiveGain = max(highestPositiveGain, gains[band])
            val coefficients = peakingEqCoefficients(
                frequency = CENTRE_FREQUENCIES[band],
                gainDb = gains[band],
                sampleRate = sampleRate.toDouble()
            )
            b0[band] = coefficients[0]
            b1[band] = coefficients[1]
            b2[band] = coefficients[2]
            a1[band] = coefficients[3]
            a2[band] = coefficients[4]
        }

        val width = if (configuration.enabled) {
            configuration.stereoWidth.coerceIn(1.0, 1.5)
        } else {
            1.0
        }
        val widthHeadroomDb = (width - 1.0) * 4.0
        val automaticHeadroomDb = -(highestPositiveGain + widthHeadroomDb)
            .coerceIn(0.0, 12.0)
        val outputBoostDb = if (configuration.enabled) {
            configuration.volumeBoost * 3.0
        } else {
            0.0
        }

        return TargetState(
            enabled = configuration.enabled,
            b0 = b0,
            b1 = b1,
            b2 = b2,
            a1 = a1,
            a2 = a2,
            preampLinear = dbToLinear(automaticHeadroomDb),
            outputGainLinear = dbToLinear(outputBoostDb),
            stereoWidth = width,
            normalization = configuration.enabled && configuration.normalization,
            revision = configuration.revision
        )
    }

    private fun peakingEqCoefficients(
        frequency: Double,
        gainDb: Double,
        sampleRate: Double
    ): DoubleArray {
        if (gainDb in -0.0001..0.0001 || frequency >= sampleRate * 0.49) {
            return doubleArrayOf(1.0, 0.0, 0.0, 0.0, 0.0)
        }

        val omega = 2.0 * PI * frequency / sampleRate
        val amplitude = 10.0.pow(gainDb / 40.0)
        val alpha = sin(omega) / (2.0 * Q)
        val cosine = cos(omega)

        val numerator0 = 1.0 + alpha * amplitude
        val numerator1 = -2.0 * cosine
        val numerator2 = 1.0 - alpha * amplitude
        val denominator0 = 1.0 + alpha / amplitude
        val denominator1 = -2.0 * cosine
        val denominator2 = 1.0 - alpha / amplitude

        return doubleArrayOf(
            numerator0 / denominator0,
            numerator1 / denominator0,
            numerator2 / denominator0,
            denominator1 / denominator0,
            denominator2 / denominator0
        )
    }

    private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)
}
