package com.vextech.vexmusic.audioformat

/**
 * What the app can actually do with a given audio file, decided from its
 * real, byte-verified container/codec rather than a filename extension.
 *
 * This is a capability table, not an extension whitelist: "supported" here
 * means the bundled `net.jthink:jaudiotagger:3.0.1` has a registered
 * reader/writer that can handle this exact container+codec combination.
 * `AudioFileIO` (jaudiotagger) itself dispatches purely by the extension of
 * the file name it's handed — "It selects the appropriate reader/writer
 * based on the file extension" (jaudiotagger's own AudioFileIO Javadoc) —
 * so [tagIoExtension] is the exact suffix this app must give the temp file
 * it hands to jaudiotagger for that dispatch to land on the right adapter.
 * A sniffed container that has no safe [tagIoExtension] cannot be tagged by
 * this library, no matter what extension a filename or MIME type claims.
 */
data class AudioFormatProfile(
    val displayLabel: String,

    /** True if jaudiotagger 3.0.1 has a registered reader+writer for this
     *  exact container+codec that can persist text tags (title/artist/
     *  album/etc). */
    val supportsTagWrite: Boolean,

    /** True if jaudiotagger 3.0.1 can additionally read/write embedded
     *  artwork for this exact container+codec. Kept independent of
     *  [supportsTagWrite] rather than derived from it, since the two are
     *  genuinely separate capabilities in jaudiotagger even though every
     *  container in this table's tag-writable set also turns out to
     *  support artwork - a future addition to this table is not
     *  guaranteed to. */
    val supportsArtworkWrite: Boolean,

    /** The suffix jaudiotagger's own extension-keyed reader/writer lookup
     *  needs to select the right adapter. Null when this container has no
     *  safe mapping — i.e. every extension jaudiotagger recognizes would
     *  either fail outright or, worse, silently hand the file to the wrong
     *  format-specific parser. */
    val tagIoExtension: String?
)

/**
 * Per-format adapters, keyed by the [SniffedContainer] that
 * [AudioContainerSniffer] actually found in the file's bytes — never by a
 * filename extension.
 *
 * Verified against jaudiotagger 3.0.1's own registration list
 * (`AudioFileIO.prepareReadersAndWriters`) and format-specific Javadoc:
 *  - MP3, MP4 family, native FLAC, WAV, Ogg Vorbis: fully supported, tags
 *    + artwork. jaudiotagger's `OggFileReader` Javadoc states it is "Only
 *    implemented for ogg files containing a vorbis stream with vorbis
 *    comments" — this is the one Ogg codec it actually handles, and
 *    `VorbisCommentTag` implements the same `Tag`/`Artwork` interface as
 *    every other format (it base64-encodes the picture into a
 *    METADATA_BLOCK_PICTURE comment internally, transparently to callers).
 *  - Ogg Opus: NOT supported by this library. jaudiotagger 3.0.1 registers
 *    no "opus" reader/writer at all (that exists only in unrelated,
 *    differently-packaged community forks, not the `net.jthink` artifact
 *    this app depends on), and handing an Opus stream to the Vorbis-only
 *    `OggFileReader` fails for the same reason standard Vorbis-comment
 *    tools reject real .opus files: Opus and Vorbis are different codecs
 *    that merely share the Ogg container.
 *  - Ogg-mapped FLAC: NOT supported. The plain `OggFileReader` registered
 *    for the "ogg" extension is Vorbis-only, so a FLAC-in-Ogg stream (a
 *    real but uncommon mapping, distinct from native ".flac") is rejected
 *    the same way Opus-in-Ogg is; jaudiotagger has no adapter that expects
 *    FLAC packets inside an Ogg page.
 */
object AudioFormatCapabilities {

    private val MP4_LIKE = AudioFormatProfile(
        displayLabel = "MP4 audio",
        supportsTagWrite = true,
        supportsArtworkWrite = true,
        tagIoExtension = "m4a"
    )

    fun profileFor(sniff: SniffResult): AudioFormatProfile = when (sniff.container) {
        SniffedContainer.MP3 -> AudioFormatProfile(
            displayLabel = "MP3",
            supportsTagWrite = true,
            supportsArtworkWrite = true,
            tagIoExtension = "mp3"
        )

        SniffedContainer.MP4_FAMILY -> mp4Profile(sniff.mp4Brand)

        SniffedContainer.FLAC_NATIVE -> AudioFormatProfile(
            displayLabel = "FLAC",
            supportsTagWrite = true,
            supportsArtworkWrite = true,
            tagIoExtension = "flac"
        )

        SniffedContainer.OGG_VORBIS -> AudioFormatProfile(
            displayLabel = "OGG Vorbis",
            supportsTagWrite = true,
            // VorbisCommentTag implements the same Tag interface as every
            // other format and accepts a standard Artwork via setField();
            // internally it base64-encodes the picture into a
            // METADATA_BLOCK_PICTURE comment rather than storing raw
            // bytes, but that happens inside jaudiotagger - this app's
            // generic writeArtworkToUri call needs no Vorbis-specific path.
            supportsArtworkWrite = true,
            tagIoExtension = "ogg"
        )

        SniffedContainer.WAV -> AudioFormatProfile(
            displayLabel = "WAV",
            supportsTagWrite = true,
            // WavTag can carry an embedded ID3v2 chunk alongside the
            // LIST-INFO chunk, and ID3v2 supports an APIC artwork frame the
            // same way it does in MP3 - jaudiotagger's own WavTag class
            // imports org.jaudiotagger.tag.images.Artwork for exactly this.
            supportsArtworkWrite = true,
            tagIoExtension = "wav"
        )

        SniffedContainer.OGG_OPUS -> AudioFormatProfile(
            displayLabel = "Opus",
            supportsTagWrite = false,
            supportsArtworkWrite = false,
            tagIoExtension = null
        )

        SniffedContainer.OGG_FLAC -> AudioFormatProfile(
            displayLabel = "FLAC (Ogg)",
            supportsTagWrite = false,
            supportsArtworkWrite = false,
            tagIoExtension = null
        )

        SniffedContainer.OGG_UNKNOWN_CODEC -> AudioFormatProfile(
            displayLabel = "Ogg audio",
            supportsTagWrite = false,
            supportsArtworkWrite = false,
            tagIoExtension = null
        )

        SniffedContainer.UNKNOWN -> AudioFormatProfile(
            displayLabel = "Unknown format",
            supportsTagWrite = false,
            supportsArtworkWrite = false,
            tagIoExtension = null
        )
    }

    /**
     * MP4-family files share one box structure across audio-only variants;
     * jaudiotagger's `Mp4FileReader`/`Mp4FileWriter` handle all of them
     * (registered for "m4a", "m4p", "m4b", and "mp4" alike), so the exact
     * brand only affects which extension we hand back for [tagIoExtension]
     * — cosmetic for jaudiotagger's dispatch, not a capability difference.
     */
    private fun mp4Profile(brand: String?): AudioFormatProfile {
        val normalizedBrand = brand?.trim()?.uppercase().orEmpty()

        val extension = when {
            normalizedBrand.startsWith("M4A") -> "m4a"
            normalizedBrand.startsWith("M4B") -> "m4b"
            normalizedBrand.startsWith("M4P") -> "m4p"
            else -> "m4a"
        }

        return MP4_LIKE.copy(tagIoExtension = extension)
    }
}
