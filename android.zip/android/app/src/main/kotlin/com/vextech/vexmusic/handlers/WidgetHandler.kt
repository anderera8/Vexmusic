// android/app/src/main/kotlin/com/vextech/vexmusic/handlers/WidgetHandler.kt
package com.vextech.vexmusic.handlers

import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.vextech.vexmusic.VibesPlayerWidget

/**
 * Handles home-screen widget updates from Flutter.
 * Receives track metadata and updates all widget instances.
 */
class WidgetHandler(private val context: Context) : BaseHandler() {
    
    companion object {
        private const val CHANNEL = "com.vextech.vexmusic/widget"
    }
    
    override fun register(flutterEngine: FlutterEngine) {
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "updateWidget" -> {
                    val title = call.argument<String>("title")
                    val artist = call.argument<String>("artist")
                    val artworkPath = call.argument<String>("artworkPath")
                    val isPlaying = call.argument<Boolean>("isPlaying") ?: false
                    
                    VibesPlayerWidget.updateWidget(
                        context,
                        title,
                        artist,
                        artworkPath,
                        isPlaying
                    )
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
}
