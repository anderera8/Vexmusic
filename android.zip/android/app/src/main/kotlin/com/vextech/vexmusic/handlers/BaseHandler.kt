// android/app/src/main/kotlin/com/vextech/vexmusic/handlers/BaseHandler.kt
package com.vextech.vexmusic.handlers

import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Base class for all MethodChannel handlers.
 * Provides common functionality and lifecycle management.
 */
abstract class BaseHandler {
    
    protected lateinit var channel: MethodChannel
    
    /**
     * Register the MethodChannel with Flutter engine.
     * Must set [channelName] and implement [onMethodCall].
     */
    abstract fun register(flutterEngine: FlutterEngine)
    
    /**
     * Clean up resources when activity destroys.
     * Override if handler holds native resources (Virtualizer, Observers, etc.)
     */
    open fun cleanup() {
        // Default: no-op
    }
    
    /**
     * Called when activity saves instance state (rotation, etc.)
     * Override to save state that needs restoration.
     */
    open fun saveState(outState: android.os.Bundle) {
        // Default: no-op
    }
    
    /**
     * Called when activity restores instance state.
     * Override to restore saved state.
     */
    open fun restoreState(savedInstanceState: android.os.Bundle?) {
        // Default: no-op
    }
}