package com.vextech.vexmusic.handlers

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel

class MediaStoreObserver(private val context: Context) : BaseHandler() {

    companion object {
        private const val AUDIO_CHANNEL = "com.vextech.vexmusic/mediastore"
        private const val LOG_TAG = "MediaStoreObserver"
    }

    private var audioObserver: ContentObserver? = null
    private var audioEventSink: EventChannel.EventSink? = null

    override fun register(flutterEngine: FlutterEngine) {
        val audioChannel = EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            AUDIO_CHANNEL
        )

        audioChannel.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                audioEventSink = events
                registerAudioObserver()
            }

            override fun onCancel(arguments: Any?) {
                unregisterAudioObserver()
                audioEventSink = null
            }
        })
    }

    private fun registerAudioObserver() {
        if (audioObserver != null) return

        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)

                audioEventSink?.success(
                    mapOf(
                        "type" to "changed",
                        "uri" to uri?.toString(),
                        "volumeName" to volumeNameFromUri(uri),
                        "timestampMillis" to System.currentTimeMillis()
                    )
                )
            }
        }

        audioObserver = observer

        for (uri in observedAudioUris()) {
            try {
                context.contentResolver.registerContentObserver(
                    uri,
                    true,
                    observer
                )
            } catch (error: Throwable) {
                Log.w(LOG_TAG, "Could not observe $uri", error)
            }
        }
    }

    private fun observedAudioUris(): List<Uri> {
        val uris = linkedSetOf<Uri>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            for (volumeName in MediaStore.getExternalVolumeNames(context)) {
                uris.add(MediaStore.Audio.Media.getContentUri(volumeName))
            }
            uris.add(MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_INTERNAL))
        } else {
            uris.add(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
            uris.add(MediaStore.Audio.Media.INTERNAL_CONTENT_URI)
        }

        return uris.toList()
    }

    private fun volumeNameFromUri(uri: Uri?): String? {
        if (uri == null || uri.authority != "media") return null
        val volume = uri.pathSegments.firstOrNull()?.trim()?.lowercase()
            ?.takeIf { it.isNotEmpty() }
        return if (volume == "external") "external_primary" else volume
    }

    private fun unregisterAudioObserver() {
        val observer = audioObserver ?: return

        try {
            context.contentResolver.unregisterContentObserver(observer)
        } catch (_: Throwable) {
            // Observer may already have been detached by Android.
        }

        audioObserver = null
    }

    override fun cleanup() {
        unregisterAudioObserver()
        audioEventSink = null
    }
}
