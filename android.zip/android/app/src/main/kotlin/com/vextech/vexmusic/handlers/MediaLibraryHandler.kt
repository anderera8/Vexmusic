package com.vextech.vexmusic.handlers

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import com.vextech.vexmusic.identity.StableAudioIdentity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.Result
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * App-owned Android MediaStore bridge for Vibes Player.
 *
 * This permanently replaces the Android scanning/artwork dependency on
 * on_audio_query_android. It queries MediaStore directly through the app module,
 * so no third-party Android library module is needed for local audio discovery.
 */
class MediaLibraryHandler(private val context: Context) : BaseHandler() {

    companion object {
        private const val CHANNEL = "com.vextech.vexmusic/media_library"
        private const val LOG_TAG = "MediaLibraryHandler"

        private const val TYPE_AUDIO = "audio"
        private const val TYPE_ALBUM = "album"

        private const val DEFAULT_THUMB_SIZE = 512
        private const val DEFAULT_THUMB_QUALITY = 90
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val mediaExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "vibes-media-library").apply { isDaemon = true }
    }

    @Volatile
    private var cleanedUp = false

    override fun register(flutterEngine: FlutterEngine) {
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "hasPermission" -> result.success(hasAudioPermission())

                "queryAudio", "queryAudioVolumes" -> {
                    val minDurationMs = call.argument<Number>("minDurationMs")?.toLong() ?: 0L
                    val includeInternal = call.argument<Boolean>("includeInternal") ?: false
                    val includeRingtones = call.argument<Boolean>("includeRingtones") ?: false
                    val includeAlarms = call.argument<Boolean>("includeAlarms") ?: false
                    val includeNotifications = call.argument<Boolean>("includeNotifications") ?: false
                    val includePodcasts = call.argument<Boolean>("includePodcasts") ?: true
                    val knownVolumeNames = call.argument<List<String>>("knownVolumeNames")
                        .orEmpty()

                    queryAudioVolumes(
                        minDurationMs = minDurationMs,
                        includeInternal = includeInternal,
                        includeRingtones = includeRingtones,
                        includeAlarms = includeAlarms,
                        includeNotifications = includeNotifications,
                        includePodcasts = includePodcasts,
                        knownVolumeNames = knownVolumeNames,
                        legacyListResponse = call.method == "queryAudio",
                        result = result
                    )
                }

                "loadArtwork" -> {
                    val id = call.argument<Number>("id")?.toLong()
                    val type = call.argument<String>("type") ?: TYPE_AUDIO
                    val volumeName = call.argument<String>("volumeName")
                    val size = call.argument<Number>("size")?.toInt() ?: DEFAULT_THUMB_SIZE
                    val quality = call.argument<Number>("quality")?.toInt() ?: DEFAULT_THUMB_QUALITY
                    val format = call.argument<String>("format") ?: "jpeg"

                    if (id == null || id <= 0L) {
                        result.error("INVALID_ARG", "id must be a positive number", null)
                        return@setMethodCallHandler
                    }

                    loadArtwork(
                        id = id,
                        type = type,
                        volumeName = volumeName,
                        size = size.coerceIn(64, 2048),
                        quality = quality.coerceIn(1, 100),
                        format = format,
                        result = result
                    )
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun postToMain(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            action()
        } else {
            mainHandler.post { action() }
        }
    }

    private fun postSuccess(result: Result, value: Any?) {
        postToMain { result.success(value) }
    }

    private fun postError(
        result: Result,
        code: String,
        message: String,
        details: Any? = null
    ) {
        postToMain { result.error(code, message, details) }
    }

    private fun executeMediaOperation(
        result: Result,
        rejectedCode: String,
        rejectedMessage: String,
        work: () -> Unit
    ) {
        if (cleanedUp) {
            postError(
                result,
                "ACTIVITY_DESTROYED",
                "Activity was destroyed before the media operation could run.",
                null
            )
            return
        }

        try {
            mediaExecutor.execute {
                if (cleanedUp) return@execute
                work()
            }
        } catch (error: RejectedExecutionException) {
            postError(result, rejectedCode, error.message ?: rejectedMessage, null)
        }
    }

    private fun hasAudioPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true

        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun queryAudioVolumes(
        minDurationMs: Long,
        includeInternal: Boolean,
        includeRingtones: Boolean,
        includeAlarms: Boolean,
        includeNotifications: Boolean,
        includePodcasts: Boolean,
        knownVolumeNames: List<String>,
        legacyListResponse: Boolean,
        result: Result
    ) {
        if (!hasAudioPermission()) {
            result.error(
                "PERMISSION_DENIED",
                "Audio media permission has not been granted.",
                null
            )
            return
        }

        executeMediaOperation(
            result = result,
            rejectedCode = "QUERY_REJECTED",
            rejectedMessage = "Audio query could not be started."
        ) {
            try {
                val volumeResults = ArrayList<Map<String, Any?>>()
                val allSuccessfulRows = ArrayList<Map<String, Any?>>()

                for (target in audioScanTargets(includeInternal, knownVolumeNames)) {
                    if (!target.available || target.uri == null) {
                        volumeResults.add(
                            volumeResult(
                                volumeName = target.volumeName,
                                status = "unavailable",
                                records = emptyList(),
                                errorCode = "VOLUME_UNAVAILABLE",
                                message = "Storage volume is not currently mounted."
                            )
                        )
                        continue
                    }

                    val volumeRows = ArrayList<Map<String, Any?>>()

                    try {
                        queryAudioFromUri(
                            uri = target.uri,
                            volumeName = target.volumeName,
                            minDurationMs = minDurationMs,
                            includeRingtones = includeRingtones,
                            includeAlarms = includeAlarms,
                            includeNotifications = includeNotifications,
                            includePodcasts = includePodcasts,
                            out = volumeRows
                        )

                        sortAudioRows(volumeRows)
                        allSuccessfulRows.addAll(volumeRows)

                        volumeResults.add(
                            volumeResult(
                                volumeName = target.volumeName,
                                status = "success",
                                records = volumeRows
                            )
                        )
                    } catch (error: SecurityException) {
                        volumeResults.add(
                            volumeResult(
                                volumeName = target.volumeName,
                                status = "permission_denied",
                                records = emptyList(),
                                errorCode = "PERMISSION_DENIED",
                                message = error.message ?: "Volume access was denied."
                            )
                        )
                    } catch (error: IllegalArgumentException) {
                        volumeResults.add(
                            volumeResult(
                                volumeName = target.volumeName,
                                status = "unavailable",
                                records = emptyList(),
                                errorCode = "VOLUME_UNAVAILABLE",
                                message = error.message ?: "Storage volume is unavailable."
                            )
                        )
                    } catch (error: Throwable) {
                        Log.e(
                            LOG_TAG,
                            "Audio query failed for ${target.volumeName}",
                            error
                        )
                        volumeResults.add(
                            volumeResult(
                                volumeName = target.volumeName,
                                status = "failed",
                                records = emptyList(),
                                errorCode = "QUERY_FAILED",
                                message = error.message ?: "Audio query failed."
                            )
                        )
                    }
                }

                sortAudioRows(allSuccessfulRows)

                if (legacyListResponse) {
                    postSuccess(result, allSuccessfulRows)
                } else {
                    postSuccess(
                        result,
                        linkedMapOf(
                            "permissionGranted" to true,
                            "generatedAtMillis" to System.currentTimeMillis(),
                            "volumes" to volumeResults
                        )
                    )
                }
            } catch (error: Throwable) {
                Log.e(LOG_TAG, "queryAudioVolumes failed", error)
                postError(
                    result,
                    "QUERY_FAILED",
                    error.message ?: "Audio query failed.",
                    null
                )
            }
        }
    }

    private fun volumeResult(
        volumeName: String,
        status: String,
        records: List<Map<String, Any?>>,
        errorCode: String? = null,
        message: String? = null
    ): Map<String, Any?> {
        return linkedMapOf(
            "volumeName" to volumeName,
            "status" to status,
            "records" to records,
            "errorCode" to errorCode,
            "message" to message
        )
    }

    private fun sortAudioRows(rows: MutableList<Map<String, Any?>>) {
        rows.sortWith(
            compareByDescending<Map<String, Any?>> {
                (it["dateAdded"] as? Number)?.toLong() ?: 0L
            }.thenBy {
                (it["title"] as? String).orEmpty().lowercase()
            }.thenBy {
                (it["volumeName"] as? String).orEmpty()
            }.thenBy {
                (it["mediaStoreId"] as? Number)?.toLong() ?: 0L
            }
        )
    }

    private fun queryAudioFromUri(
        uri: Uri,
        volumeName: String,
        minDurationMs: Long,
        includeRingtones: Boolean,
        includeAlarms: Boolean,
        includeNotifications: Boolean,
        includePodcasts: Boolean,
        out: MutableList<Map<String, Any?>>
    ) {
        val projection = audioProjection()
        val selectionParts = ArrayList<String>()
        val selectionArgs = ArrayList<String>()

        selectionParts.add("${MediaStore.Audio.Media.DURATION} >= ?")
        selectionArgs.add(minDurationMs.coerceAtLeast(0L).toString())

        if (!includeRingtones) selectionParts.add("${MediaStore.Audio.Media.IS_RINGTONE} = 0")
        if (!includeAlarms) selectionParts.add("${MediaStore.Audio.Media.IS_ALARM} = 0")
        if (!includeNotifications) selectionParts.add("${MediaStore.Audio.Media.IS_NOTIFICATION} = 0")
        if (!includePodcasts) selectionParts.add("${MediaStore.Audio.Media.IS_PODCAST} = 0")

        val selection = selectionParts.joinToString(" AND ")
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC, ${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        val cursor = context.contentResolver.query(
            uri,
            projection.toTypedArray(),
            selection,
            selectionArgs.toTypedArray(),
            sortOrder
        ) ?: throw IllegalStateException(
            "MediaStore returned no cursor for volume $volumeName."
        )

        cursor.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val artistIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dateModifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
            val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            val displayNameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            val relativePathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            } else {
                -1
            }
            val composerCol = cursor.getColumnIndex(MediaStore.Audio.Media.COMPOSER)
            val isMusicCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC)
            val isRingtoneCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_RINGTONE)
            val isAlarmCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_ALARM)
            val isNotificationCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_NOTIFICATION)
            val isPodcastCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_PODCAST)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val duration = cursor.getLong(durationCol)
                if (duration < minDurationMs) continue

                val title = cursor.getNullableString(titleCol).cleanUnknown("Unknown Title")
                val artist = cursor.getNullableString(artistCol).cleanUnknown("Unknown Artist")
                val album = cursor.getNullableString(albumCol).cleanUnknown("Unknown album")
                val displayName = cursor.getNullableString(displayNameCol)
                val filePath = cursor.getNullableString(dataCol)
                val relativePath = cursor.getNullableString(relativePathCol)
                val mimeType = cursor.getNullableString(mimeCol)
                val albumId = cursor.getLongOrNull(albumIdCol)
                val artistId = cursor.getLongOrNull(artistIdCol)
                val contentUri = ContentUris.withAppendedId(uri, id).toString()

                out.add(
                    linkedMapOf(
                        "id" to id,
                        "mediaStoreId" to id,
                        "stableKey" to StableAudioIdentity.fromMediaStore(
                            volumeName = volumeName,
                            absolutePath = filePath,
                            relativePath = relativePath,
                            displayName = displayName
                        ),
                        "uri" to contentUri,
                        "title" to title,
                        "artist" to artist,
                        "album" to album,
                        "albumId" to albumId,
                        "artistId" to artistId,
                        "duration" to duration,
                        "size" to cursor.getLongOrNull(sizeCol),
                        "dateAdded" to cursor.getLongOrNull(dateAddedCol),
                        "dateModified" to cursor.getLongOrNull(dateModifiedCol),
                        "track" to cursor.getIntOrNull(trackCol),
                        "year" to cursor.getIntOrNull(yearCol),
                        "mimeType" to mimeType,
                        "displayName" to displayName,
                        "data" to filePath,
                        "path" to filePath,
                        "relativePath" to relativePath,
                        "volumeName" to volumeName,
                        "composer" to cursor.getNullableString(composerCol),
                        "folder" to folderName(relativePath, filePath),
                        "extension" to extensionFrom(displayName ?: filePath ?: ""),
                        "isMusic" to cursor.getIntOrNull(isMusicCol),
                        "isRingtone" to cursor.getIntOrNull(isRingtoneCol),
                        "isAlarm" to cursor.getIntOrNull(isAlarmCol),
                        "isNotification" to cursor.getIntOrNull(isNotificationCol),
                        "isPodcast" to cursor.getIntOrNull(isPodcastCol)
                    )
                )
            }
        }
    }

    private fun audioProjection(): List<String> {
        val columns = arrayListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.ARTIST_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.COMPOSER,
            MediaStore.Audio.Media.IS_MUSIC,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_PODCAST
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            columns.add(MediaStore.Audio.Media.RELATIVE_PATH)
        }

        return columns.distinct()
    }

    private fun loadArtwork(
        id: Long,
        type: String,
        volumeName: String?,
        size: Int,
        quality: Int,
        format: String,
        result: Result
    ) {
        if (!hasAudioPermission()) {
            result.error("PERMISSION_DENIED", "Audio media permission has not been granted.", null)
            return
        }

        executeMediaOperation(
            result = result,
            rejectedCode = "ARTWORK_REJECTED",
            rejectedMessage = "Artwork load could not be started."
        ) {
            try {
                val bytes = when (type.lowercase()) {
                    TYPE_ALBUM -> loadAlbumArtworkBytes(
                        albumId = id,
                        volumeName = volumeName,
                        size = size,
                        quality = quality,
                        format = format
                    )
                    TYPE_AUDIO -> loadAudioArtworkBytes(
                        mediaStoreId = id,
                        volumeName = volumeName,
                        size = size,
                        quality = quality,
                        format = format
                    )
                    else -> null
                }

                postSuccess(result, bytes)
            } catch (error: SecurityException) {
                postError(
                    result,
                    "PERMISSION_DENIED",
                    error.message ?: "Audio media permission denied.",
                    null
                )
            } catch (_: FileNotFoundException) {
                // Missing artwork is normal for many albums/tracks.
                // Return null quietly instead of polluting logcat with stack traces.
                postSuccess(result, null)
            } catch (error: Throwable) {
                Log.w(
                    LOG_TAG,
                    "loadArtwork failed: ${error.javaClass.simpleName}: ${error.message}"
                )
                postSuccess(result, null)
            }
        }
    }

    private fun loadAudioArtworkBytes(
        mediaStoreId: Long,
        volumeName: String?,
        size: Int,
        quality: Int,
        format: String
    ): ByteArray? {
        val audioUri = ContentUris.withAppendedId(
            audioContentUri(volumeName),
            mediaStoreId
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bitmap = context.contentResolver.loadThumbnail(
                    audioUri,
                    Size(size, size),
                    null
                )
                return bitmap.toBytes(format, quality)
            } catch (_: FileNotFoundException) {
                return null
            } catch (_: Throwable) {
                // Fall through to the album-art lookup for rows whose provider
                // cannot generate an audio thumbnail.
            }
        }

        val albumId = findAlbumIdForAudio(
            mediaStoreId = mediaStoreId,
            volumeName = volumeName
        ) ?: return null

        return loadAlbumArtworkBytes(
            albumId = albumId,
            volumeName = volumeName,
            size = size,
            quality = quality,
            format = format
        )
    }

    private fun loadAlbumArtworkBytes(
        albumId: Long,
        volumeName: String?,
        size: Int,
        quality: Int,
        format: String
    ): ByteArray? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val albumUri = ContentUris.withAppendedId(
                    MediaStore.Audio.Albums.getContentUri(
                        resolvedVolumeName(volumeName)
                    ),
                    albumId
                )
                val bitmap = context.contentResolver.loadThumbnail(
                    albumUri,
                    Size(size, size),
                    null
                )
                return bitmap.toBytes(format, quality)
            } catch (_: Throwable) {
                // Some providers expose album art only through the legacy URI.
            }
        }

        val legacyVolume = if (
            volumeName.equals(MediaStore.VOLUME_INTERNAL, ignoreCase = true) ||
            volumeName.equals("internal", ignoreCase = true)
        ) {
            "internal"
        } else {
            "external"
        }

        val albumArtUri = ContentUris.withAppendedId(
            Uri.parse("content://media/$legacyVolume/audio/albumart"),
            albumId
        )

        return try {
            context.contentResolver.openInputStream(albumArtUri)?.use { stream ->
                val original = BitmapFactory.decodeStream(stream) ?: return null
                val scaled = original.scaleToFit(size)
                scaled.toBytes(format, quality)
            }
        } catch (_: FileNotFoundException) {
            null
        }
    }

    private fun findAlbumIdForAudio(
        mediaStoreId: Long,
        volumeName: String?
    ): Long? {
        val uri = ContentUris.withAppendedId(
            audioContentUri(volumeName),
            mediaStoreId
        )
        val projection = arrayOf(MediaStore.Audio.Media.ALBUM_ID)

        context.contentResolver.query(
            uri,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getLongOrNull(0)
            }
        }

        return null
    }

    private data class AudioCollection(
        val volumeName: String,
        val uri: Uri
    )

    private data class AudioScanTarget(
        val volumeName: String,
        val uri: Uri?,
        val available: Boolean
    )

    private fun audioScanTargets(
        includeInternal: Boolean,
        knownVolumeNames: List<String>
    ): List<AudioScanTarget> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val targets = mutableListOf(
                AudioScanTarget(
                    volumeName = "external_primary",
                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    available = true
                )
            )

            if (includeInternal) {
                targets.add(
                    AudioScanTarget(
                        volumeName = "internal",
                        uri = MediaStore.Audio.Media.INTERNAL_CONTENT_URI,
                        available = true
                    )
                )
            }

            return targets
        }

        val mountedVolumes = MediaStore.getExternalVolumeNames(context)
            .asSequence()
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .toSet()

        val requestedVolumes = linkedSetOf<String>()
        requestedVolumes.addAll(mountedVolumes.sorted())

        for (knownVolume in knownVolumeNames) {
            var normalized = knownVolume.trim().lowercase()
            if (normalized.isEmpty()) continue

            if (normalized == MediaStore.VOLUME_EXTERNAL) {
                normalized = MediaStore.VOLUME_EXTERNAL_PRIMARY
            }

            if (normalized == MediaStore.VOLUME_INTERNAL && !includeInternal) continue
            requestedVolumes.add(normalized)
        }

        if (includeInternal) {
            requestedVolumes.add(MediaStore.VOLUME_INTERNAL)
        }

        if (requestedVolumes.isEmpty()) {
            requestedVolumes.add(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }

        return requestedVolumes.map { volumeName ->
            val isInternal = volumeName == MediaStore.VOLUME_INTERNAL
            val isMounted = isInternal || volumeName in mountedVolumes

            AudioScanTarget(
                volumeName = volumeName,
                uri = if (isMounted) {
                    MediaStore.Audio.Media.getContentUri(volumeName)
                } else {
                    null
                },
                available = isMounted
            )
        }
    }

    private fun externalAudioCollections(): List<AudioCollection> {
        return audioScanTargets(
            includeInternal = false,
            knownVolumeNames = emptyList()
        ).mapNotNull { target ->
            val uri = target.uri ?: return@mapNotNull null
            AudioCollection(target.volumeName, uri)
        }
    }

    private fun internalAudioCollection(): AudioCollection {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            AudioCollection(
                volumeName = MediaStore.VOLUME_INTERNAL,
                uri = MediaStore.Audio.Media.getContentUri(
                    MediaStore.VOLUME_INTERNAL
                )
            )
        } else {
            AudioCollection(
                volumeName = "internal",
                uri = MediaStore.Audio.Media.INTERNAL_CONTENT_URI
            )
        }
    }

    private fun audioContentUri(volumeName: String?): Uri {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return if (volumeName.equals("internal", ignoreCase = true)) {
                MediaStore.Audio.Media.INTERNAL_CONTENT_URI
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }
        }

        return MediaStore.Audio.Media.getContentUri(
            resolvedVolumeName(volumeName)
        )
    }

    private fun resolvedVolumeName(requestedVolumeName: String?): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return if (requestedVolumeName.equals("internal", ignoreCase = true)) {
                MediaStore.VOLUME_INTERNAL
            } else {
                MediaStore.VOLUME_EXTERNAL
            }
        }

        var requested = requestedVolumeName
            ?.trim()
            ?.lowercase()
            .orEmpty()

        if (requested.isEmpty() || requested == MediaStore.VOLUME_EXTERNAL) {
            requested = MediaStore.VOLUME_EXTERNAL_PRIMARY
        }

        if (
            requested == MediaStore.VOLUME_INTERNAL ||
            requested == MediaStore.VOLUME_EXTERNAL_PRIMARY
        ) {
            return requested
        }

        val mountedVolumes = MediaStore.getExternalVolumeNames(context)
            .map { it.trim().lowercase() }
            .toSet()

        if (requested in mountedVolumes) {
            return requested
        }

        throw FileNotFoundException(
            "MediaStore volume is unavailable: $requested"
        )
    }

    private fun folderName(relativePath: String?, filePath: String?): String? {
        val rel = relativePath?.trim('/')?.takeIf { it.isNotBlank() }
        if (rel != null) {
            return rel.substringAfterLast('/', rel)
        }

        val path = filePath?.takeIf { it.isNotBlank() } ?: return null
        return path.substringBeforeLast('/', missingDelimiterValue = "")
            .substringAfterLast('/', missingDelimiterValue = "")
            .takeIf { it.isNotBlank() }
    }

    private fun extensionFrom(name: String): String? {
        val cleanName = name.substringAfterLast('/', name)
        val index = cleanName.lastIndexOf('.')
        if (index < 0 || index == cleanName.lastIndex) return null
        return cleanName.substring(index + 1).lowercase()
    }

    private fun String?.cleanUnknown(fallback: String): String {
        val value = this?.trim().orEmpty()
        return if (value.isBlank() || value.equals("<unknown>", ignoreCase = true)) {
            fallback
        } else {
            value
        }
    }

    private fun android.database.Cursor.getNullableString(index: Int): String? {
        if (index < 0 || isNull(index)) return null
        return getString(index)
    }

    private fun android.database.Cursor.getLongOrNull(index: Int): Long? {
        if (index < 0 || isNull(index)) return null
        return getLong(index)
    }

    private fun android.database.Cursor.getIntOrNull(index: Int): Int? {
        if (index < 0 || isNull(index)) return null
        return getInt(index)
    }

    private fun Bitmap.scaleToFit(maxSize: Int): Bitmap {
        if (width <= maxSize && height <= maxSize) return this

        val ratio = minOf(maxSize.toFloat() / width.toFloat(), maxSize.toFloat() / height.toFloat())
        val targetWidth = (width * ratio).toInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).toInt().coerceAtLeast(1)

        return Bitmap.createScaledBitmap(this, targetWidth, targetHeight, true)
    }

    private fun Bitmap.toBytes(format: String, quality: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val compressFormat = if (format.equals("png", ignoreCase = true)) {
            Bitmap.CompressFormat.PNG
        } else {
            Bitmap.CompressFormat.JPEG
        }

        compress(compressFormat, quality, output)
        return output.toByteArray()
    }

    override fun cleanup() {
        cleanedUp = true

        try {
            channel.setMethodCallHandler(null)
        } catch (_: UninitializedPropertyAccessException) {
            // register() was never called, so there is no MethodChannel to detach.
        }

        mediaExecutor.shutdownNow()
    }
}
