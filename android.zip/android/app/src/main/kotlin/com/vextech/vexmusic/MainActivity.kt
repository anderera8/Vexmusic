// android/app/src/main/kotlin/com/vextech/vexmusic/MainActivity.kt
package com.vextech.vexmusic

import android.content.Intent
import com.ryanheise.audioservice.AudioServiceActivity
import com.vextech.vexmusic.handlers.*
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : AudioServiceActivity() {

    // Initialize handlers immediately, not in onCreate.
    // This ensures they are ready when configureFlutterEngine is called.
    private val fileHandler = FileOperationHandler(this)
    private val mediaObserver = MediaStoreObserver(this)
    private val widgetHandler = WidgetHandler(this)
    private val audioEffectsHandler = AudioEffectsHandler(this)
    private val spectrumCaptureHandler = SpectrumCaptureHandler()
    private val mediaLibraryHandler = MediaLibraryHandler(this)

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        widgetHandler.register(flutterEngine)
        fileHandler.register(flutterEngine)
        mediaObserver.register(flutterEngine)
        audioEffectsHandler.register(flutterEngine)
        spectrumCaptureHandler.register(flutterEngine)
        mediaLibraryHandler.register(flutterEngine)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fileHandler.onActivityResult(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        mediaObserver.cleanup()
        fileHandler.cleanup()
        audioEffectsHandler.cleanup()
        spectrumCaptureHandler.cleanup()
        mediaLibraryHandler.cleanup()
        super.onDestroy()
    }
}
