package com.vextech.vexmusic.dsp

/** Process-scoped bridge between the renderer factory and Flutter handler. */
object SoftwareEqProcessorHolder {
    val instance: SoftwareEqProcessor by lazy { SoftwareEqProcessor() }

    @Volatile
    private var rendererAttached = false

    fun markRendererAttached() {
        rendererAttached = true
    }

    fun isRendererAttached(): Boolean = rendererAttached
}
