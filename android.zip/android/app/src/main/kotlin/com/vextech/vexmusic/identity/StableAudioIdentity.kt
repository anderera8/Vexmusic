package com.vextech.vexmusic.identity

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.text.Normalizer
import java.util.ArrayDeque
import java.util.Locale

/**
 * Builds the app's Android audio identity from immutable storage location data.
 *
 * MediaStore row IDs, duration, file size, timestamps, and editable metadata are
 * deliberately excluded. Those values can change when Android reindexes a file
 * or when the user edits tags or embedded artwork.
 *
 * The preferred input is [relativePath] plus [displayName] within an actual
 * MediaStore [volumeName]. [absolutePath] is retained only as a compatibility
 * fallback for devices or rows that do not expose a relative path.
 */
object StableAudioIdentity {
    private const val VERSION_PREFIX = "audio-path-v2:"
    private const val HASH_ALGORITHM = "SHA-256"
    private const val MATERIAL_VERSION = "audio-path-v2"

    private val hexDigits = "0123456789abcdef".toCharArray()

    /**
     * Returns a versioned SHA-256 identity, or an empty string when the row does
     * not contain enough location information to produce an unambiguous key.
     */
    @JvmStatic
    fun fromMediaStore(
        volumeName: String?,
        absolutePath: String?,
        relativePath: String?,
        displayName: String?
    ): String {
        val volume = normalizeVolumeName(volumeName)
        if (volume.isEmpty()) return ""

        val location = preferredLocation(
            absolutePath = absolutePath,
            relativePath = relativePath,
            displayName = displayName
        )
        if (location.isEmpty()) return ""

        val material = buildString {
            append(MATERIAL_VERSION)
            append('\u0000')
            append(volume)
            append('\u0000')
            append(location)
        }

        return VERSION_PREFIX + sha256Hex(material)
    }

    private fun preferredLocation(
        absolutePath: String?,
        relativePath: String?,
        displayName: String?
    ): String {
        val fileName = normalizeFileName(displayName)
        if (fileName.isNotEmpty() && relativePath != null) {
            val directory = normalizePath(relativePath, absolute = false)
            return if (directory.isEmpty()) {
                fileName
            } else {
                "$directory/$fileName"
            }
        }

        return normalizePath(absolutePath, absolute = true)
    }

    private fun normalizeVolumeName(value: String?): String {
        return normalizeUnicode(value)
            .trim()
            .lowercase(Locale.ROOT)
    }

    private fun normalizeFileName(value: String?): String {
        val normalized = normalizeUnicode(value)
            .trim()
            .replace('\\', '/')
            .substringAfterLast('/')

        return when (normalized) {
            "", ".", ".." -> ""
            else -> normalized
        }
    }

    private fun normalizePath(value: String?, absolute: Boolean): String {
        val raw = normalizeUnicode(value)
            .trim()
            .replace('\\', '/')

        if (raw.isEmpty()) return ""

        val segments = ArrayDeque<String>()

        for (segment in raw.split('/')) {
            when {
                segment.isEmpty() || segment == "." -> Unit
                segment == ".." -> {
                    if (segments.isNotEmpty()) {
                        segments.removeLast()
                    } else if (!absolute) {
                        // A relative path escaping its volume root is ambiguous.
                        return ""
                    }
                }
                else -> segments.addLast(segment)
            }
        }

        if (segments.isEmpty()) return ""

        val joined = segments.joinToString("/")
        return if (absolute) "/$joined" else joined
    }

    private fun normalizeUnicode(value: String?): String {
        val safe = value ?: return ""
        return Normalizer.normalize(safe, Normalizer.Form.NFC)
    }

    private fun sha256Hex(value: String): String {
        val digest = MessageDigest.getInstance(HASH_ALGORITHM)
            .digest(value.toByteArray(StandardCharsets.UTF_8))

        val output = CharArray(digest.size * 2)
        var outputIndex = 0

        for (byte in digest) {
            val unsigned = byte.toInt() and 0xff
            output[outputIndex++] = hexDigits[unsigned ushr 4]
            output[outputIndex++] = hexDigits[unsigned and 0x0f]
        }

        return String(output)
    }
}
