package com.vextech.vexmusic.audioformat

import java.io.InputStream

/**
 * The real container/codec of an audio file, established by inspecting its
 * bytes rather than trusting a filename extension, a caller-supplied
 * "format" string, or a MediaStore MIME type.
 *
 * `content://` sources frequently carry no usable extension at all, and a
 * MIME type can be stale, generic (`application/octet-stream`), or simply
 * wrong for files that were copied/renamed outside MediaStore's own
 * scanner. None of those signals are byte-verified. This is.
 */
enum class SniffedContainer {
    MP3,

    /** ISO-BMFF / QuickTime family: mp4, m4a, m4b, m4p, ... */
    MP4_FAMILY,

    /** Native (non-Ogg) FLAC: starts with the 4-byte "fLaC" signature. */
    FLAC_NATIVE,

    /** Ogg container carrying a Vorbis I audio stream. */
    OGG_VORBIS,

    /** Ogg container carrying an Opus audio stream (RFC 7845). */
    OGG_OPUS,

    /** Ogg container carrying a FLAC stream via the Ogg-FLAC mapping. */
    OGG_FLAC,

    /** A recognized "OggS" page whose inner codec packet isn't recognized. */
    OGG_UNKNOWN_CODEC,

    /** RIFF/WAVE. */
    WAV,

    /** The header didn't match anything this sniffer knows about. */
    UNKNOWN
}

/**
 * Result of sniffing a stream's leading bytes, including the specific MP4
 * brand (e.g. "M4A ", "isom") when [container] is [SniffedContainer.MP4_FAMILY],
 * since that brand is what downstream code uses to pick a filename suffix.
 */
data class SniffResult(
    val container: SniffedContainer,
    val mp4Brand: String? = null
) {
    val isRecognized: Boolean get() = container != SniffedContainer.UNKNOWN
}

/**
 * Reads a bounded header from a stream and classifies the real container
 * and, for Ogg, the real inner codec.
 *
 * This never trusts a filename or a caller-supplied format string. It reads
 * bytes and matches them against the format specifications:
 *  - MP3: "ID3" (ID3v2 tag) or an MPEG frame sync (0xFF + top 3 bits set)
 *  - MP4 family: "ftyp" box at offset 4, brand read from offset 8
 *  - Native FLAC: "fLaC" at offset 0
 *  - Ogg: "OggS" page header at offset 0; inner codec identified from the
 *    first packet's payload, which begins after the fixed 27-byte page
 *    header plus the per-page segment table (whose length is the segment
 *    count byte at page-header offset 26):
 *      - "OpusHead"            -> Opus            (RFC 7845 §5.1)
 *      - 0x01 + "vorbis"       -> Vorbis           (Vorbis I spec §4.2.2)
 *      - 0x7F + "FLAC"         -> Ogg-mapped FLAC  (xiph.org FLAC Ogg Mapping)
 *  - WAV: "RIFF" at offset 0, "WAVE" at offset 8
 */
object AudioContainerSniffer {

    // Read enough to cover the largest header we inspect: an Ogg page can
    // legally carry up to 255 segments of up to 255 bytes each in its
    // segment table alone, before the first packet's payload even starts.
    private const val HEADER_READ_BYTES = 65536

    private val ID3 = byteArrayOf(0x49, 0x44, 0x33) // "ID3"
    private val FTYP = byteArrayOf(0x66, 0x74, 0x79, 0x70) // "ftyp"
    private val FLAC_NATIVE_MAGIC = byteArrayOf(0x66, 0x4C, 0x61, 0x43) // "fLaC"
    private val OGGS = byteArrayOf(0x4F, 0x67, 0x67, 0x53) // "OggS"
    private val RIFF = byteArrayOf(0x52, 0x49, 0x46, 0x46) // "RIFF"
    private val WAVE = byteArrayOf(0x57, 0x41, 0x56, 0x45) // "WAVE"

    private val OPUS_HEAD = "OpusHead".toByteArray(Charsets.US_ASCII)
    private val VORBIS_TAIL = "vorbis".toByteArray(Charsets.US_ASCII)
    private val OGG_FLAC_TAIL = "FLAC".toByteArray(Charsets.US_ASCII)

    fun sniff(input: InputStream): SniffResult {
        val header = readBounded(input, HEADER_READ_BYTES)
        return sniff(header)
    }

    fun sniff(header: ByteArray): SniffResult {
        if (header.isEmpty()) {
            return SniffResult(SniffedContainer.UNKNOWN)
        }

        if (matches(header, 0, RIFF) && matches(header, 8, WAVE)) {
            return SniffResult(SniffedContainer.WAV)
        }

        if (matches(header, 0, FLAC_NATIVE_MAGIC)) {
            return SniffResult(SniffedContainer.FLAC_NATIVE)
        }

        if (matches(header, 4, FTYP)) {
            val brand = readAscii(header, 8, 4)
            return SniffResult(SniffedContainer.MP4_FAMILY, mp4Brand = brand)
        }

        if (matches(header, 0, OGGS)) {
            return sniffOgg(header)
        }

        if (matches(header, 0, ID3) || looksLikeMp3FrameSync(header)) {
            return SniffResult(SniffedContainer.MP3)
        }

        return SniffResult(SniffedContainer.UNKNOWN)
    }

    /**
     * An Ogg page header is 27 fixed bytes followed by a segment table whose
     * length is the "number of page segments" byte at offset 26. The first
     * packet's payload starts immediately after that table. This walks the
     * real header layout rather than guessing a fixed offset, since a small
     * first page (as every one of these identification pages legally is)
     * still has a variable-length segment table ahead of the payload.
     */
    private fun sniffOgg(header: ByteArray): SniffResult {
        if (header.size < 27) {
            return SniffResult(SniffedContainer.OGG_UNKNOWN_CODEC)
        }

        val segmentCount = header[26].toInt() and 0xFF
        val payloadStart = 27 + segmentCount

        if (header.size < payloadStart) {
            return SniffResult(SniffedContainer.OGG_UNKNOWN_CODEC)
        }

        if (matches(header, payloadStart, OPUS_HEAD)) {
            return SniffResult(SniffedContainer.OGG_OPUS)
        }

        // Vorbis identification header: 1-byte packet type (0x01) + "vorbis".
        if (payloadStart < header.size &&
            header[payloadStart] == 0x01.toByte() &&
            matches(header, payloadStart + 1, VORBIS_TAIL)
        ) {
            return SniffResult(SniffedContainer.OGG_VORBIS)
        }

        // Ogg-mapped FLAC: 1-byte packet type (0x7F) + "FLAC".
        if (payloadStart < header.size &&
            header[payloadStart] == 0x7F.toByte() &&
            matches(header, payloadStart + 1, OGG_FLAC_TAIL)
        ) {
            return SniffResult(SniffedContainer.OGG_FLAC)
        }

        return SniffResult(SniffedContainer.OGG_UNKNOWN_CODEC)
    }

    /**
     * A raw MPEG audio frame sync: 11 set bits at the top of a 2-byte word
     * (0xFFE0 mask). This is a weaker signal than "ID3" since sync-like bit
     * patterns can theoretically occur by chance, so it is only consulted
     * when nothing else in [sniff] matched first.
     */
    private fun looksLikeMp3FrameSync(header: ByteArray): Boolean {
        if (header.size < 2) return false
        val first = header[0].toInt() and 0xFF
        val second = header[1].toInt() and 0xFF
        return first == 0xFF && (second and 0xE0) == 0xE0
    }

    private fun matches(
        buffer: ByteArray,
        offset: Int,
        signature: ByteArray
    ): Boolean {
        if (offset < 0 || offset + signature.size > buffer.size) return false
        for (i in signature.indices) {
            if (buffer[offset + i] != signature[i]) return false
        }
        return true
    }

    private fun readAscii(buffer: ByteArray, offset: Int, length: Int): String? {
        if (offset < 0 || offset + length > buffer.size) return null
        return String(buffer, offset, length, Charsets.US_ASCII)
    }

    private fun readBounded(input: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(maxBytes)
        var total = 0

        while (total < maxBytes) {
            val read = input.read(buffer, total, maxBytes - total)
            if (read < 0) break
            total += read
        }

        return if (total == buffer.size) buffer else buffer.copyOf(total)
    }
}
