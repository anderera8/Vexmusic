package com.vextech.vexmusic

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.view.KeyEvent
import android.widget.RemoteViews
import java.io.File

/**
 * Home-screen widget that shows the currently playing track
 * (or a placeholder when nothing is playing).
 *
 * The widget is updated via [updateWidget] which is called from
 * [MainActivity] when the Flutter side sends track metadata through
 * the audio_service notification or a dedicated MethodChannel.
 */
class VibesPlayerWidget : AppWidgetProvider() {

    companion object {
        private const val ACTION_PLAY_PAUSE = "com.vextech.vexmusic.WIDGET_PLAY_PAUSE"
        private const val ACTION_PREVIOUS = "com.vextech.vexmusic.WIDGET_PREVIOUS"
        private const val ACTION_NEXT = "com.vextech.vexmusic.WIDGET_NEXT"
        private const val EXTRA_WIDGET_IDS = "widget_ids"

        /**
         * Updates all widget instances with the given track info.
         * Call from [MainActivity] when playback state changes.
         */
        fun updateWidget(
            context: Context,
            title: String?,
            artist: String?,
            artworkPath: String?,
            isPlaying: Boolean
        ) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, VibesPlayerWidget::class.java)
            )
            if (ids.isEmpty()) return

            val views = RemoteViews(context.packageName, R.layout.vibes_player_widget)

            val artwork = artworkPath
                ?.takeIf { it.isNotBlank() && File(it).isFile }
                ?.let(BitmapFactory::decodeFile)
            if (artwork != null) {
                val size = (64 * context.resources.displayMetrics.density).toInt()
                val scaled = android.graphics.Bitmap.createScaledBitmap(
                    artwork,
                    size,
                    size,
                    true
                )
                views.setImageViewBitmap(R.id.widget_icon, scaled)
                if (scaled !== artwork) artwork.recycle()
            } else {
                views.setImageViewResource(R.id.widget_icon, R.mipmap.ic_launcher)
            }

            // Track info
            if (title != null && title.isNotEmpty()) {
                views.setTextViewText(R.id.widget_title, title)
                views.setTextViewText(R.id.widget_artist, artist ?: "")
            } else {
                views.setTextViewText(R.id.widget_title,
                    context.getString(R.string.widget_placeholder_title))
                views.setTextViewText(R.id.widget_artist,
                    context.getString(R.string.widget_placeholder_artist))
            }

            // Play/pause icon
            views.setImageViewResource(
                R.id.widget_play_pause,
                if (isPlaying) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )
            views.setContentDescription(
                R.id.widget_play_pause,
                if (isPlaying) context.getString(R.string.widget_pause_desc)
                else context.getString(R.string.widget_play_desc)
            )

            // Play/pause click → broadcast to widget, then forwarded to app
            val playIntent = Intent(context, VibesPlayerWidget::class.java).apply {
                action = ACTION_PLAY_PAUSE
                putExtra(EXTRA_WIDGET_IDS, ids)
            }
            val playPending = PendingIntent.getBroadcast(
                context, 0, playIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_play_pause, playPending)

            views.setOnClickPendingIntent(
                R.id.widget_previous,
                controlPendingIntent(context, ACTION_PREVIOUS, ids, 2)
            )
            views.setOnClickPendingIntent(
                R.id.widget_next,
                controlPendingIntent(context, ACTION_NEXT, ids, 3)
            )

            // Tapping the widget body opens the app
            val openIntent = context.packageManager
                .getLaunchIntentForPackage(context.packageName)
            if (openIntent != null) {
                val openPending = PendingIntent.getActivity(
                    context, 1, openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_icon, openPending)
                views.setOnClickPendingIntent(R.id.widget_title, openPending)
                views.setOnClickPendingIntent(R.id.widget_artist, openPending)
            }

            manager.updateAppWidget(ids, views)
        }

        private fun controlPendingIntent(
            context: Context,
            action: String,
            ids: IntArray,
            requestCode: Int
        ): PendingIntent {
            val intent = Intent(context, VibesPlayerWidget::class.java).apply {
                this.action = action
                putExtra(EXTRA_WIDGET_IDS, ids)
            }
            return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    override fun onUpdate(
        context: Context,
        manager: AppWidgetManager,
        widgetIds: IntArray
    ) {
        // Initial placement — show placeholder
        updateWidget(context, null, null, null, false)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val keyCode = when (intent.action) {
            ACTION_PLAY_PAUSE -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            ACTION_PREVIOUS -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            ACTION_NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> null
        }
        if (keyCode != null) {
            val mediaIntent = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                setClassName(
                    context,
                    "com.ryanheise.audioservice.MediaButtonReceiver"
                )
                putExtra(
                    Intent.EXTRA_KEY_EVENT,
                    KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
                )
            }
            context.sendBroadcast(mediaIntent)
        }
    }
}
