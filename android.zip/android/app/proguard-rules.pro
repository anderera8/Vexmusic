# ── Flutter ──────────────────────────────────────────────────────────────────
-keep class io.flutter.** { *; }
-dontwarn io.flutter.**

# ── Flutter plugin/native callback safety ────────────────────────────────────
-keepclasseswithmembernames class * {
    native <methods>;
}

# ── Audio Service ───────────────────────────────────────────────────────────
-keep class com.ryanheise.audio_service.** { *; }
-dontwarn com.ryanheise.audio_service.**

# ── just_audio ──────────────────────────────────────────────────────────────
-keep class com.ryanheise.just_audio.** { *; }
-dontwarn com.ryanheise.just_audio.**

# ── Audio Session ───────────────────────────────────────────────────────────
-keep class com.ryanheise.audio_session.** { *; }
-dontwarn com.ryanheise.audio_session.**


# ── Permission Handler ──────────────────────────────────────────────────────
-keep class com.baseflow.permissionhandler.** { *; }
-dontwarn com.baseflow.permissionhandler.**

# ── Share Plus ──────────────────────────────────────────────────────────────
-keep class dev.fluttercommunity.plus.share.** { *; }
-dontwarn dev.fluttercommunity.plus.share.**

# ── Sqflite ─────────────────────────────────────────────────────────────────
-keep class com.tekartik.sqflite.** { *; }
-dontwarn com.tekartik.sqflite.**

# ── Firebase ────────────────────────────────────────────────────────────────
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# ── dynamic_color ───────────────────────────────────────────────────────────
-keep class dev.jamesclarke.dynamic_color.** { *; }
-dontwarn dev.jamesclarke.dynamic_color.**

# ── url_launcher ────────────────────────────────────────────────────────────
-keep class io.flutter.plugins.urllauncher.** { *; }
-dontwarn io.flutter.plugins.urllauncher.**

# ── shared_preferences ──────────────────────────────────────────────────────
-keep class io.flutter.plugins.sharedpreferences.** { *; }
-dontwarn io.flutter.plugins.sharedpreferences.**

# ── path_provider ───────────────────────────────────────────────────────────
-keep class io.flutter.plugins.pathprovider.** { *; }
-dontwarn io.flutter.plugins.pathprovider.**

# ── file_picker ─────────────────────────────────────────────────────────────
-keep class com.mr.flutter.plugin.filepicker.** { *; }
-dontwarn com.mr.flutter.plugin.filepicker.**

# ── VexMusic: App Widget ────────────────────────────────────────────────────
# Instantiated by AppWidgetManager / Android framework.
-keep class com.vextech.vexmusic.VibesPlayerWidget { *; }

# ── VexMusic: Native handlers ───────────────────────────────────────────────
# Keep MethodChannel/EventChannel handlers registered from MainActivity.
-keep class com.vextech.vexmusic.MainActivity { *; }
-keep class com.vextech.vexmusic.handlers.** { *; }

# ── VexMusic: Software EQ DSP ───────────────────────────────────────────────
# SoftwareEqRendererFactory is referenced by fully-qualified class name in
# res/values/just_audio_config.xml and loaded reflectively by just_audio.
-keep class com.vextech.vexmusic.dsp.SoftwareEqRendererFactory { *; }
-keep class com.vextech.vexmusic.dsp.SoftwareEqProcessorHolder { *; }
-keep class com.vextech.vexmusic.dsp.SoftwareEqProcessor { *; }
-keep class com.vextech.vexmusic.dsp.SoftwareEqProcessor$SpectrumListener { *; }
-keep class com.vextech.vexmusic.dsp.** { *; }

# ── Jaudiotagger ─────────────────────────────────────────────────────────────
# Jaudiotagger contains optional desktop Java image APIs that Android does not
# provide. Android release builds fail R8 unless these missing desktop APIs are
# suppressed. The app does not call these desktop image APIs.
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**

-dontwarn java.awt.**
-dontwarn java.awt.image.**
-dontwarn javax.imageio.**
-dontwarn javax.imageio.stream.**

# ── ExoPlayer / Media3 ──────────────────────────────────────────────────────
# Used by just_audio and your software EQ DSP stack.
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# ── AndroidX / Kotlin harmless warnings ─────────────────────────────────────
-dontwarn kotlin.Unit
-dontwarn kotlinx.coroutines.**
-dontwarn org.jetbrains.annotations.**

# ── General Android / reflection metadata ───────────────────────────────────
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception

# ── Production logging hygiene ──────────────────────────────────────────────
# Strip debug-level native Android logs in release builds.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}