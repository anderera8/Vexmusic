import org.gradle.api.GradleException
import java.util.Properties

plugins {
    id("com.android.application")

    // START: FlutterFire Configuration
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    // END: FlutterFire Configuration
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.vextech.vexmusic"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }

    defaultConfig {
        applicationId = "com.vextech.vexmusic"
        minSdk = 24
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName

        // Do not set ndk abiFilters here.
        // Flutter handles APK ABI splitting through:
        // flutter build apk --split-per-abi --target-platform=android-arm,android-arm64
    }

    signingConfigs {
        create("release") {
            val propsFile = rootProject.file("key.properties")

            if (propsFile.exists()) {
                val props = Properties()
                props.load(propsFile.inputStream())

                storeFile = file(props.getProperty("storeFile"))
                storePassword = props.getProperty("storePassword")
                keyAlias = props.getProperty("keyAlias")
                keyPassword = props.getProperty("keyPassword")
            } else if (
                System.getenv("VEXMUSIC_STORE_FILE") != null &&
                System.getenv("VEXMUSIC_STORE_PASSWORD") != null &&
                System.getenv("VEXMUSIC_KEY_ALIAS") != null &&
                System.getenv("VEXMUSIC_KEY_PASSWORD") != null
            ) {
                storeFile = file(System.getenv("VEXMUSIC_STORE_FILE"))
                storePassword = System.getenv("VEXMUSIC_STORE_PASSWORD")
                keyAlias = System.getenv("VEXMUSIC_KEY_ALIAS")
                keyPassword = System.getenv("VEXMUSIC_KEY_PASSWORD")
            } else {
                val releaseRequested = gradle.startParameter.taskNames.any {
                    it.contains("release", ignoreCase = true)
                }

                if (releaseRequested) {
                    throw GradleException(
                        "Release signing credentials are missing. Configure " +
                            "android/key.properties or the VEXMUSIC_STORE_FILE, " +
                            "VEXMUSIC_STORE_PASSWORD, VEXMUSIC_KEY_ALIAS, and " +
                            "VEXMUSIC_KEY_PASSWORD environment variables."
                    )
                }
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    // ── Audio metadata / artwork editing ─────────────────────────────────
    implementation("net.jthink:jaudiotagger:3.0.1")

    // ── Media3 / ExoPlayer for software equalizer DSP ───────────────────
    implementation("androidx.media3:media3-common:1.5.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-decoder:1.5.1")
    implementation("androidx.media3:media3-extractor:1.5.1")
}

flutter {
    source = "../.."
}